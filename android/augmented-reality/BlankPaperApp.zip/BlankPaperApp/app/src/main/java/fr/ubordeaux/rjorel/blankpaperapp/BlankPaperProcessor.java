package fr.ubordeaux.rjorel.blankpaperapp;

import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;


/**
 * Created by Cindy BECHER & Alexandre FORTUNA on 03/03/2017.
 * Cette classe est librement inspirée d'un code d'application scanner
 * trouvé à cette adresse : https://github.com/ctodobom/OpenNoteScanner
 */
class BlankPaperProcessor {
    private static final int NB_POINT_IN_QUAD = 4;

    private Mat processedFrame;
    private Mat storedImage;


    // Quadrilateral is an object that allow us to stock the contours of
    // a quadrilateral and its four corners
    private class Quadrilateral{
        public MatOfPoint contour;
        public Point[] points;

        public Quadrilateral(MatOfPoint contour, Point[] points) {
            this.contour = contour;
            this.points = points;
        }
    }


    public BlankPaperProcessor(Mat storedImage) {
        this.storedImage = storedImage;
    }

    //Method called by CameraController -> find white paper and wrapped the image
    public Mat process(Mat frame) {
        processedFrame = frame;
        findWhitePaper(processedFrame);

        return processedFrame;
    }

    // Look at all the contours in <contours> from bigger to smaller and try to detect a qualidrateral
    // in it by calling approxPolyDP() from OpenCV. This function returns when one is found.
    private Quadrilateral getQuadrilateral(ArrayList<MatOfPoint> contours , Size srcSize) {
        for (MatOfPoint c: contours) {
            MatOfPoint2f c2f = new MatOfPoint2f(c.toArray());
            double peri = Imgproc.arcLength(c2f, true);
            MatOfPoint2f approx = new MatOfPoint2f();
            Imgproc.approxPolyDP(c2f, approx, 0.02 * peri, true);

            Point[] points = approx.toArray();

            // select biggest 4 angles polygon
            if (points.length == NB_POINT_IN_QUAD) {
                Point[] foundPoints = sortPoints(points);

                if (insideArea(foundPoints, srcSize))
                    return new Quadrilateral( c , foundPoints );
            }
        }

        return null;
    }

    private boolean insideArea(Point[] rp, Size size) {
        int width = Double.valueOf(size.width).intValue();
        int height = Double.valueOf(size.height).intValue();
        int baseMeasure = height / NB_POINT_IN_QUAD;

        int bottomPos = height - baseMeasure;
        int topPos = baseMeasure;
        int leftPos = width / 2 - baseMeasure;
        int rightPos = width / 2 + baseMeasure;

        return rp[0].x <= leftPos && rp[0].y <= topPos
                && rp[1].x >= rightPos && rp[1].y <= topPos
                && rp[2].x >= rightPos && rp[2].y >= bottomPos
                && rp[3].x <= leftPos && rp[3].y >= bottomPos;
    }

    // This function returns an array of 4 points which are the corners
    // of the Quadrilateral in this order :
    // top-left, top-right, bottom-right, bottom-left
    private Point[] sortPoints( Point[] src ) {
        ArrayList<Point> srcPoints = new ArrayList<>(Arrays.asList(src));
        Point[] result = { null , null , null , null };
        Comparator<Point> sumComparator = new Comparator<Point>() {
            @Override
            public int compare(Point lhs, Point rhs) {
                return Double.valueOf(lhs.y + lhs.x).compareTo(rhs.y + rhs.x);
            }
        };
        Comparator<Point> diffComparator = new Comparator<Point>() {

            @Override
            public int compare(Point lhs, Point rhs) {
                return Double.valueOf(lhs.y - lhs.x).compareTo(rhs.y - rhs.x);
            }
        };
        // top-left corner = minimal sum
        result[0] = Collections.min(srcPoints, sumComparator);
        // bottom-right corner = maximal sum
        result[2] = Collections.max(srcPoints, sumComparator);
        // top-right corner = minimal diference
        result[1] = Collections.min(srcPoints, diffComparator);
        // bottom-left corner = maximal diference
        result[3] = Collections.max(srcPoints, diffComparator);
        return result;
    }

    // Finds the contours and  tries to detect a quadrilateral from them.
    // If found, detects corners and computes the transformation that
    // transforms the  4 corners of the image we want to project and
    // the 4 corners of the sheet of paper. And then, applies the transformation
    // to the image.
    public void findWhitePaper(Mat image) {
        ArrayList<MatOfPoint> contours = findContours(image);
        Quadrilateral quad = getQuadrilateral(contours, image.size());

        if (quad != null) {
            Point[] p = quad.points;

            Mat srcMat = new Mat(NB_POINT_IN_QUAD, 1, CvType.CV_32FC2);
            Mat dstMat = new Mat(NB_POINT_IN_QUAD, 1, CvType.CV_32FC2);

            srcMat.put(
                    0, 0,
                    0.0, 0.0,
                    storedImage.width(), 0.0,
                    storedImage.width(), storedImage.height(),
                    0.0, storedImage.height()
            );

            dstMat.put(
                    0, 0,
                    p[0].x, p[0].y,
                    p[1].x, p[1].y,
                    p[2].x, p[2].y,
                    p[3].x, p[3].y
            );

            //Warp process
            Mat warpedFrame = new Mat();
            Mat perspectiveTransform = Imgproc.getPerspectiveTransform(srcMat, dstMat);
            Imgproc.warpPerspective(storedImage, warpedFrame, perspectiveTransform, new Size(processedFrame.width(), processedFrame.height()));

            warpedFrame.copyTo(processedFrame, warpedFrame);
        }
    }

    // Converts the image in gray scales and applies the Canny filter
    // on it and then calls the findcontours() function from OpenCV.
    private ArrayList<MatOfPoint>  findContours(Mat src) {
        Mat grayImage = new Mat(src.size(), CvType.CV_8UC4);
        Mat cannedImage = new Mat(src.size(), CvType.CV_8UC1);

        //Pre-treatment in order to have a cleaned-contour
        Imgproc.cvtColor(src, grayImage, Imgproc.COLOR_RGBA2GRAY, 4);
        Imgproc.Canny(grayImage, cannedImage, 75, 200);

        ArrayList<MatOfPoint> contours = new ArrayList<>();
        Mat hierarchy = new Mat();

        Imgproc.findContours(cannedImage, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
        hierarchy.release();

        Collections.sort(contours, new Comparator<MatOfPoint>() {
            @Override
            public int compare(MatOfPoint lhs, MatOfPoint rhs) {
                return Double.valueOf(Imgproc.contourArea(rhs)).compareTo(Imgproc.contourArea(lhs));
            }
        });

        grayImage.release();
        cannedImage.release();

        return contours;
    }

}
