package fr.ubordeaux.rjorel.blankpaperapp;

import android.content.Context;

import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.io.IOException;
import java.util.ArrayList;

import static org.opencv.imgcodecs.Imgcodecs.CV_LOAD_IMAGE_COLOR;


/**
 * A class in respect of the MVC pattern. It takes frames and call QR Code processing on them.
 */
public class CameraController implements CameraBridgeViewBase.CvCameraViewListener2 {
    private static final String TAG = "CameraController";

    private Context context;
    private BlankPaperProcessor mProcessor;


    CameraController(Context ctx) {
        this.context = ctx;

    }

    @Override
    public void onCameraViewStarted(int width, int height) {
        Mat picture = new Mat();
        try {
            picture = Utils.loadResource(context, R.drawable.animals, CV_LOAD_IMAGE_COLOR);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //We convert the image stocked in order to put it into 4 channels (RGBA)
        Mat converted = new Mat(picture.height(), picture.width(), CvType.CV_8UC4);
        Imgproc.cvtColor(picture, converted, Imgproc.COLOR_RGB2RGBA);

        mProcessor = new BlankPaperProcessor(converted);
        picture.release();
    }

    @Override
    public void onCameraViewStopped() {

    }

    @Override
    public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {
        return mProcessor.process(inputFrame.rgba());
    }
}