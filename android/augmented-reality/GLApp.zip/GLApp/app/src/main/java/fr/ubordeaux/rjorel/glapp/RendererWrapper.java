package fr.ubordeaux.rjorel.glapp;

import android.content.res.AssetManager;
import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;


/**
 * A simple class to wrap native function.
 */
class RendererWrapper implements GLSurfaceView.Renderer {
    static {
        System.loadLibrary("wrapper");
    }

    // Information to access assets in native code.
    private AssetManager assetManager;


    public RendererWrapper(AssetManager assetManager) {
        this.assetManager = assetManager;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        nativeSurfaceCreated(assetManager);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        nativeSurfaceChanged(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
         nativeDrawFrame();
    }


    /**
     * Native functions.
     */
    private native void nativeSurfaceCreated(AssetManager assetManager);
    private native void nativeSurfaceChanged(int width, int height);
    private native void nativeDrawFrame();
}
