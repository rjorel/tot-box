package fr.ubordeaux.rjorel.glapp;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


public class UrlReader {
    // Stream to read data.
    private InputStream stream = null;


    /**
     * Set object from an URL.
     * @param urlStr    - The URL to access.
     */
    public void openUrl(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

            stream = new BufferedInputStream(urlConnection.getInputStream());
        }
        catch (IOException e) {
            stream = null;
        }
    }

    /**
     * Read the stream and cast the output to string.
     * @param length    - Number of characters to read.
     * @return string.
     */
    public String read(int length) {
        StringBuilder builder = new StringBuilder(length);

        try {
            int c, offset = 0;
            while (offset++ < length && (c = stream.read()) != -1)
                builder.append((char) c);
        }
        catch (IOException e) {
            return "";
        }

        return builder.toString();
    }
}
