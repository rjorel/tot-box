#include <sstream>

#include "Mesh.h"


/**
 * Builder
 */
Mesh::Mesh() : m_isReady(false) {

}

/**
 * Get data from an OBJ file and fill up mesh structures.
 * @param assetManager  - Android asset manager, assumed to allow file access in assets/ folder.
 * @param filename      - OBJ file to read.
 */
void Mesh::readFromOBJFile(AAssetManager *manager, const char *filename) {
    AAsset *asset = AAssetManager_open(manager, filename, AASSET_MODE_UNKNOWN);

    if (asset == NULL) return;

    char buf[BUFSIZ];
    while (getLineFromFile(asset, buf, BUFSIZ))
        addData(buf);

    // Don't forget to close the asset.
    AAsset_close(asset);
}

void Mesh::readFromUrlReader(UrlReaderWrapper &urlReader) {
    while (!urlReader.eof())
        addData(urlReader.getLine());
}

/**
 * Display the mesh with the given program.
 * @param program   - program to use for displaying.
 */
void Mesh::display(const ShaderProgram &program) {
    if (!m_isReady) init();

    GLuint vertexAttribute = program.getAttribLocation("vertexPosition");

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_indexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, m_vertexBuffer);

    // Enable the vertex buffer.
    glEnableVertexAttribArray(vertexAttribute);
    glVertexAttribPointer(vertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, (void *) 0);

    glDrawElements(GL_TRIANGLES, (GLsizei) m_indices.size(), GL_UNSIGNED_INT, 0);
    glDisableVertexAttribArray(vertexAttribute);
}

/**
 * OpenGL data initialisation from mesh data.
 */
void Mesh::init() {
    glGenBuffers(1, &m_vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, m_vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, m_vertices.size() * sizeof(Vector3f), m_vertices.data(), GL_STATIC_DRAW);

    glGenBuffers(1, &m_indexBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_indexBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, m_indices.size() * sizeof(int), m_indices.data(), GL_STATIC_DRAW);

    m_isReady = true;
}

/**
 * Read next line in a file.
 * @param asset     - asset file to read.
 * @param buffer    - dest buffer, we assume its length is longer than 2 characters.
 * @param size      - buffer size.
 * @return false if end file was reached, true otherwise.
 */
bool Mesh::getLineFromFile(AAsset *asset, char *buffer, size_t size) {
    char ch;
    int offset = 0;

    // New line character purge.
    while (AAsset_read(asset, &ch, 1) > 0 && ch == '\n');
    buffer[offset++] = ch;

    // End file detection.
    if (AAsset_read(asset, &ch, 1) <= 0) return false;
    buffer[offset++] = ch;

    // Char by char method. The least efficient, but the simplest to implement.
    while (AAsset_read(asset, &ch, 1) > 0 && ch != '\n')
        if (offset < size - 1)
            buffer[offset++] = ch;

    // Don't forget the end line character.
    buffer[offset] = '\0';
    return true;
}

/**
 * Just to factorize vertex and face insertions.
 * @param fields
 */
void Mesh::addData(const std::string &str) {
    std::vector<std::string> fields = split(str, " ");

    if (fields.size() == 0)                 // Not interesting data.
        return;

    if (fields[0] == "v") {
        if (fields.size() < 4)              // Not well formatted vertex.
            return;

        m_vertices.push_back(Vector3f(str2float(fields[1]), str2float(fields[2]), str2float(fields[3])));
    }
    else if (fields[0] == "f") {
        if (fields.size() < 4)
            return;

        // We keep only 3-index faces.
        // Special processing on indices, because OBJ indexation can have '/' to specify texture or normal references.
        m_indices.push_back(str2int(fields[1].substr(0, fields[1].find('/'))) - 1);
        m_indices.push_back(str2int(fields[2].substr(0, fields[2].find('/'))) - 1);
        m_indices.push_back(str2int(fields[3].substr(0, fields[3].find('/'))) - 1);
    }
}

/**
 * Convenient function to split a string into substring according a delimiter.
 * @param str       - string to split.
 * @param delim     - list of delimiters.
 * @return list of substrings.
 */
std::vector<std::string> Mesh::split(const std::string &str, const char* delim) {
    std::vector<std::string> items;
    char *buf = strdup(str.c_str());
    char *token = strtok(buf, delim);

    while (token != 0) {
        items.push_back(token);
        token = strtok(NULL, delim);
    }

    free(buf);
    return items;
}
