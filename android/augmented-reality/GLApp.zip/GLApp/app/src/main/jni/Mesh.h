#ifndef __MESH_H_
#define __MESH_H_

#include <GLES2/gl2.h>
#include <android/log.h>
#include <android/asset_manager.h>
#include <cstdlib>

#include <string>
#include <vector>

#include "ShaderProgram.h"
#include "UrlReaderWrapper.h"

#define  LOG_TAG    "Mesh"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)


class Mesh {
public:
    Mesh();
    void readFromOBJFile(AAssetManager *manager, const char *filename);
    void readFromUrlReader(UrlReaderWrapper &urlReader);
    void display(const ShaderProgram &program);

private:
    void init();
    bool getLineFromFile(AAsset *asset, char *buffer, size_t size);
    void addData(const std::string &str);
    std::vector<std::string> split(const std::string &str, const char* delim);


    struct Vector3f {
        float x, y, z;
        Vector3f(float _x = 0.0f, float _y = 0.0f, float _z = 0.0f): x(_x), y(_y), z(_z) { }
    };

    // Mesh data.
    std::vector<Vector3f> m_vertices;
    std::vector<int> m_indices;

    // OpenGL data.
    GLuint m_vertexBuffer;
    GLuint m_indexBuffer;
    bool m_isReady;
};


/**
 * Convert a string to a float.
 * @param str
 * @return float
 */
inline float str2float(const std::string &str) {
    return strtof(str.c_str(), NULL);
}

/**
 * Convert a string to an integer.
 * @param str
 * @return int
 */
inline int str2int(const std::string &str) {
    return (int) strtol(str.c_str(), NULL, 10);
}

#endif // __MESH_H_
