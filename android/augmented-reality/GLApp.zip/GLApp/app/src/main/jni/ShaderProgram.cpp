#include <sstream>
#include "ShaderProgram.h"


/**
 * Builder.
 */
ShaderProgram::ShaderProgram() : m_programId(0) {

}

/**
 * Create a program, compile shader sources, and link them to the program.
 * Inspired by ARToolKit5 native example.
 * @param vertStr   - vertex shader source.
 * @param fragStr   - fragment shader source.
 * @return true if everything is ok, false if any error occurred.
 */
bool ShaderProgram::loadFromStrings(const std::string &vertStr, const std::string &fragStr) {
    GLuint vertShader = 0, fragShader = 0;
    GLint status = 0;

    // Destroy previous program if exists.
    if (m_programId)
        destroyProgramAndShaders(m_programId, 0, 0);

    // Program and shader creation / compilation.
    m_programId = glCreateProgram();
    if (!m_programId) {
        LOGE("Unable to create program");
        destroyProgramAndShaders(m_programId, vertShader, fragShader);
        return false;
    }

    vertShader = loadShader(GL_VERTEX_SHADER, vertStr.c_str());
    if (!vertShader) {
        LOGE("Unable to compile vertex shader");
        destroyProgramAndShaders(m_programId, vertShader, fragShader);
        return false;
    }

    fragShader = loadShader(GL_FRAGMENT_SHADER, fragStr.c_str());
    if (!fragShader) {
        LOGE("Unable to compile fragment shader");
        destroyProgramAndShaders(m_programId, vertShader, fragShader);
        return false;
    }

    // Attachment and linking.
    glAttachShader(m_programId, vertShader);
    glAttachShader(m_programId, fragShader);

    glLinkProgram(m_programId);

    // Check for errors.
    glGetProgramiv(m_programId, GL_LINK_STATUS, &status);
    if (status == GL_FALSE) {
        LOGE("Unable to link program");
        destroyProgramAndShaders(m_programId, vertShader, fragShader);
        return false;
    }

    // Release shaders after compilation and linking.
    destroyProgramAndShaders(0, vertShader, fragShader);
    return true;
}

/**
 * Load shaders from files.
 * @param manager           - Android asset manager.
 * @param vertFilename      - source filename for vertex shader.
 * @param fragFilename      - source filename for fragment shader.
 * @return true if everything is ok, false otherwise.
 */
bool ShaderProgram::loadFromFiles(AAssetManager *manager, const char *vertFilename, const char *fragFilename) {
    return loadFromStrings(
            readFileContent(manager, vertFilename),
            readFileContent(manager, fragFilename)
    );
}


/**
 * Set of convenient functions that propose an object-based interface instead of classic OpenGL interface.
 */
GLuint ShaderProgram::getId() const {
    return m_programId;
}

GLuint ShaderProgram::getUniformLocation(const char *name) const {
    return (GLuint) glGetUniformLocation(m_programId, name);
}
GLuint ShaderProgram::getAttribLocation(const char *name) const {
    return (GLuint) glGetAttribLocation(m_programId, name);
}

void ShaderProgram::activate() {
    if (m_programId)
        glUseProgram(m_programId);
}

void ShaderProgram::deactivate() {
    glUseProgram(0);
}

/**
 * Ask to OpenGL if the current program is valid.
 * @return true if the program is valid, false otherwise (of course).
 */
bool ShaderProgram::isValid() const {
    GLint status;

    glValidateProgram(m_programId);
    glGetProgramiv(m_programId, GL_VALIDATE_STATUS, &status);

    return status != GL_FALSE;
}

/**
 * Read asset file content.
 * @param manager       - Android asset manager.
 * @param filename      - name of file to read.
 * @return file content.
 */
std::string ShaderProgram::readFileContent(AAssetManager *manager, const char *filename) {
    AAsset *asset = AAssetManager_open(manager, filename, AASSET_MODE_UNKNOWN);

    if (asset == NULL)
        return std::string();

    std::stringstream ss;           // String stream instead of string... Efficient code is always a better way.
    char buf[BUFSIZ] = { 0 };       // It's pretty important to reset the buffer.

    // Read file.
    while (AAsset_read(asset, buf, BUFSIZ) > 0)
        ss << buf;

    AAsset_close(asset);
    return ss.str();
}

/**
 * Load and compile a shader from a string.
 * @param shaderType
 * @param source        - source code to compile.
 * @return shader id, or 0 if shader can't be created or compiled.
 */
GLuint ShaderProgram::loadShader(GLenum shaderType, const char *source) {
    GLint compiled = 0;
    GLuint shader = glCreateShader(shaderType);

    if (!shader)
        return 0;

    glShaderSource(shader, 1, &source, NULL);
    glCompileShader(shader);

    glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
    if (!compiled) {
        GLint infoLen = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLen);
        if (infoLen) {
            char buf[infoLen];
            glGetShaderInfoLog(shader, infoLen, NULL, buf);
            LOGE("Could not compile shader %d:\n%s\n", shaderType, buf);
        }

        glDeleteShader(shader);
        return 0;
    }

    return shader;
}

/**
 * Convenient function to release memory.
 * @param program       - program id.
 * @param vertShader    - vertex shader id.
 * @param fragShader    - fragment shader id.
 */
void ShaderProgram::destroyProgramAndShaders(GLuint program, GLuint vertShader, GLuint fragShader) {
    if (vertShader) glDeleteShader(vertShader);
    if (fragShader) glDeleteShader(fragShader);
    if (program)    glDeleteProgram(program);
}