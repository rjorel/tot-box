#ifndef __SHADER_PROGRAM_H_
#define __SHADER_PROGRAM_H_

#include <GLES2/gl2.h>
#include <android/log.h>
#include <android/asset_manager.h>

#include <string>

#define  LOG_TAG    "ShaderProgram"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)


class ShaderProgram {
public:
    ShaderProgram();

    GLuint getId() const;
    GLuint getUniformLocation(const char *name) const;
    GLuint getAttribLocation(const char *name) const;

    bool loadFromStrings(const std::string &vertStr, const std::string &fragStr);
    bool loadFromFiles(AAssetManager *manager, const char *vertFilename, const char *fragFilename);
    void activate();
    void deactivate();
    bool isValid() const;

    std::string readFileContent(AAssetManager *manager, const char *filename);

private:
    GLuint loadShader(GLenum shaderType, const char *source);
    void destroyProgramAndShaders(GLuint program, GLuint vertShader, GLuint fragShader);

    GLuint m_programId;
};


#endif // __SHADER_PROGRAM_H_
