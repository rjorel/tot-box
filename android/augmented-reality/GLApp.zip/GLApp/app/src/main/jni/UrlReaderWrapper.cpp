#include <sstream>
#include "UrlReaderWrapper.h"


UrlReaderWrapper::UrlReaderWrapper() : m_openMethodId(0), m_readMethodId(0), m_endOfFileReached(false) {

}

/**
 * Initialize Java objects and methods to call Java functions.
 * @param env   - JNI environment.
 */
void UrlReaderWrapper::init(JNIEnv *env) {
    m_jniEnv = env;

    // Get class.
    m_javaClass = env->FindClass(PACKAGE_DIR"/UrlReader");                      // The CMakeLists.txt file defines PACKAGE_DIR.

    // Object initialisation.
    jmethodID initMethodID = env->GetMethodID(m_javaClass, "<init>", "()V");
    m_javaObject = env->NewObject(m_javaClass, initMethodID);

    // Retrieve method identifiers for later accesses to Java methods.
    m_openMethodId = env->GetMethodID(m_javaClass, "openUrl", "(Ljava/lang/String;)V");
    m_readMethodId = env->GetMethodID(m_javaClass, "read", "(I)Ljava/lang/String;");
}

/**
 * Call associated Java function.
 * @param url   - URL to open.
 */
void UrlReaderWrapper::open(const std::string &url) {
    if (m_openMethodId == 0) return;

    m_jniEnv->CallObjectMethod(
            m_javaObject, m_openMethodId,
            m_jniEnv->NewStringUTF(url.c_str())
    );

    m_endOfFileReached = false;
}

/**
 * Call associated Java function and cast the result to std::string.
 * @param length    - Number of characters to read.
 * @return string
 */
std::string UrlReaderWrapper::read(uint length) {
    if (m_readMethodId == 0)
        return std::string();

    jstring result = (jstring) m_jniEnv->CallObjectMethod(m_javaObject, m_readMethodId, (jint) length);
    const char *buffer = m_jniEnv->GetStringUTFChars(result, 0);
    std::string str = buffer;

    // Maybe there is no memory leak if we don't release the buffer, but here we are sure that the data
    // will be freed by C++ at the end.
    m_jniEnv->ReleaseStringUTFChars(result, buffer);
    m_endOfFileReached = str.size() < length;

    return str;
}

/**
 * Read a line from a remote file, by splitting the file.
 * Check if the end of the file is reached during reading.
 * @return a line
 */
std::string UrlReaderWrapper::getLine() {
    std::stringstream ss;
    size_t pos;

    // If there is enough character from previous call, update buffer and return extracted string from it.
    if ((pos = m_buffer.find('\n')) != std::string::npos) {
        ss << m_buffer.substr(0, pos);
        m_buffer = m_buffer.substr(pos + 1);        // Skip \n character.
        return ss.str();
    }

    // Get characters from previous call.
    ss << m_buffer;

    // Aggregate characters from important lines.
    std::string str = read(BUFFER_SIZE);
    while ((pos = str.find('\n')) == std::string::npos) {
        ss << str;
        str = read(BUFFER_SIZE);
    }

    // Cut string at '\n' occurrence.
    ss << str.substr(0, pos);

    // Keep remaining characters and check if end-of-file was reached.
    m_buffer = str.substr(pos + 1);                 // Skip \n character.
    m_endOfFileReached = str.size() < BUFFER_SIZE;

    return ss.str();
}

/**
 * End of file reached or not.
 * @return bool
 */
bool UrlReaderWrapper::eof() {
    return m_endOfFileReached;
}
