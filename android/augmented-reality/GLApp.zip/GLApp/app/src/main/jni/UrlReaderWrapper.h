#ifndef GLAPP_URLREADERWRAPPER_H
#define GLAPP_URLREADERWRAPPER_H

#include <jni.h>
#include <string>


/**
 * Wrapper for Java class, in order to access URLs via Android API.
 * Additional functions are added to simplify remote file access.
 */
class UrlReaderWrapper {
public:
    UrlReaderWrapper();

    // Java functions.
    void init(JNIEnv *env);
    void open(const std::string &url);
    std::string read(uint length);

    // Additional functions.
    std::string getLine();
    bool eof();

private:
    const uint BUFFER_SIZE = 16;

    // Variables to link C++ class to Java class.
    JNIEnv *m_jniEnv;
    jclass m_javaClass;
    jobject m_javaObject;
    jmethodID m_openMethodId, m_readMethodId;

    // For buffered calls.
    std::string m_buffer;
    bool m_endOfFileReached;
};

#endif //GLAPP_URLREADERWRAPPRR_H
