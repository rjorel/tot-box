#include <jni.h>
#include <android/log.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <GLES2/gl2.h>
#include <glm/mat4x4.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "ShaderProgram.h"
#include "Mesh.h"
#include "UrlReaderWrapper.h"


#define JNICALL_NATIVE(func) \
    Java_fr_ubordeaux_rjorel_glapp_RendererWrapper_##func

#define  LOG_TAG    "RendererWrapperNative"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)


extern "C" {
JNIEXPORT void JNICALL_NATIVE(nativeSurfaceCreated(JNIEnv *, jobject, jobject));
JNIEXPORT void JNICALL_NATIVE(nativeSurfaceChanged(JNIEnv *, jobject, int, int));
JNIEXPORT void JNICALL_NATIVE(nativeDrawFrame(JNIEnv *, jobject));
}

// Small buffer size to test data file retrieving from the internet.
const int BUFFER_SIZE = 16;


ShaderProgram program;
Mesh mesh;
UrlReaderWrapper urlReader;

glm::mat4x4 projectionMatrix, viewMatrix;


JNIEXPORT void JNICALL_NATIVE(nativeSurfaceCreated(JNIEnv *env, jobject object, jobject assetManager)) {
    AAssetManager *manager = AAssetManager_fromJava(env, assetManager);

    if (!program.loadFromFiles(manager, "shaders/simple.vert", "shaders/simple.frag"))
        LOGE("Could not create program.");

    // OpenGL init.
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0, 0.0, 0.0, 0.0);

    // Fixed view.
    viewMatrix = glm::lookAt(glm::vec3(5, 5, -5), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0));

    // Mesh from an internal file.
    // mesh.readFromOBJFile(manager, "models/cube.obj");

    // Mesh from a remote file.
    urlReader.init(env);
    urlReader.open("http://rjorel.legtux.fr/public/assets/cube.obj");

    mesh.readFromUrlReader(urlReader);
}

JNIEXPORT void JNICALL_NATIVE(nativeSurfaceChanged(JNIEnv *env, jobject object, int width, int height)) {
    glViewport(0, 0, width, height);

    // New projection every time the viewport changes.
    projectionMatrix = glm::perspective(glm::radians(75.f), width / (float) height, 0.001f, 1000.f);
}

JNIEXPORT void JNICALL_NATIVE(nativeDrawFrame(JNIEnv *env, jobject object)) {
    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    program.activate();

    // Put matrices.
    glUniformMatrix4fv(program.getUniformLocation("projectionMatrix"), 1, GL_FALSE, &projectionMatrix[0][0]);
    glUniformMatrix4fv(program.getUniformLocation("viewMatrix"), 1, GL_FALSE, &viewMatrix[0][0]);

    mesh.display(program);
    program.deactivate();
}