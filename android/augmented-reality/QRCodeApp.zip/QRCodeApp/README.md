# QRCodeApp

Before enjoying this incredible app :D, you have to download the OpenCV native SDK for Android with
this url : https://sourceforge.net/projects/opencvlibrary/files/opencv-android/3.2.0/opencv-3.2.0-android-sdk.zip/download

If the URL is broken, try this : http://opencv.org/releases.html, and download the last version of OpenCV.
After that, unzip the archive, and copy the folders in $OPENCV_DIR/sdk/native/ to paste them in 
$APP_DIR/app/libs/opencv/. Then, copy the directory $OPENCV_DIR/sdk/native/libs/ to paste it in
$APP_DIR/app/src/main/jniLibs/. To save place, you can remove all \*.a files in jniLibs/.

Now, enjoy !
