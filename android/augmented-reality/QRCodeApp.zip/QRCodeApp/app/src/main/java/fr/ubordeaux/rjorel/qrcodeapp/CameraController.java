package fr.ubordeaux.rjorel.qrcodeapp;

import android.util.Log;

import org.opencv.android.CameraBridgeViewBase;
import org.opencv.core.Mat;


/**
 * A class in respect of the MVC pattern. It takes frames and call QR Code processing on them.
 */
public class CameraController implements CameraBridgeViewBase.CvCameraViewListener2 {
    private static final String TAG = "CameraController";

    private QRCodeProcessor mProcessor = new QRCodeProcessor();


    @Override
    public void onCameraViewStarted(int width, int height) {

    }

    @Override
    public void onCameraViewStopped() {

    }

    @Override
    public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {
        Mat frame = inputFrame.rgba();
        String result = mProcessor.process(frame, true);        // Read QR Code content every time a QR Code is found.

        Log.i(TAG, result);
        return frame;
    }
}
