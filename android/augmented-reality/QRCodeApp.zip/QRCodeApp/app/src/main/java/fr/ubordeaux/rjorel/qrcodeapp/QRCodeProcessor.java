package fr.ubordeaux.rjorel.qrcodeapp;

import org.opencv.core.Mat;


/**
 * This class is just an interface to access native functions.
 */
public class QRCodeProcessor {
    static {
        System.loadLibrary("opencv_java3");
        System.loadLibrary("wrapper");
    }

    /**
     * Java wrapper function for native processing function.
     * @param frame         - Frame to process.
     * @param readContent   - Determines if the QR Code has to be read.
     * @return QR Code content if needed.
     */
    public String process(Mat frame, boolean readContent) {
        return nativeProcess(frame.getNativeObjAddr(), readContent);
    }

    /**
     * C++ processing function.
     * @param matAddr       - Native matrix address.
     * @param readContent   - Determines if the QR Code has to be read.
     * @return QR Code content if needed.
     */
    public native String nativeProcess(long matAddr, boolean readContent);
}
