#include <iostream>
#include <cmath>

#include "qrcode_processor.h"


// For marker indices.
// As the number of needed markers is defined here, it would make no sense to put this enumeration
// in the header file.
enum {
    TOP, BOTTOM, RIGHT
};


QRCodeProcessor::QRCodeProcessor() {

}

/**
 * Process a frame to find a QR Code and warp it.
 * @param frame         - frame to process.
 * @param warpedFrame   - warped frame, processing result if needed.
 * @param warpForRead   - warp frame to prepare reading.
 */
void QRCodeProcessor::process(const cv::Mat &frame, cv::Mat &resultFrame, bool warpForRead) {
    preprocess(frame);
    searchCode();

    if (codeFound()) {
        computeMarkerPositions();       // This function doesn't place bottom and right markers at the good place.
        computeOrientation();           // This one yes.

        // Save time processing.
        if (warpForRead)
            warpCode(frame, resultFrame);
    }
}

/**
 * Perform treatments to get contours and mass centers of contours.
 * @param frame
 */
void QRCodeProcessor::preprocess(const cv::Mat &frame) {
    cv::cvtColor(frame, m_cannyFrame, CV_BGR2GRAY);
    cv::Canny(m_cannyFrame, m_cannyFrame, LOW_CANNY_THRESHOLD, LOW_CANNY_THRESHOLD * 2, KERNEL_SIZE);

    cv::findContours(m_cannyFrame, m_contours, m_hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE);

    // Mass centers computation with moments.
    m_massCenters.resize(m_contours.size());

    for (uint i = 0 ; i < m_contours.size() ; i++) {
        cv::Moments moment = cv::moments(m_contours[i], false);
        m_massCenters[i] = cv::Point2f((float) (moment.m10 / moment.m00),  (float) (moment.m01 / moment.m00));
    }
}

/**
 * Search an occurrence of QR Code, and store related data.
 */
void QRCodeProcessor::searchCode() {
    m_markerIndices.clear();

    // Check for enclosing contours.
    for (uint i = 0 ; i < m_contours.size() ; i++) {
        int currentIndex = i;
        uint cpt = 0;

        do {
            if (m_hierarchy[currentIndex][CHILD_CONTOUR_INDEX] == -1)
                break;

            // Descending into the hierarchy.
            currentIndex = m_hierarchy[currentIndex][CHILD_CONTOUR_INDEX];
            cpt++;
        } while (true);

        // We assume that a hierarchy of 5 contours matches a finder pattern. That avoid
        // computation on areas. This comes from the canny operation.
        if (cpt >= NUM_NESTED_CONTOURS)
            m_markerIndices.push_back(i);
    }
}

/**
 * Re-organize marker indices in marker list. Need 3 detected markers.
 * Bottom and right markers can be not well setted after this treatment. Orientation computation fixs this issue.
 */
void QRCodeProcessor::computeMarkerPositions() {
    if (!codeFound()) return;

    // Compute distance between marker to determine the top marker.
    float dist01 = distance(m_massCenters[m_markerIndices[0]], m_massCenters[m_markerIndices[1]]),
            dist12 = distance(m_massCenters[m_markerIndices[1]], m_massCenters[m_markerIndices[2]]),
            dist20 = distance(m_massCenters[m_markerIndices[2]], m_massCenters[m_markerIndices[0]]);

    uint topIndex = 0;
    if (dist12 > dist01 && dist12 > dist20)
        topIndex = 0;

    else if (dist20 > dist01 && dist20 > dist12)
        topIndex = 1;

    else if (dist01 > dist12 && dist01 > dist20) {
        topIndex = 2;
        std::swap(m_markerIndices[0], m_markerIndices[1]);      // For marker placement in index vector.
    }                                                           // Reorientation needs a certain placement of the indices.

    // Swap to have top marker at good position.
    std::swap(m_markerIndices[TOP], m_markerIndices[topIndex]);
}

/**
 * Orient the QR Code for recalibration.
 */
void QRCodeProcessor::computeOrientation() {
    if (!codeFound()) return;

    cv::Point2f top = m_massCenters[m_markerIndices[TOP]],
            bottom = m_massCenters[m_markerIndices[BOTTOM]],    // At this point, we don't know if bottom and right marker
            right = m_massCenters[m_markerIndices[RIGHT]];      // are well placed.

    float slope = computeSlope(bottom, right);
    float dist = distancePointLine(top, bottom, right);        // This distance can be negative.

    // Swap top and bottom markers and take orientation.
    if (slope > 0 && dist > 0)
        m_orientation = WEST;

    else if (slope > 0 && dist < 0) {
        std::swap(m_markerIndices[BOTTOM], m_markerIndices[RIGHT]);
        m_orientation = EAST;
    }
    else if (slope < 0 && dist < 0)
        m_orientation = NORTH;

    else if (slope < 0 && dist > 0) {
        std::swap(m_markerIndices[BOTTOM], m_markerIndices[RIGHT]);
        m_orientation = SOUTH;
    }
}

/**
 * Compute the warp QR Code placed in front of camera. It's mandatory to read QR Code.
 * @param frame
 * @param warpedFrame
 */
void QRCodeProcessor::warpCode(const cv::Mat &frame, cv::Mat &warpedFrame) {
    if (!codeFound()) return;

    // Contour approximation to find corners.
    m_approxContours.resize(m_markerIndices.size());
    for (uint i = 0 ; i < m_markerIndices.size() ; i++) {
        cv::approxPolyDP(cv::Mat(m_contours[m_markerIndices[i]]), m_approxContours[i], 3, true);

        if (m_approxContours[i].size() != 4)       // Ensure rectangle.
            return;

        // Search relative positions of corners.
        const std::vector<cv::Point> currentContour = m_approxContours[i];

        // Comparing by coordinates addition gives top left and bottom right corners (min and max).
        auto topLeftBottomRightCorners = std::minmax_element(
                currentContour.begin(), currentContour.end(),
                [](const cv::Point2f &a, const cv::Point2f &b) {
                    return a.y + a.x < b.y + b.x;
                });

        // Comparing by coordinate subtraction gives top right and bottom left corners (min and max).
        auto topRightBottomLeftCorners = std::minmax_element(
                currentContour.begin(), currentContour.end(),
                [](const cv::Point2f &a, const cv::Point2f &b) {
                    return a.y - a.x < b.y - b.x;
                });

        // Re-organize points in approximated contours.
        m_approxContours[i][0] = *(topLeftBottomRightCorners.first);
        m_approxContours[i][2] = *(topLeftBottomRightCorners.second);
        m_approxContours[i][3] = *(topRightBottomLeftCorners.first);
        m_approxContours[i][1] = *(topRightBottomLeftCorners.second);
    }

    cv::Point2f topLeftCorner;
    cv::Point2f topRightCorners[2];
    cv::Point2f bottomLeftCorners[2];

    // According orientation, needed points are not at the same places.
    switch (m_orientation) {
        case NORTH:
            topLeftCorner = m_approxContours[TOP][0];

            topRightCorners[0] = m_approxContours[RIGHT][3];
            topRightCorners[1] = m_approxContours[RIGHT][2];

            bottomLeftCorners[0] = m_approxContours[BOTTOM][1];
            bottomLeftCorners[1] = m_approxContours[BOTTOM][2];
            break;

        case SOUTH:
            topLeftCorner = m_approxContours[TOP][2];
            topRightCorners[0] = m_approxContours[RIGHT][1];
            topRightCorners[1] = m_approxContours[RIGHT][0];

            bottomLeftCorners[0] = m_approxContours[BOTTOM][3];
            bottomLeftCorners[1] = m_approxContours[BOTTOM][0];
            break;

        case EAST:
            topLeftCorner = m_approxContours[TOP][3];
            topRightCorners[0] = m_approxContours[RIGHT][2];
            topRightCorners[1] = m_approxContours[RIGHT][1];

            bottomLeftCorners[0] = m_approxContours[BOTTOM][0];
            bottomLeftCorners[1] = m_approxContours[BOTTOM][1];
            break;

        case WEST:
            topLeftCorner = m_approxContours[TOP][1];
            topRightCorners[0] = m_approxContours[RIGHT][0];
            topRightCorners[1] = m_approxContours[RIGHT][3];

            bottomLeftCorners[0] = m_approxContours[BOTTOM][2];
            bottomLeftCorners[1] = m_approxContours[BOTTOM][3];
            break;
    }

    // And now, compute the last corner.
    cv::Point2f bottomRightCorner;
    if (!intersection(topRightCorners[0], topRightCorners[1],
                      bottomLeftCorners[0], bottomLeftCorners[1],
                      bottomRightCorner))
        return;

    // Prepare the inputs for warp the perspective.
    std::vector<cv::Point2f> src {
            topLeftCorner,
            topRightCorners[0],
            bottomRightCorner,
            bottomLeftCorners[0]

    };

    std::vector<cv::Point2f> dst {
            cv::Point2f(0, 0),
            cv::Point2f(warpedFrame.cols, 0),
            cv::Point2f(warpedFrame.cols, warpedFrame.rows),
            cv::Point2f(0, warpedFrame.rows)
    };

    // Let's go !
    cv::Mat warpMatrix = cv::getPerspectiveTransform(src, dst);
    cv::warpPerspective(frame, warpedFrame, warpMatrix, cv::Size(warpedFrame.cols, warpedFrame.rows));

    copyMakeBorder(warpedFrame, warpedFrame, 10, 10, 10, 10, cv::BORDER_CONSTANT, cv::Scalar(255, 255, 255));
}

/**
 * A QR Code is detected when 3 finder patterns were found. This function is used just to make a code more meaningful.
 * @return bool
 */
bool QRCodeProcessor::codeFound() const {
    return m_markerIndices.size() >= 3;
}