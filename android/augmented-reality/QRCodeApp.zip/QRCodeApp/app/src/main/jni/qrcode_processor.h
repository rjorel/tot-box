/**
 * Method highly inspired by http://dsynflo.blogspot.fr/2014/10/opencv-qr-code-detection-and-extraction.html [February 17, 2017].
 * Code rewritten to understand it.
 *
 * The technique to find corners of QR Code is made by us, it's not the same method on the website.
 */

#ifndef __QRCODE_PROCESSOR_H_
#define __QRCODE_PROCESSOR_H_

#include <vector>
#include <opencv2/imgproc/imgproc.hpp>


class QRCodeProcessor {
public:
    static float cross(const cv::Point2f &a, const cv::Point2f &b);
    static float distance(const cv::Point2f &a, const cv::Point2f &b);
    static float computeSlope(const cv::Point2f &a, const cv::Point2f &b);
    static float distancePointLine(const cv::Point2f &point, const cv::Point2f &a, const cv::Point2f &b);
    static bool intersection(const cv::Point2f &o1, const cv::Point2f &p1, const cv::Point2f &o2, const cv::Point2f &p2, cv::Point2f &res);


    QRCodeProcessor();
    void process(const cv::Mat &frame, cv::Mat &resultFrame, bool warpForRead);
    bool codeFound() const;

private:
    void preprocess(const cv::Mat &frame);
    void searchCode();
    void computeMarkerPositions();
    void computeOrientation();
    void warpCode(const cv::Mat &frame, cv::Mat &warpedFrame);


    const uint KERNEL_SIZE = 3;             // For canny.
    const uint LOW_CANNY_THRESHOLD = 100;

    const uint NUM_NESTED_CONTOURS = 5;     // For detection. Due to canny applying.
    const uint CHILD_CONTOUR_INDEX = 2;     // Just to clear hierarchy indices.

    enum CodeOrientation {                  // For QR Code orientation.
        NORTH, SOUTH, EAST, WEST
    };


    // Transformed frame.
    cv::Mat m_cannyFrame;

    // Frame structure.
    std::vector<std::vector<cv::Point>> m_contours;
    std::vector<std::vector<cv::Point>> m_approxContours;   // Only used for markers and not all the contours.
    std::vector<cv::Vec4i> m_hierarchy;

    // Properties.
    std::vector<cv::Point2f> m_massCenters;     // Contours centers.
    std::vector<uint> m_markerIndices;          // Indices in contour vector.

    CodeOrientation m_orientation;
};


/**
 * Cross product.
 * @param a
 * @param b
 * @return float
 */
inline float QRCodeProcessor::cross(const cv::Point2f &a, const cv::Point2f &b) {
    return a.x * b.y - a.y * b.x;
}

/**
 * Compute distance between two points.
 * @param a
 * @param b
 * @return float
 */
inline float QRCodeProcessor::distance(const cv::Point2f &a, const cv::Point2f &b) {
    float xdiff = a.x - b.x,
            ydiff = a.y - b.y;

    return sqrtf(xdiff * xdiff + ydiff * ydiff);
}

/**
 * Slope of line between 2 points.
 * @param a
 * @param b
 * @return float
 */
inline float QRCodeProcessor::computeSlope(const cv::Point2f &a, const cv::Point2f &b) {
    float dy = b.y - a.y,
            dx = b.x - a.x;

    return (dx != 0.0) ? dy / dx : 0;   // Case where dx == 0.0 should never happen (or really rarelly).
}

/**
 * Distance between a point and point projection on a line.
 * @param p
 * @param m1
 * @param m2
 * @return float
 */
inline float QRCodeProcessor::distancePointLine(const cv::Point2f &point, const cv::Point2f &a, const cv::Point2f &b) {
    float slope = computeSlope(a, b);

    // The equation comes from [y = Ax + B], transform in [By = Ax + c => Ax + By + C = 0]
    // where [A = -slope], [B = 1] and [C = -Ax - By = -Ax - y = slope * x - y].
    // [A = -slope] because OpenCV lankmark is reverted on y-axis.
    // We can choose arbitrary the point a or the point b since they belong to the line.
    float A = -slope,
            B = 1.0,
            C = slope * a.x - a.y;

    return (A * point.x + B * point.y + C) / sqrtf(A * A + B * B);
}

/**
 * Compute the intersection point between two lines.
 * This implementation was found on http://stackoverflow.com/questions/7446126/opencv-2d-line-intersection-helper-function [2017, February].
 * @param o1    - 1st point of 1st line.
 * @param p1    - 2nd point of 1st line.
 * @param o2    - 1st point of 2nd line.
 * @param p2    - 2nd point of 2nd line.
 * @param res   - intersection point.
 * @return bool
 */
inline bool QRCodeProcessor::intersection(const cv::Point2f &o1, const cv::Point2f &p1,
                                         const cv::Point2f &o2, const cv::Point2f &p2,
                                         cv::Point2f &res) {
    cv::Point2f x = o2 - o1;
    cv::Point2f d1 = p1 - o1;
    cv::Point2f d2 = p2 - o2;

    if (fabs(cross(d1, d2)) < 1e-8)
        return false;

    double t = cross(x, d2) / cross(d1, d2);
    res = o1 + d1 * t;

    return true;
}

#endif  // __QRCODE_PROCESSOR_H_
