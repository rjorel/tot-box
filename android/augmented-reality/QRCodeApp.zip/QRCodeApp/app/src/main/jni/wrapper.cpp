#include <jni.h>
#include <string>

#include <opencv2/imgproc/imgproc.hpp>
#include <zxing/qrcode/QRCodeReader.h>
#include <zxing/common/GlobalHistogramBinarizer.h>
#include <zxing/NotFoundException.h>

#include "MatSource.h"
#include "qrcode_processor.h"


#define JNICALL_NATIVE(func) \
    Java_fr_ubordeaux_rjorel_qrcodeapp_QRCodeProcessor_##func

#define  LOG_TAG    "QRCodeProcessorNative"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)


extern "C" {
    JNIEXPORT jstring JNICALL_NATIVE(nativeProcess(JNIEnv *, jobject, jlong matAddr, jboolean readContent));
}

// For threshold before Zxing analysis.
const uint THRESHOLD = 127;
const uint UPPER_BOUND = 255;


/**
 * QR Code reading.
 * @param warpedFrame   - warped QR Code.
 * @param str           - string with content if reading gives a result.
 */
static bool readCodeContent(zxing::qrcode::QRCodeReader &reader, const cv::Mat &warpedFrame, std::string &str) {
    cv::Mat thresh;

    // Make a threshold is important. Without that, Zxing doesn't reach to read QR Codes.
    cv::cvtColor(warpedFrame, thresh, CV_RGB2GRAY);
    cv::threshold(thresh, thresh, THRESHOLD, UPPER_BOUND, CV_THRESH_BINARY);

    // It seems that the objects are freed automatically, Valgrind doesn't notice memory leak because of that.
    zxing::Ref<zxing::LuminanceSource> source = MatSource::create(thresh);
    zxing::Ref<zxing::Binarizer> binarizer(new zxing::GlobalHistogramBinarizer(source));
    zxing::Ref<zxing::BinaryBitmap> bitmap(new zxing::BinaryBitmap(binarizer));

    // Zxing lib prefers exceptions instead of error codes.
    try {
        zxing::Ref<zxing::Result> result(reader.decode(bitmap, zxing::DecodeHints(zxing::DecodeHints::TRYHARDER_HINT)));
        str = result->getText()->getText();

        return true;
    }
    // Nothing to do if the QR Code content is not readable.
    catch (zxing::NotFoundException e) { }
    catch (zxing::ReaderException e) { }

    return false;
}


/**
 * Entry point in C++ lib. Process a frame, and read QR Code content if it is detected.
 */
JNIEXPORT jstring JNICALL_NATIVE(nativeProcess(JNIEnv *env, jobject object, jlong matAddr, jboolean readContent)) {
    QRCodeProcessor processor;
    zxing::qrcode::QRCodeReader reader;

    cv::Mat frame = *(cv::Mat *) matAddr;
    cv::Mat warpedFrame(100, 100, CV_8UC3);
    std::string text;

    // Main work.
    processor.process(frame, warpedFrame, readContent);

    // Don't try to read anything if no QR Code was found, and if we don't want the QR Code content.
    if (readContent && processor.codeFound() && readCodeContent(reader, warpedFrame, text))
        return env->NewStringUTF(text.c_str());

    return env->NewStringUTF("");
}
