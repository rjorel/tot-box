package connection;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;


public class ClientConnection extends Connection implements IConnection {


	/**
	 * Initialize the connection between Client and Server,
	 * with port number 7101.
	 * @param ipAddress	: Address of the Server
	 * @throws UnknownHostException 
	 * @throws IOException
	 * @throws ConnectionException 
	 */
	public ClientConnection(String ipAddress) throws ConnectionException{
			try {
				this.socket = new Socket(ipAddress, port);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				throw new ConnectionException("");

			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new ConnectionException("");
			}
	}
	
	/**
	 * Close connection
	 */
	public void close() {
		try {
			socket.close();
		}
		catch(IOException e){
			System.err.println(e.getMessage());
			System.exit(-1);
		}
	}

}
