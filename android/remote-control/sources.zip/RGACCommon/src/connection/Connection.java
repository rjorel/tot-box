package connection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public abstract class Connection implements IConnection{
	protected Socket socket;
	protected static final int port = 7101;
	protected BufferedReader in;
	protected PrintWriter out;

	public Connection(){}
	
	/**
	 * Send data 
	 * @param s : Message you want to sent
	 */	
	public void send(String s) throws ConnectionException{
		try {
		socket.setReuseAddress(true);
		out = new PrintWriter(new OutputStreamWriter (socket.getOutputStream()));
        out.println(s);
        out.flush();
		}catch (IOException e){
			throw new ConnectionException("");
		}
	}
	
	/**
	 * Receive data 
	 * @return : Message of the server
	 */
	public String receive() throws ConnectionException{
		try{
		socket.setReuseAddress(true);
		in = new BufferedReader (new InputStreamReader (socket.getInputStream()));
        String message = in.readLine();
        return message;
		}catch (IOException e){
			throw new ConnectionException("");
		}
	}
	

	/**
	 * Information about the state of the connection
	 * @return Message of the connection
	 */
	public String getInfo() {
		String message;
		if(this.socket.isConnected())
			message = "Connection established to "+this.socket.getInetAddress().toString()+" .\n";
		else
			message = "Not connected.\n";
		if(this.socket.isClosed())
			message = "The Connection is closed.\n";
		return message;
	}
	
}
