package connection;

public interface IConnection {

	/**
	 * Close connection
	 */
	public void close();
	
	/**
	 * Send data 
	 * @param s : Message you want to sent
	 * @throws ConnectionException 
	 */
	public void send(String s) throws ConnectionException;
	
	/**
	 * Receive data 
	 * @return : Message received
	 * @throws ConnectionException 
	 */
	public String receive() throws ConnectionException;
	
	/**
	 * Information about the state of the connection
	 * @return Message of the connection
	 */
	public String getInfo();
	
}
