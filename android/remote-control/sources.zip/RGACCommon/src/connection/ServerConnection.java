package connection;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.UnknownHostException;

public class ServerConnection extends Connection implements IConnection {

	private ServerSocket serverSocket;

	/**
	 * Open a connection on port 7101
	 * @throws UnknownHostException
	 * @throws IOException
	 */
	public ServerConnection() throws ConnectionException {
		try {
			serverSocket = new ServerSocket(Connection.port);
		} catch (UnknownHostException e) {
			throw new ConnectionException("");
		} catch (IOException e) {
			throw new ConnectionException("");
		}
	}

	/**
	 * Accept the connection
	 * @return : Success or not of the connection
	 */
	public Boolean accept(){
		try {
			socket = serverSocket.accept();
			return true;
		} catch (IOException e) {
			System.err.println(e.getMessage());
		    System.exit(-1);
		}
		return false;
	}
	
	
	/**
	 * Close connection
	 */
	public void close() {
		try {
			socket.close();
			serverSocket.close();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		    System.exit(-1);
		}
	}
	
	
}
