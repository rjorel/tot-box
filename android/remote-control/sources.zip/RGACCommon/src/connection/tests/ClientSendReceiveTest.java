package connection.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import connection.ClientConnection;
import connection.Connection;
import connection.ConnectionException;

public class ClientSendReceiveTest {
	private Connection client;

	/**
	 * Test with local connection
	 */

	@Before
	public void setUp() throws Exception {
		try {	
			this.client = new ClientConnection("bad IP");
		} catch (ConnectionException e) {
			this.client = new ClientConnection("127.0.0.1");
		}
		System.out.println("Client information :\n" + this.client.getInfo());
	}
	
	@After
	public void tearDown() throws Exception {
		System.out.println("Client information after test:\n" + this.client.getInfo());
		client.close();
		System.out.println("Information after close function : "+ this.client.getInfo());
	}
	
	@Test
	public void testSendReceive() {
		
		try {
			this.client.send("Message1 send by client");
			System.out.println("Client : " + this.client.receive());
			
			this.client.send("Message2 send by client");
			System.out.println("Client : " + this.client.receive());
		} catch (ConnectionException e) {
			fail("ERROR sending...");
		}
	}
}
