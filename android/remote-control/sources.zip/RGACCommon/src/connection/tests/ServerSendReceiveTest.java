package connection.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import connection.Connection;
import connection.ConnectionException;
import connection.ServerConnection;

public class ServerSendReceiveTest {
	private Connection server;
	
	/**
	 * Test with local connection
	 */
	
	@Before
	public void setUp() throws Exception {
		try {	
			this.server = new ServerConnection();	
		} catch (ConnectionException e) {
			e.printStackTrace();
		}
		System.out.println("Waiting for connection...");
		((ServerConnection) this.server).accept();
		System.out.println("Server information :\n" + this.server.getInfo());
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Server information after test :\n" + this.server.getInfo());
		server.close();
		System.out.println("Information after close function : "+ this.server.getInfo());
	}

	@Test
	public void testSendReceive() {
	
		try {
			this.server.send("Message1 send by Server");
			System.out.println("Server Reception : " + this.server.receive());
			//if you want to test an send error
			//this.server.close();
			this.server.send("Message2 send by Server");
			System.out.println("Server Reception : " + this.server.receive());
		} catch (ConnectionException e) {
			fail("ERROR sending...");
		}	
	}
}
