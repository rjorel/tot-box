package events;

public final class Events
{
    public static final int NO_EVENT = -1;
    public static final int RESET = 0;
    public static final int END = 1;

    public static final int ACC_HIT = 10;
    public static final int ACC_UP = 11;
    public static final int ACC_DOWN = 12;
    public static final int ACC_LEFT = 13;
    public static final int ACC_RIGHT = 14;

    public static final int MIC_LOW = 20;
    public static final int MIC_HIGH = 21;
    
    private static final String[] events = new String[] 
    { 
        "ACC_HIT", "ACC_UP", "ACC_DOWN", "ACC_LEFT", "ACC_RIGHT",
        "MIC_LOW", "MIC_HIGH"
    };
    
    private static final int[] eventids = new int[]
    { 
        ACC_HIT, ACC_UP, ACC_DOWN, ACC_LEFT, ACC_RIGHT,
        MIC_LOW, MIC_HIGH
    };
    
   
    public static int getValue(String str)
    {
        int i;
        for (i = 0 ; i < events.length && str.compareTo(events[i]) != 0 ; i++);

        return (i < events.length) ? eventids[i] : -1;
    }
    
    
    public static String getStringValue(int id)
    {
        int i;
        for (i = 0 ; i < eventids.length && i != id ; i++);

        return (i < eventids.length) ? events[i] : "";
    }
}
