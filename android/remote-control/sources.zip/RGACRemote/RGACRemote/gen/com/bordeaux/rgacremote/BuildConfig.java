/** Automatically generated file. DO NOT MODIFY */
package com.bordeaux.rgacremote;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}