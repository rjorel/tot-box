package analysis;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.NoSuchElementException;

import client.IClient;
import events.Events;


public class AccelerometerAnalyzer implements IAnalyzer
{
    /**
     * 
     */
    
	private IClient client;
	private ArrayDeque<ArrayList<float[]>> listOfTabs;
	private ArrayList<float[]> currentTab = null;
	private float initX;
	private float initY;
	private float initZ;
	private float deltaX;
	private float deltaY;
	private float deltaZ;
	private boolean rightX = false;
	private boolean leftX = false;
	private boolean upY = false;
	private boolean downY = false;
	private boolean hitZ = false;


	/**
	 * 
	 */
	
	public AccelerometerAnalyzer(IClient client) {
		this.listOfTabs =  new ArrayDeque<ArrayList<float[]>>();

		// Following variables depend on the smartphone
		// These variables were selected based on the Google Nexus 4 by LG.
		this.deltaX = 4.5f;
		this.deltaY = 4.5f;
		this.deltaZ = 1.0f;
		this.initX = 0.18f;
		this.initY = -0.18f;
		this.initZ = 10.13f;
		this.client = client;
	}


	@SuppressWarnings("unchecked")
	public synchronized void addData(Object values) {
		listOfTabs.push((ArrayList<float[]>) values);
	}
	


	/**
	 * 
	 */	
	
	public void analysis() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (true){
					int codeX = Events.NO_EVENT;
					int codeY = Events.NO_EVENT;
					int codeZ = Events.NO_EVENT;

					try {
						currentTab = listOfTabs.pop();
						codeX = moveXDetection();
						codeY = moveYDetection();
						codeZ = moveZDetection();
					}
					catch (NoSuchElementException e) { }
					
					
					if (codeX != Events.NO_EVENT) client.give(codeX);
					if (codeY != Events.NO_EVENT) client.give(codeY);
					if (codeZ != Events.NO_EVENT) client.give(codeZ);

					try {
						Thread.sleep(5);
					} catch (InterruptedException e) { }
				}
			}
		}).start();
	}


	/**
	 * 
	 * @return
	 */
	
	private synchronized int moveXDetection() {
		int res = Events.NO_EVENT;
		int tabSize = currentTab.size();
	    
		for(int i = 0 ; i < tabSize ; ++i) {
			float valXTab = currentTab.get(i)[0];
			
			if ((initX + deltaX <= valXTab) && !leftX) {
				res = Events.ACC_LEFT;
				leftX = true;
			}
			else
				leftX = false;

			if ((initX - deltaX >= valXTab) && !rightX) {
				res = Events.ACC_RIGHT;
				rightX = true;
			}
			else
				rightX = false;
		}
		
		return res;
	}

	
	/**
	 * 
	 * @return
	 */
	
	private synchronized int moveYDetection() {
		int res = Events.NO_EVENT;
		int tabSize = currentTab.size();
		
		for (int i = 0 ; i < tabSize ; ++i) {
			float valYTab = currentTab.get(i)[1];
			
			if ((initY + deltaY <= valYTab) && !downY) {
				res = Events.ACC_DOWN;
				downY = true;
			}
			else
				downY = false;
			
			if ((initY - deltaY >= valYTab) && !upY) {
				res = Events.ACC_UP;
				upY = true;
			}
			else
				upY = false;
		}
		
		return res;
	}

	
	/**
	 * 
	 * @return
	 */
	
	private synchronized int moveZDetection() {
		int res = Events.NO_EVENT;
		int tabSize = currentTab.size();
	
		for(int i = 0 ; i < tabSize ; ++i) {
			float valZTab = currentTab.get(i)[2];
		
			if (((initZ + deltaZ) <= valZTab) && !hitZ) {
				res = Events.ACC_HIT;
				hitZ = true;
			}
			else
				hitZ = false;
		}
		
		return res;
	}
}
