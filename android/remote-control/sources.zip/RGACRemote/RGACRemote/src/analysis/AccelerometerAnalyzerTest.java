package analysis;

import java.util.ArrayList;

import junit.framework.TestCase;
import client.IClient;
import events.Events;


public class AccelerometerAnalyzerTest extends TestCase
{

    public AccelerometerAnalyzerTest(String name)
    {
        super(name);
    }

    public void testAnalysis()
    {
        final int[] events = new int[] { Events.ACC_LEFT, Events.ACC_RIGHT, Events.ACC_UP, Events.ACC_DOWN, Events.ACC_UP };
        float[] normal = new float[] { 0.18f, -0.18f, 10.13f },
        left = new float[] { 5.0f, -0.18f, 10.13f },
        right = new float[] { -5.0f, -0.18f, 10.13f },
        up = new float[] { 0.18f, 5.0f, 10.13f },
        down = new float[] { 0.18f, -5.0f, 10.13f },
        hit = new float[] { 0.18f, -0.18f, 5.0f };
        ArrayList<float[]> values = new ArrayList<float[]>(1);
        
        IClient client = new IClient()
        {
            int i = 0;
            
            @Override
            public void give(int value)
            {
                assertTrue("Bug 'analysis' function", events[i++] == value);
            }
            
        };
        
        AccelerometerAnalyzer aa = new AccelerometerAnalyzer(client);
        aa.analysis();
        
        values.set(0, normal);
        aa.addData(values.clone());
        
        values.set(0, left);
        aa.addData(values.clone());
        
        values.set(0, right);
        aa.addData(values.clone());
        
        values.set(0, up);
        aa.addData(values.clone());
        
        values.set(0, down);
        aa.addData(values.clone());
        
        values.set(0, hit);
        aa.addData(values.clone());
    }
}
