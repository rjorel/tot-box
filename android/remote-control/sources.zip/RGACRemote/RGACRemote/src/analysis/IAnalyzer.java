package analysis;


public interface IAnalyzer {
	void analysis();
	void addData(Object values);
}
