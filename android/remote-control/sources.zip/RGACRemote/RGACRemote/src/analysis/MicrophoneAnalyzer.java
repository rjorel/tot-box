package analysis;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.NoSuchElementException;

import client.IClient;
import events.Events;

public class MicrophoneAnalyzer implements IAnalyzer
{
    /**
     * 
     */
    
	private IClient client;
	private ArrayDeque<ArrayList<Double>> listsOfTabs;
	private ArrayList<Double> amplitudes;
	private double highLimit = 6000.0;
	private double lowLimit = 4000.0;
	
	
	/**
	 * 
	 * @param initValues
	 * @param client
	 */
	
	public MicrophoneAnalyzer(Object initValues, IClient client)
	{
		listsOfTabs = new ArrayDeque<ArrayList<Double>>();
		this.client = client;
	}
	
	
	/**
	 * 
	 */

	@Override
	public void analysis() {
		// TODO Auto-generated method stub
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (true){
					int code = Events.NO_EVENT;

					try {
						amplitudes = listsOfTabs.pop();
						code = soundDetection();
					}
					catch(NoSuchElementException e) { }
					
					if (code != Events.NO_EVENT) client.give(code);

					try {
						Thread.sleep(5);
					} catch (InterruptedException e) { }
				}
			}
		}).start();
	}

	
	/**
	 * @param values
	 */
	
	@SuppressWarnings("unchecked")
    @Override
	public void addData(Object values)
	{
		listsOfTabs.push((ArrayList<Double>) values);
	}
	
	
	/**
	 * 
	 * @return
	 */
	
	private synchronized int soundDetection()
	{
		int res = Events.NO_EVENT;
		int tabSize = amplitudes.size();
		
		for(int i = 0; i < tabSize ; i++){
			double tabVal = amplitudes.get(i);
			if (tabVal >= highLimit)
				res = Events.MIC_HIGH;
			
			else if ((tabVal < highLimit) && (tabVal >= lowLimit))
				res = Events.MIC_LOW;
		}
		
		return res;
	}
}
