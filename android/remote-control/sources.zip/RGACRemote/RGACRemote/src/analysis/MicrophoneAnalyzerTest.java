package analysis;

import java.util.ArrayList;

import client.IClient;
import events.Events;
import junit.framework.TestCase;

public class MicrophoneAnalyzerTest extends TestCase
{

    public MicrophoneAnalyzerTest(String name)
    {
        super(name);
    }

    public void testAnalysis()
    {
        final int[] events = new int[] { Events.MIC_LOW, Events.MIC_HIGH };
        ArrayList<Double> values = new ArrayList<Double>(1);
        
        IClient client = new IClient()
        {
            int i = 0;
            
            @Override
            public void give(int value)
            {
                assertTrue("Bug 'analysis' function", events[i++] == value);
            }
            
        };
        
        MicrophoneAnalyzer aa = new MicrophoneAnalyzer(null, client);
        aa.analysis();
        
        values.set(0, 1000.0);
        aa.addData(values.clone());
        
        values.set(0, 5000.0);
        aa.addData(values.clone());
        
        values.set(0, 7000.0);
        aa.addData(values.clone());
    }
}
