package analysis;

import java.util.ArrayList;
import java.util.HashMap;


public class SequenceAnalyzer
{
    /**
     * @attribute sequences: keys are the events types.
     * @attribute valuesMatched: values currently matched.
     * @attribute currentEvent: current event in progress. Nothing if it equals to reset event.
     * @attribute resetEvent: event to reset the sequences.
     */
    
    private HashMap<Integer, SortedAssociatedList> sequences;
    private ArrayList<Integer> valuesMatched;
    private int currentEvent;
    private int resetEvent;

    
    /**
     * Analyzer builder.
     */
    
    public SequenceAnalyzer(int resEv)
    {
        sequences = new HashMap<Integer, SortedAssociatedList>();
        valuesMatched = new ArrayList<Integer>();
        currentEvent = resetEvent = resEv;
    }
    
    
    /**
     * Adds a new entry.
     * @param event: event associated with action. Add in the map if not exists. Must not be the reset event.
     * @param number: number of consecutive event waited.
     * @param returnValue: return value if the number of events are matched.
     */
    
    public void add(int event, int number, int returnValue)
    {
        if (event == resetEvent || number <= 0) return;
        if (sequences.get(event) == null)
            sequences.put(event, new SortedAssociatedList());
        
        sequences.get(event).add(number, returnValue);
    }
    
    
    /**
     * Resets all the event sequences.
     */
    
    public void resetAll()
    {
        for (SortedAssociatedList a: sequences.values())
            a.reset();
    }
    
    
    /**
     * Handles progression of the sequences.
     * @param event: event in advance. If it's the RESET event, all the lists are reset.
     */
    
    public boolean evolve(int event)
    {
    	boolean find = false;
    	
        if (event == resetEvent) {    // If it's the RESET event, we get the last event value in advance.
            try {
            	if (currentEvent != resetEvent) { 
            		valuesMatched.add(sequences.get(currentEvent).getCurrentValue());
            		find = true;
            	}
            }
            catch (ArrayIndexOutOfBoundsException ex) {}

            resetAll();
            currentEvent = resetEvent;
        }
        else if (sequences.keySet().contains(event)) {
            if (event != currentEvent) {    // If the new event are different from the last, we get the last value in advance.
                try {
                    if (currentEvent != resetEvent) { 
                    	valuesMatched.add(sequences.get(currentEvent).getCurrentValue());
                    	find = true;
                    }
                }
                catch (ArrayIndexOutOfBoundsException ex) {}

                resetAll();
                currentEvent = event;
            }
            
            if (sequences.get(event).next()) {      // If the larger sequence are reached, it is not worth continuing.
                valuesMatched.add(sequences.get(event).getCurrentValue());
                find = true;
                resetAll();
            }
        }
        
        return find;
    }
    
    
    /**
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    
    public String toString()
    {
        String str = new String();
        for (int e: sequences.keySet())
            str += (e + ": " + sequences.get(e).toString() + "\n");
        
        return str;
    }

    public ArrayList<Integer> getValuesMatched()
    {
        return valuesMatched;
    }
    
    public void clearValuesMatched()
    {
        valuesMatched.clear();
    }
}
