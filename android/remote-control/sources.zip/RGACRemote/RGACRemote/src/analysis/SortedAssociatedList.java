package analysis;
import java.util.ArrayList;


public class SortedAssociatedList
{
    /**
     * @attribute index: associated number to values. Sorted array.
     * @attribute values: Unsorted array, depends on numbers array.
     * @attribute counter: integer to progress in numbers and values arrays.
     * @attribute offset: current index reached in numbers and values arrays.
     */
    
    private ArrayList<Integer> numbers;
    private ArrayList<Integer> values;
    private int counter = 0;
    private int offset = -1;

    
    /**
     * List builder.
     */
    
    public SortedAssociatedList()
    {
        numbers = new ArrayList<Integer>();
        values = new ArrayList<Integer>();
    }
    
    
    /**
     * Adds a new entry in arrays, sorted according to the numbers array.
     * If the number exists already, the old values are replaced.
     * @param num: number to add in numbers array. Must be positive and not equal to zero.
     * @param val: value associated.
     */
    
    public void add(int num, int val)
    {
        if (num <= 0) return;      
        if (numbers.size() == 0) {      // Empty list.
            numbers.add(num);
            values.add(val);
            return;
        }
        
        int i;
        for (i = 0 ; i < numbers.size() && num > numbers.get(i) ; i++);  // Search the good index to place the new values.

        if (i >= numbers.size()) {                            // At the end.
            numbers.add(num);
            values.add(val);
        }
        else if (num == numbers.get(i)) values.set(i, val);    // Already exists.
        else {                                              // Insertion.
            numbers.add(i, num);
            values.add(i, val);
        }
    }
    
    
    /**
     * Increments the counter, checks if its value reaches a new offset in numbers array.
     * @return true if the end of arrays are reached, false otherwise.
     * @throws IllegalArgumentException
     */
    
    public boolean next() throws IllegalArgumentException
    {
        if (offset + 1 >= numbers.size()) throw new IllegalArgumentException("Maximum value reached");
        if (++counter == numbers.get(offset + 1)) offset++;
        
        return offset == numbers.size() - 1;
    }
    
    
    /**
     * Resets the counter and offset.
     */
    
    public void reset()
    {
        counter = 0;
        offset = -1;
    }
    
    
    /**
     * Gets the value at offset index in numbers array. Be
     * @throws ArrayIndexOutOfBoundsException
     */
    
    public int getCurrentIndex() throws ArrayIndexOutOfBoundsException
    {
        return numbers.get(offset);
    }
    
    
    /**
     * Gets the value at offset index in values array.
     * @throws ArrayIndexOutOfBoundsException
     */
    
    public int getCurrentValue() throws ArrayIndexOutOfBoundsException
    {
        return values.get(offset);
    }
    
    
    /**
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    
    public String toString()
    {
        String str = new String();
        for (int i = 0 ; i < numbers.size() ; i++)
            str += (numbers.get(i) + " -> " + values.get(i) + " ");
        
        return str;
    }
}
