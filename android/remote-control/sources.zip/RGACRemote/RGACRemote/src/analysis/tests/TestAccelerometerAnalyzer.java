package analysis.tests;

import java.util.ArrayList;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import analysis.AccelerometerAnalyzer;
import client.IClient;
import events.Events;

public class TestAccelerometerAnalyzer
{
	AccelerometerAnalyzer aa;
	IClient client;
	ArrayList<Integer> valuesMatched;
	
	@Before
	public void setUp() throws Exception
	{
		valuesMatched = new ArrayList<Integer>();
		client = new IClient()
		{
			@Override
			public void give(int value)
			{
				valuesMatched.add(value);
			}
		};
		
		aa = new AccelerometerAnalyzer(client);
		aa.analysis();
	}

	@After
	public void tearDown() throws Exception { }

	@Test
	public void testAddData()
	{
		aa.addData(new ArrayList<float[]>());
	}

	@Test
	public void testAnalysis()
	{
        float[] left = new float[] { 5.0f, -0.18f, 10.13f },
        right = new float[] { -5.0f, -0.18f, 10.13f },
        up = new float[] { 0.18f, -5.0f, 10.13f },
        down = new float[] { 0.18f, 5.0f, 10.13f },
        hit = new float[] { 0.18f, -0.18f, 20.0f };
        ArrayList<float[]> values = new ArrayList<float[]>();
        
        
        values.add(left);
        aa.addData(values.clone());
        
        pause();
        assertTrue(valuesMatched.get(0) == Events.ACC_LEFT);
        valuesMatched.clear();
        
        values.set(0, right);
        aa.addData(values.clone());
        
        pause();
        assertTrue(valuesMatched.get(0) == Events.ACC_RIGHT);
        valuesMatched.clear();
        
        values.set(0, up);
        aa.addData(values.clone());
        
        pause();
        assertTrue(valuesMatched.get(0) == Events.ACC_UP);
        valuesMatched.clear();
        
        values.set(0, down);
        aa.addData(values.clone());
        
        pause();
        assertTrue(valuesMatched.get(0) == Events.ACC_DOWN);
        valuesMatched.clear();
        
        values.set(0, hit);
        aa.addData(values.clone());
        
        pause();
        assertTrue(valuesMatched.get(0) == Events.ACC_HIT);
        valuesMatched.clear();	}
	
	public void pause()
	{
        try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
