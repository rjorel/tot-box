package analysis.tests;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import analysis.MicrophoneAnalyzer;
import client.IClient;
import events.Events;

public class TestMicrophoneAnalyzer
{
	MicrophoneAnalyzer ma;
	IClient client;
	ArrayList<Integer> valuesMatched;

	
	@Before
	public void setUp() throws Exception
	{
		valuesMatched = new ArrayList<Integer>();
		client = new IClient()
		{
			@Override
			public void give(int value)
			{
				valuesMatched.add(value);
			}
		};
		
		ma = new MicrophoneAnalyzer(null, client);
		ma.analysis();
	}

	@After
	public void tearDown() throws Exception { }

	@Test
	public void testAddData()
	{
		ma.addData(new ArrayList<Double>());
	}
	
	@Test
	public void testAnalysis()
	{
		ArrayList<Double> values = new ArrayList<Double>();
		
        values.add(5000.0d);
        ma.addData(values.clone());
        
        pause();
        assertTrue(valuesMatched.get(0) == Events.MIC_LOW);
        valuesMatched.clear();
        
        values.set(0, 7000.0d);
        ma.addData(values.clone());
        
        pause();
        assertTrue(valuesMatched.get(0) == Events.MIC_HIGH);
        valuesMatched.clear();
	}
	
	public void pause()
	{
        try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
