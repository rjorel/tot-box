package analysis.tests;

import static org.junit.Assert.assertTrue;

import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import analysis.SequenceAnalyzer;

public class TestSequenceAnalyzer
{
	final int RESET = 0;
	SequenceAnalyzer sa;
	
	@Before
	public void setUp() throws Exception
	{
		sa = new SequenceAnalyzer(RESET);
		
        sa.add(1, 1, 0);
        sa.add(1, 3, 1);
		
        sa.add(2, 2, 2);
        sa.add(2, 3, 3);
	}

	@After
	public void tearDown() throws Exception { }

	@Test
	public void testAdd()
	{
		Random r = new Random();
		
		sa.add(-45, 2, 8);
		sa.add(1234, -1, 8);
		sa.add(-4, -56634, 8);
		
		assertTrue(sa.toString().compareTo("-45: 2 -> 8 \n1: 1 -> 0 3 -> 1 \n2: 2 -> 2 3 -> 3 \n") == 0);
		
		for (int i = 0 ; i < 100000 ; i++)
			sa.add(r.nextInt(), r.nextInt(), r.nextInt());
	}
	
	@Test
	public void testResetAll()
	{
		sa.resetAll();
	}

	@Test
	public void testEvolve() {
        
        // Fake case. Normally, no problem.
        
        sa.evolve(15);
        
        // Cases with reset interruption.
        
        assertTrue(!sa.evolve(1));
        assertTrue(sa.getValuesMatched().isEmpty());
        assertTrue(sa.evolve(RESET));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 0);
        
        sa.clearValuesMatched();
        
        assertTrue(!sa.evolve(1));
        assertTrue(sa.getValuesMatched().isEmpty());
        assertTrue(!sa.evolve(1));
        assertTrue(sa.getValuesMatched().isEmpty());
        assertTrue(sa.evolve(1));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 1);

        assertTrue(!sa.evolve(RESET));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 1);

        
        sa.clearValuesMatched();
        
        assertTrue(!sa.evolve(2));
        assertTrue(sa.getValuesMatched().isEmpty());
        assertTrue(!sa.evolve(2));
        assertTrue(sa.getValuesMatched().isEmpty());
        
        assertTrue(sa.evolve(RESET));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 2);
        
        sa.clearValuesMatched();
        
        assertTrue(!sa.evolve(2));
        assertTrue(sa.getValuesMatched().isEmpty());
        assertTrue(!sa.evolve(2));
        assertTrue(sa.getValuesMatched().isEmpty());
        assertTrue(sa.evolve(2));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 3);

        assertTrue(!sa.evolve(RESET));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 3);
        
        
        // Case with other events interruption.
        
        sa.clearValuesMatched();
        
        assertTrue(!sa.evolve(1));
        assertTrue(sa.evolve(2));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 0);
        
        sa.clearValuesMatched();
        
        assertTrue(!sa.evolve(2));
        assertTrue(sa.evolve(1));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 2);
        
        sa.clearValuesMatched();
        
        assertTrue(!sa.evolve(1));
        assertTrue(sa.evolve(1));
        assertTrue(!sa.evolve(2));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 1);
        
        sa.clearValuesMatched();
        
        assertTrue(!sa.evolve(2));
        assertTrue(sa.evolve(2));
        assertTrue(!sa.evolve(1));
        assertTrue(!sa.getValuesMatched().isEmpty());
        assertTrue(sa.getValuesMatched().get(0) == 3);
    }

	@Test
	public void testToString()
	{
		assertTrue(sa.toString().compareTo("1: 1 -> 0 3 -> 1 \n2: 2 -> 2 3 -> 3 \n") == 0);
	}

	@Test
	public void testGetValuesMatched()
	{
		assertTrue(sa.getValuesMatched().isEmpty());
	}

	@Test
	public void testClearValuesMatched()
	{
		sa.clearValuesMatched();
	}

}
