package analysis.tests;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import analysis.SortedAssociatedList;

public class TestSortedAssociatedList
{
	SortedAssociatedList sal;

	
	@Before
	public void setUp() throws Exception
	{
		sal = new SortedAssociatedList();
		
        sal.add(2, 4);
        sal.add(4, 8);
        sal.add(2, 4);
        
        sal.add(2, 0);
        sal.add(1, 9);
	}

	@After
	public void tearDown() throws Exception { }

	@Test
	public void testAdd()
	{
		Random r = new Random();
		
        sal.add(0, 2);
        sal.add(-1, 2);
        sal.add(-56, 123456);
        sal.add(-12345, -6755);
        sal.add(12345, -6755);

		assertTrue(sal.toString().compareTo("1 -> 9 2 -> 0 4 -> 8 12345 -> -6755 ") == 0);
        
		for (int i = 0 ; i < 100000 ; i++)
			sal.add(r.nextInt(), r.nextInt());		
	}

	@Test
	public void testNext()
	{
        assertTrue(!sal.next());
        assertTrue(sal.getCurrentIndex() == 1);
        assertTrue(sal.getCurrentValue() == 9);
        
        assertTrue(!sal.next());
        assertTrue(sal.getCurrentIndex() == 2);
        assertTrue(sal.getCurrentValue() == 0);
        
        assertTrue(!sal.next());
        assertTrue(sal.getCurrentIndex() == 2);
        assertTrue(sal.getCurrentValue() == 0);
        
        assertTrue(sal.next());
        assertTrue(sal.getCurrentIndex() == 4);
        assertTrue(sal.getCurrentValue() == 8);
        
        try {
        	sal.next();
        	fail();
        }
        catch(IllegalArgumentException e) {}
    }

	@Test
	public void testReset()
	{
		sal.reset();
		
		try {
			sal.getCurrentIndex();
			fail();
		}
		catch(ArrayIndexOutOfBoundsException e) {}
	}

	@Test
	public void testGetCurrentIndex()
	{
		try {
			sal.getCurrentIndex();
			fail();
		}
		catch(ArrayIndexOutOfBoundsException e) {}
	}

	@Test
	public void testGetCurrentValue() 
	{
		try {
			sal.getCurrentValue();
			fail();
		}
		catch(ArrayIndexOutOfBoundsException e) {}
	}

	@Test
	public void testToString()
	{
		assertTrue(sal.toString().compareTo("1 -> 9 2 -> 0 4 -> 8 ") == 0);
	}

}
