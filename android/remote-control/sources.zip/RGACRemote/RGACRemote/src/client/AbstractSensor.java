package client;


import java.util.ArrayList;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;


public abstract class AbstractSensor implements ISensor, SensorEventListener
{
    /**
     * @attribute sensorManager: sensor manager from Android API.
     * @attribute sensor: sensor device.
     * @attribute value: list of float triples (x, y and z values of measured quantities by sensor).
     */
    
    protected SensorManager sensorManager;
    protected Sensor sensor;
    protected ArrayList<float[]> values;
    
    
    /**
     * Sensor builder.
     * @param context: application context to get sensor manager.
     */
    
    public AbstractSensor(Context context)
    {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        values = new ArrayList<float[]>();
    }
    
    
    /**
     * (non-Javadoc)
     * @see android.hardware.SensorEventListener#onSensorChanged(android.hardware.SensorEvent)
     
     * Stores the values that the sensor retrieves.
     * Synchronized with the getData function to avoid the access issues at the values variables.
     * @param event: values retrieved from sensor.
     */
    
    @Override
    public synchronized void onSensorChanged(SensorEvent event)
    {
        values.add((float[]) event.values.clone());
    }
    
    
    /**
     * (non-Javadoc)
     * @see android.hardware.SensorEventListener#onAccuracyChanged(android.hardware.Sensor, int)
     
     * Non-used.
     * @param sensor
     * @param accuracy
     */
    
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }
 
    
    /**
     * Clear the data retrieved.
     * Synchronize with functions using the data array.
     */
    
    public synchronized void clearData()
    {
        values.clear();
    }
    
    
    /**
     * Start the process to retrieve data from sensor.
     */
    
    public void startSensor()
    {
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_FASTEST);
    }
    
    
    /**
     * Pause the thread which retrieves data.
     * @throws InterruptedException
     */
    
    public void pauseSensor()
    {
        sensorManager.unregisterListener(this, sensor);
    }
    
    
    /**
     * Resume the thread which retrieves data. 
     */
    
    public void resumeSensor()
    {
        this.startSensor();
    }
}
