package client;

import java.util.ArrayList;

import android.content.Context;
import android.hardware.Sensor;


public class AccelerometerSensor extends AbstractSensor
{
    /**
     * Sensor builder.
     * @param context : application context to get sensor manager.
     */
    
    public AccelerometerSensor(Context context)
    {
        super(context);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }


    /**
     * (non-Javadoc)
     * @see client.ISensor#getData()
     
     * Returns the data stored, and clears the array.
     * Synchronized with the onSensorChanged function to avoid the access issues at the values variables.
     * @return data retrieved by accelerometer sensor.
     */
    
    @Override
    public synchronized Data getData()
    {
        @SuppressWarnings("unchecked")
		ArrayList<float[]> tmp = (ArrayList<float[]>) values.clone();
        values.clear();
        return new Data(tmp, DataTag.DATA_ACCELEROMETER);
    }
}
