package client;

import java.util.ArrayList;

import analysis.AccelerometerAnalyzer;
import analysis.IAnalyzer;
import analysis.MicrophoneAnalyzer;
import analysis.SequenceAnalyzer;
import android.content.Context;
import connection.ClientConnection;
import connection.ConnectionException;
import connection.IConnection;
import events.Events;


public class Client implements IClient
{
    /**
     * 
     */

    private static final int MILLIS_DELAY = 500;
    private static final int MILLIS_RESET_DELAY = 1000; 
    
    /**
     * 
     */
    
    private boolean activateAcc = false;
    private boolean activateMicro = false;

    private Thread loop;
    private ArrayList<ISensor> sensors;
    private IAnalyzer accelerometerAnalyzer;
    private IAnalyzer microphoneAnalyzer;
    private IConnection connection;
    private SequenceAnalyzer sequenceAnalyzer;
    private boolean isRunning = true;
    private int currentEvent = Events.RESET;
    private long oldtime = 0;
    private long newtime = 0;
    
    
    /**
     * 
     * @param context
     * @param ipAdress
     * @throws ConnectionException
     */
    
    public Client(Context context, String ipAdress) throws ConnectionException
    {
        sensors = new ArrayList<ISensor>();
        sequenceAnalyzer = new SequenceAnalyzer(Events.RESET);
        connection = new ClientConnection(ipAdress);

        /*
         * Message reception to establish the events list and ID associated.
         */
        
        String receivedMessage = connection.receive();
        String[] messages = receivedMessage.split(";");
        
        for (String msg: messages) {
        	String[] elts = msg.split(",");
        	sequenceAnalyzer.add(Events.getValue(elts[0]), Integer.valueOf(elts[1]), Integer.valueOf(elts[2]));

        	String event = elts[0].substring(0, 3);
        	if (event.compareTo("ACC") == 0) activateAcc = true;
        	if (event.compareTo("MIC") == 0) activateMicro = true;
        }
        
        /*
         * Sensors and analyzers activation according to the received events.
         */
        
        if (activateAcc) {
        	sensors.add(new AccelerometerSensor(context));
            accelerometerAnalyzer = new AccelerometerAnalyzer(this);
        }
        
        if (activateMicro) {
        	sensors.add(new MicrophoneSensor());
            microphoneAnalyzer = new MicrophoneAnalyzer(null, this);
        }
        
        /*
         * Thread to retrieve data from sensors and send it to the analyzers.
         */
        
        loop = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
            	for (ISensor s: sensors) s.startSensor();
                oldtime = System.currentTimeMillis();

                while (true) {
                    newtime = System.currentTimeMillis();
                    if (newtime - oldtime > MILLIS_RESET_DELAY) 
                        give(Events.RESET);
                    
                    while (!isRunning) Thread.yield();
                	
                	for (ISensor sensor: sensors) {   //  Retrieves data from sensor and launchs analysis.
                        Data data = sensor.getData();
                        
                        switch (data.tag) {
                            case DATA_ACCELEROMETER:
                            	accelerometerAnalyzer.addData(data.data);
                            	break;
                         
                            case DATA_MICROPHONE:
                            	microphoneAnalyzer.addData(data.data);
                            	break;
                                
                            default: break;
                        }
                    }
                    try { Thread.sleep(MILLIS_DELAY); }
                    catch (InterruptedException e) { e.printStackTrace(); }
                }
            }            
        });
    }
    
    
    /**
     * 
     */
    
    public void start()
    {
    	for (ISensor sensor: sensors){
    		sensor.startSensor();
    	}
    	
    	if (activateAcc) accelerometerAnalyzer.analysis();
        if (activateMicro) microphoneAnalyzer.analysis();
        
    	loop.start();
    }
    
    
    /**
     * 
     */
    
    public void pause()
    {
    	for (ISensor sensor: sensors){
    		sensor.pauseSensor();
    		sensor.clearData();
    	}
    	
    	isRunning = false;
    }

    
    /**
     * 
     */
    
    public void resume()
    {
    	for (ISensor sensor: sensors){
    		sensor.resumeSensor();
    		sensor.clearData();
    	}
    	
    	isRunning = true;
    }
	
	
    /**
     * 
     * @param event
     */
    
	public void give(int event)
	{
		if (event == Events.RESET) currentEvent = Events.RESET;
		if (currentEvent == Events.RESET) currentEvent = event;
			
		if (currentEvent == event && sequenceAnalyzer.evolve(event)) {
			@SuppressWarnings("unchecked")
			ArrayList<Integer> ids = (ArrayList<Integer>) sequenceAnalyzer.getValuesMatched().clone();
			
			sequenceAnalyzer.clearValuesMatched();
			try {
				connection.send(String.valueOf(ids.get(0)));
			} catch (ConnectionException e) {
				System.err.println("Send fails");
			}
		}
		
		oldtime = newtime;
	}
}