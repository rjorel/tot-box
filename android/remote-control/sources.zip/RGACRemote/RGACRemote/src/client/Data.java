package client;


/**
 * Structure for data representation.
 */

public class Data
{
    public Object data;
    public DataTag tag;

    public Data(Object data, DataTag tag)
    {
        this.data = data;
        this.tag = tag;
    }
}
