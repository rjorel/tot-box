package client;


/**
 * Tags for sensors.
 */

public enum DataTag
{
    DATA_ACCELEROMETER,
    DATA_MICROPHONE,
    DATA_PROXIMITY
}
