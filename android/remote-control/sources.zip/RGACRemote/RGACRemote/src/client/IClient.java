package client;

public interface IClient
{
	/**
	 * Give a value to an object.
	 * @param value
	 */
	
	public void give(int value);
}
