package client;

public interface ISensor
{
    /**
     * Get data from sensor.
     * @return : data retrieved. 
     */
    
    public Data getData();
    
    /**
     * Clear the data retrieved.
     */

    public void clearData();
    
    /**
     * Start the data retrieving.
     */
    
    public void startSensor();
    
    /**
     * Pause the sensor. 
     */
    
    public void pauseSensor();

    /**
     * Resume the data retrieving from sensor.
     */
    
    public void resumeSensor();
}
