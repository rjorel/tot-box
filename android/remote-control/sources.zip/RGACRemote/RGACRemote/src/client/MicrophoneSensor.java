package client;

import java.util.ArrayList;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder.AudioSource;


public class MicrophoneSensor implements ISensor
{
    /**
     * Class attributes. 
     */
    
    private static final int MILLIS_DELAY = 10;

    private static final int RECORDER_SOURCE = AudioSource.MIC;
    private static final int RECORDER_SAMPLERATE = 44100;
    private static final int RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_MONO;
    private static final int RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
    
    
    /**
     * @attribute audioRecorder: audio recorder from Android API.
     * @attribute values: list of values computed with RMS.
     * @attribute loop: thread to retrieve data.
     * @attribute buffer: buffer to get data before storage.     
     * @attribute bufferSize: buffer size.
     * @attribute isRecording: 
     */
    
    private AudioRecord audioRecorder;
    private ArrayList<Double> values;
    private Thread loop;
    private short[] buffer;
    private int bufferSize;
    private boolean isRecording = false;

    
    /**
     * Sensor builder.
     */
    
    public MicrophoneSensor()
    {
        bufferSize = AudioRecord.getMinBufferSize(RECORDER_SAMPLERATE, RECORDER_CHANNELS, RECORDER_AUDIO_ENCODING);
        audioRecorder = new AudioRecord(RECORDER_SOURCE, RECORDER_SAMPLERATE, RECORDER_CHANNELS,
        				RECORDER_AUDIO_ENCODING, bufferSize);
        buffer = new short[bufferSize];
        values = new ArrayList<Double>();
        
        loop = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                while (true) {
                    while (!isRecording) Thread.yield();
                    record();
                    
                    try { Thread.sleep(MILLIS_DELAY); }
                    catch (InterruptedException e) { e.printStackTrace(); }
                }
            }
            
        });
        
        loop.start();
    }
    
    
    /**
     * Read and compute amplitude of sound, using the RMS technique to get the effective amplitude of a sample.
     * Synchronized with the getData function to avoid the access issues at the values variables.
     */
    
    private synchronized void record()
    {
        int readSize = audioRecorder.read(buffer, 0, buffer.length);
        double sum = 0.0;
        
        for (int i = 0 ; i < readSize ; i++) 
            sum += buffer[i] * buffer[i];
        
        if (readSize > 0) values.add(Math.sqrt(sum / readSize));
    }
        
    
    /**
     * (non-Javadoc)
     * @see client.ISensor#getData()
     
     * Returns the data stored, and clears the array.
     * Synchronized with the onSensorChanged function to avoid the access issues at the values variables.
     * @return data retrieved by microphone
     */
    
    @Override
    public synchronized Data getData()
    {
        @SuppressWarnings("unchecked")
		ArrayList<Double> tmp = (ArrayList<Double>) values.clone();
        values.clear();
        return new Data(tmp, DataTag.DATA_MICROPHONE);
    }
    
    
    /**
     * Clear the data retrieved.
     * Synchronize with functions using the data array.
     */
    
    public void clearData()
    {
        values.clear();
    }
    

    /**
     * Start the process to retrieve data from microphone.
     */
    
    public void startSensor()
    {
        audioRecorder.startRecording();
        isRecording = true;
    }
    
    
    /**
     * Pause the thread which retrieves data.
     * @throws InterruptedException
     */
    
    public void pauseSensor()
    {
        isRecording = false;
        audioRecorder.stop();
    }
    
    
    /**
     * Resume the thread which retrieves data. 
     */
    
    public void resumeSensor()
    {
        startSensor();
    }
}
