package client;

import java.util.ArrayList;

import android.content.Context;
import android.hardware.Sensor;

public class ProximitySensor extends AbstractSensor
{
    /**
     * Sensor builder.
     * @param context: application context to get sensor manager.
     */
    
    public ProximitySensor(Context context)
    {
        super(context);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
    }
    
    
    /**
     * (non-Javadoc)
     * @see client.ISensor#getData()
     
     * Returns the data stored, and clears the array.
     * Synchronized with the onSensorChanged function to avoid the access issues at the values variables.
     * @return data retrieved by proximity sensor.
     */
    
    @Override
    public Data getData()
    {
        @SuppressWarnings("unchecked")
        ArrayList<float[]> tmp = (ArrayList<float[]>) values.clone();
        values.clear();
        return new Data(tmp, DataTag.DATA_PROXIMITY);
    }
}
