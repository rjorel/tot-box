package com.bordeaux.rgacremote;

import java.util.List;

import connection.ClientConnection;
import connection.ConnectionException;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class ConnectionActivity extends Activity {

	/**
	 * @attribute EXTRA_* : strings to give param to children activities
	 * @attribute ip : object used to store the address ip given by the user
	 * @attribute client : object instantiated to test the connection
	 */

	private final String EXTRA_STATUS = "status";
	private final String EXTRA_HELP_TYPE = "help";
	private final String EXTRA_MOTION_TYPE = "motion";
	private final String EXTRA_IP = "ip";
	private String ip;
	private EditText ipAddressEdit = null;
	private Button tryConnectionButton = null;
	private Button helpConnectionButton = null;
	private String motionType = "all";
	private ClientConnection client = null;

	
	/**
	 * Activity builder
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_connection);

		// Get back all views that we need
		ipAddressEdit = (EditText) findViewById(R.id.ip_address_edit);
		tryConnectionButton = (Button) findViewById(R.id.try_connect_button);
		helpConnectionButton = (Button) findViewById(R.id.connection_help_button);

		// Attach a listener to the views in need
		tryConnectionButton.setOnClickListener(tryConnectionListener);
		helpConnectionButton.setOnClickListener(helpConnectionListener);
	}

	/**
	 * Listeners of the views in need
	 * #1
	 */
	private OnClickListener tryConnectionListener = new OnClickListener() {
		public void onClick(View v){
			ip = ipAddressEdit.getText().toString();
			int SDK_INT = android.os.Build.VERSION.SDK_INT;
			
			if(SDK_INT > 9){
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy);
				
				try {				
					client = new ClientConnection(ip);
					motionType = client.receive();
					Intent tryConnectionIntent = new Intent(ConnectionActivity.this, ResultConnectionActivity.class);
					tryConnectionIntent.putExtra(EXTRA_STATUS, "success");
					tryConnectionIntent.putExtra(EXTRA_MOTION_TYPE, motionType.toString());
					client.close();
					if(isCallable(tryConnectionIntent)) {startActivityForResult(tryConnectionIntent,2);}
					
				} catch (ConnectionException e) {
					Intent tryConnectionIntent = new Intent(ConnectionActivity.this, ResultConnectionActivity.class);
					tryConnectionIntent.putExtra(EXTRA_STATUS, "fail");
					tryConnectionIntent.putExtra(EXTRA_MOTION_TYPE, "no motion");
					if(isCallable(tryConnectionIntent)) {startActivityForResult(tryConnectionIntent,3);}
				}
			}
		}
	};

	/**
	 * #2
	 */
	private OnClickListener helpConnectionListener = new OnClickListener() {
		public void onClick(View v){
			Intent helpConnectionIntent = new Intent(ConnectionActivity.this, HelpActivity.class);
			helpConnectionIntent.putExtra(EXTRA_HELP_TYPE,"connection");
			if(isCallable(helpConnectionIntent)) {startActivity(helpConnectionIntent);}
		}
	};

	
	/**
	 * To change activity after connection success
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (resultCode == 0){
			Intent sensorsIntent = new Intent(ConnectionActivity.this, SensorsActivity.class);
			sensorsIntent.putExtra(EXTRA_IP, ip.toString());
			if(isCallable(sensorsIntent)) { startActivity(sensorsIntent); }
		}
	}
	
	/**
	 *
	 * @param intent : an intent given in parameter
	 * @return return if the intent given is callable or not
	 */
	private boolean isCallable(Intent intent){
		List<ResolveInfo> list = getPackageManager().queryIntentActivities(intent, 
				PackageManager.MATCH_DEFAULT_ONLY);
		return list.size() > 0;
	}
}
