package com.bordeaux.rgacremote;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class HelpActivity extends Activity {

	/**
	 * @attribute s : object used to store the string given by the father
	 */
	private TextView helpText = null;
	private String s;

	/**
	 * Activity builder
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_help);

		// Get back all views that we need
		helpText = (TextView) findViewById(R.id.text_view_help);

		// Get back extras given by the father
		Bundle extras = getIntent().getExtras();
		s = new String(extras.getString("help"));

		if(s.compareTo("connection") == 0)
			helpText.setText(R.string.help_connection_text);
		else if (s.compareTo("sensors") == 0)
			helpText.setText(R.string.help_sensors_selection_text);
	}
}