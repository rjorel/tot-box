package com.bordeaux.rgacremote;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivity extends Activity {

	private Button main_connection_button = null;
	
	/**
	 * Activity builder
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// Get back all views that we need
		main_connection_button = (Button)findViewById(R.id.main_connection_button);
		
		// Attach a listener to the views in need
		main_connection_button.setOnClickListener(connectionListener);
	}

	private OnClickListener connectionListener = new OnClickListener() {
		public void onClick(View v){
			Intent connectionIntent = new Intent(MainActivity.this, ConnectionActivity.class);
			if(isCallable(connectionIntent)) { startActivity(connectionIntent); }
		}
	};
	
	/**
	 *
	 * @param intent : an intent given in parameter
	 * @return return if the intent given is callable or not
	 */
	private boolean isCallable(Intent intent){
		List<ResolveInfo> list = getPackageManager().queryIntentActivities(intent, 
				PackageManager.MATCH_DEFAULT_ONLY);
		return list.size() > 0;
	}
}