package com.bordeaux.rgacremote;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class PauseCaptureActivity extends Activity {

	private Button resumeCaptureButton = null;
	private Button backToSensorsButton = null;

	/**
	 * Activity builder
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pause_capture);

		// Get back all views that we need
		resumeCaptureButton = (Button) findViewById(R.id.resume_capture_button);
		backToSensorsButton = (Button) findViewById(R.id.back_sensors_button);

		// Attach a listener to the views in need
		resumeCaptureButton.setOnClickListener(resumeCaptureListener);
		backToSensorsButton.setOnClickListener(backToSensorsListener);
	}

	/**
	 * Listeners of the views in need
	 * #1
	 */
	private OnClickListener resumeCaptureListener = new OnClickListener() {
		public void onClick(View v){
			setResult(1);
			PauseCaptureActivity.this.finish();
		}
	};

	/**
	 * #2
	 */
	private OnClickListener backToSensorsListener = new OnClickListener() {
		public void onClick(View v){
			setResult(0);
			PauseCaptureActivity.this.finish();
		}
	};

}