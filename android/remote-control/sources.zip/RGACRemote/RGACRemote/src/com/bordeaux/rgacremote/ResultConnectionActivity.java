package com.bordeaux.rgacremote;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ResultConnectionActivity extends Activity {

	/**
	 * @attribute statusConnection : object used to store string given by the father
	 * @attrivute typeMotionCapture : object used to store sting given by the father
	 */
	private TextView failText = null;
	private TextView successText = null;
	private TextView motionType = null;
	private String statusConnection;
	private String typeMotionCapture;

	/**
	 * Activity builder
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_result_connection);

		// Get back all views that we need
		failText = (TextView) findViewById(R.id.text_view_fail);
		successText = (TextView) findViewById(R.id.text_view_success);
		motionType = (TextView) findViewById(R.id.type_motion_capture);

		// Get back extras given by the father
		Bundle extras = getIntent().getExtras();
		statusConnection = new String(extras.getString("status"));
		typeMotionCapture = new String(extras.getString("motion"));

		if(!(typeMotionCapture.compareTo("no motion") == 0)){
			motionType.setText("Motion type catched : "+typeMotionCapture);
			motionType.setVisibility(View.VISIBLE);
		}

		if(statusConnection.compareTo("fail") == 0){
			failText.setVisibility(View.VISIBLE);
			successText.setVisibility(View.GONE);
		}else if (statusConnection.compareTo("success") == 0){
			failText.setVisibility(View.GONE);
			successText.setVisibility(View.VISIBLE);
		}
		thread.start();
	}



	/**
	 * Thread used to kill activity after few seconds
	 */
	Thread thread = new Thread(){
		@Override
		public void run() {
			try {
				Thread.sleep(3000); 
				if(statusConnection.compareTo("fail") == 0)
					setResult(1);
				else if (statusConnection.compareTo("success") == 0)
					setResult(0);
				ResultConnectionActivity.this.finish();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}  
	};

	public void onBackPressed(){
		return;
	}
}