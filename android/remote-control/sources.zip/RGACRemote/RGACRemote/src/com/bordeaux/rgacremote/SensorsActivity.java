package com.bordeaux.rgacremote;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SensorsActivity extends Activity {

	/**
	 * @attribute EXTRA_IP : string to give param to child activity
	 * @attribute ip : string used to store string given by the father
	 */
	private final String EXTRA_IP = "ip";
	private String ip;
	private Button sensorsCaptureButton = null;
	private Button sensorsCommandsButton = null;
	private Button sensorsDetailsButton = null;

	/**
	 * Activity builder
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sensors);

		// Get back all views that we need
		sensorsCaptureButton = (Button) findViewById(R.id.sensors_capture_button);
		sensorsCommandsButton = (Button) findViewById(R.id.sensors_commands_button);
		sensorsDetailsButton = (Button) findViewById(R.id.sensors_details_button);

		// Attach a listener to the views in need
		sensorsCaptureButton.setOnClickListener(sensorsCaptureListener);
		sensorsCommandsButton.setOnClickListener(sensorsCommandsListener);
		sensorsDetailsButton.setOnClickListener(sensorsDetailsListener);

		// Get back extras given by the father
		Bundle extras = getIntent().getExtras();
		ip = new String(extras.getString("ip"));
	}

	/**
	 * Listeners of the views in need
	 * #1
	 */
	private OnClickListener sensorsCaptureListener = new OnClickListener() {
		public void onClick(View v){
			Intent captureSensorIntent = new Intent(SensorsActivity.this, SensorsCaptureActivity.class);
			captureSensorIntent.putExtra(EXTRA_IP, ip.toString());
			if(isCallable(captureSensorIntent)) {startActivity(captureSensorIntent);}
		}
	};

	/**
	 * #2
	 */
	private OnClickListener sensorsCommandsListener = new OnClickListener() {
		public void onClick(View v){
			Intent commandsSensorsIntent = new Intent(SensorsActivity.this, SensorsCommandsActivity.class);
			if(isCallable(commandsSensorsIntent)) {startActivity(commandsSensorsIntent);}
		}
	};

	/**
	 * #3
	 */
	private OnClickListener sensorsDetailsListener = new OnClickListener() {
		public void onClick(View v){
			Intent helpConnectionIntent = new Intent(SensorsActivity.this, SensorsDetailsActivity.class);
			if(isCallable(helpConnectionIntent)) {startActivity(helpConnectionIntent);}
		}
	};
	
	/**
	 *
	 * @param intent : an intent given in parameter
	 * @return return if the intent given is callable or not
	 */
	private boolean isCallable(Intent intent){
		List<ResolveInfo> list = getPackageManager().queryIntentActivities(intent, 
				PackageManager.MATCH_DEFAULT_ONLY);
		return list.size() > 0;
	}
}