package com.bordeaux.rgacremote;

import java.util.List;

import connection.ConnectionException;
import client.Client;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SensorsCaptureActivity extends Activity {

	/**
	 * @attribute ip : object used to store address ip given by the father
	 * @attribute client : object instantiated to capture & analyze smartphone's environment
	 */
	private Button pauseCaptureButton = null;
	private String ip;
	private Client client;

	/**
	 * Activity builder
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sensors_capture);

		// Get back all views that we need
		pauseCaptureButton = (Button) findViewById(R.id.pause_capture_button);

		// Attach a listener to the views in need
		pauseCaptureButton.setOnClickListener(pauseCaptureListener);

		// Get back extras given by the father
		Bundle extras = getIntent().getExtras();
		ip = new String(extras.getString("ip"));

		try {
			client = new Client(SensorsCaptureActivity.this.getApplicationContext(), ip);
			client.start();
		} catch (ConnectionException e) {
			//e.printStackTrace();
		}
	}

	/**
	 * Listeners for views in need
	 */
	private OnClickListener pauseCaptureListener = new OnClickListener() {
		public void onClick(View v){
			Intent pauseCaptureIntent = new Intent(SensorsCaptureActivity.this, PauseCaptureActivity.class);
			if(isCallable(pauseCaptureIntent)) {startActivityForResult(pauseCaptureIntent,1);}
		}
	};

	/**
	 * To change activity after connection success
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (resultCode == 0){
			SensorsCaptureActivity.this.finish();
		}
	}

	/**
	 * To pause the client capture
	 */
	protected void onPause(){
		super.onPause();
		client.pause();
	}

	/**
	 * To resume the client capture
	 */
	protected void onResume(){
		super.onResume();
		client.resume();
	}
	
	/**
	 *
	 * @param intent : an intent given in parameter
	 * @return return if the intent given is callable or not
	 */
	private boolean isCallable(Intent intent){
		List<ResolveInfo> list = getPackageManager().queryIntentActivities(intent, 
				PackageManager.MATCH_DEFAULT_ONLY);
		return list.size() > 0;
	}
}