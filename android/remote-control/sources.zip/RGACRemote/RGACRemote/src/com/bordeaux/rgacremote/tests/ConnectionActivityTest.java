package com.bordeaux.rgacremote.tests;

import com.bordeaux.rgacremote.ConnectionActivity;
import com.bordeaux.rgacremote.R;

import android.test.ActivityInstrumentationTestCase2;
import android.test.ViewAsserts;
import android.test.suitebuilder.annotation.MediumTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ConnectionActivityTest extends ActivityInstrumentationTestCase2<ConnectionActivity> {

	private ConnectionActivity connectionActivity;
	private TextView titleTextView;
	private TextView ipTextView;
	private Button tryConnectionButton;
	private Button helpButton;
	private EditText ipAddressEditText;

	public ConnectionActivityTest() {
		super(ConnectionActivity.class);
	}


	@Override
	protected void setUp() throws Exception {
		super.setUp();
		connectionActivity = getActivity();
		titleTextView = (TextView) connectionActivity.findViewById(R.id.title_connection);
		ipTextView = (TextView) connectionActivity.findViewById(R.id.text_view_ip);
		tryConnectionButton = (Button) connectionActivity.findViewById(R.id.try_connect_button);
		helpButton = (Button) connectionActivity.findViewById(R.id.connection_help_button);
		ipAddressEditText = (EditText) connectionActivity.findViewById(R.id.ip_address_edit);
	}

	public void testPreconditions() {
		assertNotNull("connectionActivity is null", connectionActivity);
		assertNotNull("titleTextView is null", titleTextView);
		assertNotNull("ipTextView is null", ipTextView);
		assertNotNull("tryConnectionButton is null", tryConnectionButton);
		assertNotNull("helpButton is null", helpButton);
		assertNotNull("ipAddressEditText is null", ipAddressEditText);
	}

	@MediumTest
	public void test_layouts() {
		final View decorView = connectionActivity.getWindow().getDecorView();
		ViewAsserts.assertOnScreen(decorView, tryConnectionButton);
		ViewAsserts.assertOnScreen(decorView, helpButton);
		ViewAsserts.assertOnScreen(decorView, ipAddressEditText);

		//Verify width and heights
		final ViewGroup.LayoutParams layoutParamsTry = tryConnectionButton.getLayoutParams();
		final ViewGroup.LayoutParams layoutParamsHelp = helpButton.getLayoutParams();
		final ViewGroup.LayoutParams layoutParamsEdit = ipAddressEditText.getLayoutParams();
		assertNotNull(layoutParamsTry);
		assertNotNull(layoutParamsHelp);
		assertNotNull(layoutParamsEdit);
		assertEquals(layoutParamsTry.width, WindowManager.LayoutParams.WRAP_CONTENT);
		assertEquals(layoutParamsTry.height, WindowManager.LayoutParams.WRAP_CONTENT);
		assertEquals(layoutParamsHelp.width, WindowManager.LayoutParams.WRAP_CONTENT);
		assertEquals(layoutParamsHelp.height, WindowManager.LayoutParams.WRAP_CONTENT);
		assertEquals(layoutParamsEdit.width, WindowManager.LayoutParams.MATCH_PARENT);
		assertEquals(layoutParamsEdit.height, WindowManager.LayoutParams.WRAP_CONTENT);
	}

}
