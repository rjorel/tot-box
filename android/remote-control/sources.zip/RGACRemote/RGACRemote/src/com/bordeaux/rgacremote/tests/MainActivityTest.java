package com.bordeaux.rgacremote.tests;

import com.bordeaux.rgacremote.MainActivity;
import com.bordeaux.rgacremote.R;

import android.test.ActivityInstrumentationTestCase2;
import android.test.ViewAsserts;
import android.test.suitebuilder.annotation.MediumTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class MainActivityTest extends ActivityInstrumentationTestCase2<MainActivity>{


	private MainActivity mainActivity;
	private TextView titleTextView;
	private TextView infoTextView;
	private Button mainButton;
	
	public MainActivityTest() {
		super(MainActivity.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mainActivity = getActivity();
		titleTextView = (TextView) mainActivity.findViewById(R.id.title_app);
		infoTextView = (TextView) mainActivity.findViewById(R.id.main_info);
		mainButton = (Button) mainActivity.findViewById(R.id.main_connection_button);
	}

	@MediumTest
	public void testPreconditions() {
		assertNotNull("mainActivity is null", mainActivity);
		assertNotNull("titleTextView is null", titleTextView);
		assertNotNull("infoTextView is null", infoTextView);
		assertNotNull("mainButton is null", mainButton);
	}

	@MediumTest
	public void testMainButton_layout() {
		final View decorView = getActivity().getWindow().getDecorView();
		ViewAsserts.assertOnScreen(decorView, mainButton);

		//Verify width and heights
		final ViewGroup.LayoutParams layoutParams = mainButton.getLayoutParams();
		assertNotNull(layoutParams);
		assertEquals(layoutParams.width, WindowManager.LayoutParams.WRAP_CONTENT);
		assertEquals(layoutParams.height, WindowManager.LayoutParams.WRAP_CONTENT);
	}
}
