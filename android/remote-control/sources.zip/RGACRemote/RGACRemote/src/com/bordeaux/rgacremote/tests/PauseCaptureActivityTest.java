package com.bordeaux.rgacremote.tests;

import com.bordeaux.rgacremote.PauseCaptureActivity;
import com.bordeaux.rgacremote.R;

import android.test.ActivityInstrumentationTestCase2;
import android.test.suitebuilder.annotation.MediumTest;
import android.widget.Button;
import android.widget.TextView;

public class PauseCaptureActivityTest extends ActivityInstrumentationTestCase2<PauseCaptureActivity>{

	private PauseCaptureActivity pauseActivity;
	private TextView titleTextView;
	private Button backButton;
	private Button resumeButton;

	public PauseCaptureActivityTest() {
		super(PauseCaptureActivity.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		pauseActivity = getActivity();
		titleTextView = (TextView) pauseActivity.findViewById(R.id.title_pause_capture);
		resumeButton = (Button) pauseActivity.findViewById(R.id.resume_capture_button);
		backButton = (Button) pauseActivity.findViewById(R.id.back_sensors_button);
	}

	@MediumTest
	public void testPreconditions() {
		assertNotNull("pauseActivity is null", pauseActivity);
		assertNotNull("titleTextView is null", titleTextView);
		assertNotNull("backButton is null", backButton);
		assertNotNull("resumeButton is null", resumeButton);
	}
}
