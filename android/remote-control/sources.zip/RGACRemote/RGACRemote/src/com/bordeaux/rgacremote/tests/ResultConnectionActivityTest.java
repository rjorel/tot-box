package com.bordeaux.rgacremote.tests;

import com.bordeaux.rgacremote.R;
import com.bordeaux.rgacremote.ResultConnectionActivity;

import android.test.ActivityInstrumentationTestCase2;
import android.test.suitebuilder.annotation.MediumTest;
import android.widget.TextView;

public class ResultConnectionActivityTest extends ActivityInstrumentationTestCase2<ResultConnectionActivity> {

	
	private ResultConnectionActivity resultActivity;
	private TextView titleTextView;
	private TextView successTextView;
	private TextView failTextView;
	private TextView motionTypeTextView;

	public ResultConnectionActivityTest() {
		super(ResultConnectionActivity.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		resultActivity = getActivity();
		titleTextView = (TextView) resultActivity.findViewById(R.id.title_result_connection);
		successTextView = (TextView) resultActivity.findViewById(R.id.text_view_success);
		failTextView = (TextView) resultActivity.findViewById(R.id.text_view_fail);
		motionTypeTextView = (TextView) resultActivity.findViewById(R.id.type_motion_capture);
	}

	@MediumTest
	public void testPreconditions() {
		assertNotNull("resultActivity is null", resultActivity);
		assertNotNull("titleTextView is null", titleTextView);
		assertNotNull("successTextView is null", successTextView);
		assertNotNull("failTextView is null", failTextView);
		assertNotNull("motionTypeTextView is null", motionTypeTextView);
	}
}
