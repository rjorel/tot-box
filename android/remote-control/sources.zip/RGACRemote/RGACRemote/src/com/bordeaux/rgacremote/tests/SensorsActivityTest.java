package com.bordeaux.rgacremote.tests;

import com.bordeaux.rgacremote.R;
import com.bordeaux.rgacremote.SensorsActivity;

import android.test.ActivityInstrumentationTestCase2;
import android.test.ViewAsserts;
import android.test.suitebuilder.annotation.MediumTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class SensorsActivityTest extends ActivityInstrumentationTestCase2<SensorsActivity>{

	private SensorsActivity sensorsActivity;
	private TextView titleTextView;
	private Button captureButton;
	private Button commandsButton;
	private Button detailsButton;

	public SensorsActivityTest() {
		super(SensorsActivity.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		sensorsActivity = getActivity();
		titleTextView = (TextView) sensorsActivity.findViewById(R.id.title_sensors);
		captureButton = (Button) sensorsActivity.findViewById(R.id.sensors_capture_button);
		commandsButton = (Button) sensorsActivity.findViewById(R.id.sensors_commands_button);
		detailsButton = (Button) sensorsActivity.findViewById(R.id.sensors_details_button);
	}

	@MediumTest
	public void testPreconditions() {
		assertNotNull("sensorsActivity is null", sensorsActivity);
		assertNotNull("titleTextView is null", titleTextView);
		assertNotNull("captureButton is null", captureButton);
		assertNotNull("commandsButton is null", commandsButton);
		assertNotNull("detailsButton is null", detailsButton);
	}
	
	@MediumTest
	public void testMainButton_layout() {
		final View decorView = getActivity().getWindow().getDecorView();
		ViewAsserts.assertOnScreen(decorView, captureButton);

		//Verify width and heights
		final ViewGroup.LayoutParams layoutParams = captureButton.getLayoutParams();
		assertNotNull(layoutParams);
		assertEquals(layoutParams.width, WindowManager.LayoutParams.WRAP_CONTENT);
		assertEquals(layoutParams.height, WindowManager.LayoutParams.WRAP_CONTENT);
	}
}