package com.bordeaux.rgacremote.tests;

import com.bordeaux.rgacremote.R;
import com.bordeaux.rgacremote.SensorsCaptureActivity;

import android.test.ActivityInstrumentationTestCase2;
import android.test.suitebuilder.annotation.MediumTest;
import android.widget.Button;
import android.widget.TextView;

public class SensorsCaptureActivityTest extends ActivityInstrumentationTestCase2<SensorsCaptureActivity>{

	private SensorsCaptureActivity captureActivity;
	private TextView titleTextView;
	private TextView recordingTextView;
	private TextView resultCaptureTextView;
	private Button pauseButton;

	public SensorsCaptureActivityTest() {
		super(SensorsCaptureActivity.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		captureActivity = getActivity();
		titleTextView = (TextView) captureActivity.findViewById(R.id.title_capture);
		recordingTextView = (TextView) captureActivity.findViewById(R.id.text_view_recording);
		resultCaptureTextView = (TextView) captureActivity.findViewById(R.id.text_view_result_capture);
		pauseButton = (Button) captureActivity.findViewById(R.id.pause_capture_button);
	}

	@MediumTest
	public void testPreconditions() {
		assertNotNull("captureActivity is null", captureActivity);
		assertNotNull("titleTextView is null", titleTextView);
		assertNotNull("recordingTextView is null", recordingTextView);
		assertNotNull("resultCaptureTextView is null", resultCaptureTextView);
		assertNotNull("pauseButton is null", pauseButton);
	}
}
