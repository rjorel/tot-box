package server;

import java.awt.AWTException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;

import org.jdom2.JDOMException;

import xml.XMLReader;
import connection.ConnectionException;

public class Controller {

	/**
	 * @attributes view : message displayed on the terminal
	 * @attributes device : control VLC Application
	 * @attributes args : argument of the main programm
	 * @attributes server : server connection
	 * @attributes problem : true initialization to go at least once in the loop
	 * @attributes bindedValues : bind values of event and action to the device
	 */

	private static final int MILLIS_DELAY = 120; // This time should be the same as the server
	private static final int MILLIS_DELAY_FOR_GET_IP = 2000;

	private View view;
	private Device device;
	private String[] args;
	private Server server;
	private Boolean problem = true;
	private HashMap<String, String> bindedValues;

	/**
	 * Controller builder
	 * 
	 * @param args : argument of the main programm
	 */

	public Controller(String[] args) throws AWTException {
		this.args = args;

		device = new Device();
		view = new View();

		bindedValues = new HashMap<String, String>();
	}

	/**
	 * This function display Ip Address every 2 seconds.
	 */
	public void giveIp() {
		Thread t = new Thread() {
			public void run() {
				while (true) {

					try {
						InetAddress address = InetAddress.getLocalHost();
						view.setIpAddress(address.toString(), true);
					} catch (UnknownHostException e1) {
						view.setIpAddress(
								"You are not connected to your local network",
								false);
					}
					try {
						Thread.sleep(MILLIS_DELAY_FOR_GET_IP);
					} catch (Exception e) {
						e.printStackTrace();
					}

				}
			}
		};
		t.start();
	}

	/**
	 * Analysis config file put in args files.
	 */
	public void analysisConfig() {
		XMLReader xmlSmartphone = null;
		XMLReader xmlDevice = null;
		String message = "";
		try {
			xmlSmartphone = new XMLReader(args[0], new String[] { "event",
					"number", "id" });
			xmlDevice = new XMLReader(args[1], new String[] { "id", "action" });

		} catch (JDOMException e) {
			System.err.println("Invalid XML file !");
			System.exit(-2);
		} catch (IOException e) {
			System.err.println("File not found !");
			System.exit(-3);
		}

		xmlSmartphone.build();
		xmlDevice.build();

		ArrayList<String[]> IdToEvent = xmlSmartphone.getData();
		ArrayList<String[]> EventToDevice = xmlDevice.getData();

		for (String[] i : IdToEvent)
			message += i[0] + "," + i[1] + "," + i[2] + ";";

		server.toBeSent(message);

		for (String[] e : EventToDevice)
			bindedValues.put(e[0], e[1]);

	}

	/**
	 * Start the server, if there is a problem, this function try to restart the
	 * server.
	 */
	public void startServer() {
		if (server == null) {
			while (problem) {
				try {
					server = new Server();
					problem = false;
				} catch (ConnectionException e2) {
					view.setConnectionStatus(
							"A other software use this port, close this software.",
							false);
					try {
						Thread.sleep(MILLIS_DELAY);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					problem = true;
				}
			}
			Thread t = new Thread() {

				public void run() {
					try {
						server.run();
					} catch (IOException e) {
						e.printStackTrace();
					}

				}
			};
			t.start();

		}
	}

	/**
	 * Retrieves information of server, analyse it and call a method of device.
	 */
	public void dataProcessing() {
		Thread t = new Thread() {
			public void run() {
				while (true) {
					try {
						Thread.sleep(MILLIS_DELAY);
					} catch (Exception e) {
					}

					if (server != null) {
						String connectionStatus = server.getConnectionStatus();
						String receiveInformation = server.getReceiveInformation();
						view.setConnectionStatus(connectionStatus, true);
						view.setReceivedInformation(receiveInformation, true);

						String act = bindedValues.get(receiveInformation);
						if (act == null)
							continue;

						System.out.println(act);

						if (act.equals("PLAY_PAUSE"))
							device.playPause();
						if (act.equals("VOLUME_UP"))
							device.volume(true);
						if (act.equals("VOLUME_DOWN"))
							device.volume(false);
						if (act.equals("FORWARD"))
							device.backForward(false);
						if (act.equals("BACK"))
							device.backForward(true);
						if (act.equals("FULLSCREEN"))
							device.fullScreen();
						if (act.equals("INFORMATION_OF_MEDIA"))
							device.informationOfMedia();
					}
				}
			}
		};
		t.start();
	}
}
