package server;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

public class Device implements IDevice {
	private Robot robot;
	private String os;
	private int intensity = 1;

	public Device() throws AWTException {
		robot = new Robot();
		os = System.getProperty("os.name");
		robot.setAutoDelay(100);
		robot.setAutoWaitForIdle(true);

	}

	public void volume(boolean up) {
		if (up) {
			if (os.equals("Mac OS X")) {
				robot.keyPress(KeyEvent.VK_META);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_UP);
					robot.keyRelease(KeyEvent.VK_UP);
				}
				robot.keyRelease(KeyEvent.VK_META);
			} else {
				robot.keyPress(KeyEvent.VK_CONTROL);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_UP);
					robot.keyRelease(KeyEvent.VK_UP);
				}
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}
		} else {
			if (os.equals("Mac OS X")) {
				robot.keyPress(KeyEvent.VK_META);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_DOWN);
					robot.keyRelease(KeyEvent.VK_DOWN);
				}
				robot.keyRelease(KeyEvent.VK_META);
			} else {
				robot.keyPress(KeyEvent.VK_CONTROL);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_DOWN);
					robot.keyRelease(KeyEvent.VK_DOWN);
				}
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}
		}
	}

	public void backForward(boolean back) {
		if (back) {
			if (os.equals("Mac OS X")) {
				robot.keyPress(KeyEvent.VK_META);
				robot.keyPress(KeyEvent.VK_ALT);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_LEFT);
					robot.keyRelease(KeyEvent.VK_LEFT);
				}
				robot.keyRelease(KeyEvent.VK_META);
				robot.keyRelease(KeyEvent.VK_ALT);

			} else {
				robot.keyPress(KeyEvent.VK_CONTROL);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_LEFT);
					robot.keyRelease(KeyEvent.VK_LEFT);
				}
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}
		} else {
			if (os.equals("Mac OS X")) {
				robot.keyPress(KeyEvent.VK_META);
				robot.keyPress(KeyEvent.VK_ALT);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_RIGHT);
					robot.keyRelease(KeyEvent.VK_RIGHT);
				}
				robot.keyRelease(KeyEvent.VK_ALT);
				robot.keyRelease(KeyEvent.VK_META);
			} else {
				robot.keyPress(KeyEvent.VK_CONTROL);
				for (int i = 0; i < this.intensity; i++) {
					robot.keyPress(KeyEvent.VK_RIGHT);
					robot.keyRelease(KeyEvent.VK_RIGHT);
				}
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}
		}
	}

	public void playPause() {
		robot.keyPress(KeyEvent.VK_SPACE);
		robot.keyRelease(KeyEvent.VK_SPACE);
	}

	public void fullScreen() {
		if (os.equals("Mac OS X")) {
			robot.keyPress(KeyEvent.VK_META);
			robot.keyPress(KeyEvent.VK_F);
			robot.keyRelease(KeyEvent.VK_F);
			robot.keyRelease(KeyEvent.VK_META);
		} else {
			robot.keyPress(KeyEvent.VK_F11);
			robot.keyRelease(KeyEvent.VK_F11);
		}
	}

	public void informationOfMedia() {
		if (os.equals("Mac OS X")) {
			robot.keyPress(KeyEvent.VK_META);
			robot.keyPress(KeyEvent.VK_I);
			robot.keyRelease(KeyEvent.VK_I);
			robot.keyRelease(KeyEvent.VK_META);
		} else {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_I);
			robot.keyRelease(KeyEvent.VK_I);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
	}

	public void setIntensity(int intensity) {
		if (intensity < 10 && intensity > 0)
			this.intensity = intensity;
		if (intensity >= 10)
			this.intensity = 10;
		if (intensity <= 0)
			this.intensity = 1;
	}

}
