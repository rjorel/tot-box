package server;

/*
 * This is the interface to control VLC application
 */

public interface IDevice {

	/**
	 * Control volume of VLC application
	 * 
	 * @param up : Up the volume when up is true, down the volume when up is
	 *            false
	 */

	public void volume(boolean up);

	/**
	 * Forward or backward in the media
	 * 
	 * @param back : back into the media when back is true, forward when back is
	 *            false
	 */

	public void backForward(boolean back);

	/**
	 * Play or pause the media
	 */

	public void playPause();

	/**
	 * Enable full screen in VLC
	 */

	public void fullScreen();

	/**
	 * Show information about media
	 */

	public void informationOfMedia();

	/**
	 * Set intensity to volume and backFoward
	 * 
	 * @param intensity : intensity should be between 1 and 10
	 */

	public void setIntensity(int intensity);
}
