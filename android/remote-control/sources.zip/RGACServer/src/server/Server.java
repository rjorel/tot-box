package server;

import java.awt.AWTException;
import java.io.IOException;

import connection.ConnectionException;
import connection.ServerConnection;

public class Server {

	/**
	 * @attribute connection : connection of the server.
	 * @attribute receiveInformation : all information receive by server go
	 *            here.
	 * @attribute connectionStatus : all information about status of connection
	 *            go here.
	 * @attribute message : message to be sent to smartphone.
	 * 
	 */

	private static final int MILLIS_DELAY = 120;
	private ServerConnection connection;
	private String receiveInformation;
	private String connectionStatus;
	private String message = "";

	/**
	 * Server builder
	 */

	public Server() throws ConnectionException {
		connection = new ServerConnection();
		receiveInformation = "";
		connectionStatus = "Waiting for connection...";
	}

	/**
	 * Message to be sent to smartphone.
	 * 
	 * @param s : String message
	 */
	public void toBeSent(String s) {
		if (s != null)
			message = s;
	}

	/**
	 * Accept the connection and retrieves information
	 * @throws IOException
	 */
	public void run() throws IOException {
		while (true) {
			connectionStatus = "Waiting for connection...";
			try {
				Thread.sleep(MILLIS_DELAY);
			} catch (Exception e) {
				;
			}
			connection.accept();
			connectionStatus = "Connection accepted";

			try {
				connection.send(message);
			} catch (ConnectionException e1) {
				connectionStatus = "Send fails";
			}

			Thread t = new Thread() {
				public void run() {
					while (true) {
						receiveInformation = "";
						String information = null;
						try {
							information = connection.receive();
						} catch (ConnectionException e) {
							connectionStatus = "Receive fails";
							Thread.yield();
						}
						if (information != null) {
							receiveInformation = information;
						}
						try {
							Thread.sleep(MILLIS_DELAY);
						} catch (Exception e) {
							;
						}
					}
				}
			};
			t.start();
		}
	}

	public synchronized String getReceiveInformation() {
		return receiveInformation;
	}

	public synchronized String getConnectionStatus() {
		return connectionStatus;
	}

	/**
	 * Main Function
	 * 
	 * @param args[0] : Path of config event smartphone xml file.
	 * @param args[1] : Path of config Event device xml file.
	 */
	public static void main(String[] args) throws AWTException {
		if (args.length < 2 || args.length > 2) {
			System.err
					.println("Usage : RGACServer confEventsToSmartphone.conf confEventsToDevice.conf");
			System.exit(-1);
		}
		Controller c = new Controller(args);
		c.startServer();
		c.giveIp();
		c.analysisConfig();
		c.dataProcessing();
	}
}