package server;

public class View {

	/**
	 * @attributes oldIpAddress : keeps the old IP address to don't display
	 *             several times the same line.
	 * @attributes oldConnectionStatus : keep the old Connection Status to don't
	 *             display several times the same line.
	 */

	private static final String connectionStatusTitle = "Connection Status : ";
	private static final String ipAddressTitle = "Ip Address : ";
	private static final String receiveInformationTitle = "Receive Information : ";

	private String oldIpAddress = "";
	private String oldConnectionStatus = "";

	/**
	 * Display a welcome message on the console.
	 */
	public View() {
		System.out.println("Welcome to RGACServer");
	}

	/**
	 * Display connection status on the console.
	 * 
	 * @param connectionStatus : message you want to see on the console.
	 * @param ok : display on error output or not.
	 */
	public void setConnectionStatus(String connectionStatus, Boolean ok) {
		if (!connectionStatus.equals(oldConnectionStatus)) {
			if (ok)
				System.out.println(connectionStatusTitle + connectionStatus);
			if (!ok)
				System.err.println(connectionStatusTitle + connectionStatus);
		}
		oldConnectionStatus = connectionStatus;
	}

	/**
	 * Display received information on the console.
	 * 
	 * @param receiveInformation : message you want to see on the console.
	 * @param ok : display on error output or not.
	 */
	public void setReceivedInformation(String receiveInformation, Boolean ok) {
		if (!receiveInformation.equals("")) {
			if (ok)
				System.out
						.println(receiveInformationTitle + receiveInformation);
			if (!ok)
				System.err
						.println(receiveInformationTitle + receiveInformation);
		}
	}

	/**
	 * Display ip address on the console.
	 * 
	 * @param ipAddress : message you want to see on the console.
	 * @param ok : display on error output or not.
	 */
	public void setIpAddress(String ipAddress, Boolean ok) {
		if (!ipAddress.equals(oldIpAddress)) {
			if (ok)
				System.out.println(ipAddressTitle + ipAddress);
			if (!ok)
				System.err.println(ipAddressTitle + ipAddress);
		}
		oldIpAddress = ipAddress;
	}

}