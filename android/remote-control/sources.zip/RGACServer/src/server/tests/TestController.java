package server.tests;

import static org.junit.Assert.*;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.JFrame;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import server.Controller;
import connection.ClientConnection;
import connection.ConnectionException;

public class TestController extends JFrame implements KeyListener{
	
	/**
	 * Be careful, when you execut this test, DO NOT PRESS A KEY ON KEYBOARD
	 * AND be careful, you don't have to to have the operating system reacts to these keyboard shortcuts !!
	 */
	private static final long serialVersionUID = 1L;
	// you have to put here config files of driver
	private static String[] args = new String[] {"/Users/craig/Dropbox/Semestre 8/Projet de Programmation/projet-eclipse/eclipse/RGACDriver/src/xml/confEventsToSmartphone.xml",
			"/Users/craig/Dropbox/Semestre 8/Projet de Programmation/projet-eclipse/eclipse/RGACDriver/src/xml/confEventsToDevice.xml"};
	private static ClientConnection c;
	private static String message = "";
	private static String localhost = "127.0.0.1"; 
	private static 	int numberOfRandomMessage = 10;
	private static final int MILLIS_DELAY_CLIENT = 200;
	private static final int MILLIS_DELAY_FOR_RECEIVE_KEYEVENT = 1000;
	private static int min = -4;
	private static int max = 42;
	private static int[] table = new int[3];
	private static int index = 0;
	
	public TestController(){
		super("name");
        setVisible(true);
        addKeyListener(this);
	}
	
	/**
	 * Launch server
	 * @throws Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		Controller c = new Controller(args);
		c.startServer();
		c.giveIp();
		c.analysisConfig();
		c.dataProcessing();
		new TestController();
        System.setProperty("os.name","Mac OS X");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test if the servers send good event to smartphone
	 * Then, client send random values to server
	 * @throws ConnectionException
	 * @throws InterruptedException
	 */
	@Test
	public void test() throws ConnectionException, InterruptedException {
		c = new ClientConnection(localhost);
		String event = c.receive();
		assertTrue(event.equals("ACC_HIT,1,0;ACC_HIT,2,1;ACC_HIT,3,2;ACC_LEFT,1,3;ACC_RIGHT,1,4;ACC_UP,1,5;ACC_DOWN,1,6;MIC_HIGH,1,7;"));
		Thread.sleep(2000);
		
		 //test value
		initializeTable();
		
		message ="0";
		c.send(message);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{32,0,0});
		initializeTable();
		
		message ="1"; 
		c.send(message);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,70,0});
		initializeTable();
		
		message ="2";  
		c.send(message);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,73,0});
		initializeTable();
		
		message ="3"; 
		c.send(message);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,18,37});
		initializeTable();
		
		message ="4"; 
		c.send(message);

		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,18,39});
		initializeTable();
		
		message ="5"; 
		c.send(message);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,38,0});
		initializeTable();
		
		message ="6"; 
		c.send(message);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,40,0});
		initializeTable();
		
		// random int value
		for (int i = 0; i < numberOfRandomMessage; i++) {
			initializeTable();
			Double random = min + (Math.random() * (max - min));
			System.out.println(random.intValue());
			message = "";
			message += random.intValue();
			c.send(message);
			try {
				Thread.sleep(MILLIS_DELAY_CLIENT);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		Thread.sleep(1000);
		
		//random double value
		for (int i = 0; i < numberOfRandomMessage; i++) {
			Double random = min + (Math.random() * (max - min));
			System.out.println(random);
			message = "";
			message += random;
			c.send(message);
			try {
				Thread.sleep(MILLIS_DELAY_CLIENT);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		Thread.sleep(1000);
		
		//random string value
		for (int i = 0; i < numberOfRandomMessage; i++) {
			char[] chars = "abcdefghijklmnopqrstuvwxyz\n\r".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int j = 0; j < 20; j++) {
			    char randomString = chars[random.nextInt(chars.length)];
			    sb.append(randomString);
			}
			System.out.println(sb);
			message = "";
			message += sb;
			c.send(message);
			
			try {
				Thread.sleep(MILLIS_DELAY_CLIENT);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void initializeTable(){
		index=0;
		for (int i=0; i<table.length; i++)
			table[i]=0;
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		table[index]=e.getKeyCode();
		index++;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}