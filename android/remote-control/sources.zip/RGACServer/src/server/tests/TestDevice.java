package server.tests;

import static org.junit.Assert.*;

import java.awt.AWTException;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import server.Device;

public class TestDevice extends JFrame implements KeyListener {
	/**
	 * Be careful, when you execut this test, DO NOT PRESS A KEY ON KEYBOARD
	 * AND be careful, you don't have to to have the operating system reacts to these keyboard shortcuts !!
	 */
	private static final long serialVersionUID = 1L;
	private static Device device;
	private static int[] table = new int[3];
	private static int index = 0;
	private static final int MILLIS_DELAY_FOR_RECEIVE_KEYEVENT = 400;	


	public TestDevice(){
		super("name");
        setVisible(true);
        addKeyListener(this);

	}
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		new TestDevice();
		device = new Device();
		device.setIntensity(-1);
        System.setProperty("os.name","Mac OS X");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws InterruptedException, AWTException {
		// test MAC OS X shortcuts
		initializeTable();
		
		device.volume(true);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,38,0});
		initializeTable();
		
		device.volume(false);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,40,0});
		initializeTable();
		
		device.backForward(true);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,18,37});
		initializeTable();
		
		device.backForward(false);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,18,39});
		initializeTable();
		
		device.playPause();
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{32,0,0});
		initializeTable();
		
		device.informationOfMedia();
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,73,0});
		initializeTable();
		
		device.fullScreen();
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{157,70,0});
		initializeTable();
		
		// test linux and windows shortcuts
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
        System.setProperty("os.name","Linux");
        device = new Device();
		device.setIntensity(1);
        
        device.volume(true);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{17,38,0});
		initializeTable();
		
		device.volume(false);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{17,40,0});
		initializeTable();
		
		device.backForward(true);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{17,37,0});
		initializeTable();
		
		device.backForward(false);
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{17,39,0});
		initializeTable();
		
		device.playPause();
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{32,0,0});
		initializeTable();
		
		device.informationOfMedia();
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{17,73,0});
		initializeTable();
		
		device.fullScreen();
		Thread.sleep(MILLIS_DELAY_FOR_RECEIVE_KEYEVENT);
		assertArrayEquals(table, new int[]{122,0,0});
		initializeTable();
        
	}
		
	public void initializeTable(){
		index=0;
		for (int i=0; i<table.length; i++)
			table[i]=0;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		table[index]=e.getKeyCode();
		index++;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
