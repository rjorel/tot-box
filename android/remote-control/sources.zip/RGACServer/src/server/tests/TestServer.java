package server.tests;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import server.Server;
import connection.ClientConnection;
import connection.ConnectionException;

public class TestServer {
	private static Server server;
	private static ClientConnection c;
	private static String test ="";
	private static String message = "";
	private static String localhost = "127.0.0.1";
	private static final int MILLIS_DELAY = 120;
	private static final int MILLIS_DELAY_CLIENT = 200;
	private static final int MILLIS_DELAY_FOR_WAIT_SERVER = 400;
	private static final int numberOfMessage = 10;
	
	/**
	 * Send 10 messages every 200 ms
	 * @throws ConnectionException
	 * @throws IOException
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws ConnectionException, IOException {
		server = new Server();
		server.toBeSent("OK");
		Thread t = new Thread() {
			public void run() {
				try {

					server.run();
				} catch (IOException e) {
					e.printStackTrace();
					
				}

			}
		};
		assertTrue(server.getConnectionStatus().equals("Waiting for connection..."));
		t.start();
		c = new ClientConnection(localhost);
		try {
			Thread.sleep(MILLIS_DELAY_FOR_WAIT_SERVER);
		} catch (InterruptedException e2) {
		}
		//assertTrue(server.getConnectionStatus().equals("Connection accepted"));

		Thread t2 = new Thread() {
			public void run() {
				try {
					for (int i = 0; i < numberOfMessage; i++) {
						message ="";
						message += i;
						c.send(message);
						try {
							Thread.sleep(MILLIS_DELAY_CLIENT);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				} catch (ConnectionException e1) {
					e1.printStackTrace();
				}
			}
		};
		t2.start();

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Client receive one message from server then the server receive 10 message of the client.
	 * @throws ConnectionException
	 * @throws IOException
	 */
	@Test
	public void test() throws ConnectionException, IOException {
		test = c.receive();
		assertTrue(test.equals("OK"));
		int i=0;
		while (i!=numberOfMessage) {
			String information = server.getReceiveInformation();
			System.out.println(information);

			if (!information.equals("")) {
				System.out.println(i);
				assertTrue(information.equals(Integer.toString(i)));
				if (information.equals(Integer.toString(i))) 
					i++;
			}
			try {
				Thread.sleep(MILLIS_DELAY);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
