package xml;
import java.io.IOException;
import java.util.ArrayList;

import org.jdom2.JDOMException;


class Main
{
    public static void main(String[] args) throws JDOMException, IOException
    {

        XMLReader xml;
        xml = new XMLReader("src/xml/conf.xml", new String[] { "event", "number", "id" });  // path is invalid I think.
        xml.build();
        
        ArrayList<String[]> l = xml.getData();
        
        for (String[] m: l)
            System.out.println(m[0] + ", " + m[1] + ", " + m[2]);
    }
}
