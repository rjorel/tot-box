package xml;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;


public class XMLReader
{
    /**
     * Default name of entry in XML file.
     */
    
    private static final String ENTRY = "entry";

    
    /**
     * @attribute sax: objet to read an XML file.
     * @attribute doc: objet which represent the XML file.
     * @attribute root: root node of the XML file.
     * @attribute listElements: list of elements labeled by ENTRY value.
     * @attribute elementNames: node name in each ENTRY.
     * @attribute listData: list of string array read in the XML file.*
     */
    
    private SAXBuilder sax;
    private Document doc;
    private Element root;
    private List<Element> listElements;
    private String[] elementNames;
    private ArrayList<String[]> listData;
    
    
    /**
     * Builder.
     * @param file: file to read.
     * @param elts: name of data to read.
     */
    
    public XMLReader(String file, String[] elts) throws JDOMException, IOException
    {
        sax = new SAXBuilder();
        doc = sax.build(new File(file));
        root = doc.getRootElement();
        listElements = root.getChildren(ENTRY);
        
        listData = new ArrayList<String[]>();
        elementNames = elts;
    }
    
    
    /**
     * Read the XML file to extract the data.
     */
    
    public void build()
    {
        for (Element elt: listElements) {
            String[] strs = new String[elementNames.length];
            
            for (int i = 0 ; i < elementNames.length ; i++) 
               strs[i] = elt.getChild(elementNames[i]).getText();
            
            listData.add(strs);
        }
    }
    
    
    public ArrayList<String[]> getData()
    {
        return listData;
    }
}
