#!/bin/bash

sudo make upload && sudo miniterm.py /dev/ttyACM0
