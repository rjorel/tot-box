#include <avr/eeprom.h>

#include "EEPROM_Ex.h"


void EEPROM_Ex_Class::read(int addr, uint8_t &dst)
{
    dst = eeprom_read_byte((uint8_t *) addr);
}

void EEPROM_Ex_Class::read(int addr, uint16_t &dst)
{
    dst = eeprom_read_word((uint16_t *) addr);
}

void EEPROM_Ex_Class::read(int addr, uint32_t &dst)
{
    dst = eeprom_read_dword((uint32_t *) addr);
}

void EEPROM_Ex_Class::read(int addr, float &dst)
{
    dst = eeprom_read_float((float *) addr);
}

void EEPROM_Ex_Class::read(int addr, void *dst, size_t size)
{
    eeprom_read_block((void *) addr, dst, size);
}

void EEPROM_Ex_Class::write(int addr, uint8_t src)
{
    eeprom_write_byte((uint8_t *) addr, src);
}

void EEPROM_Ex_Class::write(int addr, uint16_t src)
{
    eeprom_write_word((uint16_t *) addr, src);
}

void EEPROM_Ex_Class::write(int addr, uint32_t src)
{
    eeprom_write_dword((uint32_t *) addr, src);
}

void EEPROM_Ex_Class::write(int addr, float src)
{
    eeprom_write_float((float *) addr, src);
}

void EEPROM_Ex_Class::write(int addr, void *src, size_t size)
{
    eeprom_write_block((void *) addr, src, size);
}

void EEPROM_Ex_Class::update(int addr, uint8_t src)
{
    eeprom_update_byte((uint8_t *) addr, src);
}

void EEPROM_Ex_Class::update(int addr, uint16_t src)
{
    eeprom_update_word((uint16_t *) addr, src);
}

void EEPROM_Ex_Class::update(int addr, uint32_t src)
{
    eeprom_update_dword((uint32_t *) addr, src);
}

void EEPROM_Ex_Class::update(int addr, float src)
{
    eeprom_update_float((float *) addr, src);
}

void EEPROM_Ex_Class::update(int addr, void *src, size_t size)
{
    eeprom_update_block((void *) addr, src, size);
}

EEPROM_Ex_Class EEPROM_Ex;