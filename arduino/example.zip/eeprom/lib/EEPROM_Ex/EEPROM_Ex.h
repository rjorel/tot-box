#ifndef __EEPROM_EX_H_
#define __EEPROM_EX_H_

class EEPROM_Ex_Class
{
public:
    /*
     * Simple overrides of existing AVR functions.
     */
    void read(int addr, uint8_t &dst);
    void read(int addr, uint16_t &dst);
    void read(int addr, uint32_t &dst);
    void read(int addr, float &dst);
    void read(int addr, void *dst, size_t size);

    void write(int addr, uint8_t src);
    void write(int addr, uint16_t src);
    void write(int addr, uint32_t src);
    void write(int addr, float src);
    void write(int addr, void *src, size_t size);

    void update(int addr, uint8_t src);
    void update(int addr, uint16_t src);
    void update(int addr, uint32_t src);
    void update(int addr, float src);
    void update(int addr, void *src, size_t size);
};

extern EEPROM_Ex_Class EEPROM_Ex;

#endif
