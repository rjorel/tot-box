#include "EEPROM_Ex.h"

void setup()
{
#ifdef DEBUG
    Serial.begin(9600);
    Serial.println("Debug mode");
#endif

    unsigned int test;
    EEPROM_Ex.read(10, test);
}

void loop()
{
#ifdef DEBUG
    Serial.println("New turn");
#endif
}