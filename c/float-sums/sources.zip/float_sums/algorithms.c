#include <stdio.h>
#include <math.h>
#include <string.h>

#include "algorithms.h"


double A1(double *values, int n) {
    double result = 0.0;

    for (int i = 0; i < n; i++) {
        result += values[i];
    }

    return result;
}

double A2(double *values, int n) {
    double result = 0.0;

    for (int i = n - 1; i >= 0; i--) {
        result += values[i];
    }

    return result;
}

double A3(double *values, int n) {
    int offset = 0;
    double result = 0.0;

    double aux[n];

    for (int i = 0; i < n; i++) {
        if (values[i] >= 0) {
            result += values[i];
        } else {
            aux[offset++] = values[i];
        }
    }

    for (int i = 0; i < offset; i++) {
        result += aux[i];
    }

    return result;
}

double A4(double *values, int n) {
    int offset = 0;
    double res = 0.0;

    double aux[n];

    for (int i = 0; i < n; i++) {
        if (values[i] < 0) {
            res += values[i];
        } else {
            aux[offset++] = values[i];
        }
    }

    for (int i = 0; i < offset; i++) {
        res += aux[i];
    }

    return res;
}

double A5(double *values, int n) {
    double negative_result = 0.0;
    double positive_result = 0.0;

    for (int i = 0; i < n; i++) {
        if (values[i] < 0) {
            negative_result += values[i];
        } else {
            positive_result += values[i];
        }
    }

    return negative_result + positive_result;
}

double A6(double *values, int n) {
    double result = 0.0;

    double aux[n];
    memcpy(aux, values, n * sizeof(double));

    // Sort.
    for (int i = 0, j; i < n; i++) {
        double tmp = aux[i];

        for (j = i; j > 0 && aux[j - 1] > tmp; j--) {
            aux[j] = aux[j - 1];
        }

        aux[j] = tmp;
    }

    for (int i = 0; i < n; i++) {
        result += aux[i];
    }

    return result;
}

double A7(double *values, int n) {
    double result = 0.0;

    double aux[n];
    memcpy(aux, values, n * sizeof(double));

    // Sort.
    for (int i = 0, j; i < n; i++) {
        double tmp = aux[i];

        for (j = i; j > 0 && aux[j - 1] < tmp; j--) {
            aux[j] = aux[j - 1];
        }

        aux[j] = tmp;
    }

    for (int i = 0; i < n; i++) {
        result += aux[i];
    }

    return result;
}

double A8(double *values, int n) {
    double result = 0.0;

    double aux[n];
    memcpy(aux, values, n * sizeof(double));

    // Sort.
    for (int i = 0, j; i < n; i++) {
        double tmp = aux[i];

        for (j = i; j > 0 && fabs(aux[j - 1]) > fabs(tmp); j--) {
            aux[j] = aux[j - 1];
        }

        aux[j] = tmp;
    }

    for (int i = 0; i < n; i++) {
        result += aux[i];
    }

    return result;
}

double A9(double *values, int n) {
    double result = 0.0;

    double aux[n];
    memcpy(aux, values, n * sizeof(double));

    // Sort.
    for (int i = 0, j; i < n; i++) {
        double tmp = aux[i];

        for (j = i; j > 0 && fabs(aux[j - 1]) < fabs(tmp); j--) {
            aux[j] = aux[j - 1];
        }

        aux[j] = tmp;
    }

    for (int i = 0; i < n; i++) {
        result += aux[i];
    }

    return result;
}

double A10(double *values, int n) {
    double result = 0.0;

    double aux[n];
    memcpy(aux, values, n * sizeof(double));

    // Sort.
    for (int i = 0, j; i < n; i++) {
        double tmp = aux[i];

        for (j = i; j > 0 && aux[j - 1] > tmp; j--) {
            aux[j] = aux[j - 1];
        }

        aux[j] = tmp;
    }

    int i, j;
    for (i = 0, j = 0; i < n && values[i] < 0; i++, j++) {
        //
    }

    for (; i < n; i++) {
        result += aux[i];
    }

    for (i = 0; i < j; i++) {
        result += aux[i];
    }

    return result;
}

double A11(double *values, int n) {
    double aux[n];
    memcpy(aux, values, n * sizeof(double));

    while (n > 1) {
        int i;
        for (i = 0; i < n / 2; i++) {
            aux[i] = aux[i * 2] + aux[i * 2 + 1];
        }

        // If the number of operands is even.
        if (n & 1) {
            aux[i] = aux[i * 2];
        }

        n = (n + 1) / 2;
    }

    return aux[0];
}

double A12(double *values, int n) {
    double aux[n];
    memcpy(aux, values, n * sizeof(double));

    for (int i = 0, j; i < n; i++) {
        double tmp = aux[i];

        for (j = i; j > 0 && fabs(aux[j - 1]) > fabs(tmp); j--) {
            aux[j] = aux[j - 1];
        }

        aux[j] = tmp;
    }

    for (int i = 0, j; i < n - 1; i++) {
        double result = aux[i] + aux[i + 1];

        aux[i + 1] = result;

        for (j = i + 1; j < n && fabs(result) > fabs(aux[j]); j++) {
            aux[j - 1] = aux[j];
        }

        aux[j - 1] = result;
    }

    return aux[n - 1];
}
