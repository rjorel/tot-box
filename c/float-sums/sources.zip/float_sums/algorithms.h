#ifndef DEF_ALGORITHMS
#define DEF_ALGORITHMS

double A1(double *values, int n);
double A2(double *values, int n);
double A3(double *values, int n);
double A4(double *values, int n);
double A5(double *values, int n);
double A6(double *values, int n);
double A7(double *values, int n);
double A8(double *values, int n);
double A9(double *values, int n);
double A10(double *values, int n);
double A11(double *values, int n);
double A12(double *values, int n);

#endif
