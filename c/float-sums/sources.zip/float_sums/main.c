#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <math.h>

#include "algorithms.h"


#define NUM_CONDITIONINGS           11
#define NUM_FILES_BY_CONDITIONING   4
#define NUM_ALGORITHMS              12

static const char *file_names[NUM_CONDITIONINGS][NUM_FILES_BY_CONDITIONING] = {
    { "TD7-File01-N100-C10e3.txt",  "TD7-File02-N100-C10e3.txt",  "TD7-File03-N100-C10e3.txt",  "TD7-File04-N100-C10e3.txt" },
    { "TD7-File05-N100-C10e6.txt",  "TD7-File06-N100-C10e6.txt",  "TD7-File07-N100-C10e6.txt",  "TD7-File08-N100-C10e6.txt" },
    { "TD7-File09-N100-C10e9.txt",  "TD7-File10-N100-C10e9.txt",  "TD7-File11-N100-C10e9.txt",  "TD7-File12-N100-C10e9.txt" },
    { "TD7-File13-N100-C10e12.txt", "TD7-File14-N100-C10e12.txt", "TD7-File15-N100-C10e12.txt", "TD7-File16-N100-C10e12.txt" },
    { "TD7-File17-N100-C10e15.txt", "TD7-File18-N100-C10e15.txt", "TD7-File19-N100-C10e15.txt", "TD7-File20-N100-C10e15.txt" },
    { "TD7-File21-N100-C10e16.txt", "TD7-File22-N100-C10e16.txt", "TD7-File23-N100-C10e16.txt", "TD7-File24-N100-C10e16.txt" },
    { "TD7-File25-N100-C10e18.txt", "TD7-File26-N100-C10e18.txt", "TD7-File27-N100-C10e18.txt", "TD7-File28-N100-C10e18.txt" },
    { "TD7-File29-N100-C10e20.txt", "TD7-File30-N100-C10e20.txt", "TD7-File31-N100-C10e20.txt", "TD7-File32-N100-C10e20.txt" },
    { "TD7-File33-N100-C10e24.txt", "TD7-File34-N100-C10e24.txt", "TD7-File35-N100-C10e24.txt", "TD7-File36-N100-C10e24.txt" },
    { "TD7-File37-N100-C10e28.txt", "TD7-File38-N100-C10e28.txt", "TD7-File39-N100-C10e28.txt", "TD7-File40-N100-C10e28.txt" },
    { "TD7-File41-N100-C10e32.txt", "TD7-File42-N100-C10e32.txt", "TD7-File43-N100-C10e32.txt", "TD7-File44-N100-C10e32.txt" }
};

static const int conditionings[NUM_CONDITIONINGS] = {
    3, 6, 9, 12, 15, 16, 18, 20, 24, 28, 32
};

static double (*algorithms[NUM_ALGORITHMS])(double *, int) = {
    A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12
};

static enum {
    MEANS, MAX
};

static int real_bit_error_precise(double d1, double d2) {
    long long i_d1 = *(long long *) &d1;
    long long i_d2 = *(long long *) &d2;

    int i = 1;

    while (((i_d1 >> (53 - i)) & 1) == ((i_d2 >> (53 - i)) & 1) && i <= 53) {
        i++;
    }

    return i - 1;
}

static int number_lost_bits(double d1, double d2) {
    return 53 - real_bit_error_precise(d1, d2);
}

static double *get_information(const char *filename, int *n, double *cond, double *exact_result) {
    char path[128];
    snprintf(path, 128, DATA_DIR"/%s", filename);

    FILE *file = fopen(path, "r");

    if (file == NULL) {
        return NULL;
    }

    fscanf(file, "%d %lf", n, cond);

    double *values = malloc(*n * sizeof(double));

    for (int i = 0; i < *n; i++) {
        fscanf(file, "%lf", &values[i]);
    }

    fscanf(file, "%lf", exact_result);
    fclose(file);

    return values;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        return EXIT_FAILURE;
    }

    int mode;

    if (strcmp(argv[1], "--means") == 0) {
        mode = MEANS;
    } else if (strcmp(argv[1], "--max") == 0) {
        mode = MAX;
    } else {
        return EXIT_FAILURE;
    }

    for (int cond_offset = 0; cond_offset < NUM_CONDITIONINGS; cond_offset++) {
        int lost_bits[NUM_ALGORITHMS] = { 0 };

        for (int file_num = 0; file_num < NUM_FILES_BY_CONDITIONING; file_num++) {
            double cond, exact_result;
            int n;

            double *values = get_information(
                file_names[cond_offset][file_num], &n, &cond, &exact_result
            );

            for (int i = 0; i < NUM_ALGORITHMS; i++) {
                double result = algorithms[i](values, n);
                int bits = number_lost_bits(exact_result, result);

                if (mode == MEANS) {
                    lost_bits[i] += bits;
                } else {
                    if (bits > lost_bits[i]) {
                        lost_bits[i] = bits;
                    }
                }
            }

            free(values);
        }

        double result = conditionings[cond_offset] / log10(2);

        int power = ((result - (int) result) < 0.5)
            ? (int) floor(result)
            : (int) ceil(result);

        printf("%d ", power);

        for (int i = 0; i < NUM_ALGORITHMS; i++) {
            printf(
                "%d ", (mode == MEANS)
                    ? lost_bits[i] / NUM_FILES_BY_CONDITIONING
                    : lost_bits[i]
            );
        }

        printf("\n");
    }

    return EXIT_SUCCESS;
}