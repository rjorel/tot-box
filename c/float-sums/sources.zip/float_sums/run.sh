#!/bin/bash

mkdir build
cd build

cmake .. && make
cd ..

./build/float_sums --means > means.txt
./build/float_sums --max > max.txt

gnuplot script.gnuplot

rm -rf build
rm -f means.txt max.txt