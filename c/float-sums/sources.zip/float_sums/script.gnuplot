set logscale x
set key outside

set title 'Mean errors'
set xlabel 'Conditioning  (power of 2)'
set ylabel 'Number of lost bits'

plot [10:110] 'means.txt' title 'A1' with linespoints
replot 'means.txt' using 1:3 title 'A2' with linespoints
replot 'means.txt' using 1:4 title 'A3' with linespoints
replot 'means.txt' using 1:5 title 'A4' with linespoints
replot 'means.txt' using 1:6 title 'A5' with linespoints
replot 'means.txt' using 1:7 title 'A6' with linespoints
replot 'means.txt' using 1:8 title 'A7' with linespoints
replot 'means.txt' using 1:9 title 'A8' with linespoints
replot 'means.txt' using 1:10 title 'A9' with linespoints
replot 'means.txt' using 1:11 title 'A10' with linespoints
replot 'means.txt' using 1:12 title 'A11' with linespoints
replot 'means.txt' using 1:13 title 'A12' with linespoints

set terminal png
set output 'means.png'
replot

set title 'Maximal errors'
set xlabel 'Conditioning  (power of 2)'
set ylabel 'Number of lost bits'

plot [10:110] 'max.txt' title 'A1' with linespoints
replot 'max.txt' using 1:3 title 'A2' with linespoints
replot 'max.txt' using 1:4 title 'A3' with linespoints
replot 'max.txt' using 1:5 title 'A4' with linespoints
replot 'max.txt' using 1:6 title 'A5' with linespoints
replot 'max.txt' using 1:7 title 'A6' with linespoints
replot 'max.txt' using 1:8 title 'A7' with linespoints
replot 'max.txt' using 1:9 title 'A8' with linespoints
replot 'max.txt' using 1:10 title 'A9' with linespoints
replot 'max.txt' using 1:11 title 'A10' with linespoints
replot 'max.txt' using 1:12 title 'A11' with linespoints
replot 'max.txt' using 1:13 title 'A12' with linespoints

set terminal png
set output 'max.png'
replot