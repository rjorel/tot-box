#ifndef __GAME_H_
#define __GAME_H_

#include "model_manager.h"

#define NUM_GAME_ROWS       100
#define NUM_GAME_COLUMNS    200
#define NUM_GAME_CELLS      NUM_GAME_ROWS * NUM_GAME_COLUMNS
#define DEAD_CELL           0
#define ALIVE_CELL          1

typedef struct game_t {
    unsigned char *cells;
    unsigned char *next_cells;
} game_t;

game_t *create_game();
void free_game(game_t *game);

void reset_cells(game_t *game);
void randomize_cells(game_t *game);

void make_cell_alive(game_t *game, int x, int y);
void make_cells_alive(game_t *game, int x, int y, coord_t *coords, size_t num_coords);

void evolve_cells(game_t *game);

#endif
