#ifndef __INPUT_H_
#define __INPUT_H_

#include <stdbool.h>
#include <SDL2/SDL.h>

#define NUM_KEYS            256
#define NUM_MOUSE_BUTTONS   8

typedef struct input_t {
    bool pressed_keys[NUM_KEYS];
    bool pressed_mouse_buttons[NUM_MOUSE_BUTTONS];

    unsigned int mouse_x;
    unsigned int mouse_y;

    bool quit;
    int wheel_y;
} input_t;

input_t *create_input();
void free_input(input_t *input);

void update_input(input_t *input);
void release_mouse_button(input_t *input, unsigned int button);

bool is_key_pressed(input_t *input, unsigned int key);
bool is_mouse_button_pressed(input_t *input, unsigned int button);
bool is_mouse_wheel_up(input_t *input);
bool is_mouse_wheel_down(input_t *input);

#endif
