#ifndef __MODELS_H_
#define __MODELS_H_

typedef struct coord_t {
    int x;
    int y;
} coord_t;

typedef struct model_t {
    size_t num_coords;
    coord_t *coords;
} model_t;

typedef struct model_manager_t {
    model_t **models;
    size_t num_models;

    int current_model_index;
} model_manager_t;

model_manager_t *create_model_manager();
void free_model_manager(model_manager_t *model_manager);

void load_models_from_directory(model_manager_t *model_manager, const char *directory);

model_t *get_selected_model(model_manager_t *model_manager);
void select_next_model(model_manager_t *model_manager);
void select_previous_model(model_manager_t *model_manager);

#endif
