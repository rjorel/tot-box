#ifndef __UTILS_H_
#define __UTILS_H_

#include <stdio.h>
#include <dirent.h>

void swap(void *a, void *b, size_t size);

size_t count_lines_in_file(FILE *file);
size_t count_files_in_directory(DIR *dir);

#endif
