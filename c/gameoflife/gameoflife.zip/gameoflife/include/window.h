#ifndef __WINDOW_H_
#define __WINDOW_H_

#include <SDL2/SDL.h>
#include "game.h"
#include "model_manager.h"

#define DELAY           50
#define CELL_SIZE       5
#define WINDOW_WIDTH    NUM_GAME_COLUMNS * CELL_SIZE
#define WINDOW_HEIGHT   NUM_GAME_ROWS * CELL_SIZE

typedef struct window_t {
    game_t *game;
    input_t *input;
    model_manager_t *manager;

    SDL_Window *screen;
    SDL_Renderer *renderer;
} window_t;

window_t *create_window(game_t *game, input_t *input, model_manager_t *manager);
void free_window(window_t *window);

void refresh_window(window_t *window);

#endif
