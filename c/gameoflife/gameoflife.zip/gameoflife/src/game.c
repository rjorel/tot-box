#include <stdlib.h>
#include <memory.h>
#include "utils.h"
#include "game.h"

game_t *create_game() {
    game_t *game = malloc(sizeof(game_t));

    game->cells = calloc(NUM_GAME_CELLS, sizeof(char));
    game->next_cells = calloc(NUM_GAME_CELLS, sizeof(char));

    return game;
}

void free_game(game_t *game) {
    free(game->cells);
    free(game->next_cells);

    free(game);
}

void reset_cells(game_t *game) {
    memset(game->cells, 0, NUM_GAME_CELLS * sizeof(char));
}

void randomize_cells(game_t *game) {
    for (int i = 0; i < NUM_GAME_CELLS; i++) {
        game->cells[i] = (unsigned char) (rand() & 1);
    }
}

static int get_cell_offset(int x, int y) {
    return y * NUM_GAME_COLUMNS + x;
}

void make_cell_alive(game_t *game, int x, int y) {
    if (x < 0 || y < 0 || x >= NUM_GAME_COLUMNS || y >= NUM_GAME_ROWS) {
        return;
    }

    game->cells[get_cell_offset(x, y)] = ALIVE_CELL;
}

void make_cells_alive(game_t *game, int x, int y, coord_t *coords, size_t num_coords) {
    for (size_t i = 0; i < num_coords; i++) {
        make_cell_alive(game, x + coords[i].x, y + coords[i].y);
    }
}

static int count_living_cell_neighbors(game_t *game, int cell_offset) {
    int num_living_cells = 0;

    int left = (cell_offset % NUM_GAME_COLUMNS == 0);
    int right = (cell_offset % NUM_GAME_COLUMNS == (NUM_GAME_COLUMNS - 1));
    int top = cell_offset - NUM_GAME_COLUMNS < 0;
    int bottom = cell_offset + NUM_GAME_COLUMNS >= NUM_GAME_CELLS;

    if (!left) {
        num_living_cells += game->cells[cell_offset - 1];
    }

    if (!right) {
        num_living_cells += game->cells[cell_offset + 1];
    }

    if (!top) {
        num_living_cells += game->cells[cell_offset - NUM_GAME_COLUMNS];
    }

    if (!bottom) {
        num_living_cells += game->cells[cell_offset + NUM_GAME_COLUMNS];
    }

    if (!left && !top) {
        num_living_cells += game->cells[cell_offset - 1 - NUM_GAME_COLUMNS];
    }

    if (!left && !bottom) {
        num_living_cells += game->cells[cell_offset - 1 + NUM_GAME_COLUMNS];
    }

    if (!right && !top) {
        num_living_cells += game->cells[cell_offset + 1 - NUM_GAME_COLUMNS];
    }

    if (!right && !bottom) {
        num_living_cells += game->cells[cell_offset + 1 + NUM_GAME_COLUMNS];
    }

    return num_living_cells;
}

void evolve_cells(game_t *game) {
    for (int cell_offset = 0; cell_offset < NUM_GAME_CELLS; cell_offset++) {
        switch (count_living_cell_neighbors(game, cell_offset)) {
            case 2:
                game->next_cells[cell_offset] = game->cells[cell_offset];
                break;

            case 3:
                game->next_cells[cell_offset] = ALIVE_CELL;
                break;

            default:
                game->next_cells[cell_offset] = DEAD_CELL;
                break;
        }
    }

    swap(&game->cells, &game->next_cells, sizeof(&game->cells));
}
