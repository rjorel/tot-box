#include "input.h"

input_t *create_input() {
    return calloc(1, sizeof(input_t));
}

void free_input(input_t *input) {
    free(input);
}

void update_input(input_t *input) {
    SDL_Event event;

    input->quit = false;
    input->wheel_y = 0;

    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                input->quit = true;
                break;

            case SDL_KEYDOWN:
                // Handle Ctrl + q to quit program.
                if ((event.key.keysym.mod & KMOD_LCTRL || event.key.keysym.mod & KMOD_RCTRL) 
                    && event.key.keysym.sym == SDLK_q) {
                    input->quit = true;
                }
                else if (event.key.keysym.sym < NUM_KEYS) {
                    input->pressed_keys[event.key.keysym.sym] = true;
                }
                break;

            case SDL_KEYUP:
                if (event.key.keysym.sym < NUM_KEYS) {
                    input->pressed_keys[event.key.keysym.sym] = false;
                }
                break;
            
            case SDL_MOUSEBUTTONDOWN:
                if (event.button.button < NUM_MOUSE_BUTTONS) {
                    input->pressed_mouse_buttons[event.button.button] = true;
                }
                break;

            case SDL_MOUSEBUTTONUP:
                if (event.button.button < NUM_MOUSE_BUTTONS) {
                    input->pressed_mouse_buttons[event.button.button] = false;
                }
                break;

            case SDL_MOUSEMOTION:
                input->mouse_x = event.motion.x;
                input->mouse_y = event.motion.y;
                break;

            case SDL_MOUSEWHEEL:
                input->wheel_y = event.wheel.y;
                break;

            default:
                break;
        }
    }
}

void release_mouse_button(input_t *input, unsigned int button) {
    if (button >= NUM_MOUSE_BUTTONS) {
        return;
    }

    input->pressed_mouse_buttons[button] = false;
}

bool is_key_pressed(input_t *input, unsigned int key) {
    if (key >= NUM_KEYS) {
        return false;
    }

    return input->pressed_keys[key];
}

bool is_mouse_button_pressed(input_t *input, unsigned int button) {
    if (button >= NUM_MOUSE_BUTTONS) {
        return false;
    }

    return input->pressed_mouse_buttons[button];
}

bool is_mouse_wheel_up(input_t *input) {
    return input->wheel_y > 0;
}

bool is_mouse_wheel_down(input_t *input) {
    return input->wheel_y < 0;
}
