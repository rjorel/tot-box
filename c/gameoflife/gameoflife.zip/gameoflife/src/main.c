#include <stdbool.h>
#include <time.h>
#include "model_manager.h"
#include "input.h"
#include "game.h"
#include "window.h"

int main() {
    input_t *input = create_input();
    game_t *game = create_game();
    model_manager_t *model_manager = create_model_manager();
    window_t *window = create_window(game, input, model_manager);

    bool is_running = false;

    srand(time(NULL));

    load_models_from_directory(model_manager, MODEL_DIR);

    while (true) {
        update_input(input);

        if (input->quit) {
            break;
        }

        if (is_mouse_button_pressed(input, SDL_BUTTON_LEFT)) {
            model_t *model = get_selected_model(model_manager);

            if (model == NULL) {
                make_cell_alive(
                    game,
                    input->mouse_x / CELL_SIZE,
                    input->mouse_y / CELL_SIZE
                );
            } else {
                make_cells_alive(
                    game,
                    input->mouse_x / CELL_SIZE,
                    input->mouse_y / CELL_SIZE,
                    model->coords,
                    model->num_coords
                );

                // Avoid multiple additions of a model when user remains pressed on left click.
                release_mouse_button(input, SDL_BUTTON_LEFT);
            }
        } else if (is_mouse_wheel_up(input)) {
            select_previous_model(model_manager);
        } else if (is_mouse_wheel_down(input)) {
            select_next_model(model_manager);
        } else if (is_key_pressed(input, SDLK_BACKSPACE)) {
            reset_cells(game);
        } else if (is_key_pressed(input, SDLK_r)) {
            randomize_cells(game);
        } else if (is_key_pressed(input, SDLK_RETURN)) {
            is_running = true;
        } else if (is_key_pressed(input, SDLK_ESCAPE)) {
            is_running = false;
        }

        if (is_running) {
            evolve_cells(game);
        }

        refresh_window(window);
    }

    free_input(input);
    free_game(game);
    free_model_manager(model_manager);
    free_window(window);

    return EXIT_SUCCESS;
}
