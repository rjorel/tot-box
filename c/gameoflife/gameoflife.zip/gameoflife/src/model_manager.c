#include <stdio.h>
#include <stdlib.h>
#include "utils.h"
#include "model_manager.h"

model_manager_t *create_model_manager() {
    model_manager_t *model_manager = malloc(sizeof(model_manager_t));

    model_manager->models = NULL;
    model_manager->num_models = 0;

    model_manager->current_model_index = -1;

    return model_manager;
}

static void free_model(model_t *model) {
    free(model->coords);
    free(model);
}

void free_model_manager(model_manager_t *model_manager) {
    for (unsigned int i = 0; i < model_manager->num_models; i++) {
        free_model(model_manager->models[i]);
    }

    free(model_manager->models);
    free(model_manager);
}

static model_t *create_model(const char *path) {
    FILE *file;

    if ((file = fopen(path, "r")) == NULL) {
        return NULL;
    }

    model_t *model = malloc(sizeof(model_t));

    model->num_coords = count_lines_in_file(file);
    model->coords = malloc(model->num_coords * sizeof(coord_t));

    for (unsigned int i = 0; i < model->num_coords; i++) {
        char x[32], y[32];

        fscanf(file, "%s %s", x, y);

        model->coords[i].x = (int) strtol(x, NULL, 10);
        model->coords[i].y = (int) strtol(y, NULL, 10);
    }

    fclose(file);

    return model;
}

void load_models_from_directory(model_manager_t *model_manager, const char *directory) {
    DIR *dir = opendir(directory);

    if (dir == NULL) {
        return;
    }

    size_t num_models = count_files_in_directory(dir);
    model_t **models = malloc(num_models * sizeof(model_t *));

    struct dirent *entry;
    int offset = 0;

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR) {
            continue;
        }

        char path[512];
        sprintf(path, "%s/%s", directory, entry->d_name);

        models[offset++] = create_model(path);
    }

    model_manager->num_models = num_models;
    model_manager->models = models;

    closedir(dir);
}

model_t *get_selected_model(model_manager_t *model_manager) {
    if (model_manager->current_model_index < 0) {
        return NULL;
    }

    return model_manager->models[model_manager->current_model_index];
}

static void change_game_used_model(model_manager_t *model_manager, int delta) {
    model_manager->current_model_index += delta;

    if (model_manager->current_model_index < -1) {
        model_manager->current_model_index = (int) (model_manager->num_models - 1);
    }

    if (model_manager->current_model_index >= (int) model_manager->num_models) {
        model_manager->current_model_index = -1;
    }
}

void select_next_model(model_manager_t *model_manager) {
    change_game_used_model(model_manager, 1);
}

void select_previous_model(model_manager_t *model_manager) {
    change_game_used_model(model_manager, -1);
}
