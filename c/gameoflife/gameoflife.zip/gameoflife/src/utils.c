#include <stdlib.h>
#include <memory.h>
#include "utils.h"

void swap(void *a, void *b, size_t size) {
    void *tmp = malloc(size);

    memcpy(tmp, a, size);
    memcpy(a, b, size);
    memcpy(b, tmp, size);

    free(tmp);
}

size_t count_lines_in_file(FILE *file) {
    long index = ftell(file);
    size_t num_lines = 0;
    int c;

    rewind(file);

    while ((c = fgetc(file)) != EOF) {
        if (c == '\n') {
            num_lines++;
        }
    }

    fseek(file, index, SEEK_SET);

    return num_lines;
}

size_t count_files_in_directory(DIR *dir) {
    long index = telldir(dir);
    size_t num_files = 0;

    rewinddir(dir);

    struct dirent *entry;

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR) {
            continue;
        }

        num_files++;
    }

    seekdir(dir, index);

    return num_files;
}
