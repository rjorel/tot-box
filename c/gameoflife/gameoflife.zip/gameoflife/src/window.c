#include "input.h"
#include "window.h"

window_t *create_window(game_t *game, input_t *input, model_manager_t *manager) {
    window_t *window = malloc(sizeof(window_t));

    window->game = game;
    window->input = input;
    window->manager = manager;

    SDL_Init(SDL_INIT_VIDEO);

    window->screen = SDL_CreateWindow(
        "Game of life",
        SDL_WINDOWPOS_UNDEFINED,
        SDL_WINDOWPOS_UNDEFINED,
        WINDOW_WIDTH, 
        WINDOW_HEIGHT,
        0
    );

    window->renderer = SDL_CreateRenderer(window->screen, -1, 0);

    return window;
}

void free_window(window_t *window) {
    SDL_DestroyRenderer(window->renderer);
    SDL_DestroyWindow(window->screen);
    SDL_Quit();

    free(window);
}

static void fill_rect(SDL_Renderer *renderer, unsigned int x, unsigned int y) {
    SDL_Rect rect = {
        .x = x,
        .y = y,
        .w = CELL_SIZE,
        .h = CELL_SIZE
    };

    SDL_RenderFillRect(renderer, &rect);
}

static void fill_alive_cell_rects(window_t *window) {
    for (int cell_offset = 0; cell_offset < NUM_GAME_CELLS; cell_offset++) {
        if (window->game->cells[cell_offset] == DEAD_CELL) {
            continue;
        }

        fill_rect(
            window->renderer, 
            (unsigned int) (cell_offset % NUM_GAME_COLUMNS) * CELL_SIZE,
            (unsigned int) (cell_offset / NUM_GAME_COLUMNS) * CELL_SIZE
        );
    }
}

static void fill_selected_model_rects(window_t *window) {
    model_t *model = get_selected_model(window->manager);

    if (model == NULL) {
        return;
    }

    int x = window->input->mouse_x;
    int y = window->input->mouse_y;

    for (int i = 0; i < model->num_coords; i++) {
        fill_rect(
            window->renderer,
            (unsigned int) (x + (model->coords[i].x * CELL_SIZE)),
            (unsigned int) (y + (model->coords[i].y * CELL_SIZE))
        );
    }
}

void refresh_window(window_t *window) {
    // Clear screen with black color.
    SDL_SetRenderDrawColor(window->renderer, 0, 0, 0, 0);
    SDL_RenderClear(window->renderer);

    // Fill white rectangles for alive cells and selected model.
    SDL_SetRenderDrawColor(window->renderer, 255, 255, 255, 0);

    fill_alive_cell_rects(window);
    fill_selected_model_rects(window);

    SDL_RenderPresent(window->renderer);

    SDL_Delay(DELAY);
}
