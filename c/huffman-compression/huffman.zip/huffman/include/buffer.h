#ifndef __BUFFERED_FILE_H_
#define __BUFFERED_FILE_H_

#include <stdio.h>


typedef struct buffer_t {
    FILE *file;

    unsigned char bits;
    int offset;
} buffer_t;

buffer_t *create_buffer(FILE *file);
void free_buffer(buffer_t *buffer);

void flush_buffer(buffer_t *buffer);
void push_in_buffer(buffer_t *buffer, int bit);

#endif
