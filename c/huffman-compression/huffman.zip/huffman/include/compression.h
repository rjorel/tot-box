#ifndef DEF_COMPRESS
#define DEF_COMPRESS

#include <stdlib.h>


typedef struct word_t {
    size_t size;
    unsigned char *bits;
} word_t;

int compress(FILE *src, FILE *dst);
void uncompress(FILE *src, FILE *dst);

#endif