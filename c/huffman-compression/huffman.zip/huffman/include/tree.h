#ifndef __TREE_H_
#define __TREE_H_

typedef struct tree_t {
    unsigned char byte;         // Represented byte.
    unsigned int frequency;     // Byte frequency.

    struct tree_t *left_son;
    struct tree_t *right_son;
} tree_t;

tree_t *create_tree(unsigned char byte, unsigned int frequency);
void free_tree(tree_t *tree);

tree_t *build_huffman_tree(unsigned int *frequencies);

#endif
