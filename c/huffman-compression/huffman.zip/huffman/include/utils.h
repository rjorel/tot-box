#ifndef __UTILS_H_
#define __UTILS_H_

#include <stdio.h>


#define NUM_FREQUENCIES 256

long get_file_size(FILE *file);

#endif
