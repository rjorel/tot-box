#include <stdlib.h>
#include <limits.h>

#include "buffer.h"


buffer_t *create_buffer(FILE *file) {
    buffer_t *buffer = malloc(sizeof(buffer_t));

    buffer->file = file;
    buffer->bits = 0;
    buffer->offset = 0;

    return buffer;
}

void free_buffer(buffer_t *buffer) {
    free(buffer);
}

static int get_shift_offset(buffer_t *buffer) {
    return CHAR_BIT - buffer->offset - 1;
}

static void write_at_current_offset(buffer_t *buffer, int bit) {
    int shift_offset = get_shift_offset(buffer);

    // Reset bit at offset.
    buffer->bits &= ~(1 << shift_offset);

    // Write bit at offset.
    buffer->bits |= ((0x01 & bit) << shift_offset);
}

void flush_buffer(buffer_t *buffer) {
    if (buffer->offset == 0) {
        return;
    }

    while (buffer->offset < CHAR_BIT) {
        write_at_current_offset(buffer, 0);

        buffer->offset++;
    }

    fwrite(&buffer->bits, sizeof(char), 1, buffer->file);

    buffer->bits = 0;
    buffer->offset = 0;
}

void push_in_buffer(buffer_t *buffer, int bit) {
    if (buffer->offset == CHAR_BIT) {
        flush_buffer(buffer);
    }

    write_at_current_offset(buffer, bit);
    buffer->offset++;
}