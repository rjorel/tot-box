#include <stdio.h>
#include <buffer.h>

#include "utils.h"
#include "tree.h"
#include "compression.h"


#define LEFT    0
#define RIGHT   1

static unsigned int *compute_frequencies(FILE *file) {
    unsigned int *frequencies = calloc(NUM_FREQUENCIES, sizeof(int));
    int byte;

    while ((byte = fgetc(file)) != EOF) {
        frequencies[(unsigned char) byte]++;
    }

    // File is rewound to leave it as he was.
    rewind(file);

    return frequencies;
}

static void get_codes(word_t *words, tree_t *tree, unsigned char *bits, int index) {
    // Should rarely happens.
    if (tree == NULL) {
        return;
    }

    // Leaf.
    if (tree->left_son == NULL && tree->right_son == NULL) {
        words[tree->byte].size = (size_t) index;
        words[tree->byte].bits = malloc(index * sizeof(char));

        // Copy bits to make the bit representation.
        for (int i = 0; i < index; i++) {
            words[tree->byte].bits[i] = bits[i];
        }

        return;
    }

    bits[index] = LEFT;
    get_codes(words, tree->left_son, bits, index + 1);

    bits[index] = RIGHT;
    get_codes(words, tree->right_son, bits, index + 1);
}

static word_t *build_words(unsigned int *frequencies) {
    tree_t *root_tree = build_huffman_tree(frequencies);

    // No character in the file.
    if (root_tree == NULL) {
        return NULL;
    }

    // Buffer for bit codes.
    unsigned char bits[255] = { 0 };

    word_t *words = calloc(NUM_FREQUENCIES, sizeof(word_t));

    get_codes(words, root_tree, bits, 0);
    free_tree(root_tree);

    return words;
}

static void convert(FILE *src, FILE *dst, word_t *words) {
    int byte;
    buffer_t *buffer = create_buffer(dst);

    while ((byte = fgetc(src)) != EOF) {
        word_t word = words[byte];

        for (int i = 0; i < word.size; i++) {
            push_in_buffer(buffer, word.bits[i]);
        }
    }

    flush_buffer(buffer);
    free_buffer(buffer);
}

static void free_words(word_t *words) {
    for (int i = 0; i < NUM_FREQUENCIES; i++) {
        free(words[i].bits);
    }

    free(words);
}

int compress(FILE *src, FILE *dst) {
    unsigned int *frequencies = compute_frequencies(src);
    word_t *words = build_words(frequencies);

    fwrite(frequencies, sizeof(int), NUM_FREQUENCIES, dst);
    free(frequencies);

    if (words == NULL) {
        return -1;
    }

    convert(src, dst, words);
    free_words(words);

    return 0;
}

static void restore(FILE *src, FILE *dst, tree_t *root) {
    int byte;
    tree_t *current = root;

    while ((byte = fgetc(src)) != EOF) {
        for (int i = 0; i < 8; i++) {
            // If this case happens, some issues could occur during compression.
            if (current == NULL) {
                current = root;
            }

            // Leaf.
            if (current->left_son == NULL && current->right_son == NULL) {
                fwrite(&current->byte, sizeof(char), 1, dst);
                current = root;
            }

            int bit = (byte >> (7 - i)) & 0x01;

            if (bit == LEFT) {
                current = current->left_son;
            } else {
                current = current->right_son;
            }
        }
    }
}

void uncompress(FILE *src, FILE *dst) {
    unsigned int *frequencies = malloc(NUM_FREQUENCIES * sizeof(int));

    fread(frequencies, sizeof(int), NUM_FREQUENCIES, src);

    tree_t *tree = build_huffman_tree(frequencies);
    free(frequencies);

    restore(src, dst, tree);
    free_tree(tree);
}