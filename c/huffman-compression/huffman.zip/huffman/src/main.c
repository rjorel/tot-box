#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utils.h"
#include "compression.h"


void usage(const char *name) {
    printf("Usage: %s mode SRC DST\n", name);

    puts("\nmode");
    puts("  -c  compress the source file and make the destination file.");
    puts("  -u  uncompress the source file and make the destination file.");
}

int main(int argc, char *argv[]) {
    if (argc < 4) {
        printf("%s: missing operand\n\n", argv[0]);
        usage(argv[0]);

        return EXIT_FAILURE;
    }

    FILE *src = fopen(argv[2], "rb");

    if (src == NULL) {
        printf("%s: cannot access '%s': No such file\n", argv[0], argv[2]);
        return 0;
    }

    FILE *dst = fopen(argv[3], "wb");

    if (strcmp(argv[1], "-c") == 0) {
        int ret = compress(src, dst);

        if (ret == -1) {
            printf("%s: error: file empty\n", argv[0]);
        } else {
            float rate = (float) get_file_size(dst) / get_file_size(src);

            printf("Compression rate : %d%%\n", (int) (rate * 100));
        }
    } else if (strcmp(argv[1], "-u") == 0) {
        uncompress(src, dst);
    } else {
        printf("%s: invalid mode: '%s'\n\n", argv[0], argv[1]);
        usage(argv[0]);
    }

    fclose(src);
    fclose(dst);

    return EXIT_SUCCESS;
}
