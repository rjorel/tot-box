#include <stdio.h>
#include <stdlib.h>
#include <utils.h>
#include <limits.h>

#include "tree.h"


tree_t *create_tree(unsigned char byte, unsigned int frequency) {
    tree_t *tree = malloc(sizeof(tree_t));

    tree->byte = byte;
    tree->frequency = frequency;

    tree->left_son = NULL;
    tree->right_son = NULL;

    return tree;
}

void free_tree(tree_t *tree) {
    if (tree->left_son != NULL) {
        free_tree(tree->left_son);
    }

    if (tree->right_son != NULL) {
        free_tree(tree->right_son);
    }

    free(tree);
}

static tree_t **create_tree_list(unsigned int *frequencies) {
    tree_t **trees = malloc(NUM_FREQUENCIES * sizeof(tree_t *));

    for (int i = 0; i < NUM_FREQUENCIES; i++) {
        if (frequencies[i] != 0) {
            trees[i] = create_tree((unsigned char) i, frequencies[i]);
        } else {
            trees[i] = NULL; // Non-present bytes are represented by NULL.
        }
    }

    return trees;
}

static int get_min_frequency_index(tree_t **trees) {
    int frequency = INT_MAX;
    int index = -1;

    for (int i = 0; i < NUM_FREQUENCIES; i++) {
        if (trees[i] == NULL) {
            continue;
        }

        if (trees[i]->frequency < frequency) {
            frequency = trees[i]->frequency;
            index = i;
        }
    }

    return index;
}

static tree_t *extract_tree(tree_t **trees, int index) {
    tree_t *tree = trees[index];

    // Mark index as NULL to mean tree extraction.
    // As the tree is no longer present in tree list, it is no longer considered in function that searches tree with
    // minimal frequency.
    trees[index] = NULL;

    return tree;
}

tree_t *build_huffman_tree(unsigned int *frequencies) {
    tree_t **trees = create_tree_list(frequencies);

    for (;;) {
        int left_index = get_min_frequency_index(trees);

        // In this case, there is no tree in list.
        if (left_index == -1) {
            free(trees);
            return NULL;
        }

        // Extract the first tree here is important, because the next minimum tree search depends on present trees in
        // tree list.
        tree_t *left = extract_tree(trees, left_index);

        int right_index = get_min_frequency_index(trees);

        // Every tree construction should end here, because this iterative method leads to get only one tree in list.
        if (right_index == -1) {
            free(trees);
            return left;
        }

        tree_t *right = extract_tree(trees, right_index);

        // Father creation, with frequency sum of son frequencies.
        tree_t *father = create_tree(0, left->frequency + right->frequency);

        father->left_son = left;
        father->right_son = right;

        // Left son index is arbitrary chosen to place the father.
        // Even if this choice affects the final tree hierarchy, it does not affect attributed codes to bytes.
        trees[left_index] = father;
    }
}
