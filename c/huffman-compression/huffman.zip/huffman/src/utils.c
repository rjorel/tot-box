#include "utils.h"


long get_file_size(FILE *file) {
    long index = ftell(file);

    fseek(file, 0L, SEEK_END);
    long size = ftell(file);

    fseek(file, index, SEEK_SET);

    return size;
}