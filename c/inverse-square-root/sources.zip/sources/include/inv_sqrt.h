#ifndef __INV_SQRT_H_
#define __INV_SQRT_H_

double inv_sqrt(double a, int precision, int num_iterations);

#endif
