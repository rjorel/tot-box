#ifndef __TABLES_H_
#define __TABLES_H_

#include "tables/isqrt_prec4.h"
#include "tables/isqrt_prec5.h"
#include "tables/isqrt_prec6.h"
#include "tables/isqrt_prec7.h"
#include "tables/isqrt_prec8.h"
#include "tables/isqrt_prec9.h"
#include "tables/isqrt_prec10.h"
#include "tables/isqrt_prec11.h"
#include "tables/isqrt_prec12.h"


#endif
