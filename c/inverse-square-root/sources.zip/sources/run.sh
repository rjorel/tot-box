#!/bin/bash

mkdir ./build
cd ./build

cmake ..
make

cd ..
./build/inv_sqrt 1.100000 8 > ./data.txt

gnuplot script.gnuplot

rm -f ./data.txt
rm -rf ./build