set title 'number = 1.100000'

set xlabel 'Number of iterations'
set ylabel 'Correct figures'

plot [0:8] 'data.txt' title 'prec_4' with linespoints
replot 'data.txt' using 1:3 title 'prec_5' with linespoints
replot 'data.txt' using 1:4 title 'prec_6' with linespoints
replot 'data.txt' using 1:5 title 'prec_7' with linespoints
replot 'data.txt' using 1:6 title 'prec_8' with linespoints
replot 'data.txt' using 1:7 title 'prec_9' with linespoints
replot 'data.txt' using 1:8 title 'prec_10' with linespoints
replot 'data.txt' using 1:9 title 'prec_11' with linespoints
replot 'data.txt' using 1:10 title 'prec_12' with linespoints

pause -1