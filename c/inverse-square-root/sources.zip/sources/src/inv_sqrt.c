#include <stdio.h>

#include "tables.h"


static const double *tables[] = {
    isqrt_4, isqrt_5, isqrt_6, isqrt_7, isqrt_8, isqrt_9, isqrt_10, isqrt_11, isqrt_12
};

static const double *get_table_for_precision(int precision) {
    return tables[precision - 4];
}

static int get_approximation_index(double a, int precision) {
    // Use floats here because tables are made to be addressed according float significands.
    float f_a = (float) a;

    int bits = *(int *) &f_a;
    int mask = (1 << precision) - 1;

    return  ((bits >> (23 - precision) & mask));
}

static double get_approximated_value(double a, int precision) {
    const double *table = get_table_for_precision(precision);
    int index = get_approximation_index(a, precision);

    return table[index];
}

double inv_sqrt(double a, int precision, int num_iterations) {
    if (a < 1 || a >= 2) {
        return 0.0;
    }

    double x = get_approximated_value(a, precision);

    for (int i = 0; i < num_iterations; i++) {
        x = (x * (3 - a * x * x)) / 2;
    }

    return x;
}
