#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>

#include "inv_sqrt.h"


static void usage(char *name) {
    printf("Usage: %s number [num-max-iterations = 8]\n", name);
}

static unsigned int count_correct_figures(double a, double b) {
    char a_str[64], b_str[64];

    snprintf(a_str, 50, "%.50f", a);
    snprintf(b_str, 50, "%.50f", b);

    char *a_dot = strchr(a_str, '.');
    char *b_dot = strchr(b_str, '.');

    char *str = a_dot;

    for (; *str != EOF && *str == *b_dot; str++, b_dot++) {
        //
    }


    return (unsigned int) (str - a_dot);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        usage(argv[0]);

        return EXIT_FAILURE;
    }

    double number = strtod(argv[1], NULL);
    unsigned int num_max_iterations = 8;

    if (argc > 2) {
        num_max_iterations = (unsigned int) strtol(argv[2], NULL, 10);
    }

    double exact_result = 1 / sqrt(number);

    for (int num_iterations = 0; num_iterations <= num_max_iterations; num_iterations++) {
        printf("%d ", num_iterations);

        for (int precision = 4; precision <= 12; precision++) {
            double sqrt_value = inv_sqrt(
                number, precision, num_iterations
            );

            int correct_figures = count_correct_figures(
                sqrt_value, exact_result
            );

            printf("%d ", correct_figures);
        }

        printf("\n");
    }

    return 0;
}
