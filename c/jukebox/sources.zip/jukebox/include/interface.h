#ifndef __INTERFACE_H_
#define __INTERFACE_H_

#include "jukebox.h"


enum {
    RECORD, PLAY, SAVE, LOAD, SETTINGS, DISPLAY, QUIT
};

int get_user_choice();
char *get_name();
FILE *get_file(char *mode);

track_t *get_track_in_playlist(jukebox_t *jukebox);

void change_settings(jukebox_t *jukebox);

#endif
