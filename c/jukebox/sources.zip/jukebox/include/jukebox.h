#ifndef __JUKEBOX_H_
#define __JUKEBOX_H_

#include <pulse/simple.h>

#include "track.h"
#include "window.h"
#include "playlist.h"


typedef struct {
    // User parameters for tracks.
    uint32_t track_frequency;
    uint8_t track_mode;
    pa_sample_format_t track_format;

    // In theory, duration is expressed in seconds, but because of internal mechanisms of pulse audio,
    // it's not really the record duration in seconds.
    float track_duration;

    // Track list.
    playlist_t *playlist;

    // Window for frequency curves.
    window_t *window;
} jukebox_t;

jukebox_t *create_jukebox();
void free_jukebox(jukebox_t *jukebox);

#endif
