#ifndef __PLAYLIST_H_
#define __PLAYLIST_H_

#include "track.h"


typedef struct playlist_t {
    track_t *track;
    struct playlist_t *next;
} playlist_t;

playlist_t *create_playlist();
void free_playlist(playlist_t *playlist);

int is_empty_playlist(playlist_t *playlist);
void add_track(playlist_t *playlist, track_t *track);

#endif
