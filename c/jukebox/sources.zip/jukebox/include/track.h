#ifndef __TRACK_H_
#define __TRACK_H_

#include <stdio.h>
#include <pulse/simple.h>


typedef struct track_t {
    char *name;
    uint32_t frequency;
    uint8_t mode;
    pa_sample_format_t format;

    uint8_t *data;
    size_t length;
} track_t;

enum {
    MONO = 1, STEREO = 2
};

track_t *create_track(char *name, uint32_t frequency, uint8_t mode, pa_sample_format_t format);
void free_track(track_t *track);

void record_track(track_t *track, float duration);
void play_track(track_t *track);

track_t *read_track_from_file(FILE *fp, char *name);
void write_track_to_file(FILE *fp, track_t *track);

#endif
