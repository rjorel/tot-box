#ifndef __WINDOW_H_
#define __WINDOW_H_

#include <X11/Xlib.h>

#include "track.h"


typedef struct {
    int width;
    int height;

    Display *display;
    Window x_window;
    XEvent event;
} window_t;

window_t *create_window(int width, int height);
void free_window(window_t *window);

void draw_track(window_t *window, track_t *track);

#endif
