#include <stdio.h>
#include <stdlib.h>

#include "interface.h"


static void empty_buffer() {
    while (getchar() != '\n') {
        //
    }
}

int get_user_choice() {
    puts("\n------------------------------------------------");
    puts("Menu\n------------------------------------------------\n");
    puts("1. Record");
    puts("2. Play");
    puts("3. Save");
    puts("4. Load");
    puts("5. Settings");
    puts("6. Display frequencies");
    puts("7. Quit");
    printf("Choice: ");

    int choice = 0;

    scanf("%d", &choice);
    empty_buffer();

    return choice - 1;
}

char *get_name() {
    char *name = malloc(21 * sizeof(char));

    printf("Track name (20 characters max): ");

    scanf("%s", name);
    empty_buffer();

    return name;
}

FILE *get_file(char *mode) {
    FILE *file = NULL;
    char filename[21];

    printf("File name: ");

    scanf("%s", filename);
    empty_buffer();

    if ((file = fopen(filename, mode)) == NULL) {
        printf("%s: No such file or directory\n", filename);
    }

    return file;
}

track_t *get_track_in_playlist(jukebox_t *jukebox) {
    if (is_empty_playlist(jukebox->playlist)) {
        printf("No track\n");
        return NULL;
    }

    int number = 1;
    playlist_t *playlist = jukebox->playlist;

    for (; playlist != NULL; playlist = playlist->next, number++) {
        printf("%d. %s\n", number, playlist->track->name);
    }

    int choice = 0;
    printf("Choose the track: ");

    scanf("%d", &choice);
    empty_buffer();

    if (choice < 0 || choice > number) {
        puts("\nBad choice...");
        return NULL;
    }

    number = 1;
    playlist = jukebox->playlist;

    for (; number < choice; playlist = playlist->next, number++) {
        //
    }

    return playlist->track;
}

void change_settings(jukebox_t *jukebox) {
    char choice = 0;

    printf("Settings:\n");
    printf("Frequency: %d\n", jukebox->track_frequency);
    printf("Mode: %s\n", (jukebox->track_mode == MONO) ? "Mono" : "Stereo");
    printf("Duration: %f\n", jukebox->track_duration);

    printf("\nChange options (y/n) ? ");

    scanf("%c", &choice);
    empty_buffer();

    if (choice != 'y') {
        return;
    }

    printf("Frequency: ");

    scanf("%"SCNd32, &jukebox->track_frequency);
    empty_buffer();

    do {
        printf("Mode (1 -> Mono / 2 -> Stereo): ");

        scanf("%"SCNd8, &jukebox->track_mode);
        empty_buffer();
    } while (jukebox->track_mode != MONO && jukebox->track_mode != STEREO);

    printf("Duration: ");

    scanf("%f", &jukebox->track_duration);
    empty_buffer();
}