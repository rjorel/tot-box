#include <stdio.h>
#include <stdlib.h>
#include <pulse/simple.h>

#include "jukebox.h"


jukebox_t *create_jukebox() {
    jukebox_t *jukebox = malloc(sizeof(jukebox_t));

    jukebox->track_frequency = 44110;
    jukebox->track_mode = STEREO;

    jukebox->track_format = PA_SAMPLE_S16NE;
    jukebox->track_duration = 5.f;

    jukebox->playlist = create_playlist();

    // Window creation can fail, because we try to communicate with X11, and X11 can be unavailable at this moment.
    if ((jukebox->window = create_window(1024, 256)) == NULL) {
        fprintf(stderr, "Window creation failed\n");
        free(jukebox);

        return NULL;
    }

    return jukebox;
}

void free_jukebox(jukebox_t *jukebox) {
    free_playlist(jukebox->playlist);
    free_window(jukebox->window);

    free(jukebox);
}