#include <stdlib.h>

#include "jukebox.h"
#include "interface.h"


void execute_choice(jukebox_t *jukebox, int choice) {
    switch (choice) {
        case RECORD:
        case LOAD: {
            char *name = get_name();
            track_t *track = NULL;

            if (choice == RECORD) {
                track = create_track(
                    name,
                    jukebox->track_frequency,
                    jukebox->track_mode,
                    jukebox->track_format
                );

                record_track(track, jukebox->track_duration);
            } else {
                FILE *file = get_file("rb");

                if (file != NULL) {
                    track = read_track_from_file(file, name);
                    fclose(file);
                }
            }

            if (track != NULL) {
                add_track(jukebox->playlist, track);
            }
        }
            break;

        case PLAY:
        case SAVE:
        case DISPLAY: {
            track_t *track = get_track_in_playlist(jukebox);

            if (track == NULL) {
                return;
            }

            if (choice == PLAY) {
                play_track(track);
            } else if (choice == SAVE) {
                FILE *file = get_file("wb");

                if (file != NULL) {
                    write_track_to_file(file, track);
                    fclose(file);
                }
            } else {
                draw_track(jukebox->window, track);
            }
        }
            break;

        case SETTINGS:
            change_settings(jukebox);
            break;

        case QUIT:
            break;

        default:
            printf("Bad choice...\n");
            break;
    }
}

int main(int argc, char *argv[]) {
    jukebox_t *jukebox = create_jukebox();

    if (jukebox == NULL) {
        return EXIT_FAILURE;
    }

    int choice;

    do {
        execute_choice(
            jukebox, choice = get_user_choice()
        );
    } while (choice != QUIT);

    printf("Bye !\n");
    free_jukebox(jukebox);

    return EXIT_SUCCESS;
}