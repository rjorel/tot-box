#include <malloc.h>

#include "playlist.h"


playlist_t *create_playlist() {
    playlist_t *playlist = malloc(sizeof(playlist_t));

    playlist->track = NULL;
    playlist->next = NULL;
}

void free_playlist(playlist_t *playlist) {
    playlist_t *current = playlist;

    while (current != NULL) {
        if (current->track != NULL) {
            free_track(current->track);
        }

        playlist_t *tmp = current;
        current = current->next;

        free(tmp);
    }
}

int is_empty_playlist(playlist_t *playlist) {
    return playlist == NULL
        || playlist->track == NULL;
}

void add_track(playlist_t *playlist, track_t *track) {
    if (playlist->track == NULL) {
        playlist->track = track;
        return;
    }

    if (playlist->next == NULL) {
        playlist->next = create_playlist();
    }

    add_track(playlist->next, track);
}