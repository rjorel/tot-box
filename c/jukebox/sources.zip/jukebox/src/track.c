#include <stdio.h>
#include <stdlib.h>
#include <pulse/simple.h>

#include "track.h"


track_t *create_track(char *name, uint32_t frequency, uint8_t mode, pa_sample_format_t format) {
    track_t *track = malloc(sizeof(track_t));

    track->name = name;
    track->frequency = frequency;
    track->mode = mode;
    track->format = format;

    track->length = 0;
    track->data = NULL;

    return track;
}

void free_track(track_t *track) {
    free(track->name);
    free(track->data);

    free(track);
}

void record_track(track_t *track, float duration) {
    pa_sample_spec specs = {
        .format = track->format,
        .channels = track->mode,
        .rate = track->frequency
    };

    pa_simple *sample = pa_simple_new(
        NULL, track->name, PA_STREAM_RECORD, NULL, "record", &specs, NULL, NULL, NULL
    );

    if (sample == NULL) {
        return;
    }

    track->length = (size_t) (duration * specs.rate * specs.channels);
    track->data = malloc(track->length * sizeof(uint8_t *));

    pa_simple_read(sample, track->data, track->length, NULL);
    pa_simple_free(sample);
}

void play_track(track_t *track) {
    pa_sample_spec specs = {
        .format = track->format,
        .channels = track->mode,
        .rate = track->frequency
    };

    pa_simple *sample = pa_simple_new(
        NULL, track->name, PA_STREAM_PLAYBACK, NULL, "playback", &specs, NULL, NULL, NULL
    );

    if (sample == NULL) {
        return;
    }

    pa_simple_write(sample, track->data, track->length, NULL);
    pa_simple_free(sample);
}

track_t *read_track_from_file(FILE *fp, char *name) {
    uint8_t mode;
    uint32_t frequency, length;

    fread(&frequency, sizeof(uint32_t), 1, fp);
    fread(&mode, sizeof(uint8_t), 1, fp);
    fread(&length, sizeof(size_t), 1, fp);

    track_t *track = create_track(
        name, frequency, mode, PA_SAMPLE_S16NE
    );

    track->length = length;
    track->data = malloc(track->length * sizeof(uint8_t));

    fread(track->data, sizeof(uint8_t), track->length, fp);

    return track;
}

void write_track_to_file(FILE *fp, track_t *track) {
    fwrite(&track->frequency, sizeof(uint32_t), 1, fp);
    fwrite(&track->mode, sizeof(uint8_t), 1, fp);
    fwrite(&track->length, sizeof(size_t), 1, fp);

    fwrite(track->data, sizeof(uint8_t), track->length, fp);
}