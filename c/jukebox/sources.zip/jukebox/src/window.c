#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>

#include "window.h"


window_t *create_window(int width, int height) {
    window_t *window;
    int screen;

    window = malloc(sizeof(window_t));

    if ((window->display = XOpenDisplay(NULL)) == NULL) {
        free(window);
        return NULL;
    }

    screen = DefaultScreen(window->display);

    window->x_window = XCreateSimpleWindow(
        window->display,
        RootWindow(window->display, screen),
        10, 10,
        (unsigned int) width, (unsigned int) height,
        1,
        BlackPixel(window->display, screen),
        WhitePixel(window->display, screen)
    );

    XStoreName(window->display, window->x_window, "Frequency curve");

    window->width = width;
    window->height = height;

    return window;
}

void free_window(window_t *window) {
    XCloseDisplay(window->display);

    free(window);
}

void draw_track(window_t *window, track_t *track) {
    int screen;
    Pixmap pixmap;

    screen = DefaultScreen(window->display);

    pixmap = XCreatePixmap(
        window->display, window->x_window,
        (unsigned int) window->width, (unsigned int) window->height,
        (unsigned int) DefaultDepth(window->display, screen)
    );

    XMapWindow(window->display, window->x_window);

    printf("Don't close the window !!!\n");
    sleep(1);

    for (int offset = 0; offset < track->length; offset += window->width) {
        XSetForeground(
            window->display,
            DefaultGC(window->display, screen),
            BlackPixel(window->display, screen)
        );

        XFillRectangle(
            window->display,
            pixmap,
            DefaultGC(window->display, screen),
            0, 0,
            (unsigned int) window->width, (unsigned int) window->height
        );

        XSetForeground(
            window->display,
            DefaultGC(window->display, screen),
            WhitePixel(window->display, screen)
        );

        for (int x1 = 0, x2 = 1; x2 < window->width; x1++, x2++) {
            // Possibly access to unavailable data zones.
            int y1 = (track->data[offset + x1] + 128) % 255;
            int y2 = (track->data[offset + x2] + 128) % 255;

            XDrawLine(
                window->display,
                pixmap,
                DefaultGC(window->display, screen),
                x1, y1,
                x2, y2
            );
        }

        XCopyArea(
            window->display,
            pixmap,
            window->x_window,
            DefaultGC(window->display, screen),
            0, 0,
            (unsigned int) window->width, (unsigned int) window->height,
            0, 0
        );

        XFlush(window->display);
        usleep(10000);
    }

    XUnmapWindow(window->display, window->x_window);
}
