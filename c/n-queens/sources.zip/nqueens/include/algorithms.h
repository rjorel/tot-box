#ifndef __ALGORITHMS_H_
#define __ALGORITHMS_H_

#include <stdbool.h>

#include "stats.h"
#include "dict.h"


void permutation_first(int *values, size_t n);
void permutation_all(int *values, size_t n);

void backtracking_first(int *values, size_t n);
void backtracking_all(int *values, size_t n);

void las_vegas_first(int *values, size_t n);
void last_vegas_all(int *values, size_t n);

#endif
