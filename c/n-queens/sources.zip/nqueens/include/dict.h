#ifndef __DICT_H_
#define __DICT_H_

#include <glob.h>
#include <stdbool.h>


typedef struct dict_t {
    int **data;

    size_t lines;
    size_t columns;
    size_t num_solutions;
} dict_t;

dict_t *create_dict(size_t num_lines, size_t num_columns);
void free_dict(dict_t *dict);

bool exists_in_dict(dict_t *dict, int *values, size_t n);
void push_in_dict(dict_t *dict, int *values, size_t n);

#endif
