#ifndef __STATS_H_
#define __STATS_H_

#include <sys/time.h>


typedef struct stats_t {
    __suseconds_t time;

    int num_solutions;
    int num_tests;
} stats_t;

void new_solution_found();
void reset_solutions();
int get_num_solutions();

void new_test_done();
void test_cancelled();
void reset_tests();
int get_num_tests();

#endif
