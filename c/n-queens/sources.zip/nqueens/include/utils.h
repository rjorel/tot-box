#ifndef DEF_COMMON
#define DEF_COMMON

#include <stdbool.h>


void generate(int *values, size_t n);
void swap(int *a, int *b);

bool check_combination(int *values, size_t n);
bool is_possible_value_at_position(int *values, int value, int position);

#endif