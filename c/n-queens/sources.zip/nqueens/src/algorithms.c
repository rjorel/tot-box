#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <dict.h>

#include "utils.h"
#include "algorithms.h"


/*
 * Permutation.
 */
static bool permutation(int *values, int position, size_t n, bool all) {
    if ((size_t) position == n) {
        if (check_combination(values, n)) {
            new_solution_found();

            if (!all) {
                return true;
            }
        } else {
            new_test_done();
        }

        return false;
    }

    for (int i = position; i < n; i++) {
        swap(values + position, values + i);

        // Stop recursion here when we are looking for the first solution.
        if (permutation(values, position + 1, n, all) && !all) {
            return true;
        }

        swap(values + position, values + i);
    }

    return false;
}

void permutation_first(int *values, size_t n) {
    permutation(values, 0, n, false);
}

void permutation_all(int *values, size_t n) {
    permutation(values, 0, n, true);
}

/*
 * Backtracking.
 */
static bool backtracking(int *values, int position, size_t n, bool all) {
    if ((size_t) position == n) {
        new_solution_found();
        test_cancelled();

        return true;
    }

    for (int value = 1; (size_t) value <= n; value++) {
        new_test_done();

        if (is_possible_value_at_position(values, value, position)) {
            values[position] = value;

            // Stop recursion here when we are looking for the first solution.
            if (backtracking(values, position + 1, n, all) && !all) {
                return true;
            }
        }
    }

    return false;
}

void backtracking_first(int *values, size_t n) {
    backtracking(values, 0, n, false);
}

void backtracking_all(int *values, size_t n) {
    backtracking(values, 0, n, true);
}

/*
 * Las Vegas.
 */
static bool last_vegas(int *values, size_t n) {
    int position = 0, num;

    do {
        int tmp = 0;
        num = 0;

        // It seems to simulate an uniform law for repartition, but I don't remember exactly how it works here.
        // In every case, the idea is to place queens randomly, and check if result solution is good.
        for (int value = 1; (size_t) value <= n; value++) {
            new_test_done();

            if (is_possible_value_at_position(values, value, position)) {
                num++;

                if ((rand() % num + 1) == 1) {
                    tmp = value;
                }
            }
        }

        if (num > 0) {
            values[position] = tmp;
            position++;
        }
    } while (num > 0 && (size_t) position < n);

    return ((size_t) position == n);
}

static void obstinate_last_vegas(int *values, size_t n) {
    while (!last_vegas(values, n)) {
        //
    }
}

void las_vegas_first(int *values, size_t n) {
    obstinate_last_vegas(values, n);

    new_solution_found();
}

void last_vegas_all(int *values, size_t n) {
    // Retrieve number of solutions first.
    backtracking(values, 0, n, true);

    int num_solutions = get_num_solutions();

    // Only Las Vegas algorithm tests and solutions are considered.
    reset_tests();

    // Search for all solutions using a dictionary that stores all found solutions.
    dict_t *dict = create_dict((size_t) num_solutions, n);

    while (dict->num_solutions < dict->lines) {
        obstinate_last_vegas(values, n);

        if (!exists_in_dict(dict, values, n)) {
            push_in_dict(dict, values, n);
        }
    }

    free_dict(dict);
}