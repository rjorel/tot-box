#include <stdlib.h>
#include <string.h>

#include "dict.h"


dict_t *create_dict(size_t num_lines, size_t num_columns) {
    dict_t *dict = malloc(sizeof(dict_t));

    dict->data = malloc(num_lines * sizeof(int *));

    for (int i = 0; i < num_lines; i++) {
        dict->data[i] = malloc(num_columns * sizeof(int));
    }

    dict->lines = num_lines;
    dict->columns = num_columns;
    dict->num_solutions = 0;

    return dict;
}

void free_dict(dict_t *dict) {
    for (int i = 0; i < dict->lines; i++) {
        free(dict->data[i]);
    }

    free(dict->data);
    free(dict);
}

bool exists_in_dict(dict_t *dict, int *values, size_t n) {
    if (n != dict->columns) {
        return false;
    }

    for (int i = 0; i < dict->num_solutions; i++) {
        if (memcmp(dict->data[i], values, n * sizeof(int)) == 0) {
            return true;
        }
    }

    return false;
}

void push_in_dict(dict_t *dict, int *values, size_t n) {
    if (n != dict->columns || dict->num_solutions >= dict->lines) {
        return;
    }

    memcpy(dict->data[dict->num_solutions], values, n * sizeof(int));
    dict->num_solutions++;
}