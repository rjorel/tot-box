#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "utils.h"
#include "algorithms.h"


typedef void (*func_t)(int *, size_t);

typedef struct algorithm_t {
    char *name;
    func_t func;
} algorithm_t;

static algorithm_t algorithms[] = {
    { "permutation-first",  permutation_first },
    { "permutation-all",    permutation_all },
    { "backtracking-first", backtracking_first },
    { "backtracking-all",   backtracking_all },
    { "las-vegas-first",    las_vegas_first },
    { "las-vegas-all",      last_vegas_all },
    { NULL, NULL }
};

static void usage(char *exe_name) {
    printf("Usage: %s algorithm-id [num-values = 8]\n", exe_name);
    printf("Sort values on standard input in numeric order\n\n");

    printf("algorithm-id:\n");

    for (algorithm_t *a = algorithms; a->name != NULL; a++) {
        printf("    %s\n", a->name);
    }
}

static algorithm_t get_algorithm(const char *sort_id) {
    algorithm_t *a = algorithms;

    for (; a->name != NULL && strcmp(a->name, sort_id) != 0; a++) {
        //
    }

    return *a;
}

int main(int argc, char *argv[]) {
    srand(time(NULL));

    size_t num_values = 8;

    switch (argc) {
        case 1:
            usage(argv[0]);
            return EXIT_FAILURE;

        case 2:
            break;

        default:
            num_values = (size_t) strtol(argv[2], NULL, 10);
            break;
    }

    algorithm_t algorithm = get_algorithm(argv[1]);

    if (algorithm.func == NULL) {
        printf("%s: '%s' does not refer an algorithm, see usage.\n", argv[0], argv[1]);
        return EXIT_FAILURE;
    }

    // As queens are on different rows, only columns are considered to save time.
    // Each array offset represents a row.
    int *values = malloc(num_values * sizeof(int));
    generate(values, num_values);

    reset_solutions();
    reset_tests();

    clock_t start, end;
    start = clock();

    algorithm.func(values, num_values);

    end = clock();
    free(values);

    printf("Elapsed time: %lfs\n", (end - start) / ((double) CLOCKS_PER_SEC));
    printf("#solutions: %d\n", get_num_solutions());
    printf("#tests: %d\n", get_num_tests());

    return EXIT_SUCCESS;
}