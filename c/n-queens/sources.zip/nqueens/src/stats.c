#include "stats.h"


int num_solutions;
int num_tests;

void new_solution_found() {
    num_solutions++;
}

int get_num_solutions() {
    return num_solutions;
}

void reset_solutions() {
    num_solutions = 0;
}

void new_test_done() {
    num_tests++;
}

void test_cancelled() {
    num_tests--;
}

void reset_tests() {
    num_tests = 0;
}

int get_num_tests() {
    return num_tests;
}