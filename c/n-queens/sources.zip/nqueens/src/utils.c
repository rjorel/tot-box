#include <stdio.h>
#include <stdlib.h>

#include "utils.h"


void generate(int *values, size_t n) {
    for (int i = 0; i < n; i++) {
        values[i] = i + 1;
    }
}

void swap(int *a, int *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

static bool check_columns(int *values, size_t n) {
    for (int i = 0; (size_t) i < n; i++) {
        for (int j = i + 1; (size_t) j < n; j++) {
            if (values[i] == values[j]) {
                return false;
            }
        }
    }

    return true;
}

static bool on_same_diagonal(int i, int j, int k, int l) {
    return (abs(i - k) == abs(j - l));
}

static bool check_diagonals(int *values, size_t n) {
    for (int i = 0; (size_t) i < n; i++) {
        for (int j = i + 1; (size_t) j < n; j++) {
            if (on_same_diagonal(i + 1, values[i], j + 1, values[j])) {
                return false;
            }
        }
    }

    return true;
}

bool check_combination(int *values, size_t n) {
    return check_columns(values, n)
        && check_diagonals(values, n);
}

static bool exists_in_column(int *values, int value, int position) {
    for (int i = 0; i < position; i++) {
        if (values[i] == value) {
            return true;
        }
    }

    return false;
}

static bool exists_in_diagonal(int *values, int value, int position) {
    for (int i = 0; i < position; i++) {
        if (on_same_diagonal(i + 1, values[i], position + 1, value)) {
            return true;
        }
    }

    return false;
}

bool is_possible_value_at_position(int *values, int value, int position) {
    return !exists_in_column(values, value, position)
        && !exists_in_diagonal(values, value, position);
}