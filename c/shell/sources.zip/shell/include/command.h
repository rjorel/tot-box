#ifndef __COMMAND_H_
#define __COMMAND_H_

#define SIZE_ARGS   16


typedef struct command_t {
    char *name;
    char **args;
    int in;
    int out;
    int is_background;
} command_t;

command_t *new_command(char *str, int in, int out);
void exec_command(command_t *cmd);
void display_command(command_t *cmd);
void free_command(command_t *cmd);

#endif
