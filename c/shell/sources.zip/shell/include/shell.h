#ifndef __SHELL_H_
#define __SHELL_H_

#define IN  0
#define OUT 1

int launch(char *str);

#endif
