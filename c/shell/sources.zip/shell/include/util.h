#ifndef __UTIL_H_
#define __UTIL_H_

#define CHAR_NEWLINE    '\n'
#define CHAR_ENDLINE    '\0'
#define CHAR_RETURN     '\r'
#define CHAR_TAB        '\t'
#define CHAR_SPACE      ' '
#define CHAR_BG         '&'

#define STREAM_IN       '<'
#define STREAM_OUT      '>'
#define STREAM_PIPE     '|'

#define IS_TERMINAL(c)      ((c) == CHAR_RETURN || (c) == CHAR_NEWLINE || (c) == CHAR_ENDLINE)
#define IS_BLANK(c)         ((c) == CHAR_TAB || (c) == CHAR_SPACE)
#define IS_REDIRECTION(c)   ((c) == STREAM_IN || (c) == STREAM_OUT)
#define IS_BG(c)            ((c) == CHAR_BG)

void close_file(int descriptor, int expected_value);
int next_word(char *str, char **begin);

#endif
