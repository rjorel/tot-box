#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#include "util.h"
#include "command.h"


/**
 * Parse a string, to extract a command with arguments and attached file descriptors.
 *
 * @param str command string to parse.
 * @param in input file descriptor.
 * @param out output file descriptor.
 *
 * @return the command.
 */
command_t *new_command(char *str, int in, int out) {
    command_t *cmd = NULL;
    char *begin, **tmp;
    int len, num_args = 1, times = 1;

    // This case happens when the given string is empty.
    if ((len = next_word(str, &begin)) == 0) {
        close_file(in, STDIN_FILENO);
        close_file(out, STDOUT_FILENO);

        return NULL;
    }

    cmd = malloc(sizeof(command_t));
    cmd->in = in;
    cmd->out = out;
    cmd->is_background = 0;

    cmd->name = malloc((len + 1) * sizeof(char));
    cmd->args = malloc(SIZE_ARGS * sizeof(char *));
    cmd->args[0] = malloc((len + 1) * sizeof(char));

    strncpy(cmd->name, begin, (size_t) len);
    cmd->name[len] = CHAR_ENDLINE;

    strncpy(cmd->args[0], begin, (size_t) len);
    cmd->args[0][len] = CHAR_ENDLINE;

    str = begin + len;

    while ((len = next_word(str, &begin))) {
        cmd->args[num_args] = malloc((len + 1) * sizeof(char));

        strncpy(cmd->args[num_args], begin, (size_t) len);
        cmd->args[num_args][len] = CHAR_ENDLINE;

        str = begin + len;
        num_args++;

        // Increase array size, if the command has a lots of arguments.
        if (num_args >= SIZE_ARGS * times) {
            times++;
            tmp = cmd->args;

            cmd->args = malloc((SIZE_ARGS * times) * sizeof(char *));
            memcpy(cmd->args, tmp, num_args * sizeof(char *));

            free(tmp);
        }
    }

    if (IS_BG(*begin)) {
        cmd->is_background = 1;
    }

    // NULL for last argument, due to execvp() mechanisms.
    cmd->args[num_args] = NULL;

    return cmd;
}

void exec_command(command_t *cmd) {
    if (cmd == NULL) {
        return;
    }

    // Change directory command is internal.
    if (strcmp(cmd->name, "cd") == 0) {
        if (chdir(cmd->args[1]) == -1) {
            printf("shell: %s: not a directory\n", cmd->args[1]);
        }

        return;
    }

    if (fork() == 0) {
        // Child.
        dup2(cmd->in, STDIN_FILENO);
        dup2(cmd->out, STDOUT_FILENO);

        if (execvp(cmd->name, cmd->args) == -1) {
            printf("shell: %s: bad command\n", cmd->name);
        }

        exit(0);
    } else if (!cmd->is_background) {
        // Parent.
        wait(NULL);
    }
}

void display_command(command_t *cmd) {
    if (cmd == NULL) {
        return;
    }

    puts("----------------------------");
    printf("command : %s\nargs :\n", cmd->name);

    for (int i = 0; cmd->args[i] != NULL; i++) {
        printf("\t- %s\n", cmd->args[i]);
    }

    printf("in = %d, out = %d\n", cmd->in, cmd->out);
    printf("bg = %s\n", cmd->is_background ? "true" : "false");
    puts("----------------------------");
}

void free_command(command_t *cmd) {
    if (cmd == NULL) {
        return;
    }

    for (int i = 0; cmd->args[i] != NULL; i++) {
        free(cmd->args[i]);
    }

    free(cmd->args);
    free(cmd->name);

    close_file(cmd->in, STDIN_FILENO);
    close_file(cmd->out, STDOUT_FILENO);

    free(cmd);
}
