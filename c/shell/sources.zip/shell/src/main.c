#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "shell.h"


#define MAX_LINE_SIZE   256

static char prompt[MAX_LINE_SIZE];

static char *get_prompt() {
    getcwd(prompt, MAX_LINE_SIZE);
    
    return prompt;
}

int main() {
    char str[MAX_LINE_SIZE];
    
    do {
        printf("%s$ ", get_prompt());

        if (fgets(str, MAX_LINE_SIZE, stdin) == NULL) {
            break;
        }

        launch(str);
    } while (1);

    puts("Exiting program");
    return 0;
}
