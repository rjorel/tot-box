#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#include "util.h"
#include "shell.h"
#include "command.h"


/**
 * Search for redirections in string.
 * Files are opened or created if redirects are specified (>, >>, <) and string is cleaned to keep
 * only potential command name and arguments.
 *
 * @param str string to parse.
 * @param in input file descriptor.
 * @param out output file descriptor.
 * @param init flag to indicate if file descriptors need initialisation (standard I/O if true).
 *
 * @return -1 if an error happens, 0 otherwise.
 */
static int redirection(char *str, int *in, int *out, int init) {
    int len = 0;
    char buf, *token;

    if (init) {
        *in = STDIN_FILENO, *out = STDOUT_FILENO;
    }

    while (*str != '\0') {
        for (; !IS_REDIRECTION(*str) && !IS_TERMINAL(*str); str++) {
            //
        }

        if (IS_TERMINAL(*str)) {
            break;
        }

        // Offset computation to correctly shit string and ignore redirect characters.
        int offset = (*str == STREAM_OUT && *(str + 1) == STREAM_OUT) ? 2 : 1;

        if ((len = next_word(str + offset, &token)) == 0) {
            printf("shell: unexpected token `%c'\n", *token);
            return -1;
        }

        // Isolate token to make easier file name manipulations.
        buf = token[len];
        token[len] = CHAR_ENDLINE;

        if (*str == STREAM_OUT) {
            // Close previous potential opened file, to keep only one redirection as output.
            close_file(*out, STDOUT_FILENO);

            *out = open(token, O_WRONLY | O_CREAT, 0664);

            // Append case.
            if (*(str + 1) == STREAM_OUT) {
                lseek(*out, 0, SEEK_END);
            }
        } else {
            // Same idea with input redirection.
            close_file(*in, STDIN_FILENO);

            if ((*in = open(token, O_RDONLY)) == -1) {
                printf("shell: %s: no such file or directory\n", token);

                // If any error happens when trying to open a file, it's important to ensure output
                // file is closed.
                close_file(*out, STDOUT_FILENO);

                return -1;
            }
        }

        // Restore original string, to keep a normal execution.
        token[len] = buf;

        // Purge redirection indications with blank characters.
        for (; str < token + len; str++) {
            *str = CHAR_SPACE;
        }
    }

    return 0;
}

static int execute(char *str, int in, int out) {
    command_t *cmd;

    if (redirection(str, &in, &out, 0) == -1) {
        return -1;
    }

    if ((cmd = new_command(str, in, out)) == NULL) {
        return -1;
    }

    display_command(cmd);
    exec_command(cmd);
    free_command(cmd);

    return 0;
}

static int analysis(char *str) {
    char *next;
    int index = 0;

    int tube[2][2] = {
        {STDIN_FILENO, STDOUT_FILENO},
        {STDIN_FILENO, STDOUT_FILENO}
    };

    while ((next = strchr(str, STREAM_PIPE)) != NULL) {
        *next = CHAR_ENDLINE;
        pipe(tube[1 - index]);

        if (execute(str, tube[index][IN], tube[1 - index][OUT]) == -1) {
            return -1;
        }

        str = next + 1;
        index ^= 1;
    }

    tube[1 - index][OUT] = STDOUT_FILENO;
    if (execute(str, tube[index][IN], tube[1 - index][OUT]) == -1) {
        return -1;
    }

    return 0;
}

int launch(char *str) {
    char *substr = strtok(str, ";");

    while (substr != NULL) {
        analysis(substr);
        substr = strtok(NULL, ";");
    }

    return 0;
}
