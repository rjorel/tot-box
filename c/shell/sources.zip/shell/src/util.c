#include <unistd.h>
#include "util.h"


/**
 * Securely close file descriptor if different from expected value.
 *
 * @param descriptor
 * @param expected_value
 */
void close_file(int descriptor, int expected_value) {
    if (descriptor != expected_value) {
        close(descriptor);
    }
}

/**
 * Search the next word in a string.
 * Spaces are ignored, and terminal characters or redirects stop search.
 *
 * @param str string to parse.
 * @param begin pointer to next word.
 * @return next word length.
 */
int next_word(char *str, char **begin) {
    for (; IS_BLANK(*str); str++) {
        //
    }

    *begin = str;

    int i = 0;
    while (!IS_BLANK(str[i]) && !IS_TERMINAL(str[i]) && !IS_REDIRECTION(str[i]) && !IS_BG(str[i])) {
        i++;
    }

    return i;
}
