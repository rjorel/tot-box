
#ifndef __ALGORITHMS_H_
#define __ALGORITHMS_H_

void quick_sort(int *values, size_t size);
void merge_sort(int *values, size_t size);
void bubble_sort(int *values, size_t size);
void insertion_sort(int *values, size_t size);
void selection_sort(int *values, size_t size);
void heap_sort(int *values, size_t size);
void radix_sort(int *values, size_t size);
void counting_sort(int *values, size_t size);
void bucket_sort(int *values, size_t size);
void odd_even_sort(int *values, size_t size);

#endif
