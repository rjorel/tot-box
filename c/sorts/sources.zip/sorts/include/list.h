#ifndef __LIST_H_
#define __LIST_H_

typedef struct node_t {
    int value;
    struct node_t *next;
} node_t;

typedef struct list_t {
    int length;
    struct node_t *first;
    struct node_t *last;
} list_t;

list_t *list_create();
void list_add(list_t *list, int value);
int *list_to_array(list_t *list);
void list_free(list_t *list);

#endif
