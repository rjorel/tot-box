#ifndef __UTILS_H_
#define __UTILS_H_

#include <stdlib.h>

int max(const int *values, size_t size);
int min(const int *values, size_t size);

void swap(int *a, int *b);

#endif
