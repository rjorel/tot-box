#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utils.h"
#include "list.h"
#include "algorithms.h"


void bubble_sort(int *values, size_t size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - (i + 1); j++) {
            if (values[j] > values[j + 1]) {
                swap(&values[j], &values[j + 1]);
            }
        }
    }
}

void insertion_sort(int *values, size_t size) {
    for (int i = 1; i < size; i++) {
        int tmp = values[i];
        int j;

        for (j = i; j > 0 && values[j - 1] > tmp; j--) {
            values[j] = values[j - 1];
        }

        values[j] = tmp;
    }
}

void selection_sort(int *values, size_t size) {
    for (int i = 0; i < size - 1; i++) {
        int j_min = i;

        for (int j = i + 1; j < size; j++) {
            if (values[j_min] > values[j]) {
                j_min = j;
            }
        }

        swap(&values[j_min], &values[i]);
    }
}

static int partition(int *values, int left, int right) {
    int i = left, j = right - 1;
    int pivot = values[right];

    while (i < j) {
        while (values[i] < pivot && i < right) {
            i++;
        }

        while (values[j] >= pivot && i < j) {
            j--;
        }

        swap(&values[i], &values[j]);
    }

    if (values[j] > values[right]) {
        swap(&values[j], &values[right]);
    }

    return j;
}

static void quick_sort_aux(int *values, int left, int right) {
    if (left >= right) {
        return;
    }

    int pivot = partition(values, left, right);

    quick_sort_aux(values, left, pivot - 1);
    quick_sort_aux(values, pivot + 1, right);
}

void quick_sort(int *values, size_t size) {
    quick_sort_aux(values, 0, (int) (size - 1));
}

static void merge(int *values, int left, int middle, int right) {
    int length = (right - left) + 1;
    int aux[length];

    for (int i = left, j = middle + 1, k = 0; k < length; k++) {
        if (i <= middle && j <= right) {
            aux[k] = (values[i] < values[j]) ? values[i++] : values[j++];
        } else {
            if (i <= middle) {
                aux[k] = values[i++];
            } else {
                aux[k] = values[j++];
            }
        }
    }

    for (int i = 0; i < length; i++) {
        values[left + i] = aux[i];
    }
}

static void merge_sort_aux(int *value, int left, int right) {
    if (left >= right) {
        return;
    }

    int middle = (right + left) / 2;

    merge_sort_aux(value, left, middle);
    merge_sort_aux(value, middle + 1, right);

    merge(value, left, middle, right);
}

void merge_sort(int *values, size_t size) {
    merge_sort_aux(values, 0, (int) (size - 1));
}

static void sift(int *tree, int node, int n) {
    int k = node;
    int j = 2 * k;

    while (j < n) {
        if (tree[j] < tree[j + 1]) {
            j++;
        }

        if (tree[k] < tree[j]) {
            swap(&tree[k], &tree[j]);

            k = j;
            j = 2 * k;
        } else {
            return;
        }
    }
}

void heap_sort(int *values, size_t size) {
    for (int i = (int) (size / 2); i >= 0; i--) {
        sift(values, i, (int) size);
    }

    for (int i = (int) (size - 1); i >= 1; i--) {
        swap(&values[i], &values[0]);
        sift(values, 0, i - 1);
    }
}

void radix_sort(int *values, size_t size) {
    int (*stack)[10] = malloc(size * sizeof(int[10]));
    int base = 1;

    for (;;) {
        int top_stack[10] = {0};
        int key_sum = 0;

        for (int i = 0; i < size; i++) {
            int key = (abs(values[i]) / base) % 10;
            int stack_num = top_stack[key]++;

            stack[stack_num][key] = values[i];
            key_sum += key;
        }

        if (key_sum == 0) {
            break;
        }

        int offset = 0;

        // Begin by negative values.
        for (int i = 9; i >= 0; i--) {
            for (int j = 0; j < top_stack[i]; j++) {
                if (stack[j][i] < 0) {
                    values[offset++] = stack[j][i];
                }
            }
        }

        // And finish by positive ones.
        for (int i = 0; i <= 9; i++) {
            for (int j = 0; j < top_stack[i]; j++) {
                if (stack[j][i] >= 0) {
                    values[offset++] = stack[j][i];
                }
            }
        }

        // Go to next decimal base.
        base *= 10;
    }

    free(stack);
}

void counting_sort(int *values, size_t size) {
    int inf_bound = min(values, size);
    int sup_bound = max(values, size);

    int length = (sup_bound - inf_bound) + 1;
    int counters[length];

    memset(counters, 0, length * sizeof(int));

    for (int i = 0; i < size; i++) {
        int index = values[i] - inf_bound;

        counters[index]++;
    }

    for (int i = 0, offset = 0; i < length; i++) {
        for (int j = 0; j < counters[i]; j++) {
            values[offset++] = i + inf_bound;
        }
    }
}

void bucket_sort(int *values, size_t size) {
    int a = min(values, size);
    int b = max(values, size) + 1;  // I can't really explain this '+1' here.

    list_t *buckets[size];

    for (int i = 0; i < size; i++) {
        buckets[i] = list_create();
    }

    for (int i = 0; i < size; i++) {
        // Deduced index for current value, following the bucket belonging formula.
        int index = (((int) size) * (values[i] - a) / (b - a));

        list_add(buckets[index], values[i]);
    }

    for (int i = 0, k = 0; i < size; i++) {
        int *aux = list_to_array(buckets[i]);
        quick_sort_aux(aux, 0, buckets[i]->length - 1);

        for (int j = 0; j < buckets[i]->length; j++) {
            values[k++] = aux[j];
        }

        list_free(buckets[i]);
        free(aux);
    }
}

void odd_even_sort(int *values, size_t size) {
    for (int i = 0; i < size - 1; i++) {
        // Start index is different for odd and event values.
        for (int j = i & 1; j < size - 1; j += 2) {
            if (values[j] > values[j + 1]) {
                swap(&values[j], &values[j + 1]);
            }
        }
    }
}
