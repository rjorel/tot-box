#include <stdio.h>
#include <stdlib.h>

#include "list.h"


list_t *list_create() {
    list_t *list = malloc(sizeof(list_t));

    list->length = 0;
    list->first = NULL;
    list->last = NULL;

    return list;
}

void list_add(list_t *list, int value) {
    node_t *node = malloc(sizeof(node_t));

    node->value = value;
    node->next = NULL;

    // Assume the normal case: if the first pointed node is not null, it's because this function
    // was already used, and last pointed node is not null too.
    if (list->first == NULL) {
        list->first = node;
    } else {
        list->last->next = node;
    }

    list->last = node;
    list->length++;
}

int *list_to_array(list_t *list) {
    int *values = malloc(list->length * sizeof(int));
    node_t *current = list->first;

    for (int i = 0; current != NULL; current = current->next, i++) {
        values[i] = current->value;
    }

    return values;
}

void list_free(list_t *list) {
    node_t *current = list->first, *tmp;

    while (current != NULL) {
        tmp = current;
        current = current->next;

        free(tmp);
    }

    free(list);
}