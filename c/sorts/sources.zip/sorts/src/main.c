#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "list.h"
#include "algorithms.h"


#define BLANK_CHARS     " \t"

typedef void (*func_t)(int *, size_t);

typedef struct algorithm_t {
    char *name;
    func_t func;
} algorithm_t;

static algorithm_t algorithms[] = {
    {"bubble",    bubble_sort},
    {"insertion", insertion_sort},
    {"selection", selection_sort},
    {"quick",     quick_sort},
    {"merge",     merge_sort},
    {"heap",      heap_sort},
    {"radix",     radix_sort},
    {"counting",  counting_sort},
    {"bucket",    bucket_sort},
    {"odd-even",  odd_even_sort},
    {NULL, NULL}
};

static void usage(char *exe_name) {
    printf("Usage: %s sort-id [num-iterations = 1]\n", exe_name);
    printf("Sort values on standard input in numeric order\n\n");

    printf("sort-id:\n");

    for (algorithm_t *a = algorithms; a->name != NULL; a++) {
        printf("    %s\n", a->name);
    }
}

static algorithm_t get_algorithm(const char *sort_id) {
    algorithm_t *a = algorithms;

    for (; a->name != NULL && strcmp(a->name, sort_id) != 0; a++) {
        //
    }

    return *a;
}

static list_t *read_input() {
    list_t *list = list_create();
    char buf[BUFSIZ];

    while (fgets(buf, BUFSIZ, stdin) != NULL) {
        char *token = strtok(buf, BLANK_CHARS);

        do {
            list_add(list, (int) strtol(token, NULL, 10));

            token = strtok(NULL, BLANK_CHARS);
        } while (token);
    }

    return list;
}

static void execute(func_t func, int *values, size_t size, int num_iteration) {
    for (int i = 0; i < num_iteration; i++) {
        func(values, size);
    }
}

static void write_output(int *values, size_t size) {
    for (size_t i = 0; i < size; i++) {
        printf("%d ", values[i]);
    }

    printf("\n");
}

int main(int argc, char *argv[]) {
    int num_iterations = 1;

    switch (argc) {
        case 1:
            usage(argv[0]);
            return EXIT_FAILURE;

        case 2:
            break;

        default:
            num_iterations = (int) strtol(argv[2], NULL, 10);
            break;
    }

    algorithm_t algorithm = get_algorithm(argv[1]);

    if (algorithm.func == NULL) {
        printf("%s: '%s' does not refer an algorithm, see usage.\n", argv[0], argv[1]);
        return EXIT_FAILURE;
    }

    list_t *list = read_input();
    int *values = list_to_array(list);

#ifdef DEBUG
    write_output(values, (size_t) list->length);
#endif

    clock_t start, end;
    start = clock();

    execute(algorithm.func, values, (size_t) list->length, num_iterations);

    end = clock();
    printf("Elapsed time: %lfs\n", (end - start) / ((double) CLOCKS_PER_SEC));

#ifdef DEBUG
    write_output(values, (size_t) list->length);
#endif

    list_free(list);
    free(values);

    return EXIT_SUCCESS;
}
