#include "utils.h"


static int search(const int *values, size_t size, int (cmp)(int, int)) {
    size_t index = 0;

    for (size_t i = 1; i < size; i++) {
        if (cmp(values[index], values[i])) {
            index = i;
        }
    }

    return values[index];
}

static int max_cmp(int a, int b) {
    return a < b;
}

static int min_cmp(int a, int b) {
    return a > b;
}

int max(const int *values, size_t size) {
    return search(values, size, max_cmp);
}

int min(const int *values, size_t size) {
    return search(values, size, min_cmp);
}

void swap(int *a, int *b) {
    int tmp = *a;

    *a = *b;
    *b = tmp;
}
