#ifndef ACTION_H
#define ACTION_H

#include "mesh.h"


class Action {
public:
    Action()  : m_mesh(0) { }

    void setMesh(Mesh *mesh) {
        m_mesh = mesh;
    }

    virtual void exec() = 0;

protected:
    Mesh *m_mesh;
};

#endif // ACTION_H

