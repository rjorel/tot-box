#ifndef BOUNDINGBOX_H
#define BOUNDINGBOX_H

#include "utils.h"


/**
 * Basic bounding box.
 */
class BoundingBox
{
public:
    BoundingBox();
    BoundingBox(const Vector3f &vmin, const Vector3f &vmax);

    const Vector3f min() const;
    const Vector3f max() const;

    void reset();
    void extend(const Vector3f &vertex);
    const Vector3f sizes() const;
    const float maxSize() const;
    const bool contains(const Vector3f &vertex) const;

private:
    Vector3f m_min, m_max;
    bool m_init;
};

#endif // BOUNDINGBOX_H
