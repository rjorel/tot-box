#ifndef DECIMATEACTION_H
#define DECIMATEACTION_H

#include "action.h"
#include "octree.h"
#include "meshviewer.h"
#include "glwidget.h"


class DecimateAction : public Action {
public:
    DecimateAction() : Action() { }

    void exec() {
        MeshViewer *meshViewer = new MeshViewer;
        GLWidget *viewer = new GLWidget;

        // Build octree and get remaining vertices (leaves).
        Octree octree(m_mesh->vertices());
        octree.build();
        std::vector<Vertex> remainingVertices = octree.getVertices();

        // Build a new mesh.
        Mesh *mesh = new Mesh;
        for (const Vertex &v: remainingVertices)
            mesh->addVertex(v);

        mesh->center();

        // Display only points.
        meshViewer->setMesh(mesh);
        meshViewer->addDisplayMode(MeshViewer::POINTS);
        meshViewer->delDisplayMode(MeshViewer::LINES);
        meshViewer->delDisplayMode(MeshViewer::POLYGON);
        meshViewer->setTransparency(1.f);

        // Display just in a simple viewer.
        viewer->setMeshViewer(meshViewer);
        viewer->setDistance(mesh->boundingBox().maxSize() * 1.5);
        viewer->setWindowTitle("Decimation results");
        viewer->show();
    }
};

#endif // DECIMATEACTION_H
