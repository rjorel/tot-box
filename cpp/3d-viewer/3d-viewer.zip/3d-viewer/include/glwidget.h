#ifndef GLVIEWER_H
#define GLVIEWER_H

#include <QtOpenGL>
#include "meshviewer.h"


/**
 * OpenGL rendering widget.
 */
class GLWidget : public QGLWidget {
public:
    GLWidget(QWidget *parent = 0);

    // Default widget size.
    QSize sizeHint() const;

    // Setters.
    void setMeshViewer(MeshViewer *mesh);
    void setDistance(float distance);

protected:
    // Basic functions to use OpenGL.
    void initializeGL();
    void resizeGL(int width, int height);
    void paintGL();

    // User input handling.
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);

private:
    // Variables for navigation around objects.
    int m_alpha;
    int m_beta;
    float m_distance;
    QPoint m_lastMousePosition;
    QVector3D m_center;

    MeshViewer *m_meshViewer;
};

#endif // GLVIEWER_H
