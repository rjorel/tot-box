#ifndef HOLEFILLINGACTION_H
#define HOLEFILLINGACTION_H

#include <cassert>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/Polyhedron_incremental_builder_3.h>

#include "action.h"
#include "meshviewer.h"
#include "glwidget.h"

typedef CGAL::Simple_cartesian<double>                  Kernel;
typedef Kernel::Point_3                                 Point_3;
typedef Kernel::Vector_3                                Vector_3;
typedef Kernel::Plane_3                                 Plane_3;
typedef CGAL::Polyhedron_3<Kernel>                      Polyhedron;
typedef Polyhedron::HalfedgeDS                          HalfedgeDS;
typedef Polyhedron::Vertex_iterator                     Vertex_iterator;
typedef Polyhedron::Face_iterator                       Face_iterator;
typedef Polyhedron::Halfedge_iterator                   Halfedge_iterator;
typedef Polyhedron::Halfedge_handle                     Halfedge_handle;
typedef Polyhedron::Halfedge_around_facet_circulator    Halfedge_facet_circulator;
typedef Polyhedron::Halfedge_around_vertex_circulator   Halfedge_vertex_circulator;


/**
 * Class to build a polyhedron from a vertice list and a face list.
 */
template <class HDS>
class Polyhedron_builder: public CGAL::Modifier_base<HDS>{
protected:
    std::vector<Vertex> m_vertices;
    std::vector<FaceIdx> m_faces;

public:
    typedef HDS Half_edge_data_structure;

    Polyhedron_builder(std::vector<Vertex> vertices, std::vector<FaceIdx> faces) :
        m_vertices(vertices), m_faces(faces){}

    void operator()(HDS& hds);
};

template <class HDS>
void Polyhedron_builder<HDS>::operator()(HDS& hds) {
    CGAL::Polyhedron_incremental_builder_3<HDS> B(hds, true);
    B.begin_surface(m_vertices.size(), m_faces.size());

    for (Vertex v: m_vertices)
        B.add_vertex(Point_3(v.position.x, v.position.y, v.position.z));

    for (FaceIdx face: m_faces) {
        B.begin_facet();

        for (uint index : face.indices)
            B.add_vertex_to_facet(index);

        B.end_facet();
    }
}


class HoleFillingAction : public Action {
public:
    HoleFillingAction() : Action() { }

    void exec() {
        Polyhedron P;
        Polyhedron_builder<HalfedgeDS> P_builder(m_mesh->vertices(), m_mesh->faces());

        P.delegate(P_builder);
        P.normalize_border();

        if (!P.is_valid()) {
            QMessageBox::critical(0, "Error", "The mesh is not topologically valid");
            return;
        }

        if (P.is_closed()) {
            QMessageBox::warning(0, "Warning", "The mesh is closed yet");
            return;
        }

        // If the mesh is not closed, we fill in holes.
        for (Halfedge_iterator he = P.halfedges_begin() ; he != P.halfedges_end() ; ++he) {
            if (he->is_border()) {

                Halfedge_handle he1 = he->prev();
                Halfedge_handle he2 = he1->next();
                Halfedge_handle he3 = he1->next()->next();

                if (he1 != he2 && he1 != he3 && he2 != he3) {
                    Plane_3 plane(he1->vertex()->point(),
                                  he2->vertex()->point(),
                                  he3->vertex()->point());

                    Halfedge_iterator hit = he1;
                    do {
                        Point_3 proj = plane.projection(hit->vertex()->point());
                        Vector_3 v = proj - hit->vertex()->point();

                        if (v.squared_length() > 1e-15)
                            break;

                        hit = hit->next();
                    } while (hit != he1);

                    if (hit == he1)
                        P.fill_hole(he1);

                    else
                        P.add_facet_to_border(he1, hit->prev());
                }
            }
        }

        P.normalize_border();

        MeshViewer *meshViewer = new MeshViewer;
        GLWidget *viewer = new GLWidget;

        Mesh *mesh = new Mesh;
        for (Vertex_iterator v = P.vertices_begin() ; v != P.vertices_end() ; ++v)
            mesh->addVertex(Vertex(Vector3f(
                                       v->point().x(),
                                       v->point().y(),
                                       v->point().z())));

        for (Face_iterator f = P.facets_begin() ; f != P.facets_end() ; ++f) {
            Halfedge_facet_circulator he = f->facet_begin();
            FaceIdx face;

            do {
                size_t index = 0;
                for (Vertex_iterator v = P.vertices_begin() ; v != P.vertices_end() && he->vertex() != v ; ++v, index++)
                    ;

                face << index;
            } while (++he != f->facet_begin());

            mesh->addFaceIndex(face);
        }

        mesh->center();

        // Display only points.
        meshViewer->setMesh(mesh);
        meshViewer->delDisplayMode(MeshViewer::POINTS);
        meshViewer->addDisplayMode(MeshViewer::LINES);
        meshViewer->addDisplayMode(MeshViewer::POLYGON);
        meshViewer->setTransparency(0.5f);

        // Display just in a simple viewer.
        viewer->setMeshViewer(meshViewer);
        viewer->setDistance(mesh->boundingBox().maxSize() * 1.5);
        viewer->setWindowTitle("Hole filling results");
        viewer->show();

        if (!P.is_closed()) QMessageBox::critical(0, "Error", "The mesh is still not topologically valid");
        else                QMessageBox::information(0, "Success", "Every hole was filled");

    }
};

#endif // HOLEFILLINGACTION_H
