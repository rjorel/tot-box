    #ifndef MESH_H
#define MESH_H

#include <QtOpenGL>
#include <iostream>
#include <vector>

#include "utils.h"
#include "boundingbox.h"


/**
 * Mesh representation and rendering.
 */
class Mesh {
public:
    Mesh();

    // Data handling.
    void reset();
    void addVertex(const Vertex &vertex);
    void addFaceIndex(const FaceIdx &face);

    // Mesh transformations.
    void translate(float dx, float dy, float dz);
    void translate(const Vector3f &vector);
    void center();

    // Getters.
    const std::vector<Vertex>& vertices() const;
    const Vertex& vertex(uint index) const;
    const std::vector<FaceIdx>& faces() const;

    const QMatrix4x4& transformation() const;
    const BoundingBox& boundingBox() const;

private:
    // Data storage.
    std::vector<Vertex> m_vertices;
    std::vector<FaceIdx> m_faces;

    // Bounding box.
    BoundingBox m_bbox;

    // Model transformation matrix.
    QMatrix4x4 m_transformation;
};

#endif // MESH_H
