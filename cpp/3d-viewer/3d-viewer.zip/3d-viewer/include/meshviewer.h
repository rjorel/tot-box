#ifndef MESHVIEWER_H
#define MESHVIEWER_H

#include <QtOpenGL>
#include "mesh.h"


class MeshViewer {
public:
    const static uint POINTS    = 1 << 0;
    const static uint LINES     = 1 << 1;
    const static uint POLYGON   = 1 << 2;


    MeshViewer();

    void setMesh(Mesh *mesh);
    void setTransparency(float transparency);
    void setShadeMode(GLenum mode);
    void setDisplayBBox(bool value);

    void addDisplayMode(uint mode);
    void delDisplayMode(uint mode);

    void display();

private:
    Mesh *m_mesh;

    uint m_displayModeMask;
    GLenum m_shadeMode;
    bool m_displayBBox;
    float m_transparency;
};

#endif // MESHVIEWER_H
