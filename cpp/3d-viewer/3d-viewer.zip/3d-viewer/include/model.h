#ifndef MODEL_H
#define MODEL_H

#include "mesh.h"


/**
 * Abstract class for different models.
 * Normally, each derived classe represents a type of mesh representation (PGM3D, OBJ, ...).
 */
class Model {
public:
    Model() { }
    virtual ~Model() { }

    virtual int readFromFile(const std::string &filename) = 0;      // Representation loading from file.
    virtual Mesh* getMesh() const = 0;                              // Build mesh from data representation.
};

#endif // MODEL_H
