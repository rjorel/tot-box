#ifndef OBJMODEL_H
#define OBJMODEL_H

#include "model.h"


/**
 * Model for OBJ files.
 */
class OBJModel : public Model
{
public:
    OBJModel();

    int readFromFile(const std::string &filename);
    Mesh* getMesh() const;

private:
    // Split a string (char sequence) according a delimiter.
    std::vector<std::string> split(char *buf, const char *delim);

    std::vector<Vertex> m_vertices;
    std::vector<FaceIdx> m_faces;
};

#endif // OBJMODEL_H
