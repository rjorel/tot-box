#ifndef OCTREE_H
#define OCTREE_H

#include <vector>

#include "utils.h"
#include "boundingbox.h"


/**
 * Octree representation for decimation.
 */
class Octree {
public:
    static const int NumMaxVertices = 10;

    struct Node {
        Vertex meanVertex;
        uint children[8];
        bool isLeaf;
    };

    Octree(const std::vector<Vertex> vertices);

    std::vector<Vertex> getVertices();
    void build();                           // Optimized by vertex sort.
    void basicBuild();                      // Not optimized.

private:
    void buildNode(uint nodeId, BoundingBox bbox, uint start, uint end);            // Optimized version.
    void buildNode(uint nodeId, BoundingBox bbox, Vector3f mean, uint numVertex);   // Not optimized.

    // Vertex index considering bounding box and this latter splitted in 8 sub-bounding boxes.
    // Return an integer between 0 et 7 (corresponding of each sub-bounding boxes).
    uint computeIndex(const Vector3f &vec, const BoundingBox &bbox) const;

    std::vector<Node> m_nodes;
    std::vector<Vertex> m_vertices;

    uint *m_vertexIndices;
};

#endif // OCTREE_H
