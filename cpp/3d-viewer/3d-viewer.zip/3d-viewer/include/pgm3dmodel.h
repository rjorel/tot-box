#ifndef PGM3DMODEL_H
#define PGM3DMODEL_H

#include "model.h"


/**
 * Model for PGM3D files.
 */
class PGM3DModel : public Model {
public:
    PGM3DModel();
    ~PGM3DModel();

    int readFromFile(const std::string &filename);
    Mesh* getMesh() const;

private:
    // Convenient function to create face in mesh.
    void addFace(Mesh *mesh, uint &offset, const Vector3f &current, const Color &color,
                 uint i1, uint i2, uint i3, uint i4) const;

    //     E-----F
    //    /|    /|       y
    //   A-----B |       |
    //   | G --|-H        --- x
    //   |/    |/       /
    //   C-----D       z

    // Invariable data. Deltas around a voxel.
    const Vector3f m_vertices[8] = {
        Vector3f(-0.5f,  0.5f,  0.5f),    // A. 0
        Vector3f( 0.5f,  0.5f,  0.5f),    // B. 1
        Vector3f(-0.5f, -0.5f,  0.5f),    // C. 2
        Vector3f( 0.5f, -0.5f,  0.5f),    // D. 3
        Vector3f(-0.5f,  0.5f, -0.5f),    // E. 4
        Vector3f( 0.5f,  0.5f, -0.5f),    // F. 5
        Vector3f(-0.5f, -0.5f, -0.5f),    // G. 6
        Vector3f( 0.5f, -0.5f, -0.5f)     // H. 7
    };

    uint m_width;
    uint m_height;
    uint m_depth;
    uint m_graymax;
    uint *m_data;
};

inline bool is_black(uint color) {
    return color == 0;
}

#endif // PGM3DMODEL_H
