#ifndef UTILS_H
#define UTILS_H

#include <iostream>
#include <vector>
#include <cmath>


/**
 * Util structures for mesh representation.
 */
struct Vector3f {
    float x, y, z;

    Vector3f(float _x = 0.f, float _y = 0.f, float _z = 0.f) : x(_x), y(_y), z(_z) { }

    // Operations.
    inline Vector3f& operator+=(const Vector3f &other) {
        *this = *this + other;
    }

    inline Vector3f& operator/=(float scalar) {
        *this = *this / scalar;
    }

    // Methods.
    inline float norm() const {
        return std::sqrt(x * x + y * y + z * z);
    }

    inline void normalize() {
        *this /= norm();
    }

    inline Vector3f normalized() const {
        return *this / norm();
    }

    // Friends. Convenient functions.
    inline friend Vector3f operator+(const Vector3f &v1, const Vector3f &v2) {
        return Vector3f(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
    }

    inline friend Vector3f operator-(const Vector3f &v1, const Vector3f &v2) {
        return Vector3f(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
    }

    inline friend Vector3f operator-(const Vector3f &v) {
        return Vector3f(-v.x, -v.y, -v.z);
    }

    inline friend Vector3f operator*(const Vector3f &vertex, float scalar) {
        return Vector3f(vertex.x * scalar, vertex.y * scalar, vertex.z * scalar);
    }

    inline friend Vector3f operator/(const Vector3f &vertex, float scalar) {
        return Vector3f(vertex.x / scalar, vertex.y / scalar, vertex.z / scalar);
    }
};

struct Color {
    float r, g, b, a;

    Color(float _r = 0.f, float _g = 0.f, float _b = 0.f, float _a = 0.f) : r(_r), g(_g), b(_b), a(_a) { }
};


struct Vertex {
    Vector3f position;
    Color color;

    Vertex(Vector3f pos = Vector3f(0.f, 0.f, 0.f), Color c = Color(1.f, 1.f, 1.f)) {
        position = pos;
        color = c;
    }
};

struct FaceIdx {
    std::vector<uint> indices;

    void operator<<(uint index) {
        indices.push_back(index);
    }
};

#endif // UTILS_H
