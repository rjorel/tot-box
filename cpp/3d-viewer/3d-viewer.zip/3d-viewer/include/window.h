#ifndef WINDOW_H
#define WINDOW_H

#include <QMainWindow>

#include "glwidget.h"
#include "model.h"
#include "action.h"


class Window : public QMainWindow {
    Q_OBJECT

public:
    Window(QWidget *parent = 0);
    ~Window();

public slots:
    void openFile();
    void changeTransparency(int value);
    void changeShadeRendering();
    void changeModeRendering();
    void changeBBoxDisplay(bool value);
    void execAction();

private:
    void initMenu();
    void initData();

    QString m_workingDir;                   // To remember last used folder.
    GLWidget *m_viewer;
    QSlider *m_transparencySlider;
    QActionGroup *m_shadeGroup;
    QAction *m_modeGroup[3];

    std::map<QString, Model *> m_models;    // Model collection.
    std::vector<Action *> m_actions;

    Mesh *m_mesh;
    MeshViewer *m_meshViewer;
};

#endif // WINDOW_H
