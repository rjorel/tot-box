#include "boundingbox.h"


BoundingBox::BoundingBox() : m_init(true) {

}

BoundingBox::BoundingBox(const Vector3f &vmin, const Vector3f &vmax)
    : m_min(vmin), m_max(vmax), m_init(false) {

}

const Vector3f BoundingBox::min() const {
    return m_min;
}

const Vector3f BoundingBox::max() const {
    return m_max;
}


void BoundingBox::reset() {
    m_min = Vector3f();
    m_max = Vector3f();
    m_init = true;
}

void BoundingBox::extend(const Vector3f &vertex) {
    if (m_init) {
        m_min = m_max = vertex;
        m_init = false;
        return;
    }

    if (vertex.x < m_min.x)  m_min.x = vertex.x;
    if (vertex.x > m_max.x)  m_max.x = vertex.x;

    if (vertex.y < m_min.y)  m_min.y = vertex.y;
    if (vertex.y > m_max.y)  m_max.y = vertex.y;

    if (vertex.z < m_min.z)  m_min.z = vertex.z;
    if (vertex.z > m_max.z)  m_max.z = vertex.z;
}

const Vector3f BoundingBox::sizes() const {
    return Vector3f(m_max.x - m_min.x,
                    m_max.y - m_min.y,
                    m_max.z - m_min.z);
}

const float BoundingBox::maxSize() const {
    const Vector3f v = sizes();
    return std::max(v.x, std::max(v.y, v.z));
}

const bool BoundingBox::contains(const Vector3f &vertex) const {
    return vertex.x >= m_min.x && vertex.x <= m_max.x
            && vertex.y >= m_min.y && vertex.y <= m_max.y
            && vertex.z >= m_min.z && vertex.z <= m_max.z;
}
