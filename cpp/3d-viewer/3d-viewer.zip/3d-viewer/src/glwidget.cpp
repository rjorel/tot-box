#include <iostream>
#include <sstream>

#include "glwidget.h"


GLWidget::GLWidget(QWidget *parent) : QGLWidget(QGLFormat(), parent), m_meshViewer(0),
    m_alpha(25), m_beta(-25), m_distance(100.f) {

    setFocusPolicy(Qt::StrongFocus);
}


// Default size;
QSize GLWidget::sizeHint() const {
    return QSize(640, 480);
}


// Setters.
void GLWidget::setMeshViewer(MeshViewer *mesh) {
    m_meshViewer = mesh;
}

void GLWidget::setDistance(float distance) {
    m_distance = distance;
}


// OpenGL handling.
void GLWidget::initializeGL() {
    QMatrix4x4 persp;
    persp.setToIdentity();
    persp.perspective(60.0, (GLfloat) width() / (GLfloat) height(), .1f, 10000.f);

    glEnable(GL_DEPTH_TEST);

    // Initialize main light for shade models.
    // Inspired by http://info.ee.surrey.ac.uk/Teaching/Courses/eem.cgi/lectures_pdf/opengl4.pdf [25/01/2017].
    glEnable(GL_LIGHT0);
    GLfloat pos[] = {1.0, 5.0, 7.0, 1.0};
    GLfloat diffuse[] = {1.0, 1.0, 1.0, 1.0};
    GLfloat ambient[] = {1.0, 1.0, 1.0, 1.0};
    GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
    glLightfv(GL_LIGHT0, GL_POSITION, pos);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);

    // Transparency activation.
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    qglClearColor(QColor(Qt::black));

    // Render settings.
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMultMatrixd(persp.constData());
    glViewport(0, 0, width(), height());

    glMatrixMode(GL_MODELVIEW);
}

void GLWidget::resizeGL(int width, int height) {
    QMatrix4x4 persp;
    persp.setToIdentity();
    persp.perspective(60.0, (GLfloat) width / (GLfloat) height, .1f, 10000.f);

    height = qMax(1, height);           // Avoid possible bugs.

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMultMatrixd(persp.constData());
    glViewport(0, 0, width, height);

    glMatrixMode(GL_MODELVIEW);
}

void GLWidget::paintGL() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // Matrix computation for navigation in scene.
    QMatrix4x4 camTrans;
    camTrans.rotate(m_alpha, 0, 1, 0);
    camTrans.rotate(m_beta, 1, 0, 0);

    QMatrix4x4 vMatrix;
    QVector3D camPos = camTrans * QVector3D(0, 0, m_distance),
            camUpDir = camTrans * QVector3D(0, 1, 0);
    vMatrix.lookAt(camPos, m_center, camUpDir);

    glTranslatef(0, 0, -m_distance);
    glMultMatrixd(vMatrix.constData());

    // Maybe user didn't have set mesh viewer.
    if (m_meshViewer)
        m_meshViewer->display();
}


// User input handling.
void GLWidget::mousePressEvent(QMouseEvent *event) {
    m_lastMousePosition = event->pos();
    event->accept();
}

void GLWidget::mouseMoveEvent(QMouseEvent *event) {
    int deltaX = event->x() - m_lastMousePosition.x(),
            deltaY = event->y() - m_lastMousePosition.y();

    if (event->buttons() && Qt::LeftButton) {
        m_alpha -= deltaX;
        m_beta -= deltaY;

        while (m_alpha < 0)       m_alpha += 360;
        while (m_alpha >= 360)    m_alpha -= 360;
        if (m_beta < -90)         m_beta = -90;
        if (m_beta > 90)          m_beta = 90;

        updateGL();
    }

    m_lastMousePosition = event->pos();
    event->accept();
}

void GLWidget::wheelEvent(QWheelEvent *event) {
    int delta  = event->delta();

    if (event->orientation() == Qt::Vertical) {
        if (delta < 0)      m_distance *= 1.1f;
        else if (delta > 0) m_distance *= 1 / 1.1f;

        updateGL();
    }

    event->accept();
}
