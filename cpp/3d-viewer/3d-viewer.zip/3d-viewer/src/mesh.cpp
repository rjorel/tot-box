#include "mesh.h"
#include "octree.h"


Mesh::Mesh() {
    m_transformation.setToIdentity();
}


// Clean data.
void Mesh::reset() {
    m_vertices.clear();
    m_faces.clear();

    m_bbox.reset();
}

// Add data.
void Mesh::addVertex(const Vertex &vertex) {
    m_vertices.push_back(vertex);
    m_bbox.extend(vertex.position);
}

void Mesh::addFaceIndex(const FaceIdx &face) {
    m_faces.push_back(face);
}

// Move mesh.
void Mesh::translate(float dx, float dy, float dz) {
    m_transformation.setToIdentity();
    m_transformation.translate(dx, dy, dz);
}

void Mesh::translate(const Vector3f &vector) {
    m_transformation.setToIdentity();
    m_transformation.translate(vector.x, vector.y, vector.z);
}

void Mesh::center() {
    translate(-(m_bbox.min() + m_bbox.sizes() / 2));
}

// Getters.
const std::vector<Vertex>& Mesh::vertices() const {
    return m_vertices;
}

const Vertex& Mesh::vertex(uint index) const {
    return m_vertices[index];
}

const std::vector<FaceIdx>& Mesh::faces() const {
    return m_faces;
}

const QMatrix4x4& Mesh::transformation() const {
    return m_transformation;
}

const BoundingBox& Mesh::boundingBox() const {
    return m_bbox;
}
