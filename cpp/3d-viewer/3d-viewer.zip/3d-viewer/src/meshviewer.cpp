#include "meshviewer.h"


MeshViewer::MeshViewer() : m_mesh(0),
    m_displayModeMask(POLYGON), m_shadeMode(-1), m_displayBBox(false), m_transparency(1.f) {
}


void MeshViewer::setMesh(Mesh *mesh) {
    m_mesh = mesh;
    m_mesh->center();
}

void MeshViewer::setTransparency(float transparency) {
    m_transparency = transparency;
}

void MeshViewer::setShadeMode(GLenum mode) {
    m_shadeMode = mode;
}

void MeshViewer::setDisplayBBox(bool value) {
    m_displayBBox = value;
}

void MeshViewer::addDisplayMode(uint mode) {
    m_displayModeMask |= mode;
}

void MeshViewer::delDisplayMode(uint mode) {
    m_displayModeMask &= ~mode;
}


void MeshViewer::display() {
    if (!m_mesh) return;

    glDisable(GL_LIGHTING);
    glMultMatrixd(m_mesh->transformation().constData());

    // Point drawing.
    if ((m_displayModeMask & MeshViewer::POINTS) == MeshViewer::POINTS) {
        glPointSize(2.f);
        glColor3f(1.f, 0.f, 0.f);

        glBegin(GL_POINTS);
        for (const Vertex &v: m_mesh->vertices())
            glVertex3f(v.position.x, v.position.y, v.position.z);

        glEnd();
    }

    // Line drawing.
    if ((m_displayModeMask & MeshViewer::LINES) == MeshViewer::LINES) {
        glColor3f(0.f, 0.f, 1.f);

        for (const FaceIdx &face: m_mesh->faces()) {
            glBegin(GL_LINE_LOOP); {
                for (const uint index: face.indices) {
                    const Vertex &vertex = m_mesh->vertex(index);
                    glVertex3f(vertex.position.x, vertex.position.y, vertex.position.z);
                }
            }
            glEnd();
        }
    }

    // Bounding box drawing.
    if (m_displayBBox) {
        const BoundingBox bbox = m_mesh->boundingBox();
        const Vector3f vmin = bbox.min();
        const Vector3f vmax = bbox.max();

        glColor3f(0.f, 1.f, 0.f);
        glBegin(GL_LINES); {
            glVertex3f(vmin.x, vmin.y, vmin.z); glVertex3f(vmax.x, vmin.y, vmin.z);
            glVertex3f(vmin.x, vmin.y, vmin.z); glVertex3f(vmin.x, vmax.y, vmin.z);
            glVertex3f(vmin.x, vmin.y, vmin.z); glVertex3f(vmin.x, vmin.y, vmax.z);

            glVertex3f(vmax.x, vmax.y, vmax.z); glVertex3f(vmin.x, vmax.y, vmax.z);
            glVertex3f(vmax.x, vmax.y, vmax.z); glVertex3f(vmax.x, vmin.y, vmax.z);
            glVertex3f(vmax.x, vmax.y, vmax.z); glVertex3f(vmax.x, vmax.y, vmin.z);

            glVertex3f(vmax.x, vmin.y, vmin.z); glVertex3f(vmax.x, vmax.y, vmin.z);
            glVertex3f(vmax.x, vmin.y, vmin.z); glVertex3f(vmax.x, vmin.y, vmax.z);

            glVertex3f(vmin.x, vmax.y, vmin.z); glVertex3f(vmax.x, vmax.y, vmin.z);
            glVertex3f(vmin.x, vmax.y, vmin.z); glVertex3f(vmin.x, vmax.y, vmax.z);

            glVertex3f(vmin.x, vmin.y, vmax.z); glVertex3f(vmax.x, vmin.y, vmax.z);
            glVertex3f(vmin.x, vmin.y, vmax.z); glVertex3f(vmin.x, vmax.y, vmax.z);
        }
        glEnd();
    }

    if (m_shadeMode != -1)
        glEnable(GL_LIGHTING);
    glShadeModel(m_shadeMode);

    // Polygon drawing.
    if ((m_displayModeMask & MeshViewer::POLYGON) == MeshViewer::POLYGON) {
        for (const FaceIdx &face: m_mesh->faces()) {
            glBegin(GL_POLYGON); {
                for (const uint index: face.indices) {
                    const Vertex &vertex = m_mesh->vertex(index);

                    glColor4f(vertex.color.r, vertex.color.g, vertex.color.b, m_transparency);
                    glVertex3f(vertex.position.x, vertex.position.y, vertex.position.z);
                }
            }
            glEnd();
        }
    }
}
