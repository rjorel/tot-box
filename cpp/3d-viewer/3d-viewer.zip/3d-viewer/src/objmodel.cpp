#include <iostream>
#include <fstream>

#include "objmodel.h"


OBJModel::OBJModel() {

}


int OBJModel::readFromFile(const std::string &filename) {
    std::ifstream file(filename.c_str());
    std::string c;

    if (!file) {
        std::cerr << filename << ": no such file or directory" << std::endl;
        return -1;
    }

    m_vertices.clear();
    m_faces.clear();

    char buf[1024];
    char *lastLocale = std::setlocale(LC_NUMERIC, "C");     // Because some locales use ',' as decimal separator... and OBJ files use '.'
                                                            // in every case.
    while (file.getline(buf, 1024)) {
        std::vector<std::string> fields = split(buf, " ");
        uint fieldSize = fields.size();

        if (fieldSize == 0) continue;       // Not interesting data.

        if (fields[0] == "v") {
            if (fieldSize < 4) continue;    // Not well formatted vertex.
            m_vertices.push_back(Vertex(Vector3f(std::stof(fields[1]), std::stof(fields[2]), std::stof(fields[3]))));
        }
        else if (fields[0] == "f") {
            if (fieldSize < 4) continue;    // A face has a least 3 indices.

            FaceIdx face;
            for (uint i = 1 ; i < fieldSize ; i++)
                face << std::stoi(fields[i].substr(0, fields[i].find('/'))) - 1;

             m_faces.push_back(face);
        }
    }

    std::setlocale(LC_NUMERIC, lastLocale);                 // Restore previous locale.
    return 0;
}

Mesh* OBJModel::getMesh() const {   // Because OBJ files store data as it's displayed in OpenGL, mesh building is really simple.
    Mesh *mesh = new Mesh;

    for (const Vertex &v: m_vertices)   mesh->addVertex(v);
    for (const FaceIdx &f: m_faces)     mesh->addFaceIndex(f);

    return mesh;
}


// Split a string (char sequence) according a delimiter.
std::vector<std::string> OBJModel::split(char *buf, const char *delim) {
    std::vector<std::string> items;
    char *token = strtok(buf, delim);

    while (token != 0) {
        items.push_back(token);
        token = strtok(NULL, delim);
    }

    return items;
}
