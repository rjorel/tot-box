#include <cstring>
#include "octree.h"


Octree::Octree(std::vector<Vertex> vertices) : m_vertices(vertices) {

}

std::vector<Vertex> Octree::getVertices() {
    if (m_nodes.size() == 0)    // Octree is built if there is no node.
        build();

    std::vector<Vertex> vertices;
    for (const Node &node: m_nodes)
        if (node.isLeaf)
            vertices.push_back(node.meanVertex);

    return vertices;
}


/**
 * This method optimizes vertex checks by sorting them in an array.
 * Each sub-bounding boxes considerate vertices between certain indices in this array.
 * Thanks to this approach, every vertex check is useful.
 */
void Octree::build() {
    BoundingBox bbox;

    // Use an index array referring vertices. Avoid vertex displacements.
    m_vertexIndices = new uint[m_vertices.size()];

    for (uint i = 0 ; i < m_vertices.size() ; i++) {
        bbox.extend(m_vertices[i].position);        // Original bounding box building.
        m_vertexIndices[i] = i;                     // At start, every index are placed like in the vertex array.
    }

    m_nodes.resize(1);
    buildNode(0, bbox, 0, m_vertices.size());
    delete [] m_vertexIndices;
}

void Octree::buildNode(uint nodeId, BoundingBox bbox, uint start, uint end) {
    Node &node = m_nodes[nodeId];

    // If the number of vertex contained in the node has reached the max number, the node is a leaf
    // and we can stop recursion.
    if (end - start <= Octree::NumMaxVertices) {
        Vector3f sum;
        for (uint i = start ; i < end ; i++)                    // Compute mean vertex.
            sum += m_vertices[m_vertexIndices[i]].position;

        node.meanVertex = Vertex(sum / (end - start));
        node.isLeaf = true;                                     // Mark node as leaf.
        return;
    }

    const Vector3f vmin = bbox.min(), bboxSizes = bbox.sizes();
    const Vector3f halfSize = bboxSizes / 2;
    Vector3f sum;

    uint boxes[9] = { 0 };
    uint iboxes[9];
    uint tmpIndices[end - start];

    // Get number of vertices by sub-bounding boxes.
    // First index remain zero because it will point the first index of vertex array.
    for (uint i = start ; i < end ; i++) {
        const Vector3f v = m_vertices[m_vertexIndices[i]].position;
        uint index = computeIndex(v, bbox);

        boxes[index + 1]++;
        sum += v;
    }

    // It's a interior node, but we need mean vertex too.
    node.meanVertex = Vertex(sum / (end - start));
    node.isLeaf = false;

    // Prefix sum, to know where vertex indices will be displaced, according sub-bounding box belonging.
    for (uint i = 1 ; i < 8 ; i++)
        boxes[i + 1] += boxes[i];

    // iboxes array is used to remember next positions which vertex indices will be placed.
    // We need this second array because the values of the first one are reused after.
    memcpy(iboxes, boxes, 9 * sizeof(uint));

    // Move vertex indices to good positions in the index array.
    for (uint i = start ; i < end ; i++) {
        uint index = computeIndex(m_vertices[m_vertexIndices[i]].position, bbox);

        // Get index to place current vertex index, and point the position for next vertex index to place
        // in the same sub-bounding box.
        uint offset = iboxes[index]++;

        tmpIndices[offset] = m_vertexIndices[i];
    }

    // Copy to original array. Pay attention to place sorted vertex indices to the good place (between start and end).
    memcpy(m_vertexIndices + start, tmpIndices, (end - start) * sizeof(uint));

    // Loop over all sub-bouding boxes.
    for (uint  i = 0 ; i < 8 ; i++) {
        if (boxes[i + 1] - boxes[i] <= 0)               // Don't build boxes with 0 vertex.
            continue;

        uint x = i % 2, y = (i % 4) / 2, z = i / 4;     // To avoid 3 nested loops.
        uint childId = m_nodes.size();

        // Compute child bounding box according (x, y, z).
        Vector3f childVmin = vmin + Vector3f(halfSize.x * x, halfSize.y * y, halfSize.z * z);
        BoundingBox cbbox(childVmin, childVmin + halfSize);

        m_nodes.resize(m_nodes.size() + 1);
        node.children[i] = childId;

        // Recursive call, with index interval.
        buildNode(childId, cbbox, start + boxes[i], start + boxes[i + 1]);
    }
}

uint Octree::computeIndex(const Vector3f &vec, const BoundingBox &bbox) const {
    const Vector3f vmin = bbox.min(), bboxSizes = bbox.sizes();
    const Vector3f pos = vec - vmin;

    return  (int) round(pos.x / bboxSizes.x)
            + 2 * ((int) round(pos.y / bboxSizes.y))
            + 4 * ((int) round(pos.z / bboxSizes.z));
}


/**
 * Not optimized version of decimation.
 * This version loop over all vertices for each sub-bounding boxes of considerated bounding box.
 */
void Octree::basicBuild() {
    BoundingBox bbox;
    Vector3f sum;

    for (const Vertex &v: m_vertices) {
        bbox.extend(v.position);
        sum += v.position;
    }

    m_nodes.resize(1);
    buildNode(0, bbox, sum / m_vertices.size(), m_vertices.size());
}

void Octree::buildNode(uint nodeId, BoundingBox bbox, Vector3f mean, uint numVertex) {
    Node &node = m_nodes[nodeId];
    Vector3f halfSize = bbox.sizes() / 2;

    node.meanVertex = Vertex(mean);
    node.isLeaf = false;

    // If the number of vertex contained in the node has reached the max number, the node is a leaf
    // and we can stop recursion.
    if (numVertex <= Octree::NumMaxVertices) {
        node.isLeaf = true;
        return;
    }

    // Loop over the 8 sub-bounding boxes.
    for (uint i = 0 ; i < 8 ; i++) {
        uint x = i % 2, y = (i % 4) / 2, z = i / 4;     // To avoid 3 nested loops.

        Vector3f vmin = bbox.min() + Vector3f(halfSize.x * x, halfSize.y * y, halfSize.z * z);
        BoundingBox cbbox(vmin, vmin + halfSize);

        // Search for vertices in bounding box. Vertex sum is done at the same time.
        Vector3f sum;
        int num = 0;
        bool contains = false;

        // Oops... really ugly ! Poor little computer...
        for (const Vertex &v: m_vertices)
            if (cbbox.contains(v.position)) {
                contains = true;
                sum += v.position;
                num++;
            }

        if (contains) {
            uint childId = m_nodes.size();
            m_nodes.resize(m_nodes.size() + 1);

            node.children[i] = childId;
            buildNode(childId, cbbox, sum / num, num);
        }
        else
            node.children[i] = -1;
    }
}
