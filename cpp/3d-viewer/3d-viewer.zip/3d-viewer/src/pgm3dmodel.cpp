#include <iostream>
#include <fstream>

#include "pgm3dmodel.h"
#include "utils.h"


PGM3DModel::PGM3DModel() : m_width(0), m_height(0), m_depth(0), m_graymax(0), m_data(0) {

}

PGM3DModel::~PGM3DModel() {
    delete m_data;
}


int PGM3DModel::readFromFile(const std::string &filename) {     // PGM3D files store gray values. Each position represents a voxel.
    std::ifstream file(filename.c_str());
    std::string format;

    if (!file) {
        std::cerr << filename << ": no such file or directory" << std::endl;
        return -1;
    }

    file >> format;
    if (format != "PGM3D") {
        std::cerr << filename << " is not tagged as PGM3D file" << std::endl;
        return -1;
    }

    file >> m_width >> m_height >> m_depth >> m_graymax;
    delete m_data;
    m_data = new uint[m_width * m_height * m_depth];

    // Gray value reading.
    for (uint i = 0 ; i < m_width * m_height * m_depth && file >> m_data[i]; i++)
        ;

    return 0;
}

Mesh* PGM3DModel::getMesh() const {
    Mesh *mesh = new Mesh;

    //     E-----F
    //    /|    /|       y
    //   A-----B |       |
    //   | G --|-H        --- x
    //   |/    |/       /
    //   C-----D       z

    // For each voxel, a cube is built.
    for (uint offset = 0, vertexOffset = 0 ; offset < m_width * m_height * m_depth ; offset++) {
        if (is_black(m_data[offset])) continue;                             // Black voxels are skipped.

        uint x = offset % m_width,                                          // (x, y, z) is voxel center.
                y = (offset % (m_width * m_height)) / m_width,
                z = offset / (m_width * m_height);

        // More expressive variables.
        const bool left = (x == 0), right = (x == m_width - 1),
                bottom = (y == 0), top = (y == m_height - 1),
                back = (z == 0), front = (z == m_depth - 1);

        Vector3f current(x, y, z);

        /* Some check for face addition
         * ----------------------------
         * For left face, just check if the voxel is on the left or if the voxel on the left is black.
         *
         * For right face, we check if the voxel on the right has the same gray level (black voxels are inspected).
         *
         * The same idea is repeated for bottom, top, front and back faces. We needed to check for black voxels on
         * left, bottom and back because these one are skipped and faces between two voxels side by side with different
         * gray levels are built once.
         *
         * Given the arbitrary construction (these latter faces are built when we check for right, top and front faces),
         * an additional verification is needed for the other faces.
         */

        if (left || is_black(m_data[offset - 1])) {
            float value = (m_data[offset] / 2.f) / m_graymax;
            addFace(mesh, vertexOffset, current, Color(value, value, value), 0, 2, 6, 4);   // ACGE
        }

        if (right || m_data[offset] != m_data[offset + 1]) {
            float value = ((m_data[offset] + m_data[offset + 1]) / 2.f) / m_graymax;
            addFace(mesh, vertexOffset, current, Color(value, value, value), 1, 3, 7, 5);   // BDHF
        }

        if (bottom || is_black(m_data[offset - m_width])) {
            float value = (m_data[offset] / 2.f) / m_graymax;
            addFace(mesh, vertexOffset, current, Color(value, value, value), 2, 6, 7, 3);   // CGHD
        }

        if (top || m_data[offset] != m_data[offset + m_width]) {
            float value = ((m_data[offset] + m_data[offset + m_width]) / 2.f) / m_graymax;
            addFace(mesh, vertexOffset, current, Color(value, value, value), 0, 4, 5, 1);   // AEFB
        }

        if (back || is_black(m_data[offset - m_width * m_height])) {
            float value = (m_data[offset] / 2.f) / m_graymax;
            addFace(mesh, vertexOffset, current, Color(value, value, value), 4, 6, 7, 5);   // EGHF

        }

        if (front || m_data[offset] != m_data[offset + m_width * m_height]) {
            float value = ((m_data[offset] + m_data[offset + m_width * m_height]) / 2.f) / m_graymax;
            addFace(mesh, vertexOffset, current, Color(value, value, value), 0, 2, 3, 1);   // ACDB
        }
    }

    return mesh;
}


// Convenient function to avoid code repetition.
void PGM3DModel::addFace(Mesh *mesh, uint &offset, const Vector3f &current, const Color &color,
                         uint i1, uint i2, uint i3, uint i4) const {

    mesh->addVertex(Vertex(current + m_vertices[i1], color));
    mesh->addVertex(Vertex(current + m_vertices[i2], color));
    mesh->addVertex(Vertex(current + m_vertices[i3], color));
    mesh->addVertex(Vertex(current + m_vertices[i4], color));

    FaceIdx face;
    face << offset + 0;
    face << offset + 1;
    face << offset + 2;
    face << offset + 3;

    mesh->addFaceIndex(face);
    offset += 4;
}
