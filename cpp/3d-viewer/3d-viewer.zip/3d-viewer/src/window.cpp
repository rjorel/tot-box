#include <QVBoxLayout>
#include <QMenuBar>
#include <QAction>
#include <QFileDialog>
#include <QtOpenGL>
#include <iostream>

#include "window.h"
#include "pgm3dmodel.h"
#include "objmodel.h"
#include "decimateaction.h"
#include "holefillingaction.h"


Window::Window(QWidget *parent) : QMainWindow(parent), m_workingDir("."), m_mesh(0) { //m_model(0) {
    QWidget *centralWidget = new QWidget;                   // UI initialization (no need of *.ui file).
    QVBoxLayout *mainLayout = new QVBoxLayout;

    m_viewer = new GLWidget;
    m_meshViewer = new MeshViewer;

    m_viewer->setMeshViewer(m_meshViewer);

    m_transparencySlider = new QSlider(Qt::Horizontal);
    m_transparencySlider->setMinimum(0);
    m_transparencySlider->setMaximum(255);

    mainLayout->addWidget(m_viewer);
    mainLayout->addWidget(m_transparencySlider);
    centralWidget->setLayout(mainLayout);

    setCentralWidget(centralWidget);
    setWindowTitle("Viewer");

    initData();
    initMenu();

    QObject::connect(m_transparencySlider, SIGNAL(valueChanged(int)), this, SLOT(changeTransparency(int)));
}

Window::~Window() {
    // delete m_model;
    delete m_mesh;
    delete m_meshViewer;

    // Collection release.
    for (std::map<QString, Model *>::iterator it = m_models.begin() ; it != m_models.end() ; ++it)
        delete (*it).second;

    for (Action *action: m_actions)
        delete action;
}


void Window::initData() {
    // Model collection filling.
    m_models["pgm3d"] = new PGM3DModel;
    m_models["obj"] = new OBJModel;

     // Action collection.
    m_actions.push_back(new DecimateAction);
    m_actions.push_back(new HoleFillingAction);
}

void Window::initMenu() {
    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));
    QMenu *renderMenu = menuBar()->addMenu(tr("&Render"));
    QMenu *actionMenu = menuBar()->addMenu(tr("&Action"));

    QAction *openFile = new QAction(tr("&Open file"), this);
    QAction *quit = new QAction(tr("&Quit"), this);

    openFile->setShortcut(QKeySequence::Open);          // Shortcuts are really appreciable in a software.
    quit->setShortcut(QKeySequence::Quit);
    fileMenu->addAction(openFile);
    fileMenu->addAction(quit);

    // Shading.
    QString shaderNames[3] { "Basic", "Flat", "Smooth" };
    int shadeValues[3] { -1, GL_FLAT, GL_SMOOTH };
    m_shadeGroup = new QActionGroup(this);
    for (uint i = 0 ; i < 3 ; i++) {
        QAction *action = new QAction(shaderNames[i], this);

        action->setCheckable(true);
        action->setData(QVariant(shadeValues[i]));
        renderMenu->addAction(action);

        action->setActionGroup(m_shadeGroup);
        QObject::connect(action, SIGNAL(triggered()), this, SLOT(changeShadeRendering()));
    }

    renderMenu->addSeparator();

    // Modes.
    QString modeNames[3] { "Points", "Lines", "Faces" };
    uint modeValues[3] { MeshViewer::POINTS, MeshViewer::LINES, MeshViewer::POLYGON };
    for (uint i = 0 ; i < 3 ; i++) {
        QAction *action = new QAction(modeNames[i], this);

        action->setCheckable(true);
        action->setData(QVariant(modeValues[i]));
        renderMenu->addAction(action);

        m_modeGroup[i] = action;
        QObject::connect(action, SIGNAL(triggered()), this, SLOT(changeModeRendering()));
    }

    // BBox display.
    renderMenu->addSeparator();
    QAction *action = new QAction("Bounding box", this);
    action->setCheckable(true);
    renderMenu->addAction(action);
    QObject::connect(action, SIGNAL(triggered(bool)), this, SLOT(changeBBoxDisplay(bool)));

    m_shadeGroup->actions().at(0)->setChecked(true);
    m_modeGroup[2]->setChecked(true);

    // Actions.
    QString actionNames[2] { "Decimate", "Hole filling" };
    for (uint i = 0 ; i < m_actions.size() ; i++) {
        QAction *action = new QAction(actionNames[i], this);

        action->setData(QVariant(i));
        actionMenu->addAction(action);
        QObject::connect(action, SIGNAL(triggered()), this, SLOT(execAction()));
    }

    QObject::connect(openFile, SIGNAL(triggered()), this, SLOT(openFile()));
    QObject::connect(quit, SIGNAL(triggered()), qApp, SLOT(quit()));
}


void Window::openFile() {
    QString filename = QFileDialog::getOpenFileName(this, tr("Open file"), m_workingDir,
                                                    tr("PGM3D & OBJ files (*.pgm3d *.obj)"));
    if (filename == "") return;

    QFileInfo fileInfo(filename);
    QString ext = fileInfo.completeSuffix();
    m_workingDir = fileInfo.absoluteDir().absolutePath();           // Remember directory.
    Model *model;

    if (m_models.find(ext.toLower()) == m_models.end()) {           // Check if extension is registered in model collection.
        QMessageBox::critical(this, "Wrong file", "This type of file is not supported" );
        return;
    }
    else {
        model = m_models[ext.toLower()];                            // And use the corresponding model if that is the case.
    }

    if (model->readFromFile(filename.toStdString()) == -1) {
        QMessageBox::critical(this, "Read error", "An error occured while reading file");
        return;
    }

    Mesh *lastMesh = m_mesh;                                        // Save pointer to current mesh, to avoid bugs with mesh viewer.
    m_meshViewer->setMesh(m_mesh = model->getMesh());
    m_viewer->setDistance(m_mesh->boundingBox().maxSize() * 1.5);   // Place the view according mesh size. That works for some cases.
    m_transparencySlider->setValue(120);

    delete lastMesh;                                                // Now, every is well set, we can safely release last mesh.
}

void Window::changeTransparency(int value) {
    m_meshViewer->setTransparency((uchar) value / 255.f);
    m_viewer->update();
}

void Window::changeShadeRendering() {
    QAction *action = m_shadeGroup->checkedAction();

    m_meshViewer->setShadeMode(action->data().toInt());
    m_viewer->update();
}

void Window::changeModeRendering() {
    const QAction *action = static_cast<QAction *>(QObject::sender());
    if (action->isChecked())
        m_meshViewer->addDisplayMode(action->data().toInt());

    else
        m_meshViewer->delDisplayMode(action->data().toInt());

    m_viewer->update();
}

void Window::changeBBoxDisplay(bool value) {
    m_meshViewer->setDisplayBBox(value);
    m_viewer->update();
}

void Window::execAction() {
    if (!m_mesh) {
        QMessageBox::critical(this, "Error", "No mesh to process");
        return;
    }

    const QAction *action = static_cast<QAction *>(QObject::sender());
    Action *act = m_actions[action->data().toInt()];
    act->setMesh(m_mesh);
    act->exec();
}
