#include "compensators.h"


cv::Mat FullSearchBlockMatchingCompensator::getMotionVectors(const cv::Mat &prev, const cv::Mat &curr) {
    int rows = curr.rows / blockSize;
    int cols = curr.cols / blockSize;
    int halfWindowSize = windowSize / 2;

    cv::Size block(blockSize, blockSize);
    cv::Mat motionVectors(rows, cols, CV_32SC2);

    for (int blowRow = 0; blowRow < rows; blowRow++) {
        for (int blockCol = 0; blockCol < cols; blockCol++) {
            int currentRow = blowRow * blockSize,
                currentCol = blockCol * blockSize;

            cv::Point2i currentPoint(
                blockCol * blockSize, blowRow * blockSize
            );

            // Compute boundaries to avoid illegal accesses in matrices.
            int dxInf = std::max(-halfWindowSize, -currentCol);
            int dxSup = std::min(halfWindowSize, curr.cols - currentCol - blockSize - 1);

            int dyInf = std::max(-halfWindowSize, -currentRow);
            int dySup = std::min(halfWindowSize, curr.rows - currentRow - blockSize - 1);

            cv::Vec2i bestVector(-halfWindowSize, -halfWindowSize);

            double minError = std::numeric_limits<double>::max();

            // Loop over all vectors to find the one that minimizes the MSE.
            for (int dx = dxInf; dx <= dxSup; dx++) {
                for (int dy = dyInf; dy <= dySup; dy++) {
                    cv::Vec2i vector(dx, dy);

                    cv::Mat roiCurr = curr(cv::Rect(currentPoint, block));
                    cv::Mat roiPrev = prev(cv::Rect(currentPoint + cv::Point2i(vector), block));

                    double error = getMeanSquareError(roiCurr, roiPrev);

                    if (error < minError) {
                        bestVector = vector;
                        minError = error;
                    }
                }
            }

            motionVectors.at<cv::Vec2i>(blowRow, blockCol) = bestVector;
        }
    }

    return motionVectors;
}

cv::Mat FullSearchBlockMatchingCompensator::compensateFrame(const cv::Mat &prev, const cv::Mat &vectors) {
    cv::Size block(blockSize, blockSize);
    cv::Mat compensated(prev.rows, prev.cols, prev.type());

    for (int row = 0; row < vectors.rows; row++) {
        const auto *ptr = vectors.ptr<cv::Vec2i>(row);

        for (int col = 0; col < vectors.cols; col++) {
            cv::Point2i point(col * blockSize, row * blockSize);
            cv::Vec2i vector = ptr[col];

            cv::Mat src = prev(cv::Rect(point + cv::Point2i(vector), block));
            cv::Mat dst = compensated(cv::Rect(point, block));

            src.copyTo(dst);
        }
    }

    return compensated;
}

cv::Mat FarnebackCompensator::getMotionVectors(const cv::Mat &prev, const cv::Mat &curr) {
    cv::Mat vectors(prev.rows, prev.cols, CV_32FC2);

    cv::calcOpticalFlowFarneback(
        curr, prev, vectors,
        pyrScale, levels, winSize, numIterations, polyN, polySigma, flags
    );

    return vectors;
}

cv::Mat FarnebackCompensator::compensateFrame(const cv::Mat &prev, const cv::Mat &vectors) {
    cv::Mat compensated;
    cv::Mat map(vectors.rows, vectors.cols, vectors.type());

    for (int row = 0; row < vectors.rows; row++) {
        const auto *ptr = vectors.ptr<cv::Vec2f>(row);

        for (int col = 0; col < vectors.cols; col++) {
            cv::Vec2f vector = ptr[col];

            map.at<cv::Vec2f>(row, col) = cv::Vec2f(col, row) + vector;
        }
    }

    cv::remap(prev, compensated, map, cv::Mat(), cv::INTER_LINEAR);

    return compensated;
}
