#ifndef __COMPENSATORS_H_
#define __COMPENSATORS_H_

#include <opencv2/core/mat.hpp>
#include "utils.h"


class Compensator {
public:
    cv::Mat compensate(const cv::Mat &prev, const cv::Mat &curr) {
        assertCompatibleMats(prev, curr, CV_8UC1);

        cv::Mat vectors = getMotionVectors(prev, curr);

        return compensateFrame(prev, vectors);
    }

private:
    virtual cv::Mat getMotionVectors(const cv::Mat &prev, const cv::Mat &curr) = 0;
    virtual cv::Mat compensateFrame(const cv::Mat &prev, const cv::Mat &vectors) = 0;
};

class FullSearchBlockMatchingCompensator : public Compensator {
public:
    explicit FullSearchBlockMatchingCompensator(
        int blockSize = 8,
        int windowSize = 32
    ) : blockSize(blockSize), windowSize(windowSize) {
        //
    }

private:
    cv::Mat getMotionVectors(const cv::Mat &prev, const cv::Mat &curr) override;
    cv::Mat compensateFrame(const cv::Mat &prev, const cv::Mat &vectors) override;

    int blockSize;
    int windowSize;
};

class FarnebackCompensator : public Compensator {
public:
    explicit FarnebackCompensator(
        double pyrScale = 0.5,
        int levels = 3,
        int winSize = 12,
        int numIterations = 20,
        int polyN = 5,
        double polySigma = 1.1,
        int flags = 0
    ) : pyrScale(pyrScale), levels(levels), winSize(winSize), numIterations(numIterations),
        polyN(polyN), polySigma(polySigma), flags(flags) {
        //
    }

private:
    cv::Mat getMotionVectors(const cv::Mat &prev, const cv::Mat &curr) override;
    cv::Mat compensateFrame(const cv::Mat &prev, const cv::Mat &vectors) override;

    double pyrScale;
    int levels;
    int winSize;
    int numIterations;
    int polyN;
    double polySigma;
    int flags;
};


#endif
