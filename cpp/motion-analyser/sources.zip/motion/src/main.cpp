#include <iostream>
#include <getopt.h>
#include <fstream>
#include <queue>
#include <map>

#include <cv.hpp>

#include "compensators.h"


int main(int argc, char *argv[]) {
    int delta = 1;

    int c;
    while ((c = getopt(argc, argv, "d:")) != -1) {
        switch (c) {
            case 'd':
                delta = std::stoi(optarg);
                if (delta == 0) {
                    delta = 1;
                }
                break;

            default:
                break;
        }
    }

    if (optind >= argc) {
        std::cerr << "Usage: " << argv[0] << " [-d delta] video" << "\n";
        return EXIT_FAILURE;
    }

    cv::VideoCapture cap(argv[optind]);

    if (!cap.isOpened()) {
        std::cerr << argv[optind] << ": no such file or directory" << std::endl;
        return EXIT_FAILURE;
    }

    std::queue<cv::Mat> previousFrames;
    cv::Mat frame;
    int frameNumber = 0;

    FullSearchBlockMatchingCompensator fullSearch;
    FarnebackCompensator farneback;

    while (cap.read(frame) && cv::waitKey(30) > 0) {
        cv::Mat currentFrame = getYChannel(frame);

        if (previousFrames.size() >= delta) {
            cv::Mat previousFrame = previousFrames.front();
            previousFrames.pop();

            cv::Mat c1 = fullSearch.compensate(previousFrame, currentFrame);
            cv::Mat c2 = farneback.compensate(previousFrame, currentFrame);

            cv::Mat err0 = getErrorFrame(currentFrame, previousFrame);
            cv::Mat err1 = getErrorFrame(currentFrame, c1);
            cv::Mat err2 = getErrorFrame(currentFrame, c2);

            std::cout << frameNumber << " "
                      << getMeanSquareError(currentFrame, c1) << " "
                      << getMeanSquareError(currentFrame, c2) << " "
                      << getPeakSignalNoiseRatio(currentFrame, c1) << " "
                      << getPeakSignalNoiseRatio(currentFrame, c2) << " "
                      << getEntropy(err0) << " "
                      << getEntropy(err1) << " "
                      << getEntropy(err2) << std::endl;
#ifdef PREVIEW
            cv::imshow("Image", currentFrame);
            cv::imshow("Error", err0);
            cv::imshow("FSBM", err1);
            cv::imshow("Farneback", err2);
#endif
        }

        previousFrames.push(currentFrame);
        frameNumber++;
    }

    return EXIT_SUCCESS;
}
