#include <iostream>
#include <cassert>

#include "utils.h"


void assertCompatibleMats(const cv::Mat &mat1, const cv::Mat &mat2, int type) {
    assert(
        mat1.size() == mat2.size()
            && mat1.type() == mat2.type()
            && mat1.type() == type
    );
}

cv::Mat getYChannel(const cv::Mat &mat) {
    cv::Mat cvtFrame, channels[3];

    cv::cvtColor(mat, cvtFrame, CV_BGR2YCrCb);
    split(cvtFrame, channels);
    return channels[0];
}

double getMeanSquareError(const cv::Mat &mat1, const cv::Mat &mat2) {
    assertCompatibleMats(mat1, mat2, CV_8UC1);

    return cv::pow(cv::norm(mat1, mat2, cv::NORM_L2), 2.0) / (double) mat1.total();
}

double getPeakSignalNoiseRatio(const cv::Mat &mat1, const cv::Mat &mat2) {
    return 10 * log10((255 * 255) / getMeanSquareError(mat1, mat2));
}

double getEntropy(const cv::Mat &mat) {
    assert(mat.type() == CV_8UC1);

    const int size = 1 << (sizeof(uchar) * 8);
    int histogram[size] = { 0 };

    cv::MatConstIterator_<uchar> fit = mat.begin<uchar>(), fend = mat.end<uchar>();

    for (; fit != fend; ++fit) {
        histogram[*fit]++;
    }

    double norm = 1. / mat.total();
    double entropy = 0.0;

    for (int value: histogram) {
        if (value > 0) {
            double pi = value * norm;
            entropy -= pi * log2(pi);
        }
    }

    return entropy;
}

cv::Mat getErrorFrame(const cv::Mat &mat1, const cv::Mat &mat2) {
    assertCompatibleMats(mat1, mat2, CV_8UC1);

    return cv::min(255, cv::max(0, mat1 - mat2 + 128));
}