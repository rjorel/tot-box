#ifndef __UTILS_H_
#define __UTILS_H_

#include <cv.hpp>


void assertCompatibleMats(const cv::Mat &mat1, const cv::Mat &mat2, int type);

cv::Mat getYChannel(const cv::Mat &mat);

double getMeanSquareError(const cv::Mat &mat1, const cv::Mat &mat2);
double getPeakSignalNoiseRatio(const cv::Mat &mat1, const cv::Mat &mat2);
double getEntropy(const cv::Mat &mat);

cv::Mat getErrorFrame(const cv::Mat &mat1, const cv::Mat &mat2);

#endif
