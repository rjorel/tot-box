#include <iostream>
#include <cmath>

#include "utils.h"
#include "Processor.h"


enum MarkerIndex {
    TOP, BOTTOM, RIGHT
};

void Processor::process(cv::Mat &frame, cv::Mat &resultFrame) {
    computeContours(frame);
    computeMassCenters();

    searchCode();

    if (codeFound()) {
        computeMarkerPositions();
        computeOrientation();

        warpCode(frame, resultFrame);
    }
}

void Processor::computeContours(const cv::Mat &frame) {
    cv::cvtColor(frame, cannyFrame, CV_BGR2GRAY);
    cv::Canny(cannyFrame, cannyFrame, LOW_THRESHOLD, LOW_THRESHOLD * 2, KERNEL_SIZE);

    cv::findContours(cannyFrame, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE);
}

void Processor::computeMassCenters() {
    massCenters.resize(contours.size());

    for (uint i = 0; i < contours.size(); i++) {
        cv::Moments moment = cv::moments(contours[i], false);

        massCenters[i] = cv::Point2f(
            (float) (moment.m10 / moment.m00),
            (float) (moment.m01 / moment.m00)
        );
    }
}

void Processor::searchCode() {
    markerIndices.clear();

    // Check for enclosing contours.
    for (uint i = 0; i < contours.size(); i++) {
        int currentIndex = i;
        uint cpt = 0;

        do {
            if (hierarchy[currentIndex][CHILD_CONTOUR_INDEX] == -1) {
                break;
            }

            // Descending into the hierarchy.
            currentIndex = hierarchy[currentIndex][CHILD_CONTOUR_INDEX];
            cpt++;
        } while (true);

        // We assume that a hierarchy of NUM_NESTED_CONTOURS contours corresponds to a finder pattern.
        // It avoids computations on areas. This comes from the canny operation.
        if (cpt >= NUM_NESTED_CONTOURS) {
            markerIndices.push_back(i);
        }
    }
}

void Processor::computeMarkerPositions() {
    if (!codeFound()) {
        return;
    }

    // Compute distance between marker to determine the top marker.
    float dist01 = distance(massCenters[markerIndices[0]], massCenters[markerIndices[1]]),
        dist12 = distance(massCenters[markerIndices[1]], massCenters[markerIndices[2]]),
        dist20 = distance(massCenters[markerIndices[2]], massCenters[markerIndices[0]]);

    uint topIndex = 0;

    if (dist12 > dist01 && dist12 > dist20) {
        topIndex = 0;
    } else if (dist20 > dist01 && dist20 > dist12) {
        topIndex = 1;
    } else if (dist01 > dist12 && dist01 > dist20) {
        topIndex = 2;

        // For marker placement in index vector.
        // Reorientation needs a certain placement of the indices.
        std::swap(markerIndices[0], markerIndices[1]);
    }

    // Swap to have top marker at good position.
    std::swap(markerIndices[TOP], markerIndices[topIndex]);
}

void Processor::computeOrientation() {
    if (!codeFound()) {
        return;
    }

    cv::Point2f top = massCenters[markerIndices[TOP]],
        bottom = massCenters[markerIndices[BOTTOM]],    // At this point, we don't know if bottom and right marker
        right = massCenters[markerIndices[RIGHT]];      // are well placed.

    float slope = computeSlope(bottom, right);
    float dist = distancePointLine(top, bottom, right);        // This distance can be negative.

    // Swap top and bottom markers and take orientation.
    if (slope > 0 && dist > 0) {
        orientation = WEST;
    } else if (slope > 0 && dist < 0) {
        std::swap(markerIndices[BOTTOM], markerIndices[RIGHT]);
        orientation = EAST;
    } else if (slope < 0 && dist < 0) {
        orientation = NORTH;
    } else if (slope < 0 && dist > 0) {
        std::swap(markerIndices[BOTTOM], markerIndices[RIGHT]);
        orientation = SOUTH;
    }
}

void Processor::warpCode(cv::Mat &frame, cv::Mat &warpedFrame) {
    if (!codeFound()) {
        return;
    }

    // Contour approximation to find corners.
    approxContours.resize(markerIndices.size());

    for (uint i = 0; i < markerIndices.size(); i++) {
        cv::approxPolyDP(cv::Mat(contours[markerIndices[i]]), approxContours[i], 3, true);

        if (approxContours[i].size() != 4) {       // Ensure rectangle.
            return;
        }

        // Search relative positions of corners.
        const std::vector<cv::Point> currentContour = approxContours[i];

        // Comparing by coordinates addition gives top left and bottom right corners (min and max).
        auto topLeftBottomRightCorners = std::minmax_element(
            currentContour.begin(), currentContour.end(),
            [](const cv::Point2f &a, const cv::Point2f &b) {
                return a.y + a.x < b.y + b.x;
            }
        );

        // Comparing by coordinate subtraction gives top right and bottom left corners (min and max).
        auto topRightBottomLeftCorners = std::minmax_element(
            currentContour.begin(), currentContour.end(),
            [](const cv::Point2f &a, const cv::Point2f &b) {
                return a.y - a.x < b.y - b.x;
            }
        );

        approxContours[i][0] = *(topLeftBottomRightCorners.first);
        approxContours[i][2] = *(topLeftBottomRightCorners.second);
        approxContours[i][3] = *(topRightBottomLeftCorners.first);
        approxContours[i][1] = *(topRightBottomLeftCorners.second);
    }

    cv::Point2f topLeftCorner;
    cv::Point2f topRightCorners[2];
    cv::Point2f bottomLeftCorners[2];

    // According orientation, needed points are not at the same places.
    switch (orientation) {
        case NORTH:
            topLeftCorner = approxContours[TOP][0];

            topRightCorners[0] = approxContours[RIGHT][3];
            topRightCorners[1] = approxContours[RIGHT][2];

            bottomLeftCorners[0] = approxContours[BOTTOM][1];
            bottomLeftCorners[1] = approxContours[BOTTOM][2];
            break;

        case SOUTH:
            topLeftCorner = approxContours[TOP][2];
            topRightCorners[0] = approxContours[RIGHT][1];
            topRightCorners[1] = approxContours[RIGHT][0];

            bottomLeftCorners[0] = approxContours[BOTTOM][3];
            bottomLeftCorners[1] = approxContours[BOTTOM][0];
            break;

        case EAST:
            topLeftCorner = approxContours[TOP][3];
            topRightCorners[0] = approxContours[RIGHT][2];
            topRightCorners[1] = approxContours[RIGHT][1];

            bottomLeftCorners[0] = approxContours[BOTTOM][0];
            bottomLeftCorners[1] = approxContours[BOTTOM][1];
            break;

        case WEST:
            topLeftCorner = approxContours[TOP][1];
            topRightCorners[0] = approxContours[RIGHT][0];
            topRightCorners[1] = approxContours[RIGHT][3];

            bottomLeftCorners[0] = approxContours[BOTTOM][2];
            bottomLeftCorners[1] = approxContours[BOTTOM][3];
            break;
    }

    // And now, compute the last corner.
    cv::Point2f bottomRightCorner;

    bool intersectionExists = intersection(
        topRightCorners[0], topRightCorners[1],
        bottomLeftCorners[0], bottomLeftCorners[1],
        bottomRightCorner
    );

    if (!intersectionExists) {
        return;
    }

    // Prepare the inputs to warp the perspective.
    std::vector<cv::Point2f> src {
        topLeftCorner,
        topRightCorners[0],
        bottomRightCorner,
        bottomLeftCorners[0]
    };

    std::vector<cv::Point2f> dst {
        cv::Point2f(0, 0),
        cv::Point2f(warpedFrame.cols, 0),
        cv::Point2f(warpedFrame.cols, warpedFrame.rows),
        cv::Point2f(0, warpedFrame.rows)
    };

    // Let's go !
    cv::Mat warpMatrix = cv::getPerspectiveTransform(src, dst);
    cv::warpPerspective(
        frame, warpedFrame, warpMatrix, cv::Size(warpedFrame.cols, warpedFrame.rows)
    );

    copyMakeBorder(
        warpedFrame, warpedFrame, 10, 10, 10, 10, cv::BORDER_CONSTANT, cv::Scalar(255, 255, 255)
    );
}

bool Processor::codeFound() const {
    return markerIndices.size() >= 3;
}
