/**
 * Method highly inspired by http://dsynflo.blogspot.fr/2014/10/opencv-qr-code-detection-and-extraction.html [2017, February].
 * Code rewritten and understood most of time.
 *
 * The technique to find corners of QR Code is made by me, it's not the method proposed on the website
 * (and it's not the best part :D).
 */
#ifndef __PROCESSOR_H_
#define __PROCESSOR_H_

#include <cmath>
#include <vector>
#include <opencv2/imgproc.hpp>


class Processor {
public:
    void process(cv::Mat &frame, cv::Mat &resultFrame);
    bool codeFound() const;

private:
    void computeContours(const cv::Mat &frame);
    void computeMassCenters();

    void searchCode();
    void computeMarkerPositions();
    void computeOrientation();
    void warpCode(cv::Mat &frame, cv::Mat &warpedFrame);

    const uint KERNEL_SIZE = 3;             // For canny.
    const uint LOW_THRESHOLD = 100;

    const uint NUM_NESTED_CONTOURS = 5;     // For detection. Due to canny applying.
    const uint CHILD_CONTOUR_INDEX = 2;     // Just to clear OpenCV hierarchy indices.

    enum CodeOrientation {                  // For QR Code orientation.
        NORTH, SOUTH, EAST, WEST
    };

    // Transformed frame.
    cv::Mat cannyFrame;

    // Frame structure.
    std::vector<std::vector<cv::Point>> contours;
    std::vector<std::vector<cv::Point>> approxContours;   // Only used for markers and not all the contours.
    std::vector<cv::Vec4i> hierarchy;

    // Properties.
    std::vector<cv::Point2f> massCenters;     // Contours centers.
    std::vector<uint> markerIndices;          // Indices in contour vector.

    CodeOrientation orientation;
};

#endif
