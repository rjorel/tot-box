#ifndef __READER_H_
#define __READER_H_

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>

#include <zxing/MatSource.h>
#include <zxing/NotFoundException.h>
#include <zxing/common/GlobalHistogramBinarizer.h>
#include <zxing/qrcode/QRCodeReader.h>


class Reader {
public:
    bool read(const cv::Mat &frame) {
        cv::Mat thresh;

        cv::cvtColor(frame, thresh, CV_RGB2GRAY);
        cv::threshold(thresh, thresh, 127, 255, CV_THRESH_BINARY);

        // It seems that the objects are freed automatically, Valgrind doesn't notice memory leak
        // because of that.
        zxing::Ref<zxing::LuminanceSource> source = MatSource::create(thresh);
        zxing::Ref<zxing::Binarizer> binarizer(new zxing::GlobalHistogramBinarizer(source));
        zxing::Ref<zxing::BinaryBitmap> bitmap(new zxing::BinaryBitmap(binarizer));

        try {
            zxing::Ref<zxing::Result> result(
                reader.decode(bitmap, zxing::DecodeHints(zxing::DecodeHints::TRYHARDER_HINT))
            );

            text = result->getText()->getText();

            return true;
        }
        catch (zxing::NotFoundException &e) {
            //
        }
        catch (zxing::ReaderException &e) {
            //
        }

        return false;
    }

    const std::string getText() const {
        return text;
    }

private:
    zxing::qrcode::QRCodeReader reader;
    std::string text;
};

#endif // __READER_H_
