#include <iostream>
#include <vector>
#include <opencv2/highgui.hpp>

#include "Processor.h"
#include "Reader.hpp"


int main() {
    cv::VideoCapture video(0);
    Processor processor;
    Reader reader;

    if (!video.isOpened()) {
        std::cerr << "Unable to open camera" << std::endl;
        return 1;
    }

    while (cv::waitKey(30) != 'q') {
        cv::Mat frame, warpedFrame(100, 100, CV_8UC3);

        video >> frame;
        processor.process(frame, warpedFrame);

        if (processor.codeFound() && reader.read(warpedFrame)) {
            std::cout << reader.getText() << std::endl;
        }

        cv::imshow("Video", frame);
        cv::imshow("Code", warpedFrame);
    }

    return 0;
}
