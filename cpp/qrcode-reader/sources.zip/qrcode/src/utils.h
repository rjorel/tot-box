#ifndef __UTILS_H_
#define __UTILS_H_

#include <opencv2/core/types.hpp>


float cross(const cv::Point2f &a, const cv::Point2f &b) {
    return a.x * b.y - a.y * b.x;
}

float distance(const cv::Point2f &a, const cv::Point2f &b) {
    float xDiff = a.x - b.x,
        yDiff = a.y - b.y;

    return sqrtf(
        xDiff * xDiff + yDiff * yDiff
    );
}

float computeSlope(const cv::Point2f &a, const cv::Point2f &b) {
    float dy = b.y - a.y,
        dx = b.x - a.x;

    // Case where dx == 0.0 should never (or really rarely) happen.
    if (dx == 0.0) {
        return 0;
    }

    return dy / dx;
}

/**
 * Distance between a point and point projection on a line.
 *
 * @param p
 * @param m1
 * @param m2
 * @return float
 */
float distancePointLine(
    const cv::Point2f &point, const cv::Point2f &a, const cv::Point2f &b
) {
    float slope = computeSlope(a, b);

    // The equation comes from [y = Ax + B], transform in [By = Ax + c => Ax + By + C = 0]
    // where [A = -slope], [B = 1] and [C = -Ax - By = -Ax - y = slope * x - y].
    // [A = -slope] because OpenCV landmark is reverted on y-axis.
    // We can choose arbitrary the point a or the point b since they belong to the line.
    float A = -slope,
        B = 1.0,
        C = slope * a.x - a.y;

    return (A * point.x + B * point.y + C) / sqrtf(A * A + B * B);
}

/**
 * Compute the intersection point between two lines.
 * This implementation was found on http://stackoverflow.com/questions/7446126/opencv-2d-line-intersection-helper-function [2017, February].
 *
 * @param o1 - 1st point of 1st line.
 * @param p1 - 2nd point of 1st line.
 * @param o2 - 1st point of 2nd line.
 * @param p2 - 2nd point of 2nd line.
 * @param res - intersection point.
 * @return bool
 */
bool intersection(
    const cv::Point2f &o1, const cv::Point2f &p1,
    const cv::Point2f &o2, const cv::Point2f &p2,
    cv::Point2f &res
) {
    cv::Point2f x = o2 - o1;
    cv::Point2f d1 = p1 - o1;
    cv::Point2f d2 = p2 - o2;

    if (std::fabs(cross(d1, d2)) < 1e-8) {
        return false;
    }

    double t = cross(x, d2) / cross(d1, d2);
    res = o1 + d1 * t;

    return true;
}

#endif
