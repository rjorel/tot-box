#include <cctype>

#include "Evaluator.h"


void ReversePolishEvaluator::processString(const std::string &str) {
    Token token = getToken(str.c_str());

    switch (token.type) {
        case TokenType::NUMBER:
            stack.push(
                std::stoi(token.value)
            );
            break;

        case TokenType::OPERATION:
            stack.push(
                computeResult(token.value[0])
            );
            break;

        case TokenType::UNKNOWN:
            throw std::runtime_error(
                std::string("Error: The token \"") + str + "\" is not recognized"
            );

        default:
            break;
    }
}

ReversePolishEvaluator::Token ReversePolishEvaluator::getToken(const char *str) {
    char buffer[BUFSIZ];

    if (isOperator(*str)) {
        return {
            TokenType::OPERATION, std::string(1, *str)
        };
    }

    searchNumber(str, buffer);

    if (tokenWasNotFound(buffer)) {
        return {
            TokenType::UNKNOWN, ""
        };
    }

    return {
        TokenType::NUMBER, std::string(buffer)
    };
}

bool ReversePolishEvaluator::isOperator(char c) {
    return c == '+'
        || c == '-'
        || c == 'x'
        || c == '/';
}

void ReversePolishEvaluator::searchNumber(const char *str, char *buffer) {
    int offset = 0;

    for (; offset < BUFSIZ && std::isdigit(*str); str++) {
        buffer[offset++] = *str;
    }

    buffer[offset] = '\0';
}

bool ReversePolishEvaluator::tokenWasNotFound(const char *buffer) {
    return buffer[0] == '\0';
}

int ReversePolishEvaluator::computeResult(char operation) {
    switch (operation) {
        case '+':
            return stack.pop() + stack.pop();

        case '-': {
            // Get operand to subtract first, because subtraction is not commutative.
            int sub = stack.pop();
            return stack.pop() - sub;
        }

        case 'x':
            return stack.pop() * stack.pop();

        case '/': {
            // Idem for division.
            int div = stack.pop();
            return stack.pop() / (div ? div : 1);
        }

        default:
            break;
    }

    throw std::runtime_error(
        std::string("Error: The operation \"") + operation + "\" is not processed"
    );
}

double ReversePolishEvaluator::getResult() {
    return stack.top();
}
