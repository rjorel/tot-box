#ifndef __EVALUATOR_H_
#define __EVALUATOR_H_

#include "Stack.hpp"


class ReversePolishEvaluator {
public:
    void processString(const std::string &str);
    double getResult();

private:
    enum TokenType {
        UNKNOWN, NUMBER, OPERATION
    };

    struct Token {
        TokenType type;
        std::string value;
    };

private:
    Token getToken(const char *str);

    bool isOperator(char c);
    void searchNumber(const char *str, char *buffer);
    bool tokenWasNotFound(const char *buffer);

    int computeResult(char operation);

private:
    Stack<int> stack;
};

#endif
