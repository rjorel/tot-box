#ifndef __STACK_H_
#define __STACK_H_

#include <stdexcept>


template<typename T>
class Stack {
public:
    explicit Stack(unsigned int size = 64) : size(size) {
        baseElement = new T[size];
        topElement = baseElement;
    }

    ~Stack() {
        delete[] baseElement;
    }

    T pop() {
        if (isEmpty()) {
            throw std::runtime_error("Error: stack is empty");
        }

        return *--topElement;
    }

    void push(T value) {
        if (isFull()) {
            throw std::out_of_range("Error: maximum stack size reached");
        }

        *topElement++ = value;
    }

    T top() {
        if (isEmpty()) {
            throw std::runtime_error("Error: stack is empty");
        }

        return *(topElement - 1);
    }

    bool isEmpty() {
        return getNumElements() <= 0;
    }

    bool isFull() {
        return getNumElements() > size;
    }

    unsigned long getNumElements() {
        return topElement - baseElement;
    }

private:
    T *baseElement;
    T *topElement;

    unsigned int size;
};

#endif // __STACK_H_
