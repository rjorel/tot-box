#include <iostream>

#include "Evaluator.h"


int main(int argc, char *argv[]) {
    ReversePolishEvaluator evaluator;

    for (; argc > 1; argc--) {
        evaluator.processString(*++argv);
    }

    std::cout << "Result: " << evaluator.getResult() << std::endl;
}

