#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <map>
#include <pulse/simple.h>


#define SAMPLING_FREQUENCY  44100

static const std::vector<float> frequencies {
    82.4, 87.3, 92.5, 98.0, 103.8,                                                              // E
    110.0, 116.5, 123.5, 130.8, 138.6,                                                          // A
    146.8, 155.6, 164.8, 174.6, 185.0,                                                          // D
    196.00, 207.6, 220.0, 233.1,                                                                // G
    246.9, 261.6, 277.2, 293.6, 311.1,                                                          // B
    329.6, 349.2, 370.0, 392.0, 415.3, 440.0, 466.1, 493.8, 523.2, 554.3, 587.3, 622.2, 659.2   // e
};

static const std::map<char, int> stringOffsets {
    { 'E', 0 },
    { 'A', 5 },
    { 'D', 10 },
    { 'G', 15 },
    { 'B', 19 },
    { 'e', 24 },
};

static int getOffset(char string, int fret) {
    auto search = stringOffsets.find(string);

    if (search == stringOffsets.end()) {
        return -1;
    }

    int offset = search->second + fret;

    if (offset < 0 || offset >= frequencies.size()) {
        return -1;
    }

    return offset;
}

static std::vector<std::pair<float, int>> convert(std::ifstream &file) {
    std::vector<std::pair<float, int>> notes;

    int fret, duration;
    char string;

    while (true) {
        file >> fret >> string >> duration;

        if (file.eof()) {
            break;
        }

        int offset = getOffset(string, fret);

        if (offset == -1) {
            continue;
        }

        notes.emplace_back(
            frequencies[offset], duration
        );
    }

    return notes;
}

static std::vector<int16_t> generate(float frequency, int ms_duration) {
    auto size = static_cast<size_t>(SAMPLING_FREQUENCY * ms_duration / 1000);

    std::vector<double> buffer(size);
    std::vector<int16_t> data(size);

    for (int i = 0; i < size; i++) {
        buffer[i] = sin(
            2 * M_PI * i * frequency / SAMPLING_FREQUENCY
        );
    }

    // Double to signed 16-bits integers.
    std::transform(
        buffer.begin(), buffer.end(), data.begin(), [](double value) {
            return static_cast<int16_t>(value * 32768);
        }
    );

    return data;
}

static void play(const std::vector<std::pair<float, int>> &notes) {
    pa_sample_spec specs = {
        PA_SAMPLE_S16NE,
        SAMPLING_FREQUENCY,
        1   // MONO.
    };

    pa_simple *s = pa_simple_new(
        nullptr, "music", PA_STREAM_PLAYBACK, nullptr, "playback", &specs, nullptr, nullptr, nullptr
    );

    for (const auto &note : notes) {
        std::vector<int16_t> buffer = generate(note.first, note.second);

        pa_simple_write(
            s, buffer.data(), buffer.size() * sizeof(int16_t), nullptr
        );
    }

    pa_simple_free(s);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        std::cerr << argv[0] << ": No file specified" << std::endl;
        return EXIT_FAILURE;
    }

    std::ifstream src(argv[1], std::ios::in);

    if (!src) {
        std::cerr << argv[0] << ": " << argv[1] << ": No such file or directory" << std::endl;
        return EXIT_FAILURE;
    }

    auto notes = convert(src);
    play(notes);

    return EXIT_SUCCESS;
}