#ifndef __GRID_H_
#define __GRID_H_

#include <cstring>


class Grid {
public:
    const static int BLOCK_SIZE = 3;
    const static int SIDE_SIZE = BLOCK_SIZE * BLOCK_SIZE;
    const static int TOTAL_SIZE = SIDE_SIZE * SIDE_SIZE;

    explicit Grid(int *data) : cells(nullptr), valid(false) {
        cells = new int[Grid::TOTAL_SIZE];

        std::memcpy(cells, data, Grid::TOTAL_SIZE * sizeof(int));
    }

    ~Grid() {
        delete[] cells;
    }

    bool isValid() const {
        return valid;
    }

    bool validate() {
        valid = true;
    }

    int at(int row, int column) const {
        return cells[SIDE_SIZE * row + column];
    }

    void set(int row, int column, int value) {
        cells[SIDE_SIZE * row + column] = value;
    }

private:
    int *cells;
    bool valid;
};

#endif // __GRID_H_
