#include "Solver.h"


Solver::Solver(Grid *grid) : grid(grid) {
    //
}

void Solver::solve() {
    if (!grid) {
        return;
    }

    if (backtracking()) {
        grid->validate();
    }
}

bool Solver::backtracking(int position) {
    int row = position / Grid::SIDE_SIZE,
        column = position % Grid::SIDE_SIZE;

    if (isEndReached(position)) {
        return true;
    }

    if (mustBeSkipped(row, column)) {
        return backtracking(position + 1);
    } 

    for (int value = 1; value <= Grid::SIDE_SIZE; value++) {
        if (isPossibleValue(row, column, value)) {
            grid->set(row, column, value);

            // If previous level return 'true', it's because a solution was found.
            // We don't need to continue backtracking.
            if (backtracking(position + 1)) {
                return true;
            }
        }
    }

    grid->set(row, column, 0);

    return false;
}

bool Solver::isEndReached(int position) {
    return position == Grid::TOTAL_SIZE;
}

bool Solver::mustBeSkipped(int row, int column) {
    return grid->at(row, column) != 0;
}

bool Solver::isPossibleValue(int row, int column, int value) {
    return !existsInRow(row, value)
        && !existsInColumn(column, value)
        && !existsInBlock(row, column, value);
}

bool Solver::existsInRow(int row, int value) {
    for (int column = 0; column < Grid::SIDE_SIZE; column++) {
        if (grid->at(row, column) == value) {
            return true;
        }
    }

    return false;
}

bool Solver::existsInColumn(int column, int value) {
    for (int row = 0; row < Grid::SIDE_SIZE; row++) {
        if (grid->at(row, column) == value) {
            return true;
        }
    }

    return false;
}

bool Solver::existsInBlock(int row, int column, int value) {
    int blockRow = row - row % Grid::BLOCK_SIZE,
        blockColumn = column - column % Grid::BLOCK_SIZE;

    for (int r = blockRow; r < blockRow + Grid::BLOCK_SIZE; r++) {
        for (int c = blockColumn; c < blockColumn + Grid::BLOCK_SIZE; c++) {
            if (grid->at(r, c) == value) {
                return true;
            }
        }
    }

    return false;
}
