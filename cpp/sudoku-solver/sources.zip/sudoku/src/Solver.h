#ifndef __SOLVER_H_
#define __SOLVER_H_

#include <vector>
#include "Grid.hpp"


class Solver {
public:
    explicit Solver(Grid *grid);

    void solve();

private:
    bool backtracking(int position = 0);

    bool isEndReached(int position);
    bool mustBeSkipped(int row, int column);
    bool isPossibleValue(int row, int column, int value);

    bool existsInRow(int row, int value);
    bool existsInColumn(int column, int value);
    bool existsInBlock(int row, int column, int value);

private:
    Grid *grid;
};

#endif
