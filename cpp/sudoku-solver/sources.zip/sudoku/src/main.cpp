#include <iostream>

#include "Solver.h"


static int data[] = {
    1, 0, 0, 4, 8, 9, 0, 0, 6,
    7, 3, 0, 0, 0, 0, 0, 4, 0,
    0, 0, 0, 0, 0, 1, 2, 9, 5,
    0, 0, 7, 1, 2, 0, 6, 0, 0,
    5, 0, 0, 7, 0, 3, 0, 0, 8,
    0, 0, 6, 0, 9, 5, 7, 0, 0,
    9, 1, 4, 6, 0, 0, 0, 0, 0,
    0, 2, 0, 0, 0, 0, 0, 3, 7,
    8, 0, 0, 5, 1, 2, 0, 0, 4
};

int main() {
    Grid grid(data);
    Solver solver(&grid);

    clock_t start = clock();
    solver.solve();

    double elapsedTime = ((double) (clock() - start)) / CLOCKS_PER_SEC;

    std::cout << "---------------" << std::endl;
    std::cout << "Elapsed time: " << elapsedTime << std::endl;

    if (grid.isValid()) {
        std::cout << "Resolved !" << std::endl;
    } else {
        std::cout << "Impossible grid..." << std::endl;
    }

    // Display grid.
    for (int row = 0; row < Grid::SIDE_SIZE; row++) {
        for (int column = 0; column < Grid::SIDE_SIZE; column++) {
            std::cout << grid.at(row, column) << " ";
        }

        std::cout << std::endl;
    }

    return 0;
}
