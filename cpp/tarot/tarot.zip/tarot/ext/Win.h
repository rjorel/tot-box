#ifndef WIN_HH
#define WIN_HH 1

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "Event.h"

#include <string>

using std::string;

#define FONT_SMALL  1
#define FONT_MEDIUM 2
#define FONT_LARGE  3

typedef struct {
    int pixel;
    int r, g, b;
} ColorTable;

class Win {
public:
    Win(const char *winame, int w, int h, const char *bg_color);
    ~Win();

    void DrawWindow();
    void ClearWindow();

    void FillRectangle(int x, int y, int w, int h, const char *col);
    void DrawRectangle(int x, int y, int w, int h, const char *col);
    void FillCircle(int x, int y, int w, int h, const char *col);

    void DrawCircle(int x, int y, int w, int h, const char *col);
    void DrawLine(int x, int y, int w, int h, const char *col);
    void DrawText(int x, int y, const char *text, const char *col, int fnt);

    void delay(int);
    Event getEvent();

protected:

    unsigned int width, height;
    string background_color;

    Display *display;
    int screen;
    int depth;
    Window win;
    GC gc, copygc;
    Colormap cmap;
    ColorTable idx[256];
    Pixmap buffer;
    XFontStruct *font1, *font2, *font3;

    void _create(const char *winame, int, int, const char *bg_color);
    void _close();

    void procEvent(XEvent, Event &);
    void private_colormap();
    void alloc_color(int i, int r, int g, int b);
    int get_color(const char *col);

    int _delay(int);
};

#endif // WIN_HH