#ifndef __CLASS_BUTTON
#define __CLASS_BUTTON

#include "Event.h"

class GameWindow;

class Button {
public:
    explicit Button(std::string text = "Nothing", int x = 0, int y = 0, GameWindow *w = 0);
    ~Button();

    bool clicked(Event e) const;
    void show() const;
    void erase();


    static const int Width;
    static const int Height;

private:
    int x, y;
    GameWindow *win;
    std::string text;
};

#endif
