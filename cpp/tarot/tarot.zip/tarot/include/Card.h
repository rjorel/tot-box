
#ifndef __CLASS_CARD
#define __CLASS_CARD

// #include <iostream>
// #include <stdexcept>
#include "Event.h"

#define SIZE_SHAPE    20

class GameWindow;

class Card {
public:
    enum Color {
        Diamond,
        Heart,
        Spade,
        Club,
        Atout,
        NoColor
    };

    explicit Card(int val = 0, Color col = Atout, int x = 0, int y = 0, GameWindow *w = nullptr);

    bool isFigure() const;
    bool isOudler() const;
    bool isExcuse() const;

    int getX() const;
    int getY() const;
    int getValue() const;
    Color getColor() const;
    float getValuePoints() const;

    bool clicked(Event event) const;

    void move(int x, int y);
    void display() const;
    void cross() const;
    void erase() const;

    static const int Width;
    static const int Height;

private:
    int x, y;
    GameWindow *win;
    int value;
    Color color;
    float valuePoints;
    std::string name;

    friend bool operator<(const Card &c1, const Card &c2);
};

inline bool Card::isFigure() const {
    return (color != Atout && value > 9);
}

inline bool Card::isOudler() const {
    return (color == Atout && (value == 0 || value == 1 || value == 21));
}

inline bool Card::isExcuse() const {
    return (color == Atout && value == 0);
}

inline int Card::getX() const {
    return x;
}

inline int Card::getY() const {
    return y;
}

inline int Card::getValue() const {
    return value;
}

inline Card::Color Card::getColor() const {
    return color;
}

inline float Card::getValuePoints() const {
    return valuePoints;
}

#endif
