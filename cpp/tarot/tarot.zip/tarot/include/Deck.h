#ifndef __CLASS_DECK
#define __CLASS_DECK

#include <vector>
#include "Card.h"

class GameWindow;

class Deck {
public:
    Deck();

    inline Card *operator[](int index);
    const Card *operator[](int index) const;

    int getSize() const;
    int getCardsByColor(Card::Color color) const;
    int getOudlers() const;
    int getFigures() const;

    bool isEmpty() const;

    Card *removeLast();
    Card *remove(int index);

    void addCard(Card *c);

    void generate();

    void sort();
    void mix();

    void display() const;

private:
    GameWindow *win;
    std::vector<Card *> cards;
    int numCardsByColor[5];
    int numOudlers;
    int numFigures;
};

inline Card *Deck::operator[](int index) {
    return cards[index];
}

inline const Card *Deck::operator[](int index) const {
    return cards[index];
}

inline int Deck::getSize() const {
    return (int) (cards.size());
}

inline int Deck::getCardsByColor(Card::Color color) const {
    return (color == Card::NoColor) ? 0 : numCardsByColor[color];
}

inline int Deck::getOudlers() const {
    return numOudlers;
}

inline int Deck::getFigures() const {
    return numFigures;
}

inline bool Deck::isEmpty() const {
    return cards.empty();
}

#endif
