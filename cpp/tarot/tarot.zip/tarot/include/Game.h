#ifndef __CLASS_GAME
#define __CLASS_GAME

#include <vector>

#include "Deck.h"
#include "Player.h"
#include "HumanPlayer.h"
#include "IAPlayer.h"

class GameWindow;

class Game {
public:
    explicit Game(GameWindow *w = nullptr);
    ~Game();

    int exec();
    void newRound();
    bool nextTurn();

    void distribute();
    void displayScore();

    void cont();


private:
    GameWindow *win;
    std::vector<Player *> players;
    Deck baseDeck;
    Deck dog;
    Deck playMat;
    int nbPlayers;
    int indexFirstDistributed;
    int indexTaker;
    int indexEngager;
};

#endif
