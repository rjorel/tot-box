#ifndef __CLASS_WIND
#define __CLASS_WIND

#include <vector>

#include "Win.h"
#include "Button.h"
#include "Game.h"

class GameWindow : public Win {
public:
    explicit GameWindow(std::string bg = "#008000");

    unsigned int getWidth() const;
    unsigned int getHeight() const;
    std::string getBgColor() const;

    int exec();

private:
    Game game;
    std::string bgColor;
};

inline unsigned int GameWindow::getWidth() const {
    return width;
}

inline unsigned int GameWindow::getHeight() const {
    return height;
}

inline std::string GameWindow::getBgColor() const {
    return bgColor;
}

#endif