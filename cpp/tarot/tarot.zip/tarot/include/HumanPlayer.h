#ifndef __CLASS_HUMANPLAYER
#define __CLASS_HUMANPLAYER

#include "Player.h"

class HumanPlayer : public Player {
public:
    explicit HumanPlayer(std::string n = "Human", int x = 0, int y = 0, GameWindow *w = 0);

    TypeRound doAuction() override;
    void makeDog(Deck &dog) override;
    Card *play(Card::Color color) override;
};

#endif
