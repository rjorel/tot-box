#ifndef __CLASS_IAPLAYER
#define __CLASS_IAPLAYER

#include "Player.h"

class IAPlayer : public Player {
public:
    explicit IAPlayer(std::string n = "IA", int x = 0, int y = 0, GameWindow *w = 0);

    TypeRound doAuction() override;
    void makeDog(Deck &dog) override;
    Card *play(Card::Color color) override;
};

#endif
