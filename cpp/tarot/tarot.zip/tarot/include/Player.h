#ifndef __CLASS_PLAYER
#define __CLASS_PLAYER

#include <string>
#include "Deck.h"

class GameWindow;

class Player {
public:
    enum TypeRound {
        Nothing,
        Prise,
        Garde,
        GardeSans
    };

    explicit Player(std::string = "Unknown", int x = 0, int y = 0, GameWindow *w = 0);
    virtual ~Player() = default;

    int getX() const;
    int getY() const;
    int getPoints() const;
    int getOudlers() const;

    void addPoints(int p);
    void addCardInHand(Card *c);
    void addCardInHeap(Card *c);

    void sortHand();

    int countPoints(Deck &d);

    Card *chooseReplacingCard(Card *c);

    virtual TypeRound doAuction() = 0;
    virtual void makeDog(Deck &dog) = 0;
    virtual Card *play(Card::Color color) = 0;

protected:
    GameWindow *win;
    int x, y;
    Deck hand;
    Deck heap;
    int nbPoints;
    std::string name;
};

inline int Player::getX() const {
    return x;
}

inline int Player::getY() const {
    return y;
}

inline int Player::getPoints() const {
    return nbPoints;
}

inline int Player::getOudlers() const {
    return heap.getOudlers();
}

inline void Player::addPoints(int p) {
    nbPoints += p;
}

inline void Player::addCardInHand(Card *c) {
    hand.addCard(c);
}

inline void Player::addCardInHeap(Card *c) {
    heap.addCard(c);
}

inline void Player::sortHand() {
    hand.sort();
}

#endif
