#include "GameWindow.h"

const int Button::Width = 100;
const int Button::Height = 50;

Button::Button(std::string _text, int _x, int _y, GameWindow *w) : x(_x), y(_y), win(w), text(_text) {
    //
}

Button::~Button() {
    erase();
}

bool Button::clicked(Event e) const {
    return ((e.getType() == MB1P) &&
        ((e.getX() >= x && e.getX() <= x + Width) &&
            (e.getY() >= y && e.getY() <= y + Height)));
}

void Button::show() const {
    win->FillRectangle(x, y, Width, Height, "#FFFFFF");
    win->DrawText(x + (Width - text.size() * 8.5) / 2, y + Height / 4 + 5, text.c_str(), "#000000",
                  FONT_MEDIUM);

    win->DrawWindow();
}

void Button::erase() {
    win->FillRectangle(x, y, Width, Height, win->getBgColor().c_str());
}
