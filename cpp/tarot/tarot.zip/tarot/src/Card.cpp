#include <iostream>
#include <sstream>

#include "GameWindow.h"

const int Card::Width = 30;
const int Card::Height = 70;

Card::Card(int val, Color col, int _x, int _y, GameWindow *w):
    x(_x),
    y(_y),
    win(w),
    value(val),
    color(col) {
    float valuesPoints[] = { 1.5, 2.5, 3.5, 4.5 };
    std::string nameCard[] = { "V", "C", "D", "R" };
    std::ostringstream oss;

    if (col == Card::NoColor) {
        throw std::logic_error("NoColor is not a color of card");
    }
    if ((val > 13 && col != Atout) || (val > 21 && col == Atout)) {
        throw std::logic_error("Value too large for a card");
    }

    if (color == Card::Atout) {
        if (value) {
            if (value == 1 || value == 21) {
                valuePoints = 4.5;
            } else {
                valuePoints = 0.5;
            }

            oss << value;
            name = oss.str();
        } else {
            valuePoints = 4.5;
            name = "E";
        }
    } else {
        if (value < 10) {
            valuePoints = 0.5;
            oss << value + 1;
            name = oss.str();
        } else {
            valuePoints = valuesPoints[value - 10];
            name = nameCard[value - 10];
        }
    }
}

bool Card::clicked(Event event) const {
    return (
        (event.getType() == MB1P) &&
            ((event.getX() >= x && event.getX() <= x + Width) &&
                (event.getY() >= y && event.getY() <= y + Height)
            )
    );
}

void Card::move(int _x, int _y) {
    x = _x;
    y = _y;
}

void Card::display() const {
    int shapeX = x + (Width - SIZE_SHAPE) / 2, shapeY = y + (Height - SIZE_SHAPE) / 2 + 10;


    win->FillRectangle(x, y, Width, Height, "#FFFFFF");
    win->DrawText(x + 5, y + 5, name.c_str(), "#000000", FONT_MEDIUM);

    switch (color)  // Dessin des différentes formes.
    {
        case Diamond:
            for (int i = 0, stop = SIZE_SHAPE / 2; i <= stop; i++) {
                win->DrawLine((shapeX + SIZE_SHAPE / 2) - i, shapeY + i,
                              (shapeX + SIZE_SHAPE / 2) + i, shapeY + i,
                              "#F00000");
                win->DrawLine(shapeX + i, shapeY + SIZE_SHAPE / 2 + i, (shapeX + SIZE_SHAPE) - i,
                              shapeY + SIZE_SHAPE / 2 + i, "#F00000");
            }
            break;

        case Heart:
            win->FillCircle(shapeX, shapeY, SIZE_SHAPE / 2, SIZE_SHAPE / 2, "#F00000");
            win->FillCircle(shapeX + SIZE_SHAPE / 2, shapeY, SIZE_SHAPE / 2, SIZE_SHAPE / 2,
                            "#F00000");

            for (int i = 0, stop = 3 * SIZE_SHAPE / 4; i < stop; i++) {
                win->DrawLine(shapeX + 3 * i / 4, shapeY + SIZE_SHAPE / 4 + i,
                              (shapeX + SIZE_SHAPE) - 3 * i / 4,
                              shapeY + SIZE_SHAPE / 4 + i, "#F00000");
            }

            break;

        case Spade:
            win->FillCircle(shapeX, shapeY + SIZE_SHAPE / 4, SIZE_SHAPE / 2, SIZE_SHAPE / 2,
                            "#000000");
            win->FillCircle(shapeX + SIZE_SHAPE / 2, shapeY + SIZE_SHAPE / 4, SIZE_SHAPE / 2,
                            SIZE_SHAPE / 2,
                            "#000000");

            for (int i = 0, stop = SIZE_SHAPE / 2; i <= stop; i++) {
                win->DrawLine((shapeX + SIZE_SHAPE / 2) - i, shapeY + i,
                              (shapeX + SIZE_SHAPE / 2) + i, shapeY + i,
                              "#000000");
                win->DrawLine((shapeX + SIZE_SHAPE / 2) - (i - SIZE_SHAPE / 4),
                              shapeY + SIZE_SHAPE / 2 + i,
                              (shapeX + SIZE_SHAPE / 2) + (i - SIZE_SHAPE / 4),
                              shapeY + SIZE_SHAPE / 2 + i, "#000000");
            }
            break;

        case Club:
            win->FillCircle(shapeX + SIZE_SHAPE / 4, shapeY, SIZE_SHAPE / 2, SIZE_SHAPE / 2,
                            "#000000");
            win->FillCircle(shapeX, shapeY + SIZE_SHAPE / 4, SIZE_SHAPE / 2, SIZE_SHAPE / 2,
                            "#000000");
            win->FillCircle(shapeX + SIZE_SHAPE / 2, shapeY + SIZE_SHAPE / 4, SIZE_SHAPE / 2,
                            SIZE_SHAPE / 2,
                            "#000000");

            for (int i = 0, stop = SIZE_SHAPE / 2; i <= stop; i++) {
                win->DrawLine((shapeX + SIZE_SHAPE / 2) - (i - SIZE_SHAPE / 4),
                              shapeY + SIZE_SHAPE / 2 + i,
                              (shapeX + SIZE_SHAPE / 2) + (i - SIZE_SHAPE / 4),
                              shapeY + SIZE_SHAPE / 2 + i, "#000000");
            }
            break;

        case Atout:
            win->DrawText(x + 10, y + 30, "A", "#000000", FONT_MEDIUM);
            break;

        default:
            break;
    }
}

void Card::cross() const {
    win->DrawLine(x + 1, y + 1, x + Width - 1, y + Height - 1, "#FF0000");
    win->DrawLine(x + 1, y + Height - 1, x + Width - 1, y, "#FF0000");
}

void Card::erase() const {
    win->FillRectangle(x, y, Width, Height, win->getBgColor().c_str());
}

bool operator<(const Card &c1, const Card &c2) {
    if (c1.color == Card::Atout) {
        if (c2.color == Card::Atout) {
            return (c1.value < c2.value);
        } else {
            return (c1.value == 0);
        }
    } else {
        if (c2.color == Card::Atout) {
            return (c2.value != 0);
        } else {
            return (c1.value < c2.value);
        }
    }
}
