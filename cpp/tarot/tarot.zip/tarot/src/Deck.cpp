#include <iostream>
#include <cstring>

#include "GameWindow.h"

Deck::Deck() : numOudlers(0), numFigures(0) {
    std::memset(numCardsByColor, 0, 5 * sizeof(int));
}

Card *Deck::removeLast() {
    return remove((int) (cards.size() - 1));
}

Card *Deck::remove(int index) {
    Card *tmp = cards[index];

    if (tmp->isOudler()) {
        numOudlers--;
    }
    if (tmp->isFigure()) {
        numFigures--;
    }

    numCardsByColor[(int) tmp->getColor()]--;
    cards.erase(cards.begin() + index);

    return tmp;
}

void Deck::addCard(Card *c) {
    if (c->isOudler()) {
        numOudlers++;
    }
    if (c->isFigure()) {
        numFigures++;
    }

    numCardsByColor[(int) c->getColor()]++;
    cards.push_back(c);
}

void Deck::generate() {
    for (int i = 0; i < 14; i++) {
        addCard(new Card(i, Card::Diamond, 0, 0, win));
        addCard(new Card(i, Card::Heart, 0, 0, win));
        addCard(new Card(i, Card::Spade, 0, 0, win));
        addCard(new Card(i, Card::Club, 0, 0, win));
        addCard(new Card(i, Card::Atout, 0, 0, win));
    }

    for (int i = 14; i < 22; i++) {
        addCard(new Card(i, Card::Atout, 0, 0, win));
    }
}

void Deck::sort() {
    Card *temp = 0;
    int j, posPlayer = 3 * win->getHeight() / 4;


    for (int i = 1, length = cards.size(); i < length; i++) {
        temp = cards[i];

        for (j = i; j > 0 && ((((int) cards[j - 1]->getColor() << 4) + cards[j - 1]->getValue()) >
            (((int) temp->getColor() << 4) + temp->getValue())); j--) {
            cards[j] = cards[j - 1];
        }

        cards[j] = temp;
    }

    for (int i = 0, length = cards.size(); i < length; i++) {
        cards[i]->move(i * (Card::Width + 10) + 5, posPlayer);
    }
}

void Deck::mix() {
    for (int length = cards.size() - 1; length > 0; length--) {
        int index = rand() % length;
        Card *tmp = cards[index];

        cards[index] = cards[length];
        cards[length] = tmp;
    }
}

void Deck::display() const {
    for (auto card : cards) {
        card->display();
    }
}