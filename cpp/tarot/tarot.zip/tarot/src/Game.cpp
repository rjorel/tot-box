#include <iostream>
#include <sstream>
#include <ctime>

#include "GameWindow.h"

Game::Game(GameWindow *w) : win(w), baseDeck(), nbPlayers(4), indexFirstDistributed(0),
                            indexTaker(0),
                            indexEngager(0) {
    srand(time(NULL));
    baseDeck.generate();
    players.push_back(new HumanPlayer("Player", (win->getWidth() - Card::Width) / 2,
                                      3 * win->getHeight() / 4 - (Card::Height + 5), win));

    players.push_back(new IAPlayer("IAPlayer1", (win->getWidth() - Card::Width) / 4, 5, win));
    players.push_back(new IAPlayer("IAPlayer2", (win->getWidth() - Card::Width) / 2, 5, win));
    players.push_back(new IAPlayer("IAPlayer3", 3 * (win->getWidth() - Card::Width) / 4, 5, win));
}

Game::~Game() {
    for (int i = 0, length = players.size(); i < length; i++) {
        delete players[i];
    }
}

int Game::exec() {
    Event e;
    Button yes("Oui", (win->getWidth() - 100) / 2, 200, win);
    Button no("Non", (win->getWidth() - 100) / 2, 260, win);

    win->DrawText(280, 150, "Nouvelle manche :", "#000000", FONT_MEDIUM);
    yes.show();
    no.show();

    while (true)    // On attend un réponse du joueur.
    {
        e = win->getEvent();

        if (yes.clicked(e)) {
            newRound();
            win->ClearWindow();
            win->DrawText(280, 150, "Nouvelle manche :", "#000000", FONT_MEDIUM);
            yes.show();
            no.show();
        }

        if (no.clicked(e)) {
            break;
        }
        win->DrawWindow();
        win->delay(50000);
    }

    return 0;
}

void Game::newRound() {
    Player::TypeRound contract = Player::Nothing, temp = Player::Nothing;
    std::string nameContract, nameTemp;
    std::ostringstream oss;
    int nbPointsForContract = 0;
    int nbPointsTaker = 0;
    int indexCurrentPlayer = 0;
    bool winner = false;


    win->ClearWindow();
    distribute();
    indexTaker = -1;
    displayScore();

    for (int i = 0; i < nbPlayers; i++) {
        indexCurrentPlayer = (indexFirstDistributed + i) % nbPlayers;
        temp = players[indexCurrentPlayer]->doAuction();

        nameTemp = (temp == Player::Nothing) ? "Rien" : (temp == Player::Prise) ? "Prise" : (temp ==
            Player::Garde)
                                                                                            ? "Garde"
                                                                                            : "Garde Sans";
        win->DrawText(players[indexCurrentPlayer]->getX() + (Card::Width + 5),
                      players[indexCurrentPlayer]->getY() + Card::Height / 2, nameTemp.c_str(),
                      "#000000", FONT_MEDIUM);

        if (temp > contract) {
            contract = temp;
            nameContract = nameTemp;
            indexTaker = indexCurrentPlayer;
        }
    }


    if (indexTaker == -1) {
        win->DrawText(200, 200, "Personne n'a pris", "#000000", FONT_MEDIUM);
        cont();
    } else {
        win->DrawText(players[indexTaker]->getX() + (Card::Width + 5),
                      players[indexTaker]->getY() + Card::Height / 2 + 15, "Preneur", "#F00000",
                      FONT_MEDIUM);
        cont();

        for (int i = 0; i < nbPlayers; i++) {
            win->FillRectangle(players[i]->getX() + Card::Width, players[i]->getY(), 140,
                               Card::Height,
                               win->getBgColor().c_str());
        }

        if (contract == Player::GardeSans) {
            while (!dog.isEmpty()) {
                players[indexTaker]->addCardInHeap(dog.removeLast());
            }
        } else {
            players[indexTaker]->makeDog(dog);
        }

        indexEngager = indexFirstDistributed;

        while (nextTurn()) {
        }

        nbPointsForContract = (players[indexTaker]->getOudlers() == 3) ? 36
                                                                       : (players[indexTaker]->getOudlers() ==
                2)
                                                                         ? 41
                                                                         : (players[indexTaker]->getOudlers() ==
                    1)
                                                                           ? 51 : 56;
        nbPointsTaker = players[indexTaker]->countPoints(baseDeck);

        winner = (nbPointsTaker >=
            nbPointsForContract);   // Le nombre de points du preneur lui permet de gagner le contrat.

        oss.str("");
        oss << nbPointsForContract;
        win->DrawText(win->getWidth() / 4, win->getHeight() / 4 + 10,
                      ("Points a atteindre : " + oss.str()).c_str(),
                      "#000000", FONT_MEDIUM);
        oss.str("");
        oss << nbPointsTaker;
        win->DrawText(win->getWidth() / 4, win->getHeight() / 4 + 30,
                      ("Points du preneur : " + oss.str()).c_str(),
                      "#000000", FONT_MEDIUM);

        nbPointsTaker = (nbPointsTaker - nbPointsForContract) + 25;
        nbPointsTaker = (nbPointsTaker > 0) ? nbPointsTaker : 0;

        if (contract == Player::GardeSans) {
            nbPointsTaker *= 4;
        } else if (contract == Player::Garde) {
            nbPointsTaker *= 2;
        }

        win->DrawText(win->getWidth() / 4, win->getHeight() / 4 + 50,
                      (winner) ? "Le preneur a reussi son contrat !"
                               : "Les defenseurs ont mieux gere !", "#000000",
                      FONT_MEDIUM);
        displayScore();
        oss.str("");
        oss << ((winner) ? 3 * nbPointsTaker : -3 * nbPointsTaker);
        win->DrawText(players[indexTaker]->getX() + (Card::Width + 5),
                      players[indexTaker]->getY() + 20,
                      oss.str().c_str(), (winner) ? "#0000A0" : "#F00000", FONT_MEDIUM);
        players[indexTaker]->addPoints((winner) ? 3 * nbPointsTaker : -3 * nbPointsTaker);
        oss.str("");
        oss << ((winner) ? -nbPointsTaker : nbPointsTaker);

        for (int i = 1; i < 4; i++) {
            win->DrawText(players[(indexTaker + i) % nbPlayers]->getX() + (Card::Width + 5),
                          players[(indexTaker + i) % nbPlayers]->getY() + 20, oss.str().c_str(),
                          (winner) ? "#F00000" : "#0000A0", FONT_MEDIUM);
            players[(indexTaker + i) % nbPlayers]->addPoints(
                (winner) ? -nbPointsTaker : nbPointsTaker);
        }

        cont();
    }

    for (int i = 0; i < nbPlayers; i++) {
        players[i]->countPoints(baseDeck);
    }    // Tous les joueurs rendent leurs cartes au deck de base.

    ++indexFirstDistributed %= nbPlayers;
}

bool Game::nextTurn() {
    Card *current = 0, *temp = 0;
    Card::Color colorPlayed;
    int indexNextEngager = indexEngager;
    int indexCurrentPlayer = 0, i;


    if ((current = players[indexEngager]->play(Card::NoColor)) == 0) {
        return false;
    }

    colorPlayed = current->getColor();
    current->move(players[indexEngager]->getX(), players[indexEngager]->getY());
    current->display();
    playMat.addCard(current);

    for (i = 1; i < nbPlayers; i++) {
        indexCurrentPlayer = (indexEngager + i) % nbPlayers;
        temp = players[indexCurrentPlayer]->play(colorPlayed);

        if ((temp->getColor() == colorPlayed || temp->getColor() == Card::Atout) &&
            *current < *temp) {
            current = temp;
            indexNextEngager = indexCurrentPlayer;
        }

        temp->move(players[indexCurrentPlayer]->getX(), players[indexCurrentPlayer]->getY());
        temp->display();
        playMat.addCard(temp);
    }

    win->DrawText(players[indexNextEngager]->getX() + (Card::Width + 5),
                  players[indexNextEngager]->getY() + Card::Height / 2 + 15, "Gagnant", "#F00000",
                  FONT_MEDIUM);
    cont();

    for (i = 0; i < nbPlayers && !playMat[i]->isExcuse(); i++) {
    }

    if (i < nbPlayers) {
        indexCurrentPlayer = (indexEngager + i) % nbPlayers;
        temp = players[indexCurrentPlayer]->chooseReplacingCard(playMat.remove(i));
        temp->move(players[indexCurrentPlayer]->getX(), players[indexCurrentPlayer]->getY());
        temp->display();
        playMat.addCard(temp);

        win->DrawText(players[indexCurrentPlayer]->getX() + (Card::Width + 5),
                      players[indexCurrentPlayer]->getY() + Card::Height / 2 + 15, "Remplacement",
                      "#F00000",
                      FONT_MEDIUM);
        cont();
        win->FillRectangle(players[indexCurrentPlayer]->getX() + Card::Width,
                           players[indexCurrentPlayer]->getY(), 120,
                           Card::Height, win->getBgColor().c_str());
    }

    indexEngager = indexNextEngager;

    while (!playMat.isEmpty()) {
        players[indexEngager]->addCardInHeap(playMat.removeLast());
    }

    for (int i = 0; i < nbPlayers; i++) {
        win->FillRectangle(players[i]->getX(), players[i]->getY(), Card::Width, Card::Height,
                           "#FFFFFF");
    }
    win->FillRectangle(players[indexEngager]->getX() + Card::Width, players[indexEngager]->getY(),
                       100, Card::Height,
                       win->getBgColor().c_str());

    return true;
}

void Game::distribute() {
    baseDeck.mix();

    while (!baseDeck.isEmpty()) {
        for (int i = 0; i < nbPlayers; i++) {
            for (int j = 0; j < 3; j++) {
                players[((indexFirstDistributed + i) % nbPlayers)]->addCardInHand(baseDeck.removeLast());
            }
        }

        dog.addCard(baseDeck.removeLast());
    }

    for (int i = 0; i < nbPlayers; i++) {
        players[i]->sortHand();
    }
}

void Game::displayScore() {
    std::ostringstream oss;


    for (int i = 0; i < nbPlayers; i++) {
        oss.str("");
        oss << players[i]->getPoints();
        win->FillRectangle(players[i]->getX(), players[i]->getY(), Card::Width, Card::Height,
                           "#FFFFFF");
        win->DrawText(players[i]->getX() + (Card::Width + 5), players[i]->getY() + 5,
                      (oss.str() + " point(s)").c_str(),
                      "#000000", FONT_MEDIUM);
    }
}

void
Game::cont()   // Affiche un bouton pour laisser le temps de bien voir ce qui se passe dans le jeu.
{
    Button next("Continuer", 220, 220, win);


    next.show();

    while (true) {
        if (next.clicked(win->getEvent())) {
            break;
        }
        win->DrawWindow();
        win->delay(50000);
    }
}