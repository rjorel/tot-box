#include "GameWindow.h"

GameWindow::GameWindow(std::string bg): Win("Tarot", 720, 480, bg.c_str()), game(this), bgColor(bg) {
    //
}

int GameWindow::exec() {
    return game.exec();
}
