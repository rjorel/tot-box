#include <iostream>
#include <sstream>
#include <limits>
#include <ctime>

#include "GameWindow.h"

HumanPlayer::HumanPlayer(std::string n, int x, int y, GameWindow *w) : Player(n, x, y, w) {
    //
}

Player::TypeRound HumanPlayer::doAuction() {
    Event e;
    Button nothing("Rien", win->getWidth() / 4 - Button::Width / 2, win->getHeight() / 2 - 110,
                   win);
    Button prise("Prise", (win->getWidth() - Button::Width) / 2, win->getHeight() / 2 - 110, win);
    Button garde("Garde", 3 * win->getWidth() / 4 - Button::Width / 2, win->getHeight() / 2 - 110,
                 win);
    Button gardeSans("Garde Sans", (win->getWidth() - Button::Width) / 2, win->getHeight() / 2 - 50,
                     win);


    hand.display();
    nothing.show();
    prise.show();
    garde.show();
    gardeSans.show();

    while (true) {
        e = win->getEvent();
        if (nothing.clicked(e)) {
            return Nothing;
        }
        if (prise.clicked(e)) {
            return Prise;
        }
        if (garde.clicked(e)) {
            return Garde;
        }
        if (gardeSans.clicked(e)) {
            return GardeSans;
        }
        win->delay(50000);
    }

    return Nothing;
}

void HumanPlayer::makeDog(Deck &dog) {
    Event e;
    Button end("Fini", (dog.getSize() + 1) * (Card::Width + 10) + 100,
               win->getHeight() / 2 - Card::Height, win);
    int indexDog, indexHand, x, y;
    bool loop;


    win->DrawText(100, win->getHeight() / 2 - (Card::Height + 20), "Chien :", "#000000",
                  FONT_MEDIUM);
    for (int i = 0, length = dog.getSize(); i < length; i++) {
        dog[i]->move(i * (Card::Width + 10) + 100, win->getHeight() / 2 - Card::Height);
    }
    dog.display();
    end.show();


    while (true) {
        loop = true;

        while (loop)    // Choix de la première carte, dans le chien.
        {
            e = win->getEvent();

            if (end.clicked(e)) {
                goto end_loop;
            }
            for (int i = 0, length = dog.getSize(); i < length; i++) {
                if (dog[i]->clicked(e)) {
                    indexDog = i;
                    loop = false;
                    break;
                }
            }

            win->DrawWindow();
            win->delay(50000);
        }

        loop = true;

        while (loop)    // Choix de la seconde carte, dans le jeu.
        {
            e = win->getEvent();

            if (end.clicked(e)) {
                goto end_loop;
            }
            for (int i = 0, length = hand.getSize(); i < length; i++) {
                if (hand[i]->clicked(e)) {
                    indexHand = i;
                    loop = false;
                    break;
                }
            }

            win->DrawWindow();
            win->delay(50000);
        }

        x = dog[indexDog]->getX();
        y = dog[indexDog]->getY();                   // Echange des cartes.
        dog[indexDog]->move(hand[indexHand]->getX(), hand[indexHand]->getY());
        hand[indexHand]->move(x, y);
        dog[indexDog]->display();
        hand[indexHand]->display();

        hand.addCard(dog.remove(indexDog));
        dog.addCard(hand.remove(indexHand));
    }

    end_loop:

    win->FillRectangle(100, win->getHeight() / 2 - (Card::Height + 20),
                       (dog.getSize() + 1) * (Card::Width + 10) + Button::Width, Card::Height + 20,
                       win->getBgColor().c_str());
    hand.sort();

    while (!dog.isEmpty()) {
        heap.addCard(dog.removeLast());
    }
}

Card *HumanPlayer::play(Card::Color color) {
    std::vector<int> cardsPlayable;
    std::ostringstream oss;
    Card::Color colorPlayable;
    Event e;
    time_t beginTime = time(0), currentTime;
    int i, length;
    bool loop = true;


    if (hand.isEmpty()) {
        return 0;
    }

    hand.display();
    colorPlayable = (color == Card::NoColor) ? Card::NoColor : (hand.getCardsByColor(color) > 0)
                                                               ? color
                                                               : (hand.getCardsByColor(
            Card::Atout) > 0) ? Card::Atout : Card::NoColor;

    for (int i = 0, length = hand.getSize();
         i < length; i++) // Raye les cartes en fonction de la couleur jouable.
    {
        if (colorPlayable == Card::NoColor || hand[i]->isExcuse()) {
            cardsPlayable.push_back(i);  // Les indice des cartes jouables sont retenues.
        } else if (hand[i]->getColor() != colorPlayable) {
            hand[i]->cross();
        } else {
            cardsPlayable.push_back(i);
        }
    }

    win->DrawText(3 * win->getWidth() / 4 - 100, win->getHeight() / 2, "Temps restant : ",
                  "#000000", FONT_MEDIUM);

    while (loop) {
        e = win->getEvent();

        oss.str("");
        oss << 20 - ((currentTime = time(0)) - beginTime);
        win->FillRectangle(3 * win->getWidth() / 4 + 50, win->getHeight() / 2, 100, 100,
                           win->getBgColor().c_str());
        win->DrawText(3 * win->getWidth() / 4 + 50, win->getHeight() / 2, (oss.str() + "s").c_str(),
                      "#000000",
                      FONT_MEDIUM);

        if ((currentTime - beginTime) >= 20) {
            i = 0;
            break;
        }  // Timer, si le joueur ne joue pas assez vite, la première carte jouable est choisie.

        for (i = 0, length = cardsPlayable.size();
             i < length; i++) {   // Parcours uniquement des cartes jouables.
            if (hand[cardsPlayable[i]]->clicked(e)) {
                loop = false;
                break;
            }
        }

        win->DrawWindow();
        win->delay(50000);
    }

    hand[cardsPlayable[i]]->erase();

    return hand.remove(cardsPlayable[i]);
}
