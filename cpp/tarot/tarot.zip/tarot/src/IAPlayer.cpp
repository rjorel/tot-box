#include <cstdlib>

#include "IAPlayer.h"

IAPlayer::IAPlayer(std::string n, int x, int y, GameWindow *w):
    Player(n, x, y, w) {
    //
}

Player::TypeRound IAPlayer::doAuction() {
    TypeRound contract = Nothing;
    int stats = hand.getFigures() + hand.getCardsByColor(Card::Atout) * 2 + hand.getOudlers() * 3;

    if (stats >= 20) {
        contract = GardeSans;
    } else if (stats >= 15) {
        contract = Garde;
    } else if (stats >= 10) {
        contract = Prise;
    }

    return contract;
}

void IAPlayer::makeDog(Deck &dog) {
    while (!dog.isEmpty()) {
        heap.addCard(dog.removeLast());
    }
}

Card *IAPlayer::play(Card::Color color) {
    Card::Color colorPlayable;
    int i, length;


    if (hand.isEmpty()) {
        return 0;
    }
    if (hand.getSize() == 1) {
        return hand.remove(0);
    }
    if (color == Card::NoColor) {
        return hand.remove(rand() % hand.getSize());
    }

    colorPlayable = (hand.getCardsByColor(color) > 0) ? color : (hand.getCardsByColor(Card::Atout) >
                                                                 0) ? Card::Atout
                                                                    : Card::NoColor;

    if (colorPlayable == Card::NoColor) {
        return hand.remove(rand() % hand.getSize());
    }

    for (i = 0, length = hand.getSize(); i < length && hand[i]->getColor() != colorPlayable; i++) {
    }
    if (hand.getCardsByColor(colorPlayable) == 1) {
        return hand.remove(i);
    }

    return hand.remove(i + rand() % hand.getCardsByColor(colorPlayable));
}
