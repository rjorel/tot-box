#include <cstdlib>
#include "Player.h"

Player::Player(std::string n, int _x, int _y, GameWindow *w): 
    win(w), 
    x(_x), 
    y(_y), 
    hand(), 
    heap(), 
    nbPoints(0), 
    name(n) {
    //
}

int Player::countPoints(Deck &d) {
    Card *temp;
    float points = 0.0;

    while (!heap.isEmpty()) {
        temp = heap.removeLast();
        points += temp->getValuePoints();
        d.addCard(temp);
    }

    return (int) points;
}

Card *Player::chooseReplacingCard(Card *c) {
    int imin;
    float valMin;

    // S'il n'y a pas de carte dans le tas, on renvoi la carte à remplacer.
    if (heap.isEmpty()) {
        return c;
    }

    valMin = heap[0]->getValuePoints();
    imin = 0;

    for (int i = 1, length = heap.getSize(); i < length && valMin != 0.5; i++) {
        if (heap[i]->getValuePoints() < valMin) {
            valMin = heap[i]->getValuePoints();
            imin = i;
        }
    }

    heap.addCard(c);

    return heap.remove(imin);
}
