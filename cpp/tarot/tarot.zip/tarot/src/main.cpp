#include "GameWindow.h"

int main() {
    GameWindow app;

    return app.exec();
}
