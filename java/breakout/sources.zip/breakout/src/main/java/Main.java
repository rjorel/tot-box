import models.BreakoutGame;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        BreakoutGame game = new BreakoutGame();

        game.setLevels(new String[] {
            "levels/five.txt",
            "levels/final2.txt",
            "levels/final1.txt",
            "levels/final3.txt",
        });

        game.start();
    }
}