package entities.bonus;

import java.awt.*;

public class ExplosionBonus extends AbstractBonus {

    public ExplosionBonus(Canvas canvas, int size) {
        super(canvas, size);
    }

    @Override
    public String getImagePath() {
        return "images/explosion.png";
    }
}
