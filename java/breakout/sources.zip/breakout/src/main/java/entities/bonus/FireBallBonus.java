package entities.bonus;

import java.awt.*;

public class FireBallBonus extends AbstractBonus {
    public FireBallBonus(Canvas canvas, int size) {
        super(canvas, size);
    }

    @Override
    public String getImagePath() {
        return "images/fireball.png";
    }
}