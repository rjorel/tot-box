package entities.bonus;

import java.awt.*;

public class LifeBonus extends AbstractBonus {

    public LifeBonus(Canvas canvas, int size) {
        super(canvas, size);
    }

    @Override
    public String getImagePath() {
        return "images/life.png";
    }
}
