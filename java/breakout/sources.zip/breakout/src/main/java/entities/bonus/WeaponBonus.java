package entities.bonus;

import java.awt.*;

public class WeaponBonus extends AbstractBonus {

    public WeaponBonus(Canvas canvas, int size) {
        super(canvas, size);
    }

    @Override
    public String getImagePath() {
        return "images/weapon.png";
    }
}