package utils;

import java.net.URL;

public class ResourceLoader {
    private static ClassLoader classLoader = ResourceLoader.class.getClassLoader();

    public static String getResourcePath(String filePath) {
        URL resourceUrl = classLoader.getResource(filePath);

        if (resourceUrl != null) {
            return resourceUrl.getPath();
        }

        return "";
    }
}
