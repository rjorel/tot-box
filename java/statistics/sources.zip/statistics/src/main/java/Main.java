import models.Application;
import models.ColorHandler;
import views.Window;

import javax.swing.*;

public class Main {
    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {      // Use thread to improve performances.
            try {
                UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");      // Nice style for this kind of application.
            } catch (ClassNotFoundException | InstantiationException
                | UnsupportedLookAndFeelException | IllegalAccessException ignored) {
            }

            new Window(new Application(), new ColorHandler());
        });
    }

}
