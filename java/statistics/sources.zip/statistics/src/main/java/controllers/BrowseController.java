package controllers;

import models.Application;
import views.Canvas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BrowseController implements ActionListener {
    private Application app;
    private Canvas canvas;
    private JFrame screen;
    private JScrollPane scrollPane;

    private int offset = 0;

    public BrowseController(Application app, Canvas canvas, JScrollPane scrollPane, JFrame screen, int offset) {
        this.app = app;
        this.canvas = canvas;
        this.screen = screen;
        this.scrollPane = scrollPane;
        this.offset = offset;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (!app.hasImage()) {
            JOptionPane.showMessageDialog(
                screen, "No image. Import images before browsing them", "Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        app.currentImage().setOffsetX(scrollPane.getHorizontalScrollBar().getValue());      // Retrieve scroll bars values and store it.
        app.currentImage().setOffsetY(scrollPane.getVerticalScrollBar().getValue());

        app.changeImageIndex(offset);                                                       // Change image.

        scrollPane.getHorizontalScrollBar().setValue(app.currentImage().offsetX());         // Restore scroll bar values previously stored.
        scrollPane.getVerticalScrollBar().setValue(app.currentImage().offsetY());

        Image image = app.currentImage().image();                                           // Resize canvas for image adaption.

        canvas.setPreferredSize(new Dimension(

            image.getWidth(null), image.getHeight(null)
        ));

        canvas.revalidate();
        canvas.repaint();
    }
}