package controllers;

import models.Application;
import models.ColorHandler;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChangeColorController implements ActionListener {
    private Application app;
    private ColorHandler colorHandler;
    private JLabel currentColorLabel;

    private int color;

    public ChangeColorController(Application app, ColorHandler colorHandler, JLabel currentColorLabel, int color) {
        this.app = app;
        this.colorHandler = colorHandler;
        this.color = color;

        this.currentColorLabel = currentColorLabel;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        currentColorLabel.setBackground(colorHandler.color(color));
        app.setColor(color);
    }
}