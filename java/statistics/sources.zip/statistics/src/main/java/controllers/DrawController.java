package controllers;

import models.Application;
import views.Canvas;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class DrawController implements MouseListener {
    private Application app;
    private Canvas canvas;

    public DrawController(Application app, Canvas canvas) {
        this.app = app;
        this.canvas = canvas;
    }

    @Override
    public void mouseClicked(MouseEvent mouseEvent) {

    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {
        boolean changed = false;

        if (SwingUtilities.isLeftMouseButton(mouseEvent)) {         // Add or remove points to the current image.
            app.addPoint(mouseEvent.getX(), mouseEvent.getY());
            changed = true;

        } else if (SwingUtilities.isRightMouseButton(mouseEvent)) {
            app.removePoint(mouseEvent.getX(), mouseEvent.getY());
            changed = true;
        }

        if (changed) {
            canvas.repaint();
        }
    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {

    }
}
