package controllers;

import models.Application;
import models.ColorHandler;
import views.Canvas;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ImportImageController implements ActionListener {
    private static final String[] EXTENSIONS = new String[] {"jpg", "jpeg", "png"};

    private Application app;
    private ColorHandler colorHandler;
    private Canvas canvas;
    private JFrame screen;

    public ImportImageController(Application app, ColorHandler colorHandler, Canvas canvas, JFrame screen) {
        this.app = app;
        this.colorHandler = colorHandler;
        this.canvas = canvas;
        this.screen = screen;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        JFileChooser chooser = new JFileChooser();

        chooser.setDialogTitle("Import images");
        chooser.setMultiSelectionEnabled(true);

        chooser.setFileFilter(
            new FileNameExtensionFilter("Image files", ImportImageController.EXTENSIONS)
        );

        if (chooser.showOpenDialog(screen) == JFileChooser.APPROVE_OPTION) {
            for (File file : chooser.getSelectedFiles()) {
                try {
                    app.addImage(ImageIO.read(file), colorHandler.numColors());     // Import image and give it to application.

                    Image image = app.currentImage().image();                       // Resize canvas for image adaption.

                    canvas.setPreferredSize(new Dimension(
                        image.getWidth(null), image.getHeight(null)
                    ));

                    canvas.revalidate();
                    canvas.repaint();                                               // Useful only for the first import...
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(
                        screen,
                        "Error while opening file '"
                        + file.getName() + "'... please try again",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        }
    }
}
