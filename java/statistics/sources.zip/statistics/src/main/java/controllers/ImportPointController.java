package controllers;

import models.Application;
import models.ColoredPoint;
import models.ImageModel;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import views.Canvas;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class ImportPointController implements ActionListener {
    private Application app;
    private JFrame screen;
    private Canvas canvas;

    public ImportPointController(Application app, JFrame screen, Canvas canvas) {
        this.app = app;
        this.screen = screen;
        this.canvas = canvas;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        JFileChooser chooser = new JFileChooser();

        chooser.setDialogTitle("Import point location");
        chooser.setFileFilter(new FileNameExtensionFilter("XML files", "xml"));

        if (!app.hasImage()) {
            JOptionPane.showMessageDialog(
                screen,
                "No image",
                "Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        if (chooser.showOpenDialog(screen) == JFileChooser.APPROVE_OPTION) {
            try {                                           // Just an import from and XML file.
                SAXBuilder sax = new SAXBuilder();
                Document doc = sax.build(chooser.getSelectedFile());
                Element root = doc.getRootElement();

                ImageModel image = app.currentImage();
                image.clearPoints();

                for (Element elt : root.getChildren("point")) {
                    image.addPoint(new ColoredPoint(
                        elt.getAttribute("x").getIntValue(),
                        elt.getAttribute("y").getIntValue(),
                        elt.getAttribute("color").getIntValue(),
                        elt.getAttribute("size").getIntValue()
                    ));
                }
            } catch (JDOMException | IOException e) {
                JOptionPane.showMessageDialog(
                    screen,
                    "Error while opening file... please do it again",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
            }

            canvas.repaint();
        }
    }
}
