package controllers;

import models.Application;
import models.ColoredPoint;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class SavePointController implements ActionListener {
    private Application app;
    private JFrame screen;

    public SavePointController(Application app, JFrame screen) {
        this.app = app;
        this.screen = screen;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        JFileChooser chooser = new JFileChooser();

        chooser.setDialogTitle("Save point location");
        chooser.setFileFilter(new FileNameExtensionFilter("XML files", "xml"));

        if (!app.hasImage()) {
            JOptionPane.showMessageDialog(
                screen,
                "No image",
                "Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        if (chooser.showSaveDialog(screen) == JFileChooser.APPROVE_OPTION) {
            SwingUtilities.invokeLater(() -> {      // Start a new thread for performances.
                Document doc = new Document();
                Element root = new Element("root");
                doc.setRootElement(root);

                for (ColoredPoint point : app.currentImage().points()) {    // Point locations are stored in a XML file.
                    Element child = new Element("point");

                    child.setAttribute(new Attribute("x", String.valueOf(point.x())));
                    child.setAttribute(new Attribute("y", String.valueOf(point.y())));
                    child.setAttribute(new Attribute("color", String.valueOf(point.color())));
                    child.setAttribute(new Attribute("size", String.valueOf(point.size())));

                    root.addContent(child);
                }

                XMLOutputter xml = new XMLOutputter();
                xml.setFormat(Format.getPrettyFormat());

                try {
                    FileWriter fw = new FileWriter(chooser.getSelectedFile());
                    fw.write(xml.outputString(doc));
                    fw.close();

                    JOptionPane.showMessageDialog(
                        screen,
                        "Successfully saved",
                        "Saved",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(
                        screen,
                        "Error while saving... please try again",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            });
        }
    }
}
