package controllers;

import models.Application;
import models.ColorHandler;
import models.ImageModel;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class SaveStatsController implements ActionListener {
    private Application app;
    private ColorHandler colorHandler;
    private JFrame screen;

    public SaveStatsController(Application model, ColorHandler handler, JFrame screen) {
        this.app = model;
        this.colorHandler = handler;
        this.screen = screen;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        JFileChooser chooser = new JFileChooser();

        chooser.setDialogTitle("Save stats");

        chooser.setFileFilter(
            new FileNameExtensionFilter("CSV files", "csv")
        );

        if (!app.hasImage()) {
            JOptionPane.showMessageDialog(
                screen,
                "No image",
                "Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        if (chooser.showSaveDialog(screen) == JFileChooser.APPROVE_OPTION) {
            SwingUtilities.invokeLater(() -> {                                  // New thread to avoid UI lags.
                int[] globals = new int[colorHandler.numColors()];
                int superTotal = 0;

                try {
                    FileWriter fw = new FileWriter(chooser.getSelectedFile());
                    fw.write(String.join(",", colorHandler.colorNames()) + "\n");      // Color names as titles.

                    for (ImageModel image : app.images()) {             // Statistics computation (global and local).
                        int[] values = image.counter().values();
                        int total = image.counter().total();

                        ArrayList<String> vals = new ArrayList<>();
                        for (int i = 0; i < values.length; i++) {
                            globals[i] += values[i];
                            vals.add(String.valueOf((double) values[i] / total));
                        }

                        superTotal += total;
                        fw.write(String.join(",", vals) + "\n");        // Each image statistics are written in a line.
                    }

                    ArrayList<String> sums = new ArrayList<>();
                    for (int value : globals) {
                        sums.add(String.valueOf((double) value / superTotal));
                    }

                    fw.write("\n" + String.join(",", sums));            // Global statistics are written at the end.
                    fw.close();

                    JOptionPane.showMessageDialog(
                        screen,
                        "Successfully saved",
                        "Saved",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(
                        screen,
                        "Error while saving... please try again",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            });
        }
    }
}
