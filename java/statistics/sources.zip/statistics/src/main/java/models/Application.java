package models;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Application {
    private List<ImageModel> images = new ArrayList<>();

    private int currentImageIndex = 0;      // Current edited image.
    private int color = 0;                  // Color in use.
    private int size = 10;                  // Point size, never edited in this application (maybe further).

    public ImageModel currentImage() {
        return (currentImageIndex >= 0 && currentImageIndex < images.size())
            ? images.get(currentImageIndex)
            : null;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void addImage(Image image, int counterSize) {
        images.add(new ImageModel(image, counterSize));
    }

    public void addPoint(int x, int y) {
        ImageModel model = currentImage();

        if (model == null) {
            return;
        }

        model.addPoint(new ColoredPoint(x, y, color, size));
    }

    public void removePoint(int x, int y) {
        ImageModel model = currentImage();

        if (model == null) {
            return;
        }

        model.removePointNearTo(x, y);
    }

    public boolean hasImage() {
        return (images.size() > 0);
    }

    public void changeImageIndex(int offset) {
        currentImageIndex += (offset + images.size());
        currentImageIndex %= images.size();
    }

    public List<ImageModel> images() {
        return images;
    }

    public int getNumberImages() {
        return images.size();
    }
}