package models;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ColorHandler {
    private static final Color DEFAULT_COLOR = Color.WHITE;
    private static final String COLOR_FILENAME = "colors.xml";   // Default filename for color definitions.
    private static final String ENTRY_NAME = "color";                   // Tag name for a color.

    private List<NamedColor> colors = new ArrayList<>();

    public ColorHandler(String filename) {
        try {                                                   // Get color definitions from a XML file.
            SAXBuilder sax = new SAXBuilder();
            ClassLoader loader = getClass().getClassLoader();

            Document doc = sax.build(
                new File(loader.getResource(filename).getPath())
            );

            Element root = doc.getRootElement();

            for (Element elt : root.getChildren(ENTRY_NAME)) {
                NamedColor color = new NamedColor(
                    elt.getAttribute("name").getValue(),
                    elt.getAttribute("red").getIntValue(),
                    elt.getAttribute("green").getIntValue(),
                    elt.getAttribute("blue").getIntValue()
                );

                colors.add(color);
            }
        } catch (JDOMException | IOException ignored) {
        }
    }

    public ColorHandler() {
        this(ColorHandler.COLOR_FILENAME);
    }

    public List<NamedColor> colors() {
        return colors;
    }

    public Color color(int index) {
        return (index >= 0 && index < colors.size())
            ? colors.get(index)
            : DEFAULT_COLOR;
    }

    public List<String> colorNames() {
        return colors.stream()
            .map(NamedColor::name)
            .collect(Collectors.toList());
    }

    public int numColors() {
        return colors.size();
    }
}
