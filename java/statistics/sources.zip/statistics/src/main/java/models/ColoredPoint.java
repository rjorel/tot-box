package models;

public class ColoredPoint {
    private int x;
    private int y;
    private int color;
    private int size;

    public ColoredPoint(int x, int y, int color, int size) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.size = size;
    }

    public int x() {
        return x;
    }

    public int y() {
        return y;
    }

    public int color() {
        return color;
    }

    public int size() {
        return this.size;
    }

    public double squaredDistanceTo(int x, int y) {
        return (this.x - x) * (this.x - x)
               + (this.y - y) * (this.y - y);
    }

    public double squaredDistanceTo(ColoredPoint other) {
        return squaredDistanceTo(other.x, other.y);
    }

    public double distanceTo(int x, int y) {
        return Math.sqrt(squaredDistanceTo(x, y));
    }

    public double distanceTo(ColoredPoint other) {
        return distanceTo(other.x, other.y);
    }
}
