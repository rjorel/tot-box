package models;

import java.util.Arrays;

public class Counter {
    private int[] counters = new int[] {};
    private int globalCounter = 0;

    public Counter(int size) {
        counters = new int[size];
    }

    public void reset() {
        Arrays.fill(counters, 0);

        globalCounter = 0;
    }

    public void increment(int index) {
        if (index < 0 || index >= counters.length) {
            return;
        }

        counters[index]++;
        globalCounter++;
    }

    public void decrement(int index) {
        if (index < 0 || index >= counters.length) {
            return;
        }

        counters[index]--;
        globalCounter--;
    }

    public int[] values() {
        return counters;
    }

    public int total() {
        return globalCounter;
    }
}
