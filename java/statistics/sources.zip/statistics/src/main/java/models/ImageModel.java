package models;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ImageModel {
    private List<ColoredPoint> points = new ArrayList<>();
    private Counter counter;                                    // For statistics.
    private Image image;                                        // Associated image.

    private int offsetX = 0;                                    // Scrollbar positions.
    private int offsetY = 0;

    public ImageModel(Image image, int counterSize) {
        this.counter = new Counter(counterSize);
        this.image = image;
    }

    public List<ColoredPoint> points() {
        return points;
    }

    public void addPoint(ColoredPoint point) {
        points.add(point);

        counter.increment(point.color());       // Every point is counted according its color index.
    }

    public void clearPoints() {
        points.clear();
        counter.reset();                        // Reset counter values if points are cleared.
    }

    public void removePointNearTo(int x, int y) {
        if (points.isEmpty()) {
            return;
        }

        ColoredPoint target = points.get(0);
        double minDist = target.distanceTo(x, y);

        for (ColoredPoint point : points) {              // Search the min distance between a point
            double dist = point.distanceTo(x, y);       // in the list and the point (x, y).

            if (dist < minDist) {
                target = point;
                minDist = dist;
            }
        }

        if (minDist < target.size()) {
            points.remove(target);
            counter.decrement(target.color());
        }
    }

    public Image image() {
        return image;
    }

    public Counter counter() {
        return counter;
    }

    public int offsetX() {
        return offsetX;
    }

    public int offsetY() {
        return offsetY;
    }

    public void setOffsetY(int offsetY) {
        this.offsetY = offsetY;
    }

    public void setOffsetX(int offsetX) {
        this.offsetX = offsetX;
    }
}
