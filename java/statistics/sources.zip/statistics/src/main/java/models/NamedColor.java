package models;

import java.awt.*;

public class NamedColor extends Color {
    private String name;

    public NamedColor(String name, int r, int g, int b) {
        super(r, g, b);
        this.name = name;
    }

    public String name() {
        return name;
    }
}
