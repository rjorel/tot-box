package views;

import models.Application;
import models.ColorHandler;
import models.ColoredPoint;

import javax.swing.*;
import java.awt.*;

public class Canvas extends JLabel {
    private Application app;
    private ColorHandler colorHandler;

    public Canvas(Application app, ColorHandler handler) {
        this.app = app;
        this.colorHandler = handler;

        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setBackground(Color.WHITE);
        setOpaque(true);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (!app.hasImage()) {
            return;
        }

        Image image = app.currentImage().image();
        if (image != null) {
            g.drawImage(
                image,
                0, 0,
                image.getWidth(null), image.getHeight(null),
                null
            );
        }

        for (ColoredPoint point : app.currentImage().points()) {
            g.setColor(colorHandler.color(point.color()));

            g.fillOval(
                point.x() - point.size() / 2, point.y() - point.size() / 2,
                point.size(), point.size()
            );
        }
    }
}
