package views;

import javax.swing.*;
import java.awt.*;

public class ColoredButton extends JButton {
    private Color color;

    public ColoredButton(Color color) {
        super();
        this.color = color;

        setBackground(color);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    public Color color() {
        return color;
    }
}
