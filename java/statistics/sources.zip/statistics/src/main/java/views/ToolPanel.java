package views;

import controllers.ChangeColorController;
import models.Application;
import models.ColorHandler;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ToolPanel extends JPanel {
    public static final int COLOR_BUTTON_WIDTH = 4;

    private List<JButton> colorButtons = new ArrayList<>();
    private JLabel currentColorLabel;

    private Application app;
    private ColorHandler colorHandler;

    public ToolPanel(Application app, ColorHandler colorHandler, JLabel currentColorLabel) {
        colorButtons
            .addAll(colorHandler.colors()
            .stream()
            .map(ColoredButton::new)
            .collect(Collectors.toList()));

        this.app = app;
        this.colorHandler = colorHandler;
        this.currentColorLabel = currentColorLabel;

        currentColorLabel.setBackground(colorHandler.color(0));
        initAction();
        initInterface();
    }

    public void initAction() {
        for (int i = 0; i < colorButtons.size(); i++) {
            colorButtons.get(i).addActionListener(
                new ChangeColorController(app, colorHandler, currentColorLabel, i)
            );
        }
    }

    public void initInterface() {
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(2, 2, 2, 2);

        for (int i = 0; i < colorButtons.size(); i++) {
            JButton button = colorButtons.get(i);
            button.setPreferredSize(new Dimension(20, 20));

            constraints.gridx = i % ToolPanel.COLOR_BUTTON_WIDTH;
            constraints.gridy = i / ToolPanel.COLOR_BUTTON_WIDTH;
            add(button, constraints);
        }
    }
}
