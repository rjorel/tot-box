package views;

import controllers.*;
import models.Application;
import models.ColorHandler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class Window {
    private static final int TICK_VALUE = 16;           // Scroll speed.

    private Application app;                            // Application model.
    private ColorHandler colorHandler;                  // Information about colors.
    private Canvas canvas;                              // Image display item.

    private JFrame screen = new JFrame();               // Composition instead of derivation.
    private ToolPanel toolPanel;                        // Panel for colored buttons.
    private JScrollPane scrollPane;                     // Canvas will be placed inside to allow scrolling.
    private JLabel currentColorLabel = new JLabel();    // Color indication for user.

    public Window(Application app, ColorHandler colorHandler) {
        this.app = app;
        this.colorHandler = colorHandler;
        this.canvas = new Canvas(app, colorHandler);
        this.toolPanel = new ToolPanel(app, colorHandler, currentColorLabel);
        this.scrollPane = new JScrollPane(canvas);

        initAction();
        initMenuBar();
        initInterface();
    }

    public void initAction() {
        canvas.addMouseListener(new DrawController(app, canvas));
    }

    public void initMenuBar() {
        // Menu bar creation.
        JMenuBar menuBar = new JMenuBar();

        JMenu file = new JMenu("File");
        JMenuItem importItem = new JMenuItem("Import image(s)");
        JMenuItem saveItem = new JMenuItem("Save as CSV");
        JMenuItem savePointItem = new JMenuItem("Save point location");
        JMenuItem importPointItem = new JMenuItem("Import point location");
        JMenuItem quitItem = new JMenuItem("Quit");

        JMenu navigate = new JMenu("Navigate");
        JMenuItem previousItem = new JMenuItem("Previous image");
        JMenuItem nextItem = new JMenuItem("Next image");

        int ctrl = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();    // Just to avoid multiple calls to the function.

        // File menu items.
        importItem.addActionListener(new ImportImageController(app, colorHandler, canvas, screen));
        saveItem.addActionListener(new SaveStatsController(app, colorHandler, screen));
        savePointItem.addActionListener(new SavePointController(app, screen));
        importPointItem.addActionListener(new ImportPointController(app, screen, canvas));
        quitItem.addActionListener(actionEvent -> System.exit(0));

        importItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ctrl));
        saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ctrl));
        quitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ctrl));

        // Navigate menu items.
        previousItem.addActionListener(new BrowseController(app, canvas, scrollPane, screen, -1));
        nextItem.addActionListener(new BrowseController(app, canvas, scrollPane, screen, 1));

        previousItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0));
        nextItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0));

        file.add(importItem);
        file.add(saveItem);
        file.add(savePointItem);
        file.add(importPointItem);
        file.add(quitItem);

        navigate.add(previousItem);
        navigate.add(nextItem);

        menuBar.add(file);
        menuBar.add(navigate);
        screen.setJMenuBar(menuBar);
    }

    public void initInterface() {
        JPanel
            panel = new JPanel(),
            leftPanel = new JPanel(),
            infoPanel = new JPanel();

        JScrollBar
            vtlScroll = new JScrollBar(),
            htlScroll = new JScrollBar(JScrollBar.HORIZONTAL);

        currentColorLabel.setOpaque(true);
        currentColorLabel.setPreferredSize(new Dimension(50, 50));

        infoPanel.setLayout(new FlowLayout());
        infoPanel.add(currentColorLabel);

        leftPanel.setLayout(new BorderLayout());
        leftPanel.add(toolPanel, BorderLayout.CENTER);
        leftPanel.add(infoPanel, BorderLayout.SOUTH);

        vtlScroll.setUnitIncrement(Window.TICK_VALUE);
        htlScroll.setUnitIncrement(Window.TICK_VALUE);
        scrollPane.setBorder(BorderFactory.createLoweredBevelBorder());
        scrollPane.setVerticalScrollBar(vtlScroll);
        scrollPane.setHorizontalScrollBar(htlScroll);

        panel.setLayout(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(leftPanel, BorderLayout.WEST);

        screen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        screen.setMinimumSize(new Dimension(640, 480));
        screen.setTitle("Image statistics");

        screen.setContentPane(panel);
        screen.setVisible(true);
    }
}
