import geometry.Camera;

import java.applet.Applet;
import java.awt.event.*;


public class CameraController implements MouseListener, MouseMotionListener, MouseWheelListener {
    private Applet applet;
    private Camera camera;

    private int lastX, lastY;

    CameraController(Applet applet, Camera camera) {
        this.applet = applet;
        this.camera = camera;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        //
    }

    @Override
    public void mousePressed(MouseEvent e) {
        lastX = e.getX();
        lastY = e.getY();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        // Adjust angles according to the distance travelled by the mouse since the last event.
        camera.setAzimuth(
            camera.getAzimuth() - (e.getX() - lastX)
        );

        camera.setElevation(
            camera.getElevation() + (e.getY() - lastY)
        );

        // Update our data.
        lastX = e.getX();
        lastY = e.getY();

        applet.repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        //
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        camera.setNearToObj(
            camera.getNearToObj() + e.getWheelRotation()
        );

        applet.repaint();
    }
}
