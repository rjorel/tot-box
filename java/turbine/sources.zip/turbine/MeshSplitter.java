import geometry.Edge;
import geometry.Mesh;
import geometry.Plane;
import geometry.Point;
import maths.ParametricEquation;

import java.util.List;


class MeshSplitter {
    private Mesh mesh;

    public MeshSplitter(Mesh mesh) {
        this.mesh = mesh;
    }

    public Mesh[] slipByPlane(Plane plane) {
        Mesh up = cloneMesh();
        Mesh down = cloneMesh();

        List<Point> vertices = mesh.getVertices();

        for (Edge edge : mesh.getEdges()) {
            Point pointA = vertices.get(edge.a),
                pointB = vertices.get(edge.b);

            float coeffA = getCoefficient(plane, pointA),
                coeffB = getCoefficient(plane, pointB);

            // Coefficients with same sign, according normal vector, indicate that the edge
            // between two points has not to be cut.
            if (coeffA >= 0.0f && coeffB >= 0.0f) {
                up.addEdge(edge.a, edge.b);
            } else if (coeffA < 0.0f && coeffB < 0.0f) {
                down.addEdge(edge.a, edge.b);
            } else {
                // The intersection point is computed with parametric equations.
                Point delta = pointA.diff(pointB);

                float t = -(
                    plane.a * pointA.x
                        + plane.b * pointA.y
                        + plane.c * pointA.z
                        + plane.d
                ) / (
                    plane.a * delta.x
                        + plane.b * delta.y
                        + plane.c * delta.z
                );

                ParametricEquation equation = new ParametricEquation(pointA, delta);

                up.addVertex(equation.at(t));
                down.addVertex(equation.at(t));

                up.addEdge(
                    up.getVertices().size() - 1,
                    (coeffA >= 0.0f) ? edge.a : edge.b
                );

                down.addEdge(
                    down.getVertices().size() - 1,
                    (coeffA < 0.0f) ? edge.a : edge.b
                );
            }
        }

        return new Mesh[] { down, up };
    }

    private Mesh cloneMesh() {
        Mesh clone = new Mesh();

        for (Point vertex : mesh.getVertices()) {
            clone.addVertex(vertex);
        }

        clone.setTransformation(mesh.getTransformation());

        return clone;
    }

    private float getCoefficient(Plane plane, Point point) {
        // Normal plane vector and vector between points and their projections are used to
        // determinate which side are the points from the plane.
        return findCoefficient(
            plane.getNormal(), project(point, plane).diff(point)
        );
    }

    private float findCoefficient(Point u, Point v) {
        if (u.x != 0.0f) {
            return v.x / u.x;
        }

        if (u.y != 0.0f) {
            return v.y / u.y;
        }

        if (u.z != 0.0f) {
            return v.z / u.z;
        }

        return 0.0f;
    }

    private Point project(Point point, Plane plane) {
        float t = -(
            plane.a * point.x
                + plane.b * point.y
                + plane.c * point.z
                + plane.d
        ) / (
            plane.a * plane.a
                + plane.b * plane.b
                + plane.c * plane.c
        );

        return new Point(
            t * plane.a + point.x,
            t * plane.b + point.y,
            t * plane.c + point.z
        );
    }
}
