import geometry.Camera;
import geometry.Point;
import geometry.Viewport;

import java.util.List;


/**
 * From http://www.javakode.com/applets/11-3d/.
 */
public class Rasterizer {
    private Camera camera;
    private Viewport viewport;
    private int scaleFactor;
    private float near;

    public Rasterizer(Camera camera, Viewport viewport, int scaleFactor, float near) {
        this.camera = camera;
        this.viewport = viewport;
        this.scaleFactor = scaleFactor;
        this.near = near;
    }

    public java.awt.Point[] rasterize(List<Point> vertex) {
        java.awt.Point[] points = new java.awt.Point[vertex.size()];

        // Compute coefficients for the projection.
        double theta = Math.PI * camera.getAzimuth() / 180.0;
        double phi = Math.PI * camera.getElevation() / 180.0;

        float cosTheta = (float) Math.cos(theta),
            sinTheta = (float) Math.sin(theta);

        float cosPhi = (float) Math.cos(phi),
            sinPhi = (float) Math.sin(phi);

        float cosThetaCosPhi = cosTheta * cosPhi,
            cosThetaSinPhi = cosTheta * sinPhi,
            sinThetaCosPhi = sinTheta * cosPhi,
            sinThetaSinPhi = sinTheta * sinPhi;

        for (int i = 0; i < vertex.size(); i++) {
            float x0 = vertex.get(i).x;
            float y0 = vertex.get(i).y;
            float z0 = vertex.get(i).z;

            // Compute an orthographic projection.
            float x1 = cosTheta * x0 + sinTheta * z0;
            float y1 = -sinThetaSinPhi * x0 + cosPhi * y0 + cosThetaSinPhi * z0;

            // Now adjust things to get a perspective projection.
            float z1 = cosThetaCosPhi * z0 - sinThetaCosPhi * x0 - sinPhi * y0;
            x1 = x1 * near / (z1 + near + camera.getNearToObj());
            y1 = y1 * near / (z1 + near + camera.getNearToObj());

            // The 0.5 is to round off when converting to int.
            points[i] = new java.awt.Point(
                (int) (viewport.getWidth() / 2 + scaleFactor * x1 + 0.5),
                (int) (viewport.getHeight() / 2 - scaleFactor * y1 + 0.5)
            );
        }

        return points;
    }
}