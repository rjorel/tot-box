import geometry.*;
import maths.Matrix;
import meshs.Turbine;
import meshs.WaterPlane;

import java.applet.Applet;
import java.awt.*;
import java.awt.Point;


public class TurbineApplet extends Applet {
    private Mesh waterPlane = new WaterPlane(),
        turbine = new Turbine();

    private MeshSplitter splitter = new MeshSplitter(turbine);
    private Mesh[] turbineSections;

    private Camera camera = new Camera(30, 30, 1.5f);
    private Viewport viewport;
    private Rasterizer rasterizer;

    private Image backBuffer;

    public void init() {
        float radiusX = getRadianValue("radius_x");
        float radiusY = getRadianValue("radius_y");
        float radiusZ = getRadianValue("radius_z");

        viewport = new Viewport(getSize().width, getSize().height);
        rasterizer = new Rasterizer(camera, viewport, viewport.getWidth() / 2, 3.f);

        backBuffer = createImage(viewport.getWidth(), viewport.getHeight());

        turbine.setTransformation(
            Matrix.makeFromRotation(radiusX, radiusY, radiusZ)
        );

        turbineSections = splitter.slipByPlane(
            new Plane(0, 1, 0, 0)
        );

        initListener();
        repaint();
    }

    private float getRadianValue(String name) {
        try {
            return (float) Math.PI * Float.valueOf(getParameter(name)) / 180;
        } catch (NumberFormatException | NullPointerException e) {
            return 0;
        }
    }

    private void initListener() {
        CameraController controller = new CameraController(this, camera);

        addMouseListener(controller);
        addMouseMotionListener(controller);
        addMouseWheelListener(controller);
    }

    @Override
    public void repaint() {
        drawTurbine(backBuffer.getGraphics());
        super.repaint();
    }

    private void drawTurbine(Graphics g) {
        g.setColor(Color.black);
        g.fillRect(0, 0, viewport.getWidth(), viewport.getHeight());

        drawMesh(g, turbineSections[0], Color.RED);
        drawMesh(g, waterPlane, Color.BLUE);
        drawMesh(g, turbineSections[1], Color.GREEN);
    }

    private void drawMesh(Graphics g, Mesh mesh, Color color) {
        Point[] points = rasterizer.rasterize(mesh.getVertices());

        g.setColor(color);

        for (int i = 0; i < mesh.getEdges().size(); i++) {
            Point a = points[mesh.getEdges().get(i).a],
                b = points[mesh.getEdges().get(i).b];

            g.drawLine(a.x, a.y, b.x, b.y);
        }
    }

    @Override
    public void paint(Graphics g) {
        update(g);
    }

    @Override
    public void update(Graphics g) {
        g.drawImage(backBuffer, 0, 0, this);
    }
}