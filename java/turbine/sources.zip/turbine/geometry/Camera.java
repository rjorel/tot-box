package geometry;

public class Camera {
    private int azimuth, elevation;

    // Distance from near waterPlane to center of object
    private float nearToObj;

    public Camera(int azimuth, int elevation, float nearToObj) {
        this.azimuth = azimuth;
        this.elevation = elevation;
        this.nearToObj = nearToObj;
    }

    public int getAzimuth() {
        return azimuth;
    }

    public void setAzimuth(int azimuth) {
        this.azimuth = azimuth;
    }

    public float getNearToObj() {
        return nearToObj;
    }

    public void setNearToObj(float nearToObj) {
        this.nearToObj = nearToObj;
    }

    public int getElevation() {
        return elevation;
    }

    public void setElevation(int elevation) {
        this.elevation = elevation;
    }
}
