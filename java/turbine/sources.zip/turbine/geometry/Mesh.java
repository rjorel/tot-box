package geometry;

import maths.Matrix;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class Mesh {
    protected ArrayList<Point> vertices = new ArrayList<>();
    protected ArrayList<Edge> edges = new ArrayList<>();

    protected Matrix transformation = Matrix.getIdentity();

    public List<Point> getVertices() {
        return this.getTransformedVertices();
    }

    private List<Point> getTransformedVertices() {
        return vertices.stream().map(
            point -> point.apply(transformation)
        ).collect(Collectors.toList());
    }

    public List<Edge> getEdges() {
        return edges;
    }

    public void addVertex(Point vertex) {
        vertices.add(vertex);
    }

    public void addEdge(int a, int b) {
        edges.add(new Edge(a, b));
    }

    public Matrix getTransformation() {
        return this.transformation;
    }

    public void setTransformation(Matrix transformation) {
        this.transformation = transformation;
    }
}
