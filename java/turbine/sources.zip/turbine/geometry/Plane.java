package geometry;

public class Plane {
    public float a;
    public float b;
    public float c;
    public float d;

    public Plane(float a, float b, float c, float d) {
        if (a == 0.0f && b == 0.0f && c == 0.0f) {
            throw new IllegalArgumentException("At least one coefficient must be not equal to zero");
        }

        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    public Point getNormal() {
        return new Point(a, b, c);
    }
}