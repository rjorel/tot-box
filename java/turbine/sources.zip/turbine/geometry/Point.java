package geometry;

import maths.Matrix;


public class Point {
    public float x;
    public float y;
    public float z;

    public Point(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public Point diff(Point other) {
        return new Point(other.x - x, other.y - y, other.z - z);
    }

    public Point apply(Matrix matrix) {
         return new Point(
            matrix.at(0, 0) * x + matrix.at(0, 1) * y + matrix.at(0, 2) * z,
            matrix.at(1, 0) * x + matrix.at(1, 1) * y + matrix.at(1, 2) * z,
            matrix.at(2, 0) * x + matrix.at(2, 1) * y + matrix.at(2, 2) * z
        );
    }
}