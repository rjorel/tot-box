package geometry;

public class Quad {
    public int a;
    public int b;
    public int c;
    public int d;

    public Quad(int a, int b, int c, int d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
}
