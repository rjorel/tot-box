package maths;

public class Matrix {
    private float[][] values;

    private Matrix(float[][] values) {
        this.values = values;
    }

    public static Matrix getIdentity() {
        return new Matrix(new float[][] {
            { 1, 0, 0 },
            { 0, 1, 0 },
            { 0, 0, 1 }
        });
    }

    public static Matrix makeFromRotation(float radiusX, float radiusY, float radiusZ) {
        float cosX = (float) Math.cos(radiusX),
            cosY = (float) Math.cos(radiusY),
            cosZ = (float) Math.cos(radiusZ);

        float sinX = (float) Math.sin(radiusX),
            sinY = (float) Math.sin(radiusY),
            sinZ = (float) Math.sin(radiusZ);

        // Developed form of consecutive multiplications of rotation matrices along x, y and z-axis.
        return new Matrix(new float[][] {
            {
                cosY * cosZ,
                cosZ * sinX * sinY - cosX * sinZ,
                cosX * cosZ * sinY + sinX * sinZ
            },
            {
                cosY * sinZ,
                cosX * cosZ + sinX * sinY * sinZ,
                -cosZ * sinX + cosX * sinY * sinZ
            },
            {
                -sinY,
                cosY * sinX,
                cosX * cosY
            }
        });
    }

    public float at(int i, int j) {
        return values[i][j];
    }
}
