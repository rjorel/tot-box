package maths;

import geometry.Point;

public class ParametricEquation {
    private Point origin;
    private Point direction;

    public ParametricEquation(Point origin, Point direction) {
        this.origin = origin;
        this.direction = direction;
    }

    public Point at(float t) {
        return new Point(
            direction.x * t + origin.x,
            direction.y * t + origin.y,
            direction.z * t + origin.z
        );
    }
}
