package meshs;

import geometry.Mesh;
import geometry.Point;
import geometry.Quad;
import maths.ParametricEquation;


abstract public class PredefinedMesh extends Mesh {
    private static int NUM_LINES_FOR_QUADS = 20;

    PredefinedMesh() {
        super();

        for (Point vertex : getInitialVertices()) {
            addVertex(vertex);
        }

        for (Quad quad : getInitialQuads()) {
            fillQuad(quad);
        }
    }

    abstract protected Point[] getInitialVertices();

    abstract protected Quad[] getInitialQuads();

    public void fillQuad(Quad quad) {
        Point a = vertices.get(quad.a),
            b = vertices.get(quad.b),
            c = vertices.get(quad.c),
            d = vertices.get(quad.d);

        ParametricEquation ab = new ParametricEquation(a, a.diff(b)),
            ad = new ParametricEquation(a, a.diff(d)),
            bc = new ParametricEquation(b, b.diff(c)),
            dc = new ParametricEquation(d, d.diff(c));

        // Static variable 'NUM_LINES_FOR_QUADS' permits to control the point and edge number that
        // will be added.
        for (int i = 0; i <= NUM_LINES_FOR_QUADS; i++) {
            float t = i * 1.0f / NUM_LINES_FOR_QUADS;

            addVertexFromEquation(ab, t);
            addVertexFromEquation(dc, t);

            addEdgeAccordingAddedVertices();

            addVertexFromEquation(ad, t);
            addVertexFromEquation(bc, t);

            addEdgeAccordingAddedVertices();
        }
    }

    private void addVertexFromEquation(ParametricEquation equation, float t) {
        addVertex(equation.at(t));
    }

    private void addEdgeAccordingAddedVertices() {
        addEdge(vertices.size() - 2, vertices.size() - 1);
    }
}
