package meshs;

import geometry.Point;
import geometry.Quad;


public class Turbine extends PredefinedMesh {
    @Override
    protected Point[] getInitialVertices() {
        return new Point[] {
            // Sea-level plane.
            new Point(-0.3f, 0.0f, 0.3f),       // 0
            new Point(0.0f, 0.0f, 0.7f),        // 1
            new Point(0.3f, 0.0f, 0.3f),        // 2
            new Point(0.3f, 0.0f, -0.3f),       // 3
            new Point(0.0f, 0.0f, -0.7f),       // 4
            new Point(-0.3f, 0.0f, -0.3f),      // 5

            // Higher level plane.
            new Point(-0.3f, 0.1f, 0.3f),       // 6
            new Point(0.0f, 0.1f, 0.7f),        // 7
            new Point(0.3f, 0.1f, 0.3f),        // 8
            new Point(0.3f, 0.1f, -0.3f),       // 9
            new Point(0.0f, 0.1f, -0.7f),       // 10
            new Point(-0.3f, 0.1f, -0.3f),      // 11

            // Lower level plane.
            new Point(-0.3f, -0.18f, 0.3f),     // 12
            new Point(0.0f, -0.18f, 0.7f),      // 13
            new Point(0.3f, -0.18f, 0.3f),      // 14
            new Point(0.3f, -0.18f, -0.3f),     // 15
            new Point(0.0f, -0.18f, -0.7f),     // 16
            new Point(-0.3f, -0.18f, -0.3f),    // 17

            // Mast support
            new Point(-0.3f, 0.1f, 0.07f),      // 18
            new Point(-0.05f, 0.5f, 0.07f),     // 19
            new Point(0.05f, 0.5f, 0.07f),      // 20
            new Point(0.3f, 0.1f, 0.07f),       // 21
            new Point(-0.3f, 0.1f, -0.07f),     // 22
            new Point(-0.05f, 0.5f, -0.07f),    // 23
            new Point(0.05f, 0.5f, -0.07f),     // 24
            new Point(0.3f, 0.1f, -0.07f)       // 25
        };
    }

    @Override
    protected Quad[] getInitialQuads() {
        return new Quad[] {
            new Quad(0, 1, 7, 6),
            new Quad(1, 2, 8, 7),
            new Quad(2, 3, 9, 8),
            new Quad(3, 4, 10, 9),
            new Quad(4, 5, 11, 10),
            new Quad(5, 0, 6, 11),

            new Quad(0, 1, 13, 12),
            new Quad(1, 2, 14, 13),
            new Quad(2, 3, 15, 14),
            new Quad(3, 4, 16, 15),
            new Quad(4, 5, 17, 16),
            new Quad(5, 0, 12, 17),

            new Quad(12, 13, 14, 17),
            new Quad(14, 15, 16, 17),

            new Quad(18, 19, 23, 22),
            new Quad(20, 21, 25, 24),
            new Quad(19, 20, 24, 23)
        };
    }
}