package meshs;

import geometry.Point;
import geometry.Quad;


public class WaterPlane extends PredefinedMesh {
    @Override
    protected Point[] getInitialVertices() {
        return new Point[] {
            new Point(-1.0f, 0.0f, -1.0f),
            new Point(-1.0f, 0.0f, 1.0f),
            new Point(1.0f, 0.0f, 1.0f),
            new Point(1.0f, 0.0f, -1.0f)
        };
    }

    @Override
    protected Quad[] getInitialQuads() {
        return new Quad[] {
            new Quad(0, 1, 2, 3)
        };
    }
}