var body = document.getElementById('body');
var button = document.getElementById("click");
var numPeople = 0;
var numPeopleDead = 0;
var indexPeople;
var img = new Image(), img2;

button.style.position = "absolute";
img.src = "people.png";     // preload.
img.src = "dead.png";
img.src = "monster.png";


function levelup()
{
    indexPeople = 0;
    numPeople += 5;
    body.innerHTML = "";

    for (var i = 0 ; i < numPeople ; i++)
    {
        body.innerHTML += "<img src='people.png' id='people" + i + "' />";
        img = document.getElementById("people" + i);
        img.style.position = "absolute";
        img.style.marginTop = Math.floor(Math.random() * 500) + "px";
        img.style.marginLeft = Math.floor(Math.random() * 1000) + "px";
    }
    
    button.style.marginTop = Math.floor(Math.random() * 500) + "px";
    button.style.marginLeft = Math.floor(Math.random() * 1000) + "px";
}

function end()
{
    alert("Vous avez contamine " + numPeopleDead + " personnes");
    numPeople = 0;
    numPeopleDead = 0;
    setTimeout("end()", 10000);
    levelup();
}


button.onclick = function()
{
    img = document.getElementById("people" + indexPeople);
    indexPeople++;

    if (img != null) {
        img.src = "dead.png";
        body.innerHTML += "<img src='monster.png' id='monster" + indexPeople + "' />";
        img2 = document.getElementById("monster" + indexPeople);
        img2.style.position = "absolute";
        img2.style.marginTop = img.style.marginTop;
        img2.style.marginLeft = img.style.marginLeft;
        numPeopleDead++;
    }
    else levelup();
}


setTimeout("end()", 10000);
levelup();
