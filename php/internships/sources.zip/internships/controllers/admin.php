<?php

/* admin.php
---------------

    Gestion de l'interface administrateur.
        * affiche les pages en fonction des demandes,
        * traite les informations fournies par l'utilisateur.
        * l'administrateur a tous les droits, aucune vérification n'est faite lors des suppressions / modifications.
*/

/** @var Database $db */

if (isset($_GET['add'])) {
    // Ajout de membres et formations.
    if (!empty($_POST['nameFormation'])) {
        $message = '<span style="color: green">Formation bien ajoutée</span>';

        if ($db->formationExists($_POST['nameFormation'])) {
            $message = '<span style="color: red">Cette formation existe déjà</span>';
        } else {
            $db->addFormation($_POST['nameFormation']);
        }
    } elseif (
        !empty($_POST['loginCompany'])
        && !empty($_POST['passwordCompany'])
        && !empty($_POST['nameCompany'])
    ) {
        $message = '<span style="color: green">Entreprise bien ajoutée</span>';

        if ($db->companyExists($_POST['nameCompany'])) {
            $message = '<span style="color: red">Cette entreprise existe déjà</span>';
        } elseif ($db->loginExists($_POST['loginCompany'])) {
            $message = '<span style="color: red">Cet identifiant existe déjà</span>';
        } else {
            $db->addCompany($_POST['loginCompany'], $_POST['passwordCompany'], $_POST['nameCompany']);
        }
    } elseif (
        !empty($_POST['loginTeacher'])
        && !empty($_POST['passwordTeacher'])
        && !empty($_POST['lastNameTeacher'])
        && !empty($_POST['firstNameTeacher'])
        && !empty($_POST['statusTeacher'])
        && isset($_POST['formationTeacher'])
    ) {
        if (empty($_POST['formationTeacher'])) {
            $_POST['formationTeacher'] = null;
        }

        $message = '<span style="color: green">Professeur bien ajouté(e)</span>';

        if ($db->loginExists($_POST['loginTeacher'])) {
            $message = '<span style="color: red">Cet identifiant est déjà utilisé</span>';
        } else {
            $db->addTeacher(
                $_POST['loginTeacher'],
                $_POST['passwordTeacher'],
                $_POST['lastNameTeacher'],
                $_POST['firstNameTeacher'],
                $_POST['statusTeacher'],
                $_POST['formationTeacher']
            );
        }
    } elseif (
        !empty($_POST['loginStudent'])
        && !empty($_POST['passwordStudent'])
        && !empty($_POST['lastNameStudent'])
        && !empty($_POST['firstNameStudent'])
        && !empty($_POST['tutorStudent'])
        && !empty($_POST['formationStudent'])
    ) {
        $message = '<span style="color: green">Etudiant(e) bien ajouté(e)</span>';

        if ($db->loginExists($_POST['loginStudent'])) {
            $message = '<span style="color: red">Cet identifiant est déjà utilisé</span>';
        } else {
            $db->addStudent(
                $_POST['loginStudent'],
                $_POST['passwordStudent'],
                $_POST['lastNameStudent'],
                $_POST['firstNameStudent'],
                $_POST['formationStudent'],
                $_POST['tutorStudent']
            );
        }
    }

    $teachers = $db->getTeachers();
    $tutors = $db->getTeachersTutor();
    $formations = $db->getFormations();

    include __DIR__ . '/../views/add.php';
} elseif (isset($_GET['edit'])) {
    // Modifications de membres.
    if (
        !empty($_POST['student'])
        && !empty($_POST['lastNameStudent'])
        && !empty($_POST['firstNameStudent'])
        && !empty($_POST['tutorStudent'])
        && !empty($_POST['formationStudent'])
    ) {
        $message = '<span style="color: green">Etudiant(e) bien modifié(e)</span>';

        $db->setStudent(
            $_POST['student'],
            $_POST['lastNameStudent'],
            $_POST['firstNameStudent'],
            $_POST['formationStudent'],
            $_POST['tutorStudent']
        );
    } elseif (
        !empty($_POST['teacher'])
        && !empty($_POST['lastNameTeacher'])
        && !empty($_POST['firstNameTeacher'])
        && !empty($_POST['statusTeacher'])
        && isset($_POST['formationTeacher'])
    ) {
        if (empty($_POST['formationTeacher'])) {
            // Si la formation n'est pas précisée on la met à NULL, pour éviter les problèmes de
            // clefs étrangères dans la base de données.
            $_POST['formationTeacher'] = null;
        }

        $teacher = $db->getTeacherByID($_POST['teacher']);
        $message = '<span style="color: green">Professeur bien modifié(e)</span>';

        if (
            ($teacher->status == 'admin')
            && ($_POST['statusTeacher'] == 'teacherTutor')
        ) {
            $message = '<span style="color: red">Impossible de changer le statut d\'un administrateur</span>';
        } else {
            $db->setTeacher(
                $_POST['teacher'],
                $_POST['lastNameTeacher'],
                $_POST['firstNameTeacher'],
                $_POST['statusTeacher'],
                $_POST['formationTeacher']
            );
        }
    } elseif (
        !empty($_POST['company'])
        && !empty($_POST['nameCompany'])
    ) {
        $message = '<span style="color: green">Entreprise bien modifiée</span>';
        if ($db->companyExists($_POST['nameCompany'])) {
            $message = '<span style="color: red">Cette entreprise existe déjà</span>';
        } else {
            $db->setCompany($_POST['company'], $_POST['nameCompany']);
        }
    }

    if (isset($_GET['del'])) {
        // Suppression.
        if (!empty($_GET['student'])) {
            $message = '<span style="color: green">Elève bien supprimé</span>';
            $db->delStudent($_GET['student']);
        } elseif (!empty($_GET['teacher'])) {
            // Les administrateurs ne sont pas supprimables, les professeurs tuteurs ne peuvent être
            // supprimés s'ils ont des élèves sous tutelle.
            $teacher = $db->getTeacherByID($_GET['teacher']);
            $message = '<span style="color: green">Professeur bien supprimé</span>';

            if ($teacher->status == 'admin') {
                $message = '<span style="color: red">Impossible de supprimer un administrateur</span>';
            } elseif ($db->getStudentsSupervised($_GET['teacher'])) {
                $message = '<span style="color: red">Supprimez d\'abord les élèves sous sa tutelle</span>';
            } else {
                $db->delTeacher($_GET['teacher']);
            }
        } elseif (!empty($_GET['company'])) {
            $message = '<span style="color: green">Entreprise et stages rattachés supprimés</span>';
            $db->delCompany($_GET['company']);
        }
    } elseif (isset($_GET['modify'])) {
        // Ou modification des données, pas de vérifications ici.
        if (!empty($_GET['student'])) {
            $student = $db->getStudentByID($_GET['student']);
            $formations = $db->getFormations();
            $tutors = $db->getTeachersTutor();
        } elseif (!empty($_GET['teacher'])) {
            $teacher = $db->getTeacherByID($_GET['teacher']);
            $formations = $db->getFormations();
        } elseif (!empty($_GET['company'])) {
            $company = $db->getCompanyByID($_GET['company']);
        }

        include __DIR__ . '/../views/modify.php';
    }

    $teachers = $db->getTeachers();
    $companies = $db->getCompanies();
    $students = $db->getStudents();

    include __DIR__ . '/../views/edit.php';
} elseif (isset($_GET['list'])) {
    // Listes des entités présentes suivant les demandes (la page se charge de tout).
    include __DIR__ . '/../views/lists.php';
} elseif (isset($_GET['valid'])) {
    // Validation de stages.
    $formations = $db->getFormations();
    $teachers = $db->getTeachers();

    if (!empty($_POST['answer'])) {
        // Si le stage est refusé, alors le reste des informations est inutile.
        if ($_POST['answer'] == 'no') {
            $message = '<span style="color: green">Validé</span>';
            $db->setUnAvailableInternship($_POST['internship']);
        }  // Sinon on vérifie la cohérence des dates (existence + supérieure à la date de fin de stage).
        elseif (
            $_POST['answer'] == 'yes'
            && !empty($_POST['internship'])
            && !empty($_POST['dateEnd'])
            && isset($_POST['day'])
            && isset($_POST['month'])
            && isset($_POST['year'])
            && isset($_POST['hour'])
            && isset($_POST['minute'])
            && !empty($_POST['room'])
        ) {
            if (!checkdate($_POST['month'], $_POST['day'], $_POST['year'])) {
                $message = '<span style="color: red">Date de soutenance invalide</span>';
            } elseif (
                $_POST['dateEnd'] > mktime(0, 0, 0, $_POST['month'], $_POST['day'], $_POST['year'])
            ) {
                $message = '<span style="color: red">La date de soutenance est inférieur à la date de fin</span>';
            } else {
                $message = '<span style="color: green">Validé</span>';

                // Récupération des formations et enseignants via des regex.
                $chosenFormationNames = preg_filter('/^formation=/', '', array_keys($_POST));
                $chosenTeacherIds = preg_filter('/^teacher=/', '', array_keys($_POST));

                if (empty($chosenFormationNames)) {
                    $message = '<span style="color: red">Aucune formation choisie</span>';
                } elseif (empty($chosenTeacherIds)) {
                    $message = '<span style="color: red">Aucun professeur choisi pour la soutenance</span>';
                } else {
                    foreach ($chosenFormationNames as $formationName) {
                        $db->addInternshipToFormation(
                            $_POST['internship'],
                            str_replace('_', ' ', $formationName)
                        );
                    }

                    foreach ($chosenTeacherIds as $teacherID) {
                        $db->addTeacherToInternship($teacherID, $_POST['internship']);
                    }

                    $db->setAvailableInternship(
                        $_POST['day'],
                        $_POST['month'],
                        $_POST['year'],
                        $_POST['hour'],
                        $_POST['minute'],
                        $_POST['room'],
                        $_POST['internship']
                    );
                }
            }
        }
    }

    $internships = $db->getInternshipsNotDecided();
    include __DIR__ . '/../views/valid.php';
} elseif (isset($_GET['grant'])) {
    // Accord des stages aux élèves.
    if (
        !empty($_GET['internship'])
        && !empty($_GET['student'])
        && !empty($_GET['value'])
    ) {
        if ($_GET['value'] == 'yes') {
            $db->setInternshipGrantedToStudent($_GET['internship'], $_GET['student']);
        } elseif ($_GET['value'] == 'no') {
            $db->setInternshipNotGrantedToStudent($_GET['student']);
        }
    }

    $students = $db->getStudentsNotGranted();

    include __DIR__ . '/../views/grant.php';
} else {
    include __DIR__ . '/../views/admin.php';
}
