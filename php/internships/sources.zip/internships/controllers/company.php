<?php

/* company.php
-----------------

    Gestion de l'interface des entreprises.
        * traite les informations fournies par l'utilisateur.
*/

/** @var Database $db */
/** @var object $profile */

// Traitement des ajouts / suppressions de tuteurs et de stages.
if (
    !empty($_POST['internshipName'])
    && !empty($_POST['internshipTutor'])
    && !empty($_POST['dayBegin'])
    && !empty($_POST['monthBegin'])
    && !empty($_POST['yearBegin'])
    && !empty($_POST['dayEnd'])
    && !empty($_POST['monthEnd'])
    && !empty($_POST['yearEnd'])
) {
    $message = '<span style="color: green">Stage bien ajouté</span>';
    if (!checkdate($_POST['monthBegin'], $_POST['dayBegin'], $_POST['yearBegin'])) {
        $message = '<span style="color: red">Date de début invalide</span>';
    } elseif (!checkdate($_POST['monthEnd'], $_POST['dayEnd'], $_POST['yearEnd'])) {
        $message = '<span style="color: red">Date de fin invalide</span>';
    } elseif (
        mktime(0, 0, 0, $_POST['monthBegin'], $_POST['dayBegin'], $_POST['yearBegin'])
        > mktime(0, 0, 0, $_POST['monthEnd'], $_POST['dayEnd'], $_POST['yearEnd'])
    ) {
        $message = '<span style="color: red">La date de fin est inférieure à la date de début</span>';
    } else {
        $db->addInternship(
            $_POST['internshipName'],
            $_POST['internshipTutor'],
            $_SESSION['id'],
            $_POST['dayBegin'],
            $_POST['monthBegin'],
            $_POST['dayEnd'],
            $_POST['yearBegin'],
            $_POST['monthEnd'],
            $_POST['yearEnd']
        );
    }
} elseif (
    !empty($_POST['loginTutor'])
    && !empty($_POST['passwordTutor'])
    && !empty($_POST['lastNameTutor'])
    && !empty($_POST['firstNameTutor'])
) {
    $message = '<span style="color: green">Tuteur bien ajouté(e)</span>';

    if ($db->loginExists($_POST['loginTutor'])) {
        $message = '<span style="color: red">Cet identifiant existe déjà</span>';
    } else {
        $db->addTutor(
            $_POST['loginTutor'],
            $_POST['passwordTutor'],
            $_POST['lastNameTutor'],
            $_POST['firstNameTutor'],
            $_SESSION['id']
        );
    }
} elseif (
    isset($_GET['del'])
    && !empty($_GET['internship'])
) {
    $message = '<span style="color: green">Stage bien supprimé</span>';

    if ($internship = $db->getInternshipByID($_GET['internship'])) {
        // Vérification de l'existence du stage, ainsi que de l'appartenance de celui-ci à l'entreprise.
        if ($internship->companyID != $profile->ID) {
            $message = '<span style="color: red">Ce stage ne vous appartient pas</span>';
        } elseif ($internship->available) {
            $message = '<span style="color: red">Ce stage est validé, impossible de le supprimer</span>';
        } else {
            $db->delInternship($_GET['internship']);
        }
    } else {
        $message = '<span style="color: red">Erreur, ce stage n\'existe pas</span>';
    }
}

$internships = $db->getInternshipsByCompany($_SESSION['id']);
$tutors = $db->getTutorsByCompany($_SESSION['id']);

include __DIR__ . '/../views/company.php';
