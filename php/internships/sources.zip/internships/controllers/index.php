<?php

/* redirect.php
------------------

    Gestion des redirections générales, en fonction du statut des membres.
        * redirige vers des contrôleurs plus spécifiques dans le cas des administrateurs, entreprises et étudiants,
        * se charge de l'interface des tuteurs d'entreprises et enseignants tuteurs,
        * gère également la redirection vers les pages d'informations générales sur une personne, formation, stage ou entreprise.
*/

/** @var Database $db */

$message = ''; // Message affiché en haut de page.

if (isset($_GET['getInfo'])) {
    // Les informations générales sont disponibles pour tout le monde.
    if (!empty($_GET['internship'])) {
        if ($internship = $db->getInternshipByID($_GET['internship'])) {
            $studentInternship = $db->getStudentGrantedInternship($internship->ID);
            $studentsNotGrantedInternship = $db->getStudentsRequestInternship($internship->ID);
            $companyInternship = $db->getCompanyByID($internship->companyID);
            $tutorInternship = $db->getTutorByID($internship->tutorID);
            $teachersJury = $db->getTeachersByInternship($internship->ID);
            $formationsInternship = $db->getFormationsByInternship($internship->ID);
        }
    } elseif (!empty($_GET['teacher'])) {
        if ($teacher = $db->getTeacherByID($_GET['teacher'])) {
            $students = $db->getStudentsSupervised($teacher->ID);
            $formationTeacher = $db->getFormationByName($teacher->formationName);
        }
    } elseif (!empty($_GET['student'])) {
        if ($student = $db->getStudentByID($_GET['student'])) {
            $tutor = $db->getTeacherByID($student->teacherID);
            $internshipStudent = $db->getInternshipByID($student->internshipID);
        }
    } elseif (!empty($_GET['formation'])) {
        if ($formation = $db->getFormationByName($_GET['formation'])) {
            $studentsFormation = $db->getStudentsFromFormation($formation->name);
        }
    } elseif (!empty($_GET['company'])) {
        if ($company = $db->getCompanyByID($_GET['company'])) {
            $internshipsCompany = $db->getInternshipsBYCompany($company->ID);
        }
    }

    include __DIR__ . '/../views/information.php';
} else {
    switch ($_SESSION['status']) {
        // Les actions possibles sont différentes suivant le statut du membre du site.
        case 'admin':
            // L'administrateur a tous les droits.
            if (!($profile = $db->getTeacherByID($_SESSION['id']))) {
                // Vérification de l'existence du profil, sinon on redirige sur la page informant de la suppression du
                // compte. Et on supprime définitivement.
                $db->delMember($_SESSION['login']);
                include __DIR__ . '/../views/account.php';
            } else {
                require __DIR__ . '/../controllers/admin.php';
            }
            break;

        case 'teacherTutor':
            // Les enseignants tuteurs ne peuvent rien faire, à part regarder ses élèves sous tutelle.
            if (!($profile = $db->getTeacherByID($_SESSION['id']))) {
                $db->delMember($_SESSION['login']);
                include __DIR__ . '/../views/account.php';
            } else {
                $students = $db->getStudentsSupervised($_SESSION['id']);
                include __DIR__ . '/../views/teacherTutor.php';
            }
            break;

        case 'company':
            // Les entreprises peuvent déclarer stages et tuteurs.
            if (!($profile = $db->getCompanyByID($_SESSION['id']))) {
                $db->delMember($_SESSION['login']);
                include __DIR__ . '/../views/account.php';
            } else {
                require __DIR__ . '/../controllers/company.php';
            }
            break;

        case 'tutor':
            // Les tuteurs d'entreprises peuvent juste dire s'ils vont venir aux soutenancesde stages.
            if (!($profile = $db->getTutorByID($_SESSION['id']))) {
                $db->delMember($_SESSION['login']);
                include __DIR__ . '/../views/account.php';
            } else {
                $company = $db->getCompanyByID($profile->companyID);

                if (
                    !empty($_GET['internship'])
                    && !empty($_GET['value'])
                ) {
                    if ($internship = $db->getInternshipByID($_GET['internship'])) {
                        // Vérification de l'existence du stage ainsi que l'affectation du tuteur à celui-ci.
                        $message = '<span style="color: green">Réponse prise en compte</span>';

                        if ($internship->tutorID != $profile->ID) {
                            $message = '<span style="color: red">Vous n\'êtes pas le tuteur de ce stage</span>';
                        } elseif ($_GET['value'] == 'yes') {
                            $db->setTutorAssist(1, $_GET['internship']);
                        } elseif ($_GET['value'] == 'no') {
                            $db->setTutorAssist(0, $_GET['internship']);
                        }
                    } else {
                        $message = '<span style="color: red">Ce stage n\'existe pas </span>';
                    }
                }

                $internships = $db->getInternshipsByTutor($_SESSION['id']);
                include __DIR__ . '/../views/tutor.php';
            }
            break;

        case 'student':
            // Les étudiants choisissent des stages validés.
            if (!($profile = $db->getStudentByID($_SESSION['id']))) {
                $db->delMember($_SESSION['login']);
                include __DIR__ . '/../views/account.php';
            } else {
                require __DIR__ . '/../controllers/student.php';
            }
            break;

        default:
            break;
    }
}