<?php

/* student.php
-----------------

    Gestion de l'interface des étudiants.
        * traite les informations fournies par l'utilisateur.
*/

/** @var Database $db */
/** @var object $profile */

$teacherTutor = $db->getTeacherByID($profile->teacherID);

if (
    isset($_GET['request'])
    && !empty($_GET['internship'])
) {
    if ($internship = $db->getInternshipByID($_GET['internship'])) {
        // Vérification de l'existence du stage.
        if ($db->internshipAlreadyGranted($internship->ID)) {
            // On regarde si le stage n'est pas déjà accordé à quelqu'un.
            $message = '<span style="color: red">Ce stage est déjà attribué</span>';
        } elseif ($internship->available != 1) {
            // Ou s'il est valide.
            $message = '<span style="color: red">Ce stage n\'a pas encore été validé</span>';
        } else {
            if (is_null($profile->internshipID)) {
                // Si l'étudiant n'a pas déjà postulé pour un stage, on enregistre sa demande.
                $message = '<span style="color: green">Demande bien prise en compte</span>';
                $db->setInternshipToStudent($_GET['internship'], $_SESSION['id']);
                $profile = $db->getStudentByID($_SESSION['id']);
            } else {
                $message = '<span style="color: red">Vous avez déjà fait une demande de stage</span>';
            }
        }
    } else {
        $message = '<span style="color: red">Erreur, ce stage n\'existe pas</span>';
    }
} elseif (!is_null($profile->internshipGranted)) {
    // Si une demande a été refusé, on le fait savoir à la connexion.
    if ($profile->internshipGranted == 0) {
        $message = '<span style="color: red">Votre demande de stage a été refusé</span>';
        $db->annulInternshipToStudent($profile->ID);
    }
}

$internshipRequest = $db->getInternshipByID($profile->internshipID);
$internships = $db->getInternshipsNotGranted();

include __DIR__ . '/../views/student.php';
