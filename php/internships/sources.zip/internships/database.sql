-- MySQL dump 10.13  Distrib 5.7.32, for Linux (x86_64)
--
-- Host: localhost    Database: homestead
-- ------------------------------------------------------
-- Server version	5.7.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS = @@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION = @@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE = @@TIME_ZONE */;
/*!40103 SET TIME_ZONE = '+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS = @@UNIQUE_CHECKS, UNIQUE_CHECKS = 0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0 */;
/*!40101 SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES = @@SQL_NOTES, SQL_NOTES = 0 */;

--
-- Table structure for table `Companies`
--

DROP TABLE IF EXISTS `Companies`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Companies`
(
    `ID`   int(11)                       NOT NULL AUTO_INCREMENT,
    `name` varchar(255) COLLATE utf8_bin NOT NULL,
    PRIMARY KEY (`ID`, `name`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 4
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Companies`
--

LOCK TABLES `Companies` WRITE;
/*!40000 ALTER TABLE `Companies`
    DISABLE KEYS */;
INSERT INTO `Companies` (`ID`, `name`)
VALUES (1, 'Entreprise 1'),
       (2, 'Entreprise 2'),
       (3, 'Entreprise 3');
/*!40000 ALTER TABLE `Companies`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Formations`
--

DROP TABLE IF EXISTS `Formations`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Formations`
(
    `name` varchar(255) COLLATE utf8_bin NOT NULL,
    PRIMARY KEY (`name`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Formations`
--

LOCK TABLES `Formations` WRITE;
/*!40000 ALTER TABLE `Formations`
    DISABLE KEYS */;
INSERT INTO `Formations` (`name`)
VALUES ('Formation 1'),
       ('Formation 2');
/*!40000 ALTER TABLE `Formations`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Internships`
--

DROP TABLE IF EXISTS `Internships`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Internships`
(
    `ID`          int(11)                       NOT NULL AUTO_INCREMENT,
    `name`        varchar(255) COLLATE utf8_bin NOT NULL,
    `tutorAssist` tinyint(4)                    DEFAULT NULL,
    `available`   tinyint(4)                    DEFAULT NULL,
    `dateBegin`   date                          NOT NULL,
    `dateEnd`     date                          NOT NULL,
    `dateTest`    datetime                      DEFAULT NULL,
    `roomTest`    varchar(255) COLLATE utf8_bin DEFAULT NULL,
    `companyID`   int(11)                       NOT NULL,
    `tutorID`     int(11)                       NOT NULL,
    PRIMARY KEY (`ID`),
    KEY `companyID` (`companyID`),
    KEY `tutorID` (`tutorID`),
    CONSTRAINT `Internships_ibfk_1` FOREIGN KEY (`companyID`) REFERENCES `Companies` (`ID`),
    CONSTRAINT `Internships_ibfk_2` FOREIGN KEY (`tutorID`) REFERENCES `Tutors` (`ID`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 5
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Internships`
--

LOCK TABLES `Internships` WRITE;
/*!40000 ALTER TABLE `Internships`
    DISABLE KEYS */;
INSERT INTO `Internships` (`ID`, `name`, `tutorAssist`, `available`, `dateBegin`, `dateEnd`, `dateTest`, `roomTest`,
                           `companyID`, `tutorID`)
VALUES (1, 'Stage 1', 1, 1, '2014-01-01', '2014-01-05', '2014-01-07 00:00:00', 'Salle 1', 1, 1),
       (2, 'Stage 2', 0, 1, '2014-01-01', '2014-01-06', '2014-01-13 00:00:00', 'Salle 2', 1, 1),
       (3, 'Stage 3', 1, 1, '2014-01-01', '2015-01-01', '2015-02-01 00:00:00', 'Salle 2', 1, 1),
       (4, 'Stage 4', 0, 1, '2014-01-01', '2014-01-05', '2014-01-19 00:00:00', 'Salle 1', 3, 2);
/*!40000 ALTER TABLE `Internships`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InternshipsToFormations`
--

DROP TABLE IF EXISTS `InternshipsToFormations`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `InternshipsToFormations`
(
    `internshipID`  int(11)                       NOT NULL,
    `formationName` varchar(255) COLLATE utf8_bin NOT NULL,
    PRIMARY KEY (`internshipID`, `formationName`),
    KEY `formationName` (`formationName`),
    CONSTRAINT `InternshipsToFormations_ibfk_1` FOREIGN KEY (`internshipID`) REFERENCES `Internships` (`ID`),
    CONSTRAINT `InternshipsToFormations_ibfk_2` FOREIGN KEY (`formationName`) REFERENCES `Formations` (`name`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InternshipsToFormations`
--

LOCK TABLES `InternshipsToFormations` WRITE;
/*!40000 ALTER TABLE `InternshipsToFormations`
    DISABLE KEYS */;
INSERT INTO `InternshipsToFormations` (`internshipID`, `formationName`)
VALUES (1, 'Formation 1'),
       (2, 'Formation 1'),
       (3, 'Formation 2'),
       (4, 'Formation 1');
/*!40000 ALTER TABLE `InternshipsToFormations`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Members`
--

DROP TABLE IF EXISTS `Members`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Members`
(
    `login`    varchar(255) COLLATE utf8_bin NOT NULL,
    `password` varchar(255) COLLATE utf8_bin NOT NULL,
    `status`   varchar(255) COLLATE utf8_bin NOT NULL,
    `memberID` int(11)                       NOT NULL,
    PRIMARY KEY (`login`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Members`
--

LOCK TABLES `Members` WRITE;
/*!40000 ALTER TABLE `Members`
    DISABLE KEYS */;
INSERT INTO `Members` (`login`, `password`, `status`, `memberID`)
VALUES ('admin', SHA1('admin'), 'admin', 1),
       ('user01', SHA('password'), 'admin', 2),
       ('user02', SHA('password'), 'company', 1),
       ('user03', SHA('password'), 'company', 2),
       ('user04', SHA('password'), 'company', 3),
       ('user05', SHA('password'), 'tutor', 1),
       ('user06', SHA('password'), 'tutor', 2),
       ('user07', SHA('password'), 'student', 3),
       ('user08', SHA('password'), 'student', 4),
       ('user09', SHA('password'), 'student', 5),
       ('user10', SHA('password'), 'student', 6),
       ('user11', SHA('password'), 'teacherTutor', 5),
       ('user12', SHA('password'), 'teacherTutor', 6);
/*!40000 ALTER TABLE `Members`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Students`
--

DROP TABLE IF EXISTS `Students`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Students`
(
    `ID`                int(11)                       NOT NULL AUTO_INCREMENT,
    `lastName`          varchar(255) COLLATE utf8_bin NOT NULL,
    `firstName`         varchar(255) COLLATE utf8_bin NOT NULL,
    `formationName`     varchar(255) COLLATE utf8_bin NOT NULL,
    `teacherID`         int(11)                       NOT NULL,
    `internshipID`      int(11)    DEFAULT NULL,
    `internshipGranted` tinyint(4) DEFAULT NULL,
    PRIMARY KEY (`ID`),
    KEY `teacherID` (`teacherID`),
    KEY `internshipID` (`internshipID`),
    CONSTRAINT `Students_ibfk_1` FOREIGN KEY (`teacherID`) REFERENCES `Teachers` (`ID`),
    CONSTRAINT `Students_ibfk_2` FOREIGN KEY (`internshipID`) REFERENCES `Internships` (`ID`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 7
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Students`
--

LOCK TABLES `Students` WRITE;
/*!40000 ALTER TABLE `Students`
    DISABLE KEYS */;
INSERT INTO `Students` (`ID`, `lastName`, `firstName`, `formationName`, `teacherID`, `internshipID`,
                        `internshipGranted`)
VALUES (3, 'Étudiant', '1', 'Formation 2', 5, 1, 1),
       (4, 'Étudiant', '2', 'Formation 1', 6, 4, 1),
       (5, 'Étudiant', '3', 'Formation 1', 5, NULL, NULL),
       (6, 'Étudiant', '4', 'Formation 1', 5, 2, 0);
/*!40000 ALTER TABLE `Students`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Teachers`
--

DROP TABLE IF EXISTS `Teachers`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Teachers`
(
    `ID`            int(11)                       NOT NULL AUTO_INCREMENT,
    `lastName`      varchar(255) COLLATE utf8_bin NOT NULL,
    `firstName`     varchar(255) COLLATE utf8_bin NOT NULL,
    `status`        varchar(255) COLLATE utf8_bin NOT NULL,
    `formationName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
    PRIMARY KEY (`ID`),
    KEY `formationName` (`formationName`),
    CONSTRAINT `Teachers_ibfk_1` FOREIGN KEY (`formationName`) REFERENCES `Formations` (`name`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 7
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Teachers`
--

LOCK TABLES `Teachers` WRITE;
/*!40000 ALTER TABLE `Teachers`
    DISABLE KEYS */;
INSERT INTO `Teachers` (`ID`, `lastName`, `firstName`, `status`, `formationName`)
VALUES (1, 'Professeur', '1', 'admin', NULL),
       (5, 'Professeur', '2', 'teacherTutor', NULL),
       (6, 'Professeur', '3', 'teacherTutor', NULL);
/*!40000 ALTER TABLE `Teachers`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TeachersToInternships`
--

DROP TABLE IF EXISTS `TeachersToInternships`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TeachersToInternships`
(
    `teacherID`    int(11) NOT NULL,
    `internshipID` int(11) NOT NULL,
    PRIMARY KEY (`teacherID`, `internshipID`),
    KEY `internshipID` (`internshipID`),
    CONSTRAINT `TeachersToInternships_ibfk_1` FOREIGN KEY (`teacherID`) REFERENCES `Teachers` (`ID`),
    CONSTRAINT `TeachersToInternships_ibfk_2` FOREIGN KEY (`internshipID`) REFERENCES `Internships` (`ID`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TeachersToInternships`
--

LOCK TABLES `TeachersToInternships` WRITE;
/*!40000 ALTER TABLE `TeachersToInternships`
    DISABLE KEYS */;
INSERT INTO `TeachersToInternships` (`teacherID`, `internshipID`)
VALUES (1, 2),
       (5, 4);
/*!40000 ALTER TABLE `TeachersToInternships`
    ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tutors`
--

DROP TABLE IF EXISTS `Tutors`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tutors`
(
    `ID`        int(11)                       NOT NULL AUTO_INCREMENT,
    `lastName`  varchar(255) COLLATE utf8_bin NOT NULL,
    `firstName` varchar(255) COLLATE utf8_bin NOT NULL,
    `companyID` int(11)                       NOT NULL,
    PRIMARY KEY (`ID`),
    KEY `companyID` (`companyID`),
    CONSTRAINT `Tutors_ibfk_1` FOREIGN KEY (`companyID`) REFERENCES `Companies` (`ID`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 3
  DEFAULT CHARSET = utf8
  COLLATE = utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tutors`
--

LOCK TABLES `Tutors` WRITE;
/*!40000 ALTER TABLE `Tutors`
    DISABLE KEYS */;
INSERT INTO `Tutors` (`ID`, `lastName`, `firstName`, `companyID`)
VALUES (1, 'Tuteur', '1', 1),
       (2, 'Tuteur', '2', 3);
/*!40000 ALTER TABLE `Tutors`
    ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE = @OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE = @OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS = @OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS = @OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION = @OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES = @OLD_SQL_NOTES */;

-- Dump completed on 2014-01-08 23:04:39
-- Updated on 2020-12-12 16:45:53