<?php

require_once __DIR__ . '/lib/Database.php';

$db = new Database(
    getenv('DB_HOST'),
    getenv('DB_USERNAME'),
    getenv('DB_PASSWORD'),
    getenv('DB_DATABASE')
);

session_start();

if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
}

if (
    !empty($_SESSION['login'])
    && !empty($_SESSION['password'])
    && !empty($_SESSION['status'])
    && !empty($_SESSION['id'])
) {
    require __DIR__ . '/controllers/index.php';
} elseif (
    !empty($_POST['login'])
    && !empty($_POST['password'])
) {
    $profile = $db->getMember($_POST['login'], $_POST['password']);

    if (empty($profile)) {
        $message = 'Mauvais identifiants !';
        include __DIR__ . '/views/connect.php';
    } else {
        $_SESSION['login'] = $profile->login;
        $_SESSION['password'] = $profile->password;
        $_SESSION['status'] = $profile->status;
        $_SESSION['id'] = $profile->memberID;

        // Redirection vers la page d'accueil.
        header('Location:index.php');
    }
} else {
    $message = 'Identifiez-vous !';
    include __DIR__ . '/views/connect.php';
}
