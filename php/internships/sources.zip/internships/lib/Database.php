<?php

/* Database.class.php
------------------------

    Classe permettant la connexion avec MySQL.
        * encodage de caractère UTF-8,
        * requête permettant :
            - la sélection (avec ou sans critères),
            - l'insertion,
            - la modification,
            - la suppression,
            - le test d'existence.
*/

class Database
{
    private $pdo;

    public function __construct($host, $username, $password, $database)
    {
        try {
            $this->pdo = new PDO("mysql:host={$host};dbname={$database}", $username, $password);
        } catch (Exception $e) {
            die('Error : ' . $e->getMessage());
        }

        $this->pdo->exec("SET CHARACTER SET UTF8");
    }

    public function getMember($login, $password)
    {
        $req = $this->pdo->prepare("SELECT * FROM Members WHERE login = ? AND password = SHA1(?)");
        $req->execute([$login, $password]);

        return $this->fetch($req);
    }

    public function fetch($req)
    {
        $data = $req->fetch(PDO::FETCH_OBJ);
        $req->closeCursor();

        return $data;
    }

    public function getTeachersTutor()
    {
        return $this->fetchAll($this->pdo->query("SELECT * FROM Teachers WHERE status = 'teacherTutor'"));
    }

    public function fetchAll($req)
    {
        $data = $req->fetchall(PDO::FETCH_OBJ);
        $req->closeCursor();

        return $data;
    }

    public function getTeachers()
    {
        return $this->fetchAll($this->pdo->query("SELECT * FROM Teachers"));
    }

    public function getInternships()
    {
        return $this->fetchAll($this->pdo->query("SELECT * FROM Internships"));
    }

    public function getStudents()
    {
        return $this->fetchAll($this->pdo->query("SELECT * FROM Students"));
    }

    public function getCompanies()
    {
        return $this->fetchAll($this->pdo->query("SELECT * FROM Companies"));
    }

    public function getFormations()
    {
        return $this->fetchAll($this->pdo->query("SELECT * FROM Formations"));
    }

    public function getTeacherByID($teacherID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Teachers WHERE ID = ?");
        $req->execute([$teacherID]);

        return $this->fetch($req);
    }

    public function getTeachersByInternship($internshipID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Teachers WHERE ID IN (SELECT teacherID FROM TeachersToInternships WHERE internshipID = ?)");
        $req->execute([$internshipID]);

        return $this->fetchAll($req);
    }

    public function getCompanyByID($companyID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Companies WHERE ID = ?");
        $req->execute([$companyID]);

        return $this->fetch($req);
    }

    public function getTutorByID($tutorID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Tutors WHERE ID = ?");
        $req->execute([$tutorID]);

        return $this->fetch($req);
    }

    public function getTutorsByCompany($companyID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Tutors WHERE companyID = ?");
        $req->execute([$companyID]);

        return $this->fetchAll($req);
    }

    public function getFormationByName($formationName)
    {
        $req = $this->pdo->prepare("SELECT * FROM Formations WHERE name = ?");
        $req->execute([$formationName]);

        return $this->fetch($req);
    }

    public function getFormationsByInternship($internshipID)
    {
        $req = $this->pdo->prepare("SELECT formationName as name FROM InternshipsToFormations WHERE internshipID = ?");
        $req->execute([$internshipID]);

        return $this->fetchAll($req);
    }

    public function getStudentByID($studentID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Students WHERE ID = ?");
        $req->execute([$studentID]);

        return $this->fetch($req);
    }

    public function getStudentGrantedInternship($internshipID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Students WHERE internshipID = ? AND internshipGranted = 1");
        $req->execute([$internshipID]);

        return $this->fetch($req);
    }

    public function getStudentsNotGranted()
    {
        return $this->fetchAll($this->pdo->query("SELECT * FROM Students WHERE internshipID IS NOT NULL AND internshipGranted IS NULL"));
    }

    public function getStudentsFromFormation($formationName)
    {
        $req = $this->pdo->prepare("SELECT * FROM Students WHERE formationName = ?");
        $req->execute([$formationName]);

        return $this->fetchAll($req);
    }

    public function getStudentsSupervised($tutorID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Students WHERE teacherID = ?");
        $req->execute([$tutorID]);

        return $this->fetchAll($req);
    }

    public function getStudentsRequestInternship($internshipID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Students WHERE internshipID = ? AND internshipGranted IS NULL");
        $req->execute([$internshipID]);

        return $this->fetchAll($req);
    }

    public function getInternshipsNotDecided()
    {
        return $this->fetchAll(
            $this->pdo->query("SELECT ID, name, UNIX_TIMESTAMP(dateEnd) as dateEnd FROM Internships WHERE available IS NULL")
        );
    }

    public function getInternshipsNotGranted()
    {
        return $this->fetchAll(
            $this->pdo->query("SELECT * FROM Internships WHERE available = 1 AND ID NOT IN (SELECT internshipID FROM Students WHERE internshipGranted = 1)")
        );
    }

    public function getInternshipsByCompany($companyID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Internships WHERE companyID = ?");
        $req->execute([$companyID]);

        return $this->fetchAll($req);
    }

    public function getInternshipByID($internshipID)
    {
        $req = $this->pdo->prepare("SELECT ID, name, tutorAssist, available, roomTest, companyID, tutorID, DATE_FORMAT(dateBegin, '%d/%m/%Y') as dateBegin, DATE_FORMAT(dateEnd, '%d/%m/%Y') as dateEnd, DATE_FORMAT(dateTest, 'le %d/%m/%Y à %Hh%i') as dateTest FROM Internships WHERE ID = ?");
        $req->execute([$internshipID]);

        return $this->fetch($req);
    }

    public function getInternshipsByTutor($tutorID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Internships WHERE tutorID = ?");
        $req->execute([$tutorID]);

        return $this->fetchAll($req);
    }

    public function addTeacher($login, $password, $lastName, $firstName, $status, $formationName)
    {
        $this->execute(
            "INSERT INTO Teachers(lastName, firstName, status, formationName) VALUES (?, ?, ?, ?)",
            [$lastName, $firstName, $status, $formationName]
        );

        $this->addMember($login, $password, $status, $this->pdo->lastInsertId());
    }

    public function execute($query, $array)
    {
        $req = $this->pdo->prepare($query);
        $req->execute($array);
        $req->closeCursor();
    }

    public function addMember($login, $password, $status, $memberID)
    {
        $this->execute(
            "INSERT INTO Members(login, password, status, memberID) VALUES (?, SHA1(?), ?, ?)",
            [$login, $password, $status, $memberID]
        );
    }

    public function addTeacherToInternship($teacherID, $internshipID)
    {
        $this->execute(
            "INSERT INTO TeachersToInternships(teacherID, internshipID) VALUES (?, ?)",
            [$teacherID, $internshipID]
        );
    }

    public function addCompany($login, $password, $name)
    {
        $this->execute("INSERT INTO Companies(name) VALUES (?)", [$name]);
        $this->addMember($login, $password, 'company', $this->pdo->lastInsertId());
    }

    public function addTutor($login, $password, $lastName, $firstName, $companyID)
    {
        $this->execute(
            "INSERT INTO Tutors(lastName, firstName, companyID) VALUES (?, ?, ?)",
            [$lastName, $firstName, $companyID]
        );

        $this->addMember($login, $password, 'tutor', $this->pdo->lastInsertId());
    }

    public function addFormation($name)
    {
        $this->execute("INSERT INTO Formations VALUES(?)", [$name]);
    }

    public function addStudent($login, $password, $lastName, $firstName, $formationName, $teacherID)
    {
        $this->execute(
            "INSERT INTO Students(lastName, firstName, formationName, teacherID) VALUES (?, ?, ?, ?)",
            [$lastName, $firstName, $formationName, $teacherID]
        );

        $this->addMember($login, $password, 'student', $this->pdo->lastInsertId());
    }

    public function addInternship(
        $name,
        $tutorID,
        $companyID,
        $dayBegin,
        $monthBegin,
        $yearBegin,
        $dayEnd,
        $monthEnd,
        $yearEnd
    ) {
        $this->execute("INSERT INTO Internships(name, companyID, tutorID, dateBegin, dateEnd) VALUES(?, ?, ?, ?, ?)", [
            $name,
            $companyID,
            $tutorID,
            $yearBegin . '-' . $monthBegin . '-' . $dayBegin,
            $yearEnd . '-' . $monthEnd . '-' . $dayEnd
        ]);
    }

    public function addInternshipToFormation($internshipID, $formationName)
    {
        $this->execute(
            "INSERT INTO InternshipsToFormations(internshipID, formationName) VALUES (?, ?)",
            [$internshipID, $formationName]
        );
    }

    public function delMember($login)
    {
        $this->execute("DELETE FROM Members WHERE login = ?", [$login]);
    }

    public function delStudent($studentID)
    {
        $this->execute("DELETE FROM Students WHERE ID = ?", [$studentID]);
    }

    public function delTeacher($teacherID)
    {
        $this->execute("DELETE FROM TeachersToInternships WHERE teacherID = ?", [$teacherID]);
        $this->execute("DELETE FROM Teachers WHERE ID = ?", [$teacherID]);
    }

    public function delCompany($companyID)
    {
        $this->execute(
            "UPDATE Students SET internshipID = NULL, internshipGranted = NULL WHERE internshipID IN (SELECT ID FROM Internships WHERE companyID = ?)",
            [$companyID]
        );

        $this->execute(
            "DELETE FROM TeachersToInternships WHERE internshipID IN (SELECT ID FROM Internships WHERE companyID = ?)",
            [$companyID]
        );

        $this->execute(
            "DELETE FROM InternshipsToFormations WHERE internshipID IN (SELECT ID FROM Internships WHERE companyID = ?)",
            [$companyID]
        );

        $this->execute("DELETE FROM Internships WHERE companyID = ?", [$companyID]);
        $this->execute("DELETE FROM Tutors WHERE companyID = ?", [$companyID]);
        $this->execute("DELETE FROM Companies WHERE ID = ?", [$companyID]);
    }

    public function delInternship($internshipID)
    {
        $this->execute("DELETE FROM TeachersToInternships WHERE internshipID = ?", [$internshipID]);
        $this->execute("DELETE FROM InternshipsToFormations WHERE internshipID = ?", [$internshipID]);
        $this->execute("DELETE FROM Internships WHERE ID = ?", [$internshipID]);
    }

    public function setTutorAssist($answer, $internshipsID)
    {
        $this->execute("UPDATE Internships SET tutorAssist = ? WHERE ID = ?", [$answer, $internshipsID]);
    }

    public function setInternshipToStudent($internshipID, $studentID)
    {
        $this->execute("UPDATE Students SET internshipID = ? WHERE ID = ?", [$internshipID, $studentID]);
    }

    public function setUnAvailableInternship($internshipID)
    {
        $this->execute("UPDATE Internships SET available = 0 WHERE ID = ?", [$internshipID]);
    }

    public function setAvailableInternship($day, $month, $year, $hour, $minute, $room, $internshipID)
    {
        $this->execute("UPDATE Internships SET available = 1, dateTest = ?, roomTest = ? WHERE ID = ?",
            [$year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute, $room, $internshipID]);
    }

    public function setInternshipGrantedToStudent($internshipID, $studentID)
    {
        $this->execute("UPDATE Students SET internshipGranted = 1 WHERE ID = ?", [$studentID]);

        $this->execute(
            "UPDATE Students SET internshipID = NULL, internshipGranted = 0 WHERE ID != ? AND internshipID = ?",
            [$studentID, $internshipID]
        );
    }

    public function setInternshipNotGrantedToStudent($studentID)
    {
        $this->execute("UPDATE Students SET internshipID = NULL, internshipGranted = 0 WHERE ID = ?", [$studentID]);
    }

    public function annulInternshipToStudent($studentID)
    {
        $this->execute("UPDATE Students SET internshipGranted = NULL WHERE ID = ?", [$studentID]);
    }

    public function setStudent($studentID, $lastName, $firstName, $formationName, $teacherID)
    {
        $this->execute(
            "UPDATE Students SET lastName = ?, firstName = ?, formationName = ?, teacherID = ? WHERE ID = ?",
            [$lastName, $firstName, $formationName, $teacherID, $studentID]
        );
    }

    public function setTeacher($teacherID, $lastName, $firstName, $status, $formationName)
    {
        $this->execute(
            "UPDATE Teachers SET lastName = ?, firstName = ?, status = ?, formationName = ? WHERE ID = ?",
            [$lastName, $firstName, $status, $formationName, $teacherID]
        );
    }

    public function setCompany($companyID, $name)
    {
        $this->execute("UPDATE Companies SET name = ? WHERE ID = ?", [$name, $companyID]);
    }

    public function companyExists($name)
    {
        $req = $this->pdo->prepare("SELECT * FROM Companies WHERE name = ?");
        $req->execute([$name]);
        $data = $this->fetch($req);

        return (!empty($data));
    }

    public function formationExists($name)
    {
        $req = $this->pdo->prepare("SELECT * FROM Formations WHERE name = ?");
        $req->execute([$name]);
        $data = $this->fetch($req);

        return (!empty($data));
    }

    public function loginExists($login)
    {
        $req = $this->pdo->prepare("SELECT * FROM Members WHERE login = ?");
        $req->execute([$login]);
        $data = $this->fetch($req);

        return (!empty($data));
    }

    public function internshipAlreadyGranted($internshipID)
    {
        $req = $this->pdo->prepare("SELECT * FROM Students WHERE internshipID = ? AND internshipGranted = 1");
        $req->execute([$internshipID]);
        $data = $this->fetch($req);

        return (!empty($data));
    }
}
