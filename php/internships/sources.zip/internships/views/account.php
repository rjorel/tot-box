<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Administrateur, suppression de membre</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>

<h2>Votre compte a été supprimé</h2>

<br />
<a href='/index.php?logout'><input type='button' value='Retour' /></a>

</body>
</html>
