<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Administrateur, ajout de membre</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />

    <style>
        form label {
            font-weight: bold;
            width: 200px;
            float: left;
            cursor: pointer;
        }
    </style>
</head>
<body>
<h2><?php echo $message; ?></h2>

<div id='formation'>
    <h2>Ajouter une formation</h2>
    <form method="POST" action='/index.php?add'>
        <label for='nameFormation'>Nom :</label>
        <input type='text' maxlength='255' id='nameFormation' name='nameFormation' />
        <br />
        <input type='submit' value='Ajouter' />
    </form>
</div>

<div id='company'>
    <h2>Ajouter une entreprise</h2>
    <form method="POST" action='/index.php?add&amp;company'>
        <label for='loginCompany'>Identifiant :</label>
        <input type='text' maxlength='255' id='loginCompany' name='loginCompany' />
        <br />
        <label for='passwordCompany'>Mot de passe :</label>
        <input type='password' maxlength='255' id='passwordCompany' name='passwordCompany' />
        <br />
        <label for='nameCompany'>Nom :</label>
        <input type='text' maxlength='255' id='nameCompany' name='nameCompany' />
        <br />
        <input type='submit' value='Ajouter' />
    </form>
</div>

<div id='teacher'>
    <h2>Ajouter un enseignant</h2>
    <form method="POST" action='/index.php?add&amp;teacher'>
        <label for='loginTeacher'>Identifiant :</label>
        <input type='text' maxlength='255' id='loginTeacher' name='loginTeacher' />
        <br />
        <label for='passwordTeacher'>Mot de passe :</label>
        <input type='password' maxlength='255' id='passwordTeacher' name='passwordTeacher' />
        <br />
        <label for='lastNameTeacher'>Nom :</label>
        <input type='text' maxlength='255' id='lastNameTeacher' name='lastNameTeacher' />
        <br />
        <label for='firstNameTeacher'>Prénom :</label>
        <input type='text' maxlength='255' id='firstNameTeacher' name='firstNameTeacher' />
        <br />
        <label for='statusTeacher'>Statut :</label>
        <select id='statusTeacher' name='statusTeacher'>
            <option value='teacherTutor'>Tuteur</option>
            <option value='admin'>Administrateur</option>
        </select>
        <br />
        <label for='formationTeacher'>Formation</label>
        <select id='formationTeacher' name='formationTeacher'>
            <option value=''>Aucune</option>
            <?php foreach ($formations as $formation) {
                echo '<option value="' . $formation->name . '">' . $formation->name . '</option>';
            } ?>
        </select>
        <br />
        <input type='submit' value='Ajouter' />
    </form>
</div>

<div id='student'>
    <h2>Ajouter un étudiant</h2>

    <?php
    if (empty($tutors)) {
        echo "Pas d'enseignant tuteur disponible<br />";
    } elseif (empty($formations)) {
        echo "Pas de formation disponible<br />";
    } else {
        ?>
        <form method="POST" action='/index.php?add&amp;student'>
            <label for='loginStudent'>Identifiant :</label>
            <input type='text' maxlength='255' id='loginStudent' name='loginStudent' />
            <br />
            <label for='passwordStudent'>Mot de passe :</label>
            <input type='password' maxlength='255' id='passwordStudent' name='passwordStudent' />
            <br />
            <label for='lastNameStudent'>Nom :</label>
            <input type='text' maxlength='255' id='lastNameStudent' name='lastNameStudent' />
            <br />
            <label for='firstNameStudent'>Prénom :</label>
            <input type='text' maxlength='255' id='firstNameStudent' name='firstNameStudent' />
            <br />
            <label for='tutorStudent'>Tuteur :</label>
            <select id='tutorStudent' name='tutorStudent'>
                <?php foreach ($tutors as $tutor) {
                    echo '<option value="' . $tutor->ID . '">' . $tutor->lastName . ' ' . $tutor->firstName . '</option>';
                } ?>
            </select>
            <br />
            <label for='formationStudent'>Formation :</label>
            <select id='formationStudent' name='formationStudent'>
                <?php foreach ($formations as $formation) {
                    echo '<option value="' . $formation->name . '">' . $formation->name . '</option>';
                } ?>
            </select>
            <br />
            <input type='submit' value='Ajouter' />
        </form>
        <?php
    }
    ?>
</div>

<br />
<a href='/index.php'><input type='button' value='Retour' /></a>

</body>
</html>
