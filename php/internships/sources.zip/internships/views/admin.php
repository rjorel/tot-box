<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Administrateur</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>
<b><u>Membre :</u></b> <?php echo $profile->lastName . ' ' . $profile->firstName; ?><br />
<b><u>Status :</u></b> Enseignant administrateur<br />
<b><u>Formation :</u></b> <?php echo((empty($profile->formationName)) ? 'Aucune' : $profile->formationName); ?>
<br />

<h2>Ajout / modification / suppression de membres :</h2>
<ul>
    <li><a href='/index.php?add'><input type='button' value="Ajouter membres et formations" /></a></li>
    <li><a href='/index.php?edit'><input type='button' value="Modifier / supprimer des membres" /></a></li>
</ul>

<h2>Listes :</h2>
<ul>
    <li><a href='/index.php?list=students'><input type='button' value="Etudiants" /></a></li>
    <li><a href='/index.php?list=teachers'><input type='button' value="Professeurs" /></a></li>
    <li><a href='/index.php?list=companies'><input type='button' value="Entreprises" /></a></li>
    <li><a href='/index.php?list=internships'><input type='button' value="Stages" /></a></li>
    <li><a href='/index.php?list=formations'><input type='button' value="Formations" /></a></li>
</ul>

<h2>Actions :</h2>
<ul>
    <li><a href='/index.php?valid'><input type='button' value="Validation de stages" /></a></li>
    <li><a href='/index.php?grant'><input type='button' value="Accord de stages aux élèves" /></a></li>
</ul>

<br />
<a href='/index.php?logout'><input type='button' value="Se deconnecter" /></a>

</body>
</html>
