<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Entreprise</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />

    <style>
        form label {
            font-weight: bold;
            width: 150px;
            float: left;
            cursor: pointer;
        }
    </style>
</head>
<body>
<b><u>Membre :</u></b> <?php echo $profile->name; ?><br />
<b><u>Status :</u></b> Entreprise<br />

<h2><?php echo $message; ?></h2>
<h2>Proposer un stage</h2>

<?php
if (empty($tutors)) {
    echo "Vous n'avez aucun tuteur pour un stage";
} else {
    ?>
    <form method="POST" action='/index.php'>
        <label for='internshipName'>Intitulé du stage :</label>
        <input type='text' maxlength='255' id='internshipName' name='internshipName' />
        <br />
        <label for='internshipTutor'>Tuteur encadrant :</label>
        <select id='internshipTutor' name='internshipTutor'>
            <?php
            foreach ($tutors as $tutor) {
                echo '<option value="' . $tutor->ID . '">' . $tutor->lastName . ' ' . $tutor->firstName . '</option>';
            }
            ?>
        </select><br />
        <label>Date de début :</label>
        <select name='dayBegin'>
            <?php for ($i = 1; $i <= 31; $i++) {
                echo '<option value="' . $i . '">' . $i . '</option>';
            } ?>
        </select> /
        <select name='monthBegin'>
            <?php for ($i = 1; $i <= 12; $i++) {
                echo '<option value="' . $i . '">' . $i . '</option>';
            } ?>
        </select> /
        <select name='yearBegin'>
            <?php for ($i = 2014; $i <= 2024; $i++) {
                echo '<option value="' . $i . '">' . $i . '</option>';
            } ?>
        </select><br />

        <label>Date de fin :</label>
        <select name='dayEnd'>
            <?php for ($i = 1; $i <= 31; $i++) {
                echo '<option value="' . $i . '">' . $i . '</option>';
            } ?>
        </select> /
        <select name='monthEnd'>
            <?php for ($i = 1; $i <= 12; $i++) {
                echo '<option value="' . $i . '">' . $i . '</option>';
            } ?>
        </select> /
        <select name='yearEnd'>
            <?php for ($i = 2014; $i <= 2024; $i++) {
                echo '<option value="' . $i . '">' . $i . '</option>';
            } ?>
        </select><br />

        <input type='submit' value='Proposer' />
    </form>
    <?php
}
?>

<h2>Déclarer un tuteur</h2>

<form method="POST" action='/index.php'>
    <label for='loginTutor'>Identifiant :</label>
    <input type='text' maxlength='255' id='loginTutor' name='loginTutor' />
    <br />
    <label for='passwordTutor'>Mot de passe :</label>
    <input type='password' maxlength='255' id='passwordTutor' name='passwordTutor' />
    <br />
    <label for='lastNameTutor'>Nom :</label>
    <input type='text' maxlength='255' id='lastNameTutor' name='lastNameTutor' />
    <br />
    <label for='firstNameTutor'>Prénom :</label>
    <input type='text' maxlength='255' id='firstNameTutor' name='firstNameTutor' />
    <br />
    <input type='submit' value='Ajouter' />
</form>


<h2>Stage(s) proposé(s) :</h2>

<?php
if (empty($internships)) {
    echo "Pas de stage disponible<br />";
} else {
    echo '<ul>';
    foreach ($internships as $internship) {
        echo '<li>
                <a href="/index.php?getInfo&amp;internship=' . $internship->ID . '">'
            . $internship->name . '</a><a href="/index.php?del&amp;internship='
            . $internship->ID . '"><input type="button" value="Supprimer" /></a>
            </li>';
    }

    echo '</ul>';
}
?>

<h2>Tuteur(s) :</h2>

<?php
if (empty($tutors)) {
    echo "Aucun tuteur<br />";
} else {
    echo '<ul>';
    foreach ($tutors as $tutor) {
        echo '<li>' . $tutor->lastName . ' ' . $tutor->firstName . '</li>';
    }

    echo '</ul>';
}
?>

<br />
<a href='/index.php?logout'><input type='button' value="Se deconnecter" /></a>

</body>
</html>
