<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>

<body>
<?php echo $message; ?> <br /><br />

<form method="POST" action='/index.php'>
    <label for='login'>Identifiant</label> :
    <input type='text' maxlength='255' id='login' name='login' />
    <br />
    <label for='password'>Mot de passe</label> :
    <input type='password' maxlength='255' id='password' name='password' />
    <br />
    <input type='submit' value="Se connecter" />
</form>
</body>
</html>

