<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Administrateur, suppression de membre</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>
<h2><?php echo $message; ?></h2>
<h2>Liste des étudiants :</h2>

<?php
if (empty($students)) {
    echo "Il n'y a pas d'étudiant<br />";
} else {
    echo '<ul>';
    foreach ($students as $student) {
        echo '<li><a href="/index.php?edit&amp;getInfo&amp;student=' . $student->ID . '">' . $student->lastName . ' ' . $student->firstName . '<a href="/index.php?edit&amp;modify&amp;student=' . $student->ID . '"><input type="button" value="Modifier" /></a><a href="/index.php?edit&amp;del&amp;student=' . $student->ID . '"><input type="button" value="Supprimer" /></a></li>';
    }
    echo '</ul>';
}
?>

<h2>Liste des professeurs :</h2>

<?php
if (empty($teachers)) {
    echo "Il n'y a pas de professeur<br />";
} else {
    echo '<ul>';
    foreach ($teachers as $teacher) {
        echo '<li><a href="/index.php?edit&amp;getInfo&amp;teacher=' . $teacher->ID . '">' . $teacher->lastName . ' ' . $teacher->firstName . '<a href="/index.php?edit&amp;modify&amp;teacher=' . $teacher->ID . '"><input type="button" value="Modifier" /></a><a href="/index.php?edit&amp;del&amp;teacher=' . $teacher->ID . '"><input type="button" value="Supprimer" /></a></li>';
    }
    echo '</ul>';
}
?>

<h2>Liste des entreprises :</h2>

<?php
if (empty($companies)) {
    echo "Il n'y a pas d'entreprise<br />";
} else {
    echo '<ul>';
    foreach ($companies as $company) {
        echo '<li><a href="/index.php?edit&amp;getInfo&amp;company=' . $company->ID . '">' . $company->name . '<a href="/index.php?edit&amp;modify&amp;company=' . $company->ID . '"><input type="button" value="Modifier" /></a><a href="/index.php?edit&amp;del&amp;company=' . $company->ID . '"><input type="button" value="Supprimer" /></a></li>';
    }
    echo '</ul>';
}
?>

<br />
<a href='/index.php'><input type='button' value='Retour' /></a>

</body>
</html>
