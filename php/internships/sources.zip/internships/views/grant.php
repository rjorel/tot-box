<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Autorisation de stages</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>
<h2><?php echo $message; ?></h2>
<h2>Stage(s) à accorder :</h2>

<?php
if (empty($students)) {
    echo "Tous les stages ont été décidés<br />";
} else {
    echo '<ul>';
    foreach ($students as $student) {
        $internship = $db->getInternshipByID($student->internshipID);
        echo '<li><a href="/index.php?getInfo&amp;grant&amp;student=' . $student->ID . '">' . $student->lastName . ' ' . $student->firstName . '</a> -- Stage demandé : <a href="/index.php?getInfo&amp;grant&amp;internship=' . $internship->ID . '">' . $internship->name . '</a>';

        ?>

        <a href="/index.php?grant&amp;internship=<?php echo $internship->ID; ?>&amp;student=<?php echo $student->ID; ?>&amp;value=yes"><input
                type='button' value='Accorder' /></a>
        <a href="/index.php?grant&amp;internship=<?php echo $internship->ID; ?>&amp;student=<?php echo $student->ID; ?>&amp;value=no"><input
                type='button' value="Ne pas accorder" /></a>

        <?php
        echo '</li>';
    }
    echo '</ul>';
}
?>

<br />
<a href='/index.php'><input type='button' value='Retour' /></a>

</body>
</html>
