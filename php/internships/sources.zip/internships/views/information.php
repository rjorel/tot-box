<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Informations</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>

<?php
$redirect = '/index.php';

if (!empty($internship)) {
    echo '<h2>Informations de stage</h2>';
    echo '<b><u>Stage :</u></b> ' . $internship->name . '<br />';
    echo '<b><u>Entreprise :</u></b> ' . $companyInternship->name . '<br />';
    echo '<b><u>Tuteur :</u></b> ' . $tutorInternship->lastName . ' ' . $tutorInternship->firstName;

    if (is_null($internship->tutorAssist)) {
        echo " <i>(N'a pas dit s'il participait à la soutenance)</i><br />";
    } elseif ($internship->tutorAssist == 0) {
        echo " <span style=\"color: red\">Ne participe pas à la soutenance</span><br />";
    } else {
        echo " <span style=\"color: green\">Participe à la soutenance</span><br />";
    }

    echo '<b><u>Date début :</u></b> ' . $internship->dateBegin . '<br />';
    echo '<b><u>Date fin :</u></b> ' . $internship->dateEnd . '<br />';
    echo '<b><u>Date de soutenance :</u></b> ' . (is_null($internship->dateTest) ? "Pas encore de date" : $internship->dateTest . ', en ' . $internship->roomTest) . '<br />';

    if (is_null($internship->available)) {
        echo "<h3>Non validé</h3>";
    } elseif ($internship->available == 0) {
        echo "<h3>Refusé</h3>";
    } else {
        echo "<h3>Validé</h3>";

        if (empty($studentInternship)) {
            echo "Ce stage n'est pas encore attribué";

            if (empty($studentsNotGrantedInternship)) {
                echo " <i>(aucune demande)</i><br />";
            } else {
                echo "<h3>Elève(s) demandeur(s) :</h3>";
                echo '<ul>';
                foreach ($studentsNotGrantedInternship as $student) {
                    echo '<li>' . $student->lastName . ' ' . $student->firstName . '</li>';
                }
                echo '</ul>';
            }
        } else {
            echo '<b><u>Attribué à :</u></b> ' . $studentInternship->lastName . ' ' . $studentInternship->firstName . '<br />';
        }

        if (empty($teachersJury)) {
            echo "Ce stage n'a pas encore de jury<br />";
        } else {
            echo "<h3>Professeur(s) de jury :</h3>";
            echo '<ul>';
            foreach ($teachersJury as $teacher) {
                echo '<li>' . $teacher->lastName . ' ' . $teacher->firstName . '</li>';
            }
            echo '</ul>';
        }

        if (empty($formationsInternship)) {
            echo "Ce stage n'a pas de formation(s) attribuée(s)<br />";
        } else {
            echo "<h3>Formation(s) :</h3>";
            echo '<ul>';
            foreach ($formationsInternship as $formation) {
                echo '<li>' . $formation->name . '</li>';
            }
            echo '</ul>';
        }
    }

    $redirection = 'list=internships';
} elseif (!empty($teacher)) {
    echo '<h2>Fiche professeur</h2>';
    echo '<b><u>Nom :</u></b> ' . $teacher->lastName . '<br />';
    echo '<b><u>Prénom :</u></b> ' . $teacher->firstName . '<br />';
    echo '<b><u>Statut :</u></b> ' . (($teacher->status == 'teacherTutor') ? 'Tuteur' : 'Administrateur') . '<br />';
    echo '<b><u>Formation :</u></b> ' . ((is_null($teacher->formationName)) ? 'Aucune' : $teacher->formationName) . '<br />';

    if ($teacher->status == 'teacherTutor') {
        echo '<h3>Elève(s) sous tutelle :</h3>';
        if (empty($students)) {
            echo "Ce professeur n'a pas d'élèves sous tutelle<br />";
        } else {
            echo '<ul>';
            foreach ($students as $student) {
                echo '<li>' . $student->lastName . ' ' . $student->firstName . '</li>';
            }
            echo '</ul>';
        }
    }

    $redirection = 'list=teachers';
} elseif (!empty($student)) {
    echo '<h2>Fiche élève</h2>';
    echo '<b><u>Nom :</u></b> ' . $student->lastName . '<br />';
    echo '<b><u>Prénom :</u></b> ' . $student->firstName . '<br />';
    echo '<b><u>Professeur tuteur :</u></b> ' . $tutor->lastName . ' ' . $tutor->firstName . '<br />';
    echo '<b><u>Formation :</u></b> ' . $student->formationName . '<br />';

    if (empty($internshipStudent)) {
        echo "<h3>Cet élève n'a pas demandé de stage</h3>";
    } else {
        echo '<br /><b><u>Stage demandé :</u></b> <a href="/index.php?getInfo&amp;student&amp;internship=' . $internshipStudent->ID . '">' . $internshipStudent->name . '</a>';
        if (is_null($student->internshipGranted)) {
            echo " <i>(Non décidé)</i><br />";
        } elseif ($student->internshipGranted == 0) {
            echo " <span style=\"color: red\">Non accordé</span><br />";
        } else {
            echo " <span style=\"color: green\">Accordé</span><br />";
        }
    }

    $redirection = 'list=students';
} elseif (!empty($formation)) {
    echo '<h2>Formation</h2>';
    echo '<b><u>Intitulé :</u></b> ' . $formation->name . '<br />';
    echo '<h3>Elève(s) dans cette formation :</h3>';

    if (empty($studentsFormation)) {
        echo "Aucun étudiant dans cette formation<br />";
    } else {
        echo '<ul>';
        foreach ($studentsFormation as $student) {
            echo '<li>' . $student->lastName . ' ' . $student->firstName . '</li>';
        }
        echo '</ul>';
    }

    $redirection = 'list=formations';
} elseif (!empty($company)) {
    echo "<h2>Information d'entreprise</h2>";
    echo '<b><u>Nom :</u></b> ' . $company->name . '<br />';
    echo '<h3>Stage(s) proposé(s) :</h3>';

    if (empty($internshipsCompany)) {
        echo "Aucun stage proposé par cette entreprise<br />";
    } else {
        echo '<ul>';
        foreach ($internshipsCompany as $internship) {
            echo '<li>' . $internship->name . '</li>';
        }
        echo '</ul>';
    }

    $redirection = 'list=companies';
} else {
    echo 'Error !<br />';
}

if (isset($_GET['valid'])) {
    $redirection = 'valid';
} elseif (isset($_GET['grant'])) {
    $redirection = 'grant';
} elseif (isset($_GET['edit'])) {
    $redirection = 'edit';
} elseif (isset($_GET['student'])) {
    $redirection = '';
}
?>

<br />
<a href="/index.php?<?php echo $redirection; ?>"><input type='button' value='Retour' /></a>

</body>
</html>
