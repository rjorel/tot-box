<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Listes</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>

<?php
switch ($_GET['list']) {
    case 'teachers':
        $list = $db->getTeachers();

        echo "<h2>Liste des professeurs :</h2>";
        if (empty($list)) {
            echo "Il n'y a pas de professeur<br />";
        } else {
            echo '<ul>';
            foreach ($list as $teacher) {
                echo '<li><a href="/index.php?getInfo&amp;teacher=' . $teacher->ID . '">' . $teacher->lastName . ' ' . $teacher->firstName . '</a></li>';
            }
            echo '</ul>';
        }
        break;

    case 'students':
        $list = $db->getStudents();

        echo "<h2>Liste des étudiants :</h2>";
        if (empty($list)) {
            echo "Il n'y a pas d'étudiant<br />";
        } else {
            echo '<ul>';
            foreach ($list as $student) {
                echo '<li><a href="/index.php?getInfo&amp;student=' . $student->ID . '">' . $student->lastName . ' ' . $student->firstName . '</a></li>';
            }
            echo '</ul>';
        }

        break;

    case 'companies':
        $list = $db->getCompanies();

        echo "<h2>Liste des entreprises :</h2>";
        if (empty($list)) {
            echo "Il n'y a pas d'entreprise<br />";
        } else {
            echo '<ul>';
            foreach ($list as $company) {
                echo '<li><a href="/index.php?getInfo&amp;company=' . $company->ID . '">' . $company->name . '</a></li>';
            }
            echo '</ul>';
        }
        break;

    case 'internships':
        $list = $db->getInternShips();

        echo "<h2>Liste des stages :</h2>";
        if (empty($list)) {
            echo "Il n'y a pas de stage proposé<br />";
        } else {
            echo '<ul>';
            foreach ($list as $internship) {
                echo '<li><a href="/index.php?getInfo&amp;internship=' . $internship->ID . '">' . $internship->name . '</a></li>';
            }
            echo '</ul>';
        }
        break;

    case 'formations':
        $list = $db->getFormations();

        echo "<h2>Liste des formations :</h2>";
        if (empty($list)) {
            echo "Il n'y a pas de formation<br />";
        } else {
            echo '<ul>';
            foreach ($list as $formation) {
                echo '<li><a href="/index.php?getInfo&amp;formation=' . $formation->name . '">' . $formation->name . '</a></li>';
            }
            echo '</ul>';
        }
        break;

    default:
        break;
}
?>

<br />
<a href='/index.php'><input type='button' value='Retour' /></a>

</body>
</html>
