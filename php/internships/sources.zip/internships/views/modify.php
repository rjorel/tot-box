<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Administrateur, suppression de membre</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />

    <style>
        form label {
            font-weight: bold;
            width: 120px;
            float: left;
            cursor: pointer;
        }
    </style>
</head>
<body>

<?php
if (!empty($student)) {
    ?>
    <h2>Edition étudiant</h2>
    <form method="POST" action='/index.php?edit'>
        <input type='hidden' name='student' value="<?php echo $student->ID ?>" />
        <label for='lastNameStudent'>Nom :</label>
        <input type='text' maxlength='255' id='lastNameStudent' name='lastNameStudent'
               value="<?php echo $student->lastName ?>" />
        <br />
        <label for='firstNameStudent'>Prénom :</label>
        <input type='text' maxlength='255' id='firstNameStudent' name='firstNameStudent'
               value="<?php echo $student->firstName ?>" />
        <br />
        <label for='tutorStudent'>Tuteur :</label>
        <select id='tutorStudent' name='tutorStudent'>
            <?php foreach ($tutors as $tutor) {
                echo '<option value="' . $tutor->ID . '" ' . (($tutor->ID == $student->teacherID) ? 'selected' : '') . '>' . $tutor->lastName . ' ' . $tutor->firstName . '</option>';
            } ?>
        </select>
        <br />
        <label for='formationStudent'>Formation :</label>
        <select id='formationStudent' name='formationStudent'>
            <?php foreach ($formations as $formation) {
                echo '<option value="' . $formation->name . '" ' . (($formation->name == $student->formationName) ? 'selected' : '') . '>' . $formation->name . '</option>';
            } ?>
        </select>
        <br />
        <input type='submit' value='Modifier' />
    </form>

    <?php
} elseif (!empty($teacher)) {
    ?>

    <h2>Edition enseignant</h2>
    <form method="POST" action='/index.php?edit'>
        <input type='hidden' name='teacher' value="<?php echo $teacher->ID ?>" />
        <label for='lastNameTeacher'>Nom :</label>
        <input type='text' maxlength='255' id='lastNameTeacher' name='lastNameTeacher'
               value="<?php echo $teacher->lastName; ?>" />
        <br />
        <label for='firstNameTeacher'>Prénom :</label>
        <input type='text' maxlength='255' id='firstNameTeacher' name='firstNameTeacher'
               value="<?php echo $teacher->firstName; ?>" />
        <br />
        <label for='statusTeacher'>Statut :</label>
        <select id='statusTeacher' name='statusTeacher'>
            <option value='teacherTutor'>Tuteur</option>
            <option value='admin' <?php echo(($teacher->status == 'admin') ? 'selected' : ''); ?>>
                Administrateur
            </option>
        </select>
        <br />
        <label for='formationTeacher'>Formation</label>
        <select id='formationTeacher' name='formationTeacher'>
            <option value=''>Aucune</option>
            <?php foreach ($formations as $formation) {
                echo '<option value="' . $formation->name . '" ' . (($formation->name == $teacher->formationName) ? 'selected' : '') . '>' . $formation->name . '</option>';
            } ?>
        </select>
        <br />
        <input type='submit' value='Modifier' />
    </form>

    <?php
} elseif (!empty($company)) {
    ?>

    <h2>Edition entreprise</h2>
    <form method="POST" action='/index.php?edit'>
        <input type='hidden' name='company' value="<?php echo $company->ID; ?>" />
        <label for='nameCompany'>Nom :</label>
        <input type='text' maxlength='255' id='nameCompany' name='nameCompany'
               value="<?php echo $company->name; ?>" />
        <br />
        <input type='submit' value='Modifier' />
    </form>

    <?php
} else {
    echo 'Error<br />';
}
?>

<br />
<a href='/index.php?edit'><input type='button' value='Retour' /></a>

</body>
</html>
