<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Etudiant</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>
<b><u>Membre :</u></b> <?php echo $profile->lastName . ' ' . $profile->firstName; ?><br />
<b><u>Status :</u></b> Etudiant<br />
<b><u>Professeur tuteur
        :</u></b> <?php echo $teacherTutor->lastName . ' ' . $teacherTutor->firstName; ?><br />

<h2><?php echo $message; ?></h2>
<h2>Stage(s) disponible(s) :</h2>

<?php
if (empty($internships)) {
    echo "Il n'y a pas de stages disponibles<br />";
} else {
    echo '<ul>';
    foreach ($internships as $internship) {
        ?>
        <li>
            <a href="/index.php?getInfo&amp;internship=<?php echo $internship->ID; ?>"><?php echo $internship->name; ?></a>
            <a href="/index.php?request&amp;internship=<?php echo $internship->ID; ?>">
                <input type="button" value="Postuler" />
            </a>
        </li>

        <?php
    }

    echo '</ul>';
}

if (empty($internshipRequest)) {
    echo "<br />Vous n'avez pas demandé de stage<br />";
} else {
    if (is_null($profile->internshipGranted)) {
        echo '<br /><b><u>Stage :</u></b> <a href="/index.php?getInfo&amp;internship=' . $internshipRequest->ID . '">' . $internshipRequest->name . '</a> <i>(en attente de validation)</i><br />';
    } elseif ($profile->internshipGranted == 1) {
        echo '<br /><b><u>Stage :</u></b> <a href="/index.php?getInfo&amp;internship=' . $internshipRequest->ID . '">' . $internshipRequest->name . '</a> <span style="color: green">Accordé</span><br />';
    }
}
?>

<br />
<a href='/index.php?logout'><input type='button' value="Se deconnecter" /></a>

</body>
</html>
