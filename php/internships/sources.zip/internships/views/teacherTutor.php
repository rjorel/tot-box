<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Tuteur</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>
<b><u>Membre :</u></b> <?php echo $profile->lastName . ' ' . $profile->firstName; ?><br />
<b><u>Status :</u></b> Enseignant tuteur<br />
<b><u>Formation
        :</u></b> <?php echo((empty($profile->formationName)) ? 'Aucune' : $profile->formationName); ?>
<br />

<h2>Elève(s) sous tutelle :</h2>
<?php
if (empty($students)) {
    echo "Vous n'avez pas d'élèves sous tutelle<br />";
} else {
    echo '<ul>';
    foreach ($students as $student) {
        echo '<li><a href="/index.php?getInfo&amp;student=' . $student->ID . '">' . $student->lastName . ' ' . $student->firstName . '</a></li>';
    }
    echo '</ul>';
}
?>

<br />
<a href='/index.php?logout'><input type='button' value="Se deconnecter" /></a>

</body>
</html>
