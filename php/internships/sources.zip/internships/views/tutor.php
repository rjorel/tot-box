<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Tuteur d'entreprise</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>
<b><u>Membre :</u></b> <?php echo $profile->lastName . ' ' . $profile->firstName; ?><br />
<b><u>Status :</u></b> Tuteur d'entreprise<br />
<b><u>Entreprise :</u></b> <?php echo $company->name; ?><br />
<h2><?php echo $message; ?></h2>

<h2>Stage(s) encadré(s) :</h2>
<?php
if (empty($internships)) {
    echo "Vous n'êtes en charge d'aucun stage<br />";
} else {
    echo '<ul>';
    foreach ($internships as $internship) {
        echo '<li><a href="/index.php?getInfo&amp;internship=' . $internship->ID . '">' . $internship->name . '</a>';

        if (is_null($internship->tutorAssist)) {
            ?>
            -- Assister à la présentation : <a
                href="/index.php?internship=<?php echo $internship->ID; ?>&amp;value=yes">
                <input type='button' value='Oui' />
            </a>
            <a href="/index.php?internship=<?php echo $internship->ID; ?>&amp;value=no">
                <input type='button' value='Non' />
            </a>

            <?php
        } else {
            if ($internship->tutorAssist == 1) {
                echo " -- Vous participez à la soutenance de ce stage";
            } else {
                echo " -- Vous ne participez pas à la soutenance de ce stage";
            }
        }
        echo '</li>';
    }

    echo '</ul>';
}
?>

<br />
<a href='/index.php?logout'><input type='button' value="Se deconnecter" /></a>

</body>
</html>
