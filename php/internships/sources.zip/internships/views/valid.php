<!DOCTYPE html>
<html>
<head>
    <title>Gestion de stages - Validation de stages</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
</head>
<body>
<h2><?php echo $message; ?></h2>
<h2>Stage(s) à valider :</h2>

<?php
if (empty($internships)) {
    echo "Tous les stages ont été validés<br />";
} elseif (empty($formations)) {
    echo "Pas de formation disponible<br />";
} elseif (empty($teachers)) {
    echo "Pas d'enseignant disponible<br />";
} else {
    echo '<ul>';

    foreach ($internships as $i => $internship) {
        echo '<li><a href="/index.php?getInfo&amp;valid&amp;internship=' . $internship->ID . '">' . $internship->name . '</a>';
        ?>
        <form method="POST" action='/index.php?valid'>
            <input type='hidden' name='internship' value="<?php echo $internship->ID ?>" />
            <input type='hidden' name='dateEnd' value="<?php echo $internship->dateEnd; ?>" />
            <b>Formation(s) concernée(s) :</b><br />
            <?php foreach ($formations as $j => $formation) {
                echo '<input type="checkbox" id="' . $i . $j . '" name="formation=' . $formation->name . '" ><label for="' . $i . $j . '">' . $formation->name . '</label><br />';
            } ?>
            <br />
            <b>Examen :</b><br />
            Date :
            <select name='day'>
                <?php for ($i = 1; $i <= 31; $i++) {
                    echo '<option value="' . $i . '">' . $i . '</option>';
                } ?>
            </select> /
            <select name='month'>
                <?php for ($i = 1; $i <= 12; $i++) {
                    echo '<option value="' . $i . '">' . $i . '</option>';
                } ?>
            </select> /
            <select name='year'>
                <?php for ($i = 2014; $i <= 2024; $i++) {
                    echo '<option value="' . $i . '">' . $i . '</option>';
                } ?>
            </select> :
            <select name='hour'>
                <?php for ($i = 0; $i < 24; $i++) {
                    echo '<option value="' . $i . '">' . $i . '</option>';
                } ?>
            </select> h
            <select name='minute'>
                <?php for ($i = 0; $i <= 60; $i++) {
                    echo '<option value="' . $i . '">' . $i . '</option>';
                } ?>
            </select> m <br />
            Salle : <input type='text' maxlength='255' name='room' /><br />
            <br />
            <b>Professeur(s) de jury :</b><br />
            <?php foreach ($teachers as $teacher) {
                echo '<input type="checkbox" name="teacher=' . $teacher->ID . '" ><a href="/index.php?getInfo&amp;valid&amp;teacher=' . $teacher->ID . '">' . $teacher->lastName . ' ' . $teacher->firstName . '</a><br />';
            } ?>
            <br />
            Accorder : <input type='radio' id='yes' name='answer' value='yes' /><label for='yes'>Oui</label>
            <input type='radio' id='no' name='answer' value='no' /><label for='no'>Non</label><br />
            <input type='submit' value='Valider' />
        </form>

        <?php
        echo '</li><br />';
    }

    echo '</ul>';
}
?>

<br />
<a href='/index.php'><input type='button' value='Retour' /></a>

</body>
</html>
