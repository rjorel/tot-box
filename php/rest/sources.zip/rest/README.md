# Rest example

A simple example of REST server with PHP.

## Run server

```bash
$ composer run-server
```

Server is now running at [http://localhost:8000](http://localhost:8000).

## Run tests

```bash
$ composer run-tests
```

## Some explanations
This a really simple project, so an advanced way to handle routing and database is not the point 
here. The idea is just to see how it's possible to get data from a request, with different methods 
and change database values.

### Database
I use an SQLite database. A table is created each time a request is sent, and filled up with some
entries. Some objects abstract database operations, but usage is verbose.

### Routing
Two classes are used in order to handle routing, in a not-so-bad way. Routes are registered for 
each request, and the router tries to find  the last registered one that matches the current request
URI.

### Controllers
Controllers are present just to clearly define the place where code is executed after booting and 
routing.
