<?php

$db = new PDO('sqlite::memory:');

$db->exec('DROP TABLE IF EXISTS users');

$db->exec(
    'CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email VARCHAR NOT NULL,
        name VARCHAR NOT NULL
    )'
);

$db->exec('INSERT INTO users(email, name) VALUES("john.doe@example.com", "John Doe")');
$db->exec('INSERT INTO users(email, name) VALUES("james.smith@society.com", "James Smith")');

return $db;