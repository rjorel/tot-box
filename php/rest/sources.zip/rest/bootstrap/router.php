<?php

use Rest\Controllers\UserController;
use Rest\Core\Route;

$router = new Rest\Core\Router();

$router->addRoute(new Route('users', 'GET', UserController::class, 'index'));
$router->addRoute(new Route('users/([0-9]+)', 'GET', UserController::class, 'show'));
$router->addRoute(new Route('users', 'POST', UserController::class, 'create'));
$router->addRoute(new Route('users/([0-9]+)', 'PUT', UserController::class, 'update'));
$router->addRoute(new Route('users/([0-9]+)', 'DELETE', UserController::class, 'delete'));

return $router;