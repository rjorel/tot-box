<?php

$db = require __DIR__ . '/database.php';
$router = require __DIR__ . '/router.php';

return new Rest\Server($db, $router);