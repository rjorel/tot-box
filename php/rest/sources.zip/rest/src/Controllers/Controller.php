<?php

namespace Rest\Controllers;

use Rest\Core\Request;
use Rest\Database\Connection;

abstract class Controller
{
    protected Connection $connection;
    protected Request $request;

    public function __construct(Connection $connection, Request $request)
    {
        $this->connection = $connection;
        $this->request = $request;
    }
}