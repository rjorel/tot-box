<?php

namespace Rest\Controllers;

class UserController extends Controller
{
    private const USER_ATTRIBUTES = ['email', 'name'];

    public function index()
    {
        $users = $this->connection
            ->newQuery()
            ->table('users')
            ->select();

        return json_encode($users);
    }

    public function show($id)
    {
        $users = $this->connection
            ->newQuery()
            ->table('users')
            ->where('id', $id)
            ->select();

        return json_encode($users[0] ?? []);
    }

    public function create()
    {
        $this->connection
            ->newQuery()
            ->table('users')
            ->insert($this->getAttributesFromRequest());
    }

    private function getAttributesFromRequest()
    {
        $attributes = [];

        foreach (self::USER_ATTRIBUTES as $attrKey) {
            $value = $this->request->get($attrKey);

            if ($value !== null) {
                $attributes[ $attrKey ] = $value;
            }
        }

        return $attributes;
    }

    public function update($id)
    {
        $this->connection
            ->newQuery()
            ->table('users')
            ->where('id', $id)
            ->update($this->getAttributesFromRequest());
    }

    public function delete($id)
    {
        $this->connection
            ->newQuery()
            ->table('users')
            ->delete($id);
    }
}