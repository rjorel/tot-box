<?php

namespace Rest\Core;

class Request
{
    private array $query;
    private array $request;
    private array $server;

    public function __construct(array $query = [], array $request = [], array $server = [])
    {
        $this->query = $query;
        $this->request = $request;
        $this->server = $server;
    }

    public function getMethod(): string
    {
        return $this->server['REQUEST_METHOD'] ?? '';
    }

    public function getUri(): string
    {
        return $this->server['REQUEST_URI'] ?? '';
    }

    public function get(string $key)
    {
        if (array_key_exists($key, $this->query)) {
            return $this->query[ $key ];
        }

        if (array_key_exists($key, $this->request)) {
            return $this->request[ $key ];
        }

        return null;
    }

    public static function makeFromGlobals()
    {
        $request = $_POST;

        if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
            $data = file_get_contents('php://input');

            parse_str($data, $request);
        }

        return new static($_GET, $request, $_SERVER);
    }

    public static function create(string $uri, string $method, array $query = [], array $request = [])
    {
        return new static($query, $request, [
            'REQUEST_URI'    => $uri,
            'REQUEST_METHOD' => $method
        ]);
    }
}