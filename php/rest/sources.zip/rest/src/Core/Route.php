<?php

namespace Rest\Core;

class Route
{
    private string $uri;
    private string $method;
    private string $controller;
    private string $action;
    
    private array $variables = [];

    public function __construct(string $uri, string $method, string $controller, string $action)
    {
        $this->uri = $uri;
        $this->method = $method;
        $this->controller = $controller;
        $this->action = $action;
    }

    public function getUri()
    {
        return $this->uri;
    }

    public function getMethod()
    {
        return $this->method;
    }

    public function getController()
    {
        return $this->controller;
    }

    public function getAction()
    {
        return $this->action;
    }

    public function getVariables()
    {
        return $this->variables;
    }

    public function setVariables(array $variables)
    {
        $this->variables = $variables;
    }
}