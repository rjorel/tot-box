<?php

namespace Rest\Core;

use Rest\Exceptions\ServerException;

class Router
{
    private array $routes = [];

    public function addRoute(Route $route)
    {
        $this->routes[] = $route;
    }

    public function find(string $uri, string $method): Route
    {
        $matchedRoutes = $this->filterRoutesForMethod(
            $this->filterRoutesForUri($this->routes, $uri),
            $method
        );

        if (empty($matchedRoutes)) {
            throw new ServerException("No route for URI \"{$uri}\" (method: {$method})");
        }

        // Give priority to last registered routes.
        return end($matchedRoutes);
    }

    private function filterRoutesForUri(array $routes, string $uri)
    {
        return array_filter($routes, function (Route $route) use ($uri) {
            $regex = $this->formatForRegex($route->getUri());

            if (preg_match($regex, $uri, $matches)) {
                $route->setVariables(array_slice($matches, 1));

                return true;
            }

            return false;
        });
    }

    private function formatForRegex($uri)
    {
        return '/' . $this->escapeSlashes($uri) . '/';
    }

    private function escapeSlashes($uri)
    {
        return str_replace('/', '\/', $uri);
    }

    private function filterRoutesForMethod(array $routes, string $method)
    {
        return array_filter($routes, function (Route $route) use ($method) {
            return $route->getMethod() == $method;
        });
    }
}