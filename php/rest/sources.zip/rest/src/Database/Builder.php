<?php

namespace Rest\Database;

class Builder
{
    private $connection;
    private $compiler;

    private $table;
    private $wheres = [];

    public function __construct(Connection $connection)
    {
        $this->connection = $connection;

        $this->compiler = new Compiler();
    }

    public function table(string $table)
    {
        $this->table = $table;

        return $this;
    }

    public function select()
    {
        $query = $this->compiler->compileSelect($this->table, $this->wheres);

        return $this->connection->select($query, $this->getBindings());
    }

    private function getBindings()
    {
        return array_values($this->wheres);
    }

    public function insert(array $values)
    {
        $query = $this->compiler->compileInsert($this->table, $values);

        $this->connection->insert($query, array_values($values));
    }

    public function update(array $values)
    {
        $query = $this->compiler->compileUpdate($this->table, $values, $this->wheres);

        $bindings = array_merge(array_values($values), $this->getBindings());

        $this->connection->update($query, $bindings);
    }

    public function delete($id)
    {
        $this->where('id', $id);

        $query = $this->compiler->compileDelete($this->table, $this->wheres);

        $this->connection->delete($query, $this->getBindings());
    }

    public function where(string $column, $value)
    {
        $this->wheres[ $column ] = $value;

        return $this;
    }
}