<?php

namespace Rest\Database;

class Compiler
{
    use Compilers\Delete;
    use Compilers\Insert;
    use Compilers\Select;
    use Compilers\Update;

    protected function compileWheres(array $clauses)
    {
        $mappedClauses = $this->mapWhereClauses($clauses);

        if (!empty($mappedClauses)) {
            return $this->concatenateWhereClauses($mappedClauses);
        }

        return '';
    }

    private function mapWhereClauses(array $clauses)
    {
        return array_map(fn($key) => "$key = ?", array_keys($clauses));
    }

    private function concatenateWhereClauses(array $clauses)
    {
        return 'WHERE ' . implode(' AND ', $clauses);
    }
}