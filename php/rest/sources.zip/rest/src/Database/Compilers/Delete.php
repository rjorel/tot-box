<?php

namespace Rest\Database\Compilers;

trait Delete
{
    public function compileDelete(string $table, array $bindings = [])
    {
        $wheres = $this->compileWheres($bindings);

        return "DELETE FROM $table $wheres";
    }
}