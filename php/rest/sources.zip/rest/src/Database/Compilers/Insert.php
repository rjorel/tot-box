<?php

namespace Rest\Database\Compilers;

trait Insert
{
    public function compileInsert(string $table, array $values = [])
    {
        $columns = $this->prepareColumns($values);

        $parameters = $this->prepareParameters($values);

        return "INSERT INTO $table($columns) VALUES($parameters)";
    }

    private function prepareColumns(array $values)
    {
        return implode(', ', array_keys($values));
    }

    private function prepareParameters(array $values)
    {
        return implode(', ', array_fill(0, count($values), '?'));
    }
}