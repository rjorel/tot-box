<?php

namespace Rest\Database\Compilers;

trait Select
{
    public function compileSelect(string $table, array $bindings = [])
    {
        $wheres = $this->compileWheres($bindings);

        return "SELECT * FROM $table $wheres";
    }
}