<?php

namespace Rest\Database\Compilers;

trait Update
{
    public function compileUpdate(string $table, array $values = [], array $bindings = [])
    {
        $columns = $this->prepareColumnsWithKeys(
            array_keys($values)
        );

        $wheres = $this->compileWheres($bindings);

        return "UPDATE $table SET $columns $wheres";
    }

    protected function prepareColumnsWithKeys(array $keys)
    {
        return implode(', ', array_map(fn($key) => "$key = ?", $keys));
    }
}