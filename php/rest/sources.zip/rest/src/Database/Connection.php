<?php

namespace Rest\Database;

use PDO;
use PDOStatement;
use RuntimeException;

class Connection
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function newQuery()
    {
        return new Builder($this);
    }

    public function select(string $query, array $bindings = [])
    {
        $stm = $this->execute($query, $bindings);

        return $stm->fetchAll();
    }

    private function execute(string $query, array $bindings)
    {
        $statement = $this->pdo->prepare($query);

        $statement->setFetchMode(PDO::FETCH_OBJ);

        $statement->execute($bindings);

        return $statement;
    }

    public function insert(string $query, array $bindings = [])
    {
        $this->execute($query, $bindings);
    }

    public function update(string $query, array $bindings = [])
    {
        $this->execute($query, $bindings);
    }

    public function delete(string $query, array $bindings = [])
    {
        $this->execute($query, $bindings);
    }
}