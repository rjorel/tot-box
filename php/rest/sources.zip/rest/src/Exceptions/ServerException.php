<?php

namespace Rest\Exceptions;

use RuntimeException;

class ServerException extends RuntimeException
{
    //
}