<?php

namespace Rest;

use PDO;
use Rest\Core\Request;
use Rest\Core\Route;
use Rest\Core\Router;
use Rest\Database\Connection;

class Server
{
    private PDO $pdo;
    private Router $router;

    public function __construct(PDO $pdo, Router $router)
    {
        $this->pdo = $pdo;
        $this->router = $router;
    }

    public function execute(Request $request)
    {
        $route = $this->findRoute($request);

        $controller = $this->instantiateController($request, $route);

        return $this->runAction($controller, $route);
    }

    private function findRoute(Request $request)
    {
        return $this->router->find(
            $request->getUri(), 
            $request->getMethod()
        );
    }

    private function instantiateController(Request $request, Route $route)
    {
        $controller = $route->getController();

        return new $controller($this->newConnection(), $request);
    }

    public function newConnection()
    {
        return new Connection($this->pdo);
    }

    private function runAction($controller, Route $route)
    {
        $action = $route->getAction();
        $vars = $route->getVariables();

        if (!method_exists($controller, $action)) {
            return '';
        }

        return $controller->$action(...$vars);
    }
}