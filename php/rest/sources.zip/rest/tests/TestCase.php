<?php

namespace Tests\Rest;

use PHPUnit\Framework\TestCase as BaseTestCase;
use Rest\Core\Request;
use Rest\Database\Builder;
use Rest\Server;

class TestCase extends BaseTestCase
{
    private $server;

    protected function setUp(): void
    {
        if (!$this->server) {
            $this->server = $this->createServer();
        }
    }

    public function createServer(): Server
    {
        return require __DIR__ . '/../bootstrap/server.php';
    }

    protected function get(string $uri)
    {
        return $this->call('GET', $uri);
    }

    private function call(string $method, string $uri, array $query = [], array $request = [])
    {
        return $this->server->execute(
            Request::create($uri, $method, $query, $request)
        );
    }

    protected function post(string $uri, array $params = [])
    {
        return $this->call('POST', $uri, [], $params);
    }

    protected function put(string $uri, array $params = [])
    {
        return $this->call('PUT', $uri, [], $params);
    }

    protected function delete(string $uri)
    {
        return $this->call('DELETE', $uri);
    }

    protected function assertJsonResponse(array $attributes, string $response)
    {
        $this->assertJson($response);

        $this->assertJsonStringEqualsJsonString($response, json_encode($attributes));
    }

    protected function assertDatabaseHas(string $table, array $attributes = [])
    {
        $this->assertNotEmpty(
            $this->getObjectsWithAttributes($table, $attributes)
        );
    }

    private function getObjectsWithAttributes(string $table, array $attributes)
    {
        $table = $this->newQuery()->table($table);

        foreach ($attributes as $key => $value) {
            $table->where($key, $value);
        }

        return $table->select();
    }

    private function newQuery()
    {
        return $this->server->newConnection()->newQuery();
    }

    protected function assertDatabaseMissing(string $table, array $attributes = [])
    {
        $this->assertEmpty(
            $this->getObjectsWithAttributes($table, $attributes)
        );
    }
}
