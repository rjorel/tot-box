<?php

namespace Tests\Rest;

class UserTest extends TestCase
{
    /**
     * @test
     */
    public function listUsers()
    {
        $response = $this->get('/users');

        $this->assertJsonResponse([
            [
                'id'    => '1',
                'email' => 'john.doe@example.com',
                'name'  => 'John Doe',
            ],
            [
                'id'    => '2',
                'email' => 'james.smith@society.com',
                'name'  => 'James Smith',
            ]
        ], $response);
    }

    /**
     * @test
     */
    public function showUsers()
    {
        $response = $this->get('/users/1');

        $this->assertJsonResponse([
            'id'    => '1',
            'email' => 'john.doe@example.com',
            'name'  => 'John Doe',
        ], $response);

        $response = $this->get('/users/2');

        $this->assertJsonResponse([
            'id'    => '2',
            'email' => 'james.smith@society.com',
            'name'  => 'James Smith'
        ], $response);
    }

    /**
     * @test
     */
    public function addUser()
    {
        $this->post('/users', [
            'email' => 'darth.vader@death-star.com',
            'name'  => 'Darth Vader'
        ]);

        $this->assertDatabaseHas('users', [
            'id'    => 3,
            'email' => 'darth.vader@death-star.com',
            'name'  => 'Darth Vader'
        ]);
    }

    /**
     * @test
     */
    public function updateUser()
    {
        $this->put('/users/2', [
            'email' => 'james.smith@another-society.com',
            'name'  => 'James Williams Smith'
        ]);

        $this->assertDatabaseHas('users', [
            'id'    => 2,
            'email' => 'james.smith@another-society.com',
            'name'  => 'James Williams Smith'
        ]);
    }

    /**
     * @test
     */
    public function deleteUser()
    {
        $this->delete('/users/1');

        $this->assertDatabaseMissing('users', [
            'id' => 1
        ]);
    }
}