<?php

ini_set('display_errors', true);

require __DIR__ . '/../vendor/autoload.php';

$server = require __DIR__ . '/../bootstrap/server.php';

$response = $server->execute(
    Rest\Core\Request::makeFromGlobals()
);

echo $response;