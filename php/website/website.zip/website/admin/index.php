<?php

/**
 * Contrôleur de la partie dédiée à l'administration.
 */
require_once __DIR__ . '/../lib/geshi/geshi.php';
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/RCode.php';

// Variables globales pour l'accès aux deux services disponibles.
$db = new Database(
    getenv('DB_HOST'),
    getenv('DB_USERNAME'),
    getenv('DB_PASSWORD'),
    getenv('DB_DATABASE')
);

// Coloration syntaxique (les fichiers de code sont ainsi présentés avec une coloration de code).
$rcode = new RCode();

// Message utilisé dans certaines pages pour informer l'administrateur (un nom plus clair aurait pu être donné, j'en conviens).
$msg = '';

// Chemins d'accès aux fichiers rattachés aux sujets ainsi qu'aux images présentes dans les descriptions.
$FILES_PATH = '../storage/files/';
$UPLOADS_PATH = '../storage/uploads/';

/**
 * Gestion des sections
 * --------------------
 * Actions disponibles (dans l'ordre) :
 *  - ajout d'une section,
 *  - edition du nom d'une section,
 *  - edition d'une description de section,
 *  - "ascension" d'une section,
 *  - et sa "descente" (les termes sont peut-être mal choisis, l'anglais est plus simple pour le coup),
 *  - suppression d'une section (répercussion sur les sujets rattachés à la section et les fichiers rattachés aux sujets).
 */
if (!empty($_POST['section_name_add'])) {
    $db->addSection($_POST['section_name_add']);
} elseif (
    !empty($_POST['section_name_edit'])
    && !empty($_POST['section_id'])
) {
    $db->updateSectionName($_POST['section_id'], $_POST['section_name_edit']);
} elseif (
    !empty($_POST['editor_content'])
    && !empty($_POST['section_id'])
) {
    $db->updateSectionDescription($_POST['section_id'], $_POST['editor_content']);
} elseif (!empty($_POST['section_id_up'])) {
    $db->upSection($_POST['section_id_up']);
} elseif (!empty($_POST['section_id_down'])) {
    $db->downSection($_POST['section_id_down']);
} elseif (!empty($_POST['section_id_delete'])) {
    foreach ($db->getTopicsBySection($_POST['section_id_delete']) as $topic) {
        // Les fichiers du topic sont supprimés.
        foreach ($db->getFilesByTopic($topic->topicID) as $file) {
            if (file_exists($FILES_PATH . $file->filePath)) {
                unlink($FILES_PATH . $file->filePath);
            }
        }
    }

    $db->deleteSection($_POST['section_id_delete']);
}

/**
 * Gestion des sujets
 * ------------------
 * Actions disponibles (dans l'ordre) :
 *  - ajout d'un sujet,
 *  - edition du nom d'un sujet,
 *  - edition d'une description de sujet,
 *  - suppression d'un sujet (répercussion sur les fichiers rattachés).
 */
if (
    !empty($_POST['topic_name_add'])
    && !empty($_POST['section_id'])
) {
    $db->addTopic($_POST['topic_name_add'], $_POST['section_id']);
} elseif (
    !empty($_POST['topic_name_edit'])
    && !empty($_POST['topic_id'])
) {
    $db->updateTopicName($_POST['topic_id'], $_POST['topic_name_edit']);
} elseif (
    !empty($_POST['editor_content'])
    && !empty($_POST['topic_id'])
) {
    $db->updateTopicContent($_POST['topic_id'], $_POST['editor_content']);
} elseif (!empty($_POST['topic_id_delete'])) {
    foreach ($db->getFilesByTopic($_POST['topic_id_delete']) as $file) {
        // Les fichiers du topic sont supprimés.
        if (file_exists($FILES_PATH . $file->filePath)) {
            unlink($FILES_PATH . $file->filePath);
        }
    }

    $db->deleteTopic($_POST['topic_id_delete']);
}

/**
 * Gestion des fichiers
 * --------------------
 * Actions disponibles (dans l'ordre) :
 *  - ajout d'un fichier (+ upload du fichier physique dans le dossier prévu à cet effet),
 *  - edition du nom d'un fichier,
 *  - suppression d'un fichier (et du fichier physique rattaché).
 */
if (
    isset($_FILES['file_path_add'])
    && $_FILES['file_path_add']['error'] == 0
    && !empty($_POST['topic_id'])
) {
    // Récupération de l'extension.
    $extension = pathinfo($_FILES['file_path_add']['name'], PATHINFO_EXTENSION);

    $filename = basename($_FILES['file_path_add']['name']);

    // Génération d'un chemin unique pour éviter l'écrasement d'un fichier existant.
    $filepath = uniqid() . '.' . $extension;

    // Ajout du fichier en base de données si l'upload se passe bien.
    if (move_uploaded_file($_FILES['file_path_add']['tmp_name'], $FILES_PATH . $filepath)) {
        $db->addFile($filename, $filepath, $_FILES['file_path_add']['size'], $_POST['topic_id']);
    } else {
        $msg = '<span style="color: red">An error occured during upload...</font>';
    }
} elseif (
    !empty($_POST['file_id_rename'])
    && !empty($_POST['file_name_rename'])
) {
    $db->renameFile($_POST['file_id_rename'], $_POST['file_name_rename']);
} elseif (!empty($_POST['file_id_delete'])) {
    $file = $db->getFileById($_POST['file_id_delete']);

    if (file_exists($FILES_PATH . $file->filePath)) {
        unlink($FILES_PATH . $file->filePath);
    }

    $db->deleteFile($file->fileID);
}

/**
 * Affichage des données suivant la requête.
 */

// Récupération de toutes les sections.
$sections = $db->getSections();

// URL de le forme http://site.fr/admin?section=[un-nombre] (ID d'une section).
if (!empty($_GET['section'])) {
    if ($curSection = $db->getSectionById($_GET['section'])) {
        $topicsForSection = $db->getTopicsBySection($curSection->sectionID);

        $rcode->setText($curSection->sectionDescription);
        include __DIR__ . '/views/section.php';
    } else {
        // Petit message d'erreur si l'administrateur s'est planté.
        $msg = '<span style="color: red">This section doesn\'t exist</span>';
        include __DIR__ . '/views/manage.php';
    }
} // URL de la forme http://site.fr/admin?topic=[un-nombre] (ID d'un sujet).
elseif (!empty($_GET['topic'])) {
    if ($curTopic = $db->getTopicById($_GET['topic'])) {
        $filesForTopic = $db->getFilesByTopic($curTopic->topicID);

        $rcode->setText($curTopic->topicContent);
        include __DIR__ . '/views/topic.php';
    } else {
        $msg = '<span style="color: red">This topic doesn\'t exist</span>';
        include __DIR__ . '/views/manage.php';
    }
} // URL de la forme http://site.fr/admin?files. Listage de tous les fichiers rattachés à des sujets.
elseif (isset($_GET['files'])) {
    $files = $db->getFiles();
    include __DIR__ . '/views/list.php';
} // URL de la forme http://site.fr/admin?topics. Listage de tous les sujets présents sur le site.
elseif (isset($_GET['topics'])) {
    $topics = $db->getTopics();
    include __DIR__ . '/views/list.php';
} // URL de la forme http://site.fr/admin?images. Gestion des images pour les descriptions des sections et sujets.
elseif (isset($_GET['images'])) {
    // Upload en cours.
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        // Des vérification sur le type peuvent être faite pour s'assurer qu'on a bien une image.
        $extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

        // Même idée que précédemment.
        $filename = uniqid() . '.' . $extension;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $UPLOADS_PATH . $filename)) {
            $msg = '<span style="color: green">File successfully uploaded...</span>';
        } else {
            $msg = '<span style="color: red">An error occured during upload...</span>';
        }
    }
    // Suppression d'une image, basé sur le nom. Cette façon de faire n'est pas géniale, mais elle évite d'écrire une
    // nouvelle table juste pour des images.
    elseif (isset($_GET['delete']) && !empty($_GET['name'])) {
        if (file_exists($UPLOADS_PATH . $_GET['name'])) {
            unlink($UPLOADS_PATH . $_GET['name']);
        }
    }

    // Récupération de toutes les images disponibles.
    $images = array_diff(scandir($UPLOADS_PATH), ['..', '.']);
    include __DIR__ . '/views/images.php';
} else {
    // Page par défaut, affichage d'un code de base en C avec Geshi.
    $geshi = new Geshi();
    $geshi->enable_line_numbers(GESHI_NORMAL_LINE_NUMBERS);
    $geshi->set_line_style('font-size: 15px;');
    $geshi->set_language('c');
    $geshi->set_source(
        "#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    printf(\"Hello man !\\n\");
    return 0;
}"
    );

    $msg = $geshi->parse_code();
    include __DIR__ . '/views/manage.php';
}