<!DOCTYPE html>

<html>
<head>
    <title>Management</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <link rel="stylesheet" type="text/css" href="/assets/css/admin.css" />
</head>

<body id="images">
<div id="body">
    <h2>Images</h2>
    <h3>Register an image :</h3>

    <form method="post" action="/admin/index.php?images" enctype="multipart/form-data">
        <input type="file" name="file" /><br />
        <input type="submit" value="Send" />
    </form>

    <?php echo "<b>" . $msg . "</b>"; ?>

    <h3>Registered images :</h3>
    <div id="images_block">
        <?php
        if (empty($images)) {
            echo "No images";
        } else {
            foreach ($images as $img) { ?>
                <p>
                    <span class="img">
                        <a href="<?php echo $UPLOADS_PATH . $img; ?>" target="_blank">
                            <img src="<?php echo $UPLOADS_PATH . $img; ?>" class="thumbnail" />
                        </a>
                    </span>

                    <a href="/admin/index.php?images&amp;delete&amp;name=<?php echo $img; ?>">
                        <input type="button" value="Delete" />
                    </a>
                </p>
                <?php
            }
        }
        ?>
    </div>
</div>

<?php include __DIR__ . '/include/menu.php'; ?>

</body>
</html>
