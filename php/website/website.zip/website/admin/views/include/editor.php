<?php $imgs = array_diff(scandir($UPLOADS_PATH), ['..', '.']); ?>

<div id="editor">
    <div>
        <input type="button" class="button" id="editor_bold_button" value="B" />
        <input type="button" class="button" id="editor_italic_button" value="I" />
        <input type="button" class="button" id="editor_underline_button" value="U" />
        <input type="button" class="button" id="editor_images_button" value="img" />
        <input type="button" class="button" id="editor_links_button" value="</>" />
    </div>

    <div id="editor_images">
        <div>
            <?php foreach ($imgs as $img) { ?>
                <img src="<?php echo $UPLOADS_PATH . $img; ?>" title="<?php echo $img; ?>" class="thumbnail" />
            <?php } ?>
        </div>

        <input type="button" id="editor_images_cancel" value="Cancel" />
    </div>

    <div id="editor_links">
        <label>Hyperlien</label> : <input type="text" id="editor_links_hyperlink" /><br />
        <label>Nom</label> : <input type="text" id="editor_links_name" /><br /><br />
        <input type="button" class="button" id="editor_links_confirm" value="Confirm" />
        <input type="button" class="button" id="editor_links_cancel" value="Cancel" />
    </div>

    <textarea name="editor_content" id="editor_content">
<?php if (!empty($editorContent)) {
    echo $editorContent;
} ?>
</textarea>
</div>
