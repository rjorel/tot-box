<div id="menu">
    <b>Sections :</b>

    <?php if (empty($sections)) {
        echo "No sections";
    } else { ?>
        <ul>
            <?php foreach ($sections as $section) { ?>
                <li>
                    <a href="/admin/index.php?section=<?php echo $section->sectionID; ?>">
                        <?php echo $section->sectionName; ?>
                    </a>
                </li>
            <?php } ?>
        </ul>
    <?php } ?>

    <b>Others :</b>
    <ul>
        <li><a href="/admin/index.php?topics">Topics</a></li>
        <li><a href="/admin/index.php?files">Files</a></li>
        <li><a href="/admin/index.php?images">Images</a></li>
    </ul>
    <br /><br />

    <input type="button" id="section_add_button" class="button" value="+ Add a section" autocomplete="off" />

    <form id="section_add_form" class="form" method="post" action="">
        <input type="text" name="section_name_add" /><br />
        <input type="submit" class="button" value="Add" />
    </form>
</div>

<script>
    var addSectionButton = document.getElementById('section_add_button');
    var addSectionForm = document.getElementById('section_add_form');

    addSectionButton.onclick = function () {
        addSectionForm.style.display = 'block';
    };
</script>
