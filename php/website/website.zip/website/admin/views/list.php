<!DOCTYPE html>

<html>
<head>
    <title>Management</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <link rel="stylesheet" type="text/css" href="/assets/css/admin.css" />
</head>

<body id="section">
<div id="body">
    <?php
    // Affichage des listes demandées. Je dois avoue que ce n'est pas hyper clair lu comme ça, mais c'est du pur PHP / HTML,
    // donc il ne faut pas être trop exigeant.
    if (isset($files)) {
        echo "<h2>Files</h2>";

        if (empty($files)) {
            echo "No files";
        } else {
            echo "<ul>";
            foreach ($files as $file) {
                ?>
                <li><a href="<?php echo $FILES_PATH . $file->filePath; ?>"
                       target="_blank"><?php echo $file->fileName; ?></a> ->
                    <a href="/admin/index.php?topic=<?php echo $file->topicID; ?>"><?php echo $file->topicName; ?></a>
                </li>
                <?php
            }
        }
        echo "</ul>";
    } elseif (isset($topics)) {
        echo "<h2>Topics</h2>";

        if (empty($topics)) {
            echo "No topics";
        } else {
            echo "<ul>";
            foreach ($topics as $topic) {
                ?>
                <li>
                    <a href="/admin/index.php?topic=<?php echo $topic->topicID; ?>"><?php echo $topic->topicName; ?></a>
                    ->
                    <a href="/admin/index.php?section=<?php echo $topic->sectionID; ?>"><?php echo $topic->sectionName; ?></a>
                </li>
                <?php
            }
        }
        echo "</ul>";
    }
    ?>
</div>

<?php include __DIR__ . '/include/menu.php'; ?>

</body>
</html>
