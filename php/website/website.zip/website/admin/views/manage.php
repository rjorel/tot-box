<!DOCTYPE html>

<html>
<head>
    <title>Management</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <link rel="stylesheet" type="text/css" href="/assets/css/admin.css" />
</head>

<body>
<div id="body">
    <h1>Main page</h1>
    <?php echo $msg; ?>
</div>

<?php include __DIR__ . '/include/menu.php'; ?>

</body>
</html>
