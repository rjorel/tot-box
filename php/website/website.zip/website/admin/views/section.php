<!DOCTYPE html>

<html>
<head>
    <title>Management</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <link rel="stylesheet" type="text/css" href="/assets/css/admin.css" />
    <link rel="stylesheet" type="text/css" href="/assets/css/editor.css" />
</head>

<body id="section">
<div id="body">
    <h1 id="name_section">
        <?php echo $curSection->sectionName; ?>
    </h1>

    <form id="name_edit_form" class="form" method="post" action="">
        <input type="text" id="section_name_edit" name="section_name_edit"
               value="<?php echo $curSection->sectionName; ?>" />
        <br />

        <input type="hidden" name="section_id" value="<?php echo $_GET['section']; ?>" />
        <input type="submit" class="button" value="Modify" />
    </form>

    <input type="button" id="change_name_button" class="button" value="Change section name" />
    <br /><br /><br />

    <div id="description"><?php echo nl2br($rcode->parseText("../")); ?></div>
    <br />

    <form id="description_edit_form" class="form" method="post" action="">
        <?php
        $editorContent = $curSection->sectionDescription;
        include __DIR__ . '/include/editor.php';
        ?>

        <input type="hidden" name="section_id" value="<?php echo $curSection->sectionID; ?>" />
        <input type="submit" class="button" value="Modify" />
    </form>

    <input type="button" id="change_description_button" class="button" value="Edit description" />
    <br /><br />

    <h2>Topics :</h2>

    <?php
    if (empty($topicsForSection)) {
        echo "No topics";
    } else {
        echo "<ul>";
        foreach ($topicsForSection as $topic) {
            ?>
            <li>
                <a href="/admin/index.php?topic=<?php echo $topic->topicID; ?>"><?php echo $topic->topicName; ?></a>
            </li>
            <?php
        }
    }
    echo "</ul>";
    ?>

    <br /><br />
    <input type="button" id="topic_add_button" class="button" value="Create a topic" />

    <form id="topic_add_form" class="form" method="post" action="">
        <input type="text" name="topic_name_add" />
        <input type="hidden" name="section_id" value="<?php echo $curSection->sectionID; ?>" />
        <input type="submit" class="button" value="Create" />
    </form>

    <br /><br /><br /><br />

    <form method="post" action="/admin/index.php?section=<?php echo $curSection->sectionID; ?>">
        <input type="hidden" name="section_id_up" value="<?php echo $curSection->sectionID; ?>" />
        <input type="submit" class="button" value="Up section" />
    </form>

    <form method="post" action="/admin/index.php?section=<?php echo $curSection->sectionID; ?>">
        <input type="hidden" name="section_id_down" value="<?php echo $curSection->sectionID; ?>" />
        <input type="submit" class="button" value="Down section" />
    </form>

    <form method="post" action="/admin/index.php">
        <input type="hidden" name="section_id_delete" value="<?php echo $curSection->sectionID; ?>" />
        <input type="submit" class="button" value="Delete section" />
    </form>
</div>

<?php include __DIR__ . '/include/menu.php'; ?>

<script src="/assets/js/editor.js"></script>
<script>
    var nameSection = document.getElementById('name_section');
    var nameEditForm = document.getElementById('name_edit_form');
    var changeNameButton = document.getElementById('change_name_button');

    var description = document.getElementById('description');
    var descriptionEditForm = document.getElementById('description_edit_form');
    var changeDescriptionButton = document.getElementById('change_description_button');

    var addTopicButton = document.getElementById('topic_add_button');
    var addTopicForm = document.getElementById('topic_add_form');

    changeNameButton.onclick = function () {
        nameSection.style.display = 'none';
        nameEditForm.style.display = 'block';
        changeNameButton.style.display = 'none';
    };

    changeDescriptionButton.onclick = function () {
        description.style.display = 'none';
        descriptionEditForm.style.display = 'block';
        changeDescriptionButton.style.display = 'none';
    };

    addTopicButton.onclick = function () {
        addTopicForm.style.display = 'block';
    };
</script>
</body>
</html>
