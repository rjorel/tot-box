<!DOCTYPE html>

<html>
<head>
    <title>Management</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <link rel="stylesheet" type="text/css" href="/assets/css/admin.css" />
    <link rel="stylesheet" type="text/css" href="/assets/css/editor.css" />
</head>

<body id="topic">
<div id="body">
    <h1 id="name_topic">
        <?php echo $curTopic->topicName; ?>
    </h1>

    <form id="name_edit_form" class="form" method="post" action="">
        <input type="text" id="topic_name_edit" name="topic_name_edit" value="<?php echo $curTopic->topicName; ?>" />
        <br />

        <input type="hidden" name="topic_id" value="<?php echo $_GET['topic']; ?>" />
        <input type="submit" class="button" value="Modify" />
    </form>

    <input type="button" id="change_name_button" class="button" value="Change topic name" />
    <br /><br /><br />

    <div id="content"><?php echo nl2br($rcode->parseText("../")); ?></div>
    <br />

    <form id="content_edit_form" class="form" method="post" action="">
        <?php
        $editorContent = $curTopic->topicContent;
        include __DIR__ . '/include/editor.php';
        ?>

        <input type="hidden" name="topic_id" value="<?php echo $curTopic->topicID; ?>" />
        <input type="submit" class="button" value="Modify" />
    </form>

    <input type="button" id="change_content_button" class="button" value="Edit content" />
    <br /><br />

    <h2>Files :</h2>

    <?php
    if (empty($filesForTopic)) {
        echo "Aucun fichier";
    } else {
        echo "<ul>";
        foreach ($filesForTopic as $file) {
            ?>
            <li>
                <a href="<?php echo $FILES_PATH . $file->filePath; ?>" target="_blank">
                    <?php echo $file->fileName; ?>
                </a>
                - size : <?php echo $file->fileSize; ?> bytes

                <form method="post" action="">
                    <input type="hidden" name="file_id_rename" value="<?php echo $file->fileID; ?>" />
                    <input type="text" name="file_name_rename" />
                    <input type="submit" class="button" value="Rename" />
                </form>

                <form method="post" action="">
                    <input type="hidden" name="file_id_delete" value="<?php echo $file->fileID; ?>" />
                    <input type="submit" class="button" value="Delete" />
                </form>
            </li>
            <?php
        }
    }
    echo "</ul>";
    ?>

    <br /><br />
    <input type="button" id="file_add_button" class="button" value="Add a file" />

    <?php echo $msg; ?>

    <form id="file_add_form" class="form" method="post" action="" enctype="multipart/form-data">
        <input type="file" name="file_path_add" /><br />
        <input type="hidden" name="topic_id" value="<?php echo $curTopic->topicID; ?>" />
        <input type="submit" class="button" value="Add" />
    </form>

    <br /><br /><br />

    <form method="post" action="/admin/index.php">
        <input type="hidden" name="topic_id_delete" value="<?php echo $curTopic->topicID; ?>" />
        <input type="submit" class="button" value="Delete topic" />
    </form>
</div>

<?php include __DIR__ . '/include/menu.php'; ?>

<script src="/assets/js/editor.js"></script>
<script>
    var nameTopic = document.getElementById('name_topic');
    var nameEditForm = document.getElementById('name_edit_form');
    var changeNameButton = document.getElementById('change_name_button');

    var content = document.getElementById('content');
    var contentEditForm = document.getElementById('content_edit_form');
    var changeContentButton = document.getElementById('change_content_button');

    var addFileButton = document.getElementById('file_add_button');
    var addFileForm = document.getElementById('file_add_form');

    changeNameButton.onclick = function () {
        nameTopic.style.display = 'none';
        nameEditForm.style.display = 'block';
        changeNameButton.style.display = 'none';
    };

    changeContentButton.onclick = function () {
        content.style.display = 'none';
        contentEditForm.style.display = 'block';
        changeContentButton.style.display = 'none';
    };

    addFileButton.onclick = function () {
        addFileForm.style.display = 'block';
    };
</script>
</body>
</html>
