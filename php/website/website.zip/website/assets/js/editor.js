/*
    Insertion functions.
*/
function insertTag(startTag, endTag) {
    var startSelection = editorContent.value.substring(0, editorContent.selectionStart);
    var selection = editorContent.value.substring(editorContent.selectionStart, editorContent.selectionEnd);
    var endSelection = editorContent.value.substring(editorContent.selectionEnd);

    editorContent.value = startSelection + startTag + selection + endTag + endSelection;
    editorContent.setSelectionRange(
        startSelection.length + startTag.length, startSelection.length + startTag.length + selection.length);
}

function insertString(str) {
    var startSelection = editorContent.value.substring(0, editorContent.selectionStart);
    var endSelection = editorContent.value.substring(editorContent.selectionStart);
    editorContent.value = startSelection + str + endSelection;
}

/*
    Functions to handle click and insert.
*/
function clickImage(img) {
    img.onclick = function () {
        insertString('[img]storage/uploads/' + img.title + '[/img]');
        images.style.display = 'none';
    };
}

/*
    Script beginning
*/
var editorContent = document.getElementById('editor_content');

var boldButton = document.getElementById('editor_bold_button');
var italicButton = document.getElementById('editor_italic_button');
var underlineButton = document.getElementById('editor_underline_button');

var images = document.getElementById('editor_images');
var imagesButton = document.getElementById('editor_images_button');
var imagesCancel = document.getElementById('editor_images_cancel');
var imagesList = document.getElementById('editor_images').getElementsByTagName('img');

var links = document.getElementById('editor_links');
var linksButton = document.getElementById('editor_links_button');
var linksConfirm = document.getElementById('editor_links_confirm');
var linksCancel = document.getElementById('editor_links_cancel');
var linksHyperlink = document.getElementById('editor_links_hyperlink');
var linksName = document.getElementById('editor_links_name');

/*
    Text formatting handling.
*/
boldButton.onclick = function () {
    insertTag('[b]', '[/b]');
};
italicButton.onclick = function () {
    insertTag('[i]', '[/i]');
};
underlineButton.onclick = function () {
    insertTag('[u]', '[/u]');
};

imagesCancel.onclick = function () {
    images.style.display = 'none';
};
imagesButton.onclick = function () {
    images.style.display = (images.style.display == 'block') ? 'none' : 'block';
    links.style.display = 'none';
};

linksCancel.onclick = function () {
    links.style.display = 'none';
};
linksButton.onclick = function () {
    links.style.display = (links.style.display == 'block') ? 'none' : 'block';
    images.style.display = 'none';
};

linksConfirm.onclick = function () {
    insertString('[url name="' + linksName.value + '"]' + linksHyperlink.value + '[/url]');
    links.style.display = 'none';
};

for (var i = 0, l = imagesList.length; i < l; i++) {
    clickImage(imagesList[i]);
}
