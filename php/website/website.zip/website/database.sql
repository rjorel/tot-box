--
-- Structure de la table `Sections`
--
CREATE TABLE IF NOT EXISTS `Sections`
(
    `sectionID`          int(11)      NOT NULL auto_increment,
    `sectionName`        varchar(255) NOT NULL,
    `sectionPosition`    int(11)      NOT NULL,
    `sectionDescription` text,
    PRIMARY KEY (`sectionID`)
) CHARACTER SET UTF8;

--
-- Structure de la table `Topics`
--
CREATE TABLE IF NOT EXISTS `Topics`
(
    `topicID`      int(11)      NOT NULL auto_increment,
    `topicName`    varchar(255) NOT NULL,
    `topicContent` text,
    `sectionID`    int(11)      NOT NULL,
    PRIMARY KEY (`topicID`),
    FOREIGN KEY (`sectionID`) REFERENCES `Sections` (`sectionID`)
) CHARACTER SET UTF8;

--
-- Structure de la table `Files`
--
CREATE TABLE IF NOT EXISTS `Files`
(
    `fileID`   int(11)      NOT NULL auto_increment,
    `fileName` varchar(255) NOT NULL,
    `filePath` varchar(255) NOT NULL,
    `fileSize` int(11)      NOT NULL,
    `topicID`  int(11)      NOT NULL,
    PRIMARY KEY (`fileID`),
    FOREIGN KEY (`topicID`) REFERENCES `Topics` (`topicID`)
) CHARACTER SET UTF8;
