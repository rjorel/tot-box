<?php

// Redirection vers la partie d'administration (simple saut dans le dossier ./admin/).
// Pour cet exemple, la partie administration n'est pas protégée... chose à bien évidemment éviter en situation réelle.
if (isset($_GET['admin'])) {
    header('Location: admin/index.php');
    exit(0);
}

require_once __DIR__ . '/lib/geshi/geshi.php';
require_once __DIR__ . '/lib/Database.php';
require_once __DIR__ . '/lib/RCode.php';

// Point d'accès à la base de données et au formatage du texte.
$db = new Database(
    getenv('DB_HOST'),
    getenv('DB_USERNAME'),
    getenv('DB_PASSWORD'),
    getenv('DB_DATABASE')
);

// Coloration syntaxique (les fichiers de code sont ainsi présentés avec une coloration de code).
$rcode = new RCode();

// Sections disponibles.
$sections = $db->getSections();

// Valeurs par défaut pour la page à afficher et les titre et sous-titres (dans le header).
$page = 'views/pages/welcome.php';
$title = 'Bienvenue à vous';
$subtitle = '';

// Chemin où se trouve les fichiers sotckés, rattachés aux différents sujets exposés sur le site (par sections).
$FILES_PATH = '/storage/files/';

// URL de le forme http://site.fr?section=[un-nombre] (ID d'une section).
if (isset($_GET['section'])) {
    $section = $db->getSectionById($_GET['section']);

    // La classe Database renvoit des objets nuls si les IDs ne correspondent à rien en BDD.
    if (empty($section)) {
        $page = 'views/pages/error.php';
        $title = 'Erreur de section';
    } // URL de la forme http://site.fr?section=[un-nombre]&topic=[un-nombre] (ID d'un sujet).
    elseif (isset($_GET['topic'])) {
        $topic = $db->getTopicById($_GET['topic']);
        $title = $section->sectionName;

        // Vérifions quand même que le sujet correspond à la section (des petits malins pourrait s'amuser à trafiquer les URLs).
        if (empty($topic) || ($topic->sectionID != $section->sectionID)) {
            $page = 'views/pages/error.php';
            $title = 'Erreur de sujet';
        } else {
            // Parsage du texte du sujet.
            $rcode->setText($topic->topicContent);
            $topic->topicContent = nl2br($rcode->parseText());
            $files = $db->getFilesByTopic($topic->topicID);
            $page = 'views/pages/topic.php';           // Page PHP gérant le sujet via les variables $topic et $files.
            $subtitle = '>> ' . $topic->topicName;      // Nom du sujet en tant que sous-titre dans le header.
        }
    } else {
        // Parsage du texte de la section.
        $rcode->setText($section->sectionDescription);
        $section->sectionDescription = nl2br($rcode->parseText());
        $topics = $db->getTopicsBySection($section->sectionID);
        $page = 'views/pages/section.php';             // Page PHP gérant la section via les variables $section et $topics.
    }
} // Page de contact, gestion via $_POST. Cette façon de faire est on ne peut plus basique.
elseif (isset($_GET['contact'])) {
    $msg = 'Si jamais vous avez une question, une remarque, besoin d\'aide, sur un sujet ou plus, contactez-moi...';

    // Si ces variables ne sont pas vides, l'utilisateur a soumis le formulaire.
    if (
        !empty($_POST['email'])
        && !empty($_POST['email2'])
        && !empty($_POST['content'])
    ) {
        $content = '<u>adresse :</u> ' . $_POST['email'] . ', ' . $_POST['email2'] . '<br/><br />' . $_POST['content'];
        $headers = 'Content-Type: text/html; charset=\'UTF-8\'' . '\n';

        if (mail('raphael.jorel@laposte.net', 'message Free', $content, $headers)) {
            $msg = 'Merci pour votre message...';
        } else {
            $msg = 'Merci pour votre message... mais il y a eu un problème (cause non-déterminée). Pourriez-vous recommencer ?';
        }
    }

    $page = 'views/pages/contact.php';     // Page PHP avec le formulaire.
    $title = 'Contactez-moi';
} // Visualisateur de fichiers. URL de la forme http://site.fr?viewer=[un-nombre] (ID d'un fichier).
elseif (isset($_GET['viewer'])) {
    if (isset($_GET['file'])) {
        $file = $db->getFileById($_GET['file']);

        // Y'en a qui s'amusent avec les URLs parfois.
        if (empty($file)) {
            $page = 'views/pages/error.php';
            $title = 'Erreur de fichier';
        } else {
            // Parsage du code avec quelques options Geshi.
            $geshi = new Geshi();
            $geshi->set_header_type(GESHI_HEADER_DIV);
            $geshi->enable_line_numbers(GESHI_NORMAL_LINE_NUMBERS);
            $geshi->set_line_style('font-size: 12px;');
            $geshi->set_tab_width(4);
            $geshi->load_from_file($FILES_PATH . $file->filePath);
            $content = $geshi->parse_code();
            $page = 'views/pages/file.php';
            $title = $file->fileName;
        }
    } else {
        $page = 'views/pages/error.php';
        $title = 'Erreur, aucun fichier spécifié';
    }
} // S'il y a des variables en $_GET non-gérées, on affiche une erreur (l'utilisateur tente peut-être une manip' non autorisée).
elseif (!empty($_GET)) {
    $page = 'views/pages/error.php';
    $title = 'Erreur, c\'est vraiment n\'importe quoi là !';
}

// Inclusion du layout du site.
include __DIR__ . '/views/layout.php';