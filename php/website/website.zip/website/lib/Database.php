<?php

/**
 * Gestion de la base de données.
 * Utilisation de l'interface mysql non-objet à cause de Free (premier hébergeur du site).
 * L'objet PDO propose une gestion objet bien plus appréciable, à préférer bien évidemment à celle utilisée ici.
 */
class Database
{
    private $pdo;

    public function __construct($host, $username, $password, $database)
    {
        try {
            $this->pdo = mysql_connect($host, $username, $password, $database);

            mysql_select_db($database, $this->pdo);
        } catch (Exception $e) {
            die("Error" . $e->getMessage());
        }
    }

    public function __destruct()
    {
        mysql_close($this->pdo);
    }

    public function getSections()
    {
        return $this->fetchAll(
            mysql_query("SELECT * FROM Sections ORDER BY sectionPosition", $this->pdo)
        );
    }

    private function fetchAll($req)
    {
        // Fetching de tableaux.
        if ($req == null) {
            return null;
        }

        $data = [];
        while ($row = mysql_fetch_object($req)) {
            $data[] = $row;
        }

        mysql_free_result($req);
        return $data;
    }

    public function addSection($sectionName)
    {
        $res = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM Sections"));
        mysql_query("INSERT INTO Sections(sectionName, sectionPosition) VALUES('$sectionName', $res[0])", $this->pdo);
    }

    public function updateSectionName($sectionID, $sectionName)
    {
        mysql_query("UPDATE Sections SET sectionName = '$sectionName' WHERE sectionID = $sectionID", $this->pdo);
    }

    public function updateSectionDescription($sectionID, $sectionDescription)
    {
        mysql_query(
            "UPDATE Sections SET sectionDescription = '$sectionDescription' WHERE sectionID = $sectionID",
            $this->pdo
        );
    }

    /**
     * Récupération de la position de la section juste au-dessus de celle qu'on veut déplacer, et échange.
     */
    public function upSection($sectionID)
    {
        $section1 = $this->getSectionById($sectionID);

        if ($section1->sectionPosition == 0) {
            return;
        }

        $num = $section1->sectionPosition - 1;

        $section2 = $this->fetch(
            mysql_query("SELECT * FROM Sections WHERE sectionPosition = $num", $this->pdo)
        );

        mysql_query(
            "UPDATE Sections SET sectionPosition = $section2->sectionPosition WHERE sectionID = $section1->sectionID",
            $this->pdo
        );
        mysql_query(
            "UPDATE Sections SET sectionPosition = $section1->sectionPosition WHERE sectionID = $section2->sectionID",
            $this->pdo
        );
    }

    public function getSectionById($sectionID)
    {
        return $this->fetch(
            mysql_query("SELECT * FROM Sections WHERE sectionID = $sectionID", $this->pdo)
        );
    }

    private function fetch($req)
    {
        // Fetching en mode objet. Une seule valeur est fetchée ici.
        if ($req == null) {
            return null;
        }

        $data = mysql_fetch_object($req);
        mysql_free_result($req);
        return $data;
    }

    /**
     * Même idée avec la section en-dessous.
     */
    public function downSection($sectionID)
    {
        $section1 = $this->getSectionById($sectionID);
        $res = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM Sections"));     // Nombre de sections.

        if ($section1->sectionPosition == $res[0] - 1) {
            return;
        }

        $num = $section1->sectionPosition + 1;
        $section2 = $this->fetch(
            mysql_query("SELECT * FROM Sections WHERE sectionPosition = $num", $this->pdo)
        );

        mysql_query(
            "UPDATE Sections SET sectionPosition = $section2->sectionPosition WHERE sectionID = $section1->sectionID",
            $this->pdo
        );
        mysql_query(
            "UPDATE Sections SET sectionPosition = $section1->sectionPosition WHERE sectionID = $section2->sectionID",
            $this->pdo
        );
    }

    /**
     * Suppression en cascade des sujets et fichiers dépendants de la section.
     */
    public function deleteSection($sectionID)
    {
        mysql_query(
            "DELETE FROM Files WHERE topicID IN (SELECT topicID FROM Topics WHERE sectionID = $sectionID)",
            $this->pdo
        );
        mysql_query("DELETE FROM Topics WHERE sectionID = $sectionID", $this->pdo);
        mysql_query("DELETE FROM Sections WHERE sectionID = $sectionID", $this->pdo);
    }

    public function getTopics()
    {
        return $this->fetchAll(
            mysql_query("SELECT * FROM (Topics JOIN Sections ON Topics.sectionID = Sections.sectionID)", $this->pdo)
        );
    }

    public function getTopicById($topicID)
    {
        return $this->fetch(
            mysql_query("SELECT * FROM Topics WHERE topicID = $topicID", $this->pdo)
        );
    }

    public function getTopicsBySection($sectionID)
    {
        return $this->fetchAll(
            mysql_query("SELECT * FROM Topics WHERE sectionID = $sectionID ORDER BY topicName", $this->pdo)
        );
    }

    public function addTopic($topicName, $sectionID)
    {
        mysql_query("INSERT INTO Topics(topicName, sectionID) VALUES('$topicName', $sectionID)", $this->pdo);
    }

    public function updateTopicName($topicID, $topicName)
    {
        mysql_query("UPDATE Topics SET topicName = '$topicName' WHERE topicID = $topicID", $this->pdo);
    }

    public function updateTopicContent($topicID, $topicContent)
    {
        mysql_query("UPDATE Topics SET topicContent = '$topicContent' WHERE topicID = $topicID", $this->pdo);
    }

    /**
     * Suppression en cascade des fichiers dépendants du sujet.
     */
    public function deleteTopic($topicID)
    {
        mysql_query("DELETE FROM Files WHERE topicID = $topicID", $this->pdo);
        mysql_query("DELETE FROM Topics WHERE topicID = $topicID", $this->pdo);
    }

    public function getFiles()
    {
        return $this->fetchAll(
            mysql_query("SELECT * FROM (Files JOIN Topics ON Files.topicID = Topics.topicID)", $this->pdo)
        );
    }

    public function getFileById($fileID)
    {
        return $this->fetch(mysql_query("SELECT * FROM Files WHERE fileID = $fileID", $this->pdo));
    }

    public function getFilesByTopic($topicID)
    {
        return $this->fetchAll(
            mysql_query("SELECT * FROM Files WHERE topicID = $topicID ORDER BY fileName", $this->pdo)
        );
    }

    public function addFile($fileName, $filePath, $fileSize, $topicID)
    {
        mysql_query(
            "INSERT INTO Files(fileName, filePath, fileSize, topicID) VALUES('$fileName', '$filePath', $fileSize, $topicID)",
            $this->pdo
        );
    }

    public function renameFile($fileID, $fileName)
    {
        mysql_query("UPDATE Files SET fileName = '$fileName' WHERE fileID = $fileID");
    }

    public function deleteFile($fileID)
    {
        mysql_query("DELETE FROM Files WHERE fileID = $fileID", $this->pdo);
    }
}
