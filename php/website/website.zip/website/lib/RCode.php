<?php

require_once __DIR__ . '/geshi/geshi.php';

/**
 * Sorte de BBCode simplifié, incluant le parsing de code source avec Geshi.
 */
class RCode
{
    private $text;
    private $geshi;

    public function __construct($text = "")
    {
        // Options de base.
        $this->text = $text;
        $this->geshi = new Geshi();
        $this->geshi->enable_line_numbers(GESHI_NORMAL_LINE_NUMBERS);
        $this->geshi->set_line_style("font-size: 15px;");
        $this->geshi->enable_keyword_links(false);
    }

    public function getText()
    {
        return $this->text;
    }

    public function setText($text)
    {
        $this->text = $text;
    }

    public function parseText($prefix = "")
    {
        $ret = $this->text;

        // Tags de formatage (italique, gras, souligné, ...).
        $simpleTags = [
            '/\[b\](.*)\[\/b\]/isU'                                                                => "<b>$1</b>",
            '/\[i\](.*)\[\/i\]/isU'                                                                => "<i>$1</i>",
            '/\[u\](.*)\[\/u\]/isU'                                                                => "<u>$1</u>",
            '/\[h1\](.*)\[\/h1\]/isU'                                                              => "<h1>$1</h1>",
            '/\[h2\](.*)\[\/h2\]/isU'                                                              => "<h2>$1</h2>",
            '/\[h3\](.*)\[\/h3\]/isU'                                                              => "<h3>$1</h3>",
            '/\[img( *title="((.|^")*)")?( *scale="(\d*)")?( *(left|right))? *\](.*)\[\/img\]/isU' =>
                "<a href=\"${prefix}$8\" target=\"_blank\"><img src=\"${prefix}$8\" title=\"$2\" width=\"$5px\" class=\"$7img\"/></a>",
            '/\[url\](.*)\[\/url\]/isU'                                                            => "<a href=\"$1\" target=\"_blank\">$1</a>",
            '/\[url name="(.*)"\](.*)\[\/url\]/isU'                                                => "<a href=\"$2\" target=\"_blank\">$1</a>"
        ];

        foreach ($simpleTags as $rtag => $htag) {
            $ret = preg_replace($rtag, $htag, $ret);
        }

        $substr = [];
        $start = $end = true;

        while ($start !== false && $end !== false) {        // Texte découpé en parties 'normal' et 'code'.
            $start = strpos($ret, "[code");
            $end = strpos($ret, "[/code]");

            if ($start !== false && $end !== false) {
                $substr[] = ['type' => "normal", 'val' => substr($ret, 0, $start)];
                $substr[] = ['type' => "code", 'val' => substr($ret, $start, $end - $start)];
                $ret = substr($ret, $end + 7);
            }
        }

        $substr[] = ['type' => "normal", 'val' => $ret];
        $substr2 = [];

        foreach ($substr as $str) {
            if ($str['type'] == "code") {
                // Récupération du langage dans str['val'], puis remplacement.
                if (preg_match("/\[code .*language.*\].*$/isU", $str['val'])) {
                    $str['language'] = preg_replace(
                        "/\[code language=\"(.*)\"\].*$/isU", "$1", $str['val']
                    );
                } else {
                    $str['language'] = "c";
                }

                $monoline = preg_match("/\[code .*monoline.*\].*$/isU", $str['val']);
                $str['val'] = preg_replace("/\[code.*\](.*)/isU", "$1", $str['val']);

                if ($monoline) {
                    $substr2[] = "<code>" . $str['val'] . "</code>";
                } else {
                    $this->geshi->set_language($str['language']);
                    $this->geshi->set_source($str['val']);
                    $substr2[] = $this->geshi->parse_code();
                }
            } else {
                $substr2[] = $str['val'];
            }
        }

        return implode($substr2);
    }
}