<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Raphael Jorel - <?php echo $title ?> <?php echo $subtitle; ?></title>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="author" lang="fr" content="Raphael Jorel" />
    <meta name="reply-to" content="raphael.jorel@laposte.net" />

    <link rel="stylesheet" type="text/css" href="/assets/css/style.css" />
</head>

<body>
<div id="site">
    <div id="banner">
        <img src="/assets/images/revolver.png" class="side" />
        <img src="/assets/images/banner.png" />
        <img src="/assets/images/revolver2.png" class="side" />
    </div>

    <div id="main">
        <div id="menu">
            <ul>
                <li><a href="/index.php">Accueil</a></li>

                <?php
                foreach ($sections as $s) {
                    echo "<li><a href='/index.php?section={$s->sectionID}'>{$s->sectionName}</a></li>";
                }
                ?>

                <li><a href="/index.php?contact">Contact</a></li>
            </ul>
        </div>

        <?php include $page; ?>
    </div>

    <div id="footpage">
        <a href="/index.php?admin">
            <img src="/assets/images/winchester.png" />
        </a>

        <img src="/assets/images/horseshoe.png" />
    </div>
</div>

</body>
</html>
