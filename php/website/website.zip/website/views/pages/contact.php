<div id="body">
    <?php echo $msg; ?>
    <br /><br />

    <form id="contact" method="post" action="/index.php?contact">
        <label>Adresse électronique :</label>
        <input type="text" name="email" size="50" maxlength="50" required />
        <br />

        <label>Confirmation :</label>
        <input type="text" name="email2" size="50" maxlength="50" required />
        <br />

        <label>Message :</label>
        <textarea name="content" required></textarea>
        <br />

        <input type="submit" value="Envoyer" />
    </form>
</div>
