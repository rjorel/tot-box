<div id="body">
    <img src="/assets/images/sad_girl.jpg" id="img_error" />

    <h2>Non mais oh, ça va ?!!</h2>

    <p>Vous vous croyez chez vous ?!! Vous avez fait une manip' interdite, avouez !</p>

    <p>
        Quand on vous autorise certaines actions sur un site, ce n'est pas pour que vous vous amusiez à en tenter
        d'autres. Vous ne pouvez pas tout simplement visiter celui-ci, sans chercher à mettre la zone ?
    </p>

    <p>
        Et puis regardez comment vous avez rendu triste cette jeune personne par votre mauvaise conduite. Vous devriez
        avoir honte.
    </p>

    <p>Je savais que quelqu'un dans votre genre essaierait un jour de faire le malin... dommage, j'avais TOUT prévu.</p>

    <p>
        C'est vraiment durla vie de développeur, en fait. Déjà qu'on se tape tout le code pour faire fonctionner un
        site, il faut penser en plus aux gens pas gentils qui vont forcément chercher à tout faire foirer. C'est plus
        une vie, sérieux !
    </p>

    <p>Allez, retournez sur les pages autorisées...</p>
</div>
