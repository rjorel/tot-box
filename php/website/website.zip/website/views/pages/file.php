<div id="body">
    <a href="<?php echo $FILES_PATH . $file->filePath; ?>" download="<?php echo $file->fileName; ?>">
        <input type="button" value="Télécharger" />
    </a>

    <?php echo $content; ?>

    <a href="<?php echo $FILES_PATH . $file->filePath; ?>" download="<?php echo $file->fileName; ?>">
        <input type="button" value="Télécharger" />
    </a>
</div>
