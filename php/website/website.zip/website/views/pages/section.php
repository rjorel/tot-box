<div id="body">
    <h1>
        <?php echo $section->sectionName; ?>
    </h1>

    <?php echo $section->sectionDescription; ?>
</div>

<div id="attachment">
    <h2>Sujet(s) :</h2>
    <ul>
        <?php
        if (empty($topics)) {
            echo "Aucun sujet dans cette section";
        } else {
            foreach ($topics as $t) {
                echo "<li><a href='/index.php?section={$section->sectionID}&topic={$t->topicID}'>{$t->topicName}</a></li>";
            }
        }
        ?>
    </ul>
</div>
