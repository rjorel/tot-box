<div id="body">
    <i><?php echo $section->sectionName ?></i>

    <h1>
        <?php echo $topic->topicName; ?>
    </h1>

    <?php echo $topic->topicContent; ?>
</div>

<?php if (!empty($files)) { ?>
<div id="attachment">
    <h2>Fichier(s) :</h2>
    <ul>
        <?php
        foreach ($files as $f) {
            switch (strtolower(pathinfo($f->fileName, PATHINFO_EXTENSION))) {
                case 'png':
                case 'jpg':
                case 'gif':
                case 'zip':
                case 'pdf':
                    echo "<li><a href='{$FILES_PATH}{$f->filePath}' target='_blank'>{$f->fileName}</a></li>";
                    break;
                default:
                    echo "<li><a href='/index.php?viewer&file={$f->fileID}'>{$f->fileName}</a></li>";
            }
        }
        ?>
    </ul>
    <?php } ?>
</div>
