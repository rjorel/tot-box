<div id="body">
    <img src="/assets/images/amstrad_cpc_6128.jpg" class="leftimg" />

    <h1>Bienvenue</h1>

    <p>
        Bonjour et bienvenue, noble visiteur. Que diriez-vous de vous arrêter dans ma taverne et prendre une petite
        bière ? Allez, cela ne se refuse pas... <br />
        Je vous présente ce modeste site, pour essayer de contribuer un peu à ma manière à l'enrichissement intellectuel
        général des gens de notre époque. L'internet est une bien belle invention, il serait dommage de ne pas en
        profiter.
    </p>

    <p>
        Chaque programmeur que nous devenons oublie un peu ce qu'il était avant. Et avant, il était parfois bien
        embarrassé devant de simples problèmes, faisant chauffer parfois sa cervelle plus que de raison. <br />
        Avec ce site, je souhaite juste partager ce que j'ai fait depuis que je suis dans l'informatique, en espérant
        que cela pourra aider quelqu'un un jour.
    </p>

    <p>
        Que vous soyez programmeur ou pas, les différents problèmes exposés pourraient peut-être vous intéresser, il
        vaut mieux tout de même avoir quelques bases en programmation informatique. Si jamais vous rencontrez un souci,
        vous pouvez toujours me contacter via le formulaire prévu à cet effet.
    </p>
</div>
