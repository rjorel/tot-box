#!/usr/bin/python

from app import create_app

application = create_app()
