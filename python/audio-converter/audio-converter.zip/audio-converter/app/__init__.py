import os

from flask import Flask

from .blueprints import endpoint


BASE_DIR = os.path.realpath(os.path.join(os.path.dirname(__file__), '..'))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'var')
TEMPLATE_FOLDER = os.path.join(BASE_DIR, 'templates')


def create_app():
    app = Flask(__name__, template_folder=TEMPLATE_FOLDER)
    app.secret_key = os.environ.get('APP_SECRET_KEY')  # Set secret key to enable session.

    app.config.update({
        'UPLOAD_FOLDER': UPLOAD_FOLDER
    })

    app.register_blueprint(endpoint)

    return app
