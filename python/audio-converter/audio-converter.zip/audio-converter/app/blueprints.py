import os

from flask import Blueprint, current_app, render_template, request, send_file

from .helpers import generate_random_string, get_now_date_string, redirect_with_flash, run_command


endpoint = Blueprint('endpoint', __name__)


@endpoint.route('/', methods=['GET'])
def index():
    return render_template('index.html')


@endpoint.route('/convert', methods=['POST'])
def convert():
    file = request.files['file']
    format = request.form['format']

    if not file:
        return redirect_with_flash('/', 'No file given.')

    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], generate_random_string())
    output_path = f'{file_path}.{format}'

    file.save(file_path)

    try:
        run_command(f'ffmpeg -i "{file_path}" "{output_path}"')
    except RuntimeError:
        return redirect_with_flash('/', 'An error occurred while processing file.')

    return send_file(
        output_path,
        as_attachment=True,
        attachment_filename=get_now_date_string() + f'.{format}'
    )
