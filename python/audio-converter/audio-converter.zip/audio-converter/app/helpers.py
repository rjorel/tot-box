from datetime import datetime
from random import choice
from string import ascii_letters, digits
from subprocess import Popen

from flask import flash, redirect


ALPHANUM_CHARS = f'{ascii_letters}{digits}'


def generate_random_string(length: int = 16):
    return ''.join([
        choice(ALPHANUM_CHARS) for _ in range(0, length)
    ])


def get_now_date_string():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def run_command(command: str):
    process = Popen(command, shell=True)
    process.wait()

    if process.returncode != 0:
        raise RuntimeError


def redirect_with_flash(to: str, flash_msg: str):
    flash(flash_msg)
    return redirect(to)
