
Remarque importante :
    Lors de la configuration de cMind, choisir "no" lorsque cMind nous demande "forbid any writting".


Arborescence

/ + ---- data        - Fichiers de données.
  |
  | ---- gen         - Dossier dans lequel sont mis tous les fichiers généré par les scripts et modules.
  |
  | ---- json        - Fichiers JSON de configuration
  |
  | ---- modules     - Module pour cMind écrit en Python.
  |
  | ---- scripts     - Scripts spécialisés dans une tâche en particulier.
  |
  | ---- sources     - Dossier contenant les fichiers sources du programme à tester.
  |
  | ---- launch.sh   - Commande général permettant de centraliser toutes les actions à faire.
  |
  | ---- README.txt  - Ce fichier.
  

-------------------------------------------------------
launch.sh

- Exécutable permettant de reproduire les expériences déjà faites.
- Il définit deux variables d'environnement, utiles aux autres scripts :
    * INSTALL_PATH -> chemin d'installation de cMind,
    * TOOL_DIR -> nom du dossier contenant cMind.
- Il fonctionne avec des arguments, l'option --help donne toutes les façon de l'utiliser.
- C'est principalement un wrapper vers les autres scripts.

-------------------------------------------------------
data

- Ce fichiers contiennent des vecteurs de double à sommer. Leur taille, conditionnement ainsi que résultat exact
  sont donnés dans le fichier.
- Ils sont tous nommés selon le modèle c(contionnement en log10)s(taille du vecteur).dat

-------------------------------------------------------
gen

- Dans ce dossier seront mis tous les fichiers générés, c'est-à-dire :
    * les fichiers JSON de configuration de run (à chaque nouvelle run),
    * les fichiers JSON de configuration de dataset (à l'installation des datasets seulement),
    * les fichiers de données récupérées des différentes exécutions,
    * les fichiers de commandes gnuplot afin d'automatiser les graphiques,
    * les graphiques.
    
-------------------------------------------------------
json

- Les fichiers JSON qui ne sont pas modifiés :
    * code.json -> configuration du projet
    * compiler.json -> configuration du compilateur, celui-ci définit principalement les flags que l'on veut explorer.
    * dataset.json -> fichier utilisé pour configurer les datasets, son contenu est chargé puis modifié et sauvegardé dans le dossier 'gen'.
    * explore_compiler_flags.sh -> fichier de base pour les configuration de run. Comme celui des datasets, son contenu est chargé et
                                   modifié pour être sauvegardé dans 'gen'. La seul différence vient du fait que cela est fait à
                                   chaque nouvelle run, tandis que le précédent n'est utilisé qu'à la configuration des datasets.
    * statistics.json -> description des graphs et espace à plotter. Un espace est la sauvegarde des différentes compilation faite
                         sur un ensemble de codes sources (projet).
    * statistics2.json -> même chose que le précédent, seulement il définit d'autres graphs (ou presque). Ces deux fichiers sont utilisés
                          dans des commandes différentes.
                          
-------------------------------------------------------
modules

- Les modules externes permettent de profiter de la puissance de l'outil cMind. Ils commencent tous par "cme." et peuvent accèder aux
  données des dépôts de cMind. C'est une façon très pratique d'étendre les possibilités de l'outil, il faut juste apprendre à parler
  avec.
- Les deux modules sont :
    * cme.explore_compiler_flags.py -> module écrit par G. Fursin (le concepteur de cMind), il nous permet d'explorer les flags
                                       du compilateur et de faire de la compilation itérative pour parcourir l'espace des flags en faisant
                                       des mesures de performances. Toutes les données récupérées sont stockées au format JSON.
    * cme.statistics.py -> module écrit par R. Jorel, celui-ci permet de générer des fichiers de statistiques à partir des datasets 
                           utilisés dans le cadre des algorithmes de sommation. Il récupère les informations des compilations itératives,
                           les mets en forme et créer des scripts Gnuplot pour plotter ces données. Il reste donc très dépendant du
                           projet sur les algorithmes de sommation.
                           
- Ceux-ci sont appelés de la manière qui suit : cm cme.statistics action @file.json
- Pour faire son propre module, il suffit de suivre l'exemple de celui du créateur. Chaque fonction écrite donne lieu à une action du
  module.
  
-------------------------------------------------------
scripts

- Scripts permettant de reproduire les expériences :
    * configure.sh -> configure le projet des algorithmes de sommation (création, déplacement des données) ainsi que le compilateur
                      avec les fichiers JSON correspondant vu précédemment. Il crée également la classe dataset.dat, auquel les datasets
                      spécifiques aux algorithmes de sommation seront assignés.
    * datasets.sh -> installe des datasets. Un script Python est appelé pour la bonne configuration de ceux-ci.
    * explore.sh -> lance d'une run sur les 6 algorithmes de sommation avec les datasets installés, à partir des fichiers de
                    configurations. Fait appel au module externe cme.explore_compiler_flags.py
    * gen_dataset_configuration.py -> lit le fichier de configuration de dataset (dataset.json) et le modifie pour ajouter quelques
                                      informations, telle la taille du vecteur à sommer et son conditionnement. Pour cela, il parse
                                      le nom du fichier de données. Etant tous sous la forme c(conditionnement)s(taille).dat, les
                                      expressions régulières sont utilisées.
    * gen_run_configuration.py -> lit le fichier de configuration de run (explore_compiler_flags.json) et le modifie à chaque nouvelle
                                  run, pour le faire correspondre aux différents algorithmes et datasets. Il sauvegarde le résultat dans
                                  le dossier 'gen'.
    * graphs.sh -> lance la génération des fichiers de données et scripts Gnuplot avec les fichiers descriptifs JSON correspondant,
                   puis appelle Gnuplot sur les scripts.
    * install.sh -> installe cMind à l'endroit spécifié par launch.sh. Vérifie si svn est installé, car ce dernier est indispensable
                    au téléchargement de cMind. Il lance ensuite la configuration de cMind. Il est nécessaire d'ajouter les deux
                    variables d'environnement que le script précise à la fin de l'installation avant chaque utilisation de cMind.
                    Le fichier ~/.bashrc peut par exemple être modifié.
                    
-------------------------------------------------------
sources

- Fichiers sources permettant la sommation de valeurs flottantes.
- 6 algorithmes sont utilisés :
    * acc sum,
    * fast acc sum,
    * hybrid sum,
    * ifast sum,
    * online exact two sum
    * online exact fast two sum.
    
