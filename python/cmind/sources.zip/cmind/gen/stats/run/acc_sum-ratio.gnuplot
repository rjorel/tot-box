set title 'acc_sum-ratio'
set xlabel 'n'
set ylabel 'cond (en log10)'
set zlabel 'Nombre de cycles'
set view 50,50,0.92
splot 'acc_sum-ratio.dat' using 1:2:3 title ''
replot 'acc_sum-ratio-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'acc_sum-ratio.eps'
replot
