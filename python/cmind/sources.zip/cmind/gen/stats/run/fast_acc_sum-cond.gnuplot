set title 'fast_acc_sum-cond'
set xlabel 'cond (en log10)'
set ylabel 'Nombre de cycles'
plot 'fast_acc_sum-cond.dat' title ''
replot 'fast_acc_sum-cond-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'fast_acc_sum-cond.eps'
replot
