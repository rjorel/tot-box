set title 'hybrid_sum-cond'
set xlabel 'cond (en log10)'
set ylabel 'Nombre de cycles'
plot 'hybrid_sum-cond.dat' title ''
replot 'hybrid_sum-cond-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'hybrid_sum-cond.eps'
replot
