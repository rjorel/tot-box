set title 'hybrid_sum-size-cond32'
set xlabel 'n'
set ylabel 'Nombre de cycles'
set logscale x
set logscale y
plot 'hybrid_sum-size-cond32.dat' title ''
replot 'hybrid_sum-size-cond32-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'hybrid_sum-size-cond32.eps'
replot
