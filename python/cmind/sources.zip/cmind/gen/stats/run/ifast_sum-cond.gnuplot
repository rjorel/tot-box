set title 'ifast_sum-cond'
set xlabel 'cond (en log10)'
set ylabel 'Nombre de cycles'
plot 'ifast_sum-cond.dat' title ''
replot 'ifast_sum-cond-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'ifast_sum-cond.eps'
replot
