set title 'online_exact_two_sum-cond'
set xlabel 'cond (en log10)'
set ylabel 'Nombre de cycles'
plot 'online_exact_two_sum-cond.dat' title ''
replot 'online_exact_two_sum-cond-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'online_exact_two_sum-cond.eps'
replot
