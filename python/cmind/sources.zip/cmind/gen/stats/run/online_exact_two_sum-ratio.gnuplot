set title 'online_exact_two_sum-ratio'
set xlabel 'n'
set ylabel 'cond (en log10)'
set zlabel 'Nombre de cycles'
set view 50,50,0.92
splot 'online_exact_two_sum-ratio.dat' using 1:2:3 title ''
replot 'online_exact_two_sum-ratio-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'online_exact_two_sum-ratio.eps'
replot
