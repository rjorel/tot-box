set title 'online_exact_two_sum-size-cond8'
set xlabel 'n'
set ylabel 'Nombre de cycles'
set logscale x
set logscale y
plot 'online_exact_two_sum-size-cond8.dat' title ''
replot 'online_exact_two_sum-size-cond8-O3.dat' title '-O3' with points lt 3
set term postscript color
set output 'online_exact_two_sum-size-cond8.eps'
replot
