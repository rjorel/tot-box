set title 'ratio'
set xlabel 'n'
set ylabel 'cond (en log10)'
set zlabel 'Nombre de cycles'
set view 50,50,0.92
splot 'acc_sum-ratio.dat' using 1:2:3 title 'acc_sum'
replot 'fast_acc_sum-ratio.dat' title 'fast_acc_sum'
replot 'hybrid_sum-ratio.dat' title 'hybrid_sum'
replot 'ifast_sum-ratio.dat' title 'ifast_sum'
replot 'online_exact_two_sum-ratio.dat' title 'online_exact_two_sum'
set term postscript color
set output 'ratio.eps'
replot
