set title 'size-cond32'
set xlabel 'n'
set ylabel 'Nombre de cycles'
set logscale x
set logscale y
plot 'acc_sum-size-cond32.dat' title 'acc_sum'
replot 'fast_acc_sum-size-cond32.dat' title 'fast_acc_sum'
replot 'hybrid_sum-size-cond32.dat' title 'hybrid_sum'
replot 'ifast_sum-size-cond32.dat' title 'ifast_sum'
replot 'online_exact_two_sum-size-cond32.dat' title 'online_exact_two_sum'
set term postscript color
set output 'size-cond32.eps'
replot
