set title 'size-cond8'
set xlabel 'n'
set ylabel 'Nombre de cycles'
set logscale x
set logscale y
plot 'acc_sum-size-cond8.dat' title 'acc_sum'
replot 'fast_acc_sum-size-cond8.dat' title 'fast_acc_sum'
replot 'hybrid_sum-size-cond8.dat' title 'hybrid_sum'
replot 'ifast_sum-size-cond8.dat' title 'ifast_sum'
replot 'online_exact_two_sum-size-cond8.dat' title 'online_exact_two_sum'
set term postscript color
set output 'size-cond8.eps'
replot
