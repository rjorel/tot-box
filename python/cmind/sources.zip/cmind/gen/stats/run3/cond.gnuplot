set title 'cond'
set xlabel 'cond (en log10)'
set ylabel 'Nombre de cycles'
plot 'acc_sum-cond.dat' title 'acc_sum'
replot 'fast_acc_sum-cond.dat' title 'fast_acc_sum'
replot 'hybrid_sum-cond.dat' title 'hybrid_sum'
replot 'ifast_sum-cond.dat' title 'ifast_sum'
replot 'online_exact_two_sum-cond.dat' title 'online_exact_two_sum'
set term postscript color
set output 'cond.eps'
set encoding utf8
replot
