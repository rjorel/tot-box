#!/bin/bash


export INSTALL_PATH=/opt
export TOOL_DIR=cmind

usage() {
   echo "Usage: launch.sh ACTION"
   echo "";
   echo "-i, --install  [ --root ]      Install cMind tool. Use --root if you are superuser to install in superuser directory"
   echo "-c, --configure                Configure project for summing algorithms"
   echo "-d, --datasets                 Install datasets"
   echo "-e, --explore-compiler-flags   Explore compiler flags for 6 summing algorithms"
   echo "-g| --graphs                   Make graphics from different executions"
   echo "-h, --help                     Display this help"
}


if [ $# -ge 1 ]; then
    case $1 in
        -i|--install) ./scripts/install.sh $2;;
        -c|--configure) ./scripts/configure.sh;;
        -d|--datasets) ./scripts/datasets.sh;;
        -e|--explore-compiler-flags) ./scripts/explore.sh;;
        -g|--graphs) ./scripts/graphs.sh;;
        -h|--help) usage;;
        *) echo -e "Bad operand\nTry 'launch.sh --help' for more information";;
    esac
else echo -e "Nothing to do\nTry 'launch.sh --help' for more information"
fi
