#!/usr/bin/env python2.7


import sys
import os
import json
import re



data = {};
    
dir = os.listdir("results");

for file in dir:
    f = open("results/" + file, "r");
    for line in f.readlines():
        if (re.match("\./a\.out", line)):
            algo = re.sub("\./a.out (\w*) .*\n", "\\1", line);
            size = re.sub(".*c\d*s(\d*)\.dat.*\n", "\\1", line);
            cond = re.sub(".*c(\d*)s\d*\.dat.*\n", "\\1", line);
        if (re.match(".*CPU_CLK_UNHALTED_CORE.*", line)):
            cycles = line.split("|")[2];
            
    if (size, cond) not in data: data[(size, cond)] = {};
    
    if(algo not in data[(size, cond)] or float(data[(size, cond)][algo]) < float(cycles)): data[(size, cond)][algo] = cycles;
    f.close();
    
algos = ["AccSum", "FastAccSum", "HybridSum", "iFastSum", "OnlineExactTwoSum"];
graphs = [ "size-cond8", "size-cond32", "cond-size1048576" ]
f = [ open("graphs/" + graphs[0] + ".dat", "w"), open("graphs/" + graphs[1] + ".dat", "w"), open("graphs/" + graphs[2] + ".dat", "w") ];

for (size, cond) in data:
    if (cond == "8"):
        f[0].write(size);
        for algo in algos: f[0].write(" " + data[(size, cond)][algo]);
        f[0].write("\n");
        
    elif (cond == "32"):
        f[1].write(size);
        for algo in algos: f[1].write(" " + data[(size, cond)][algo]);
        f[1].write("\n");
        
    if (size == "1048576"):
        f[2].write(cond);
        for algo in algos: f[2].write(" " + data[(size, cond)][algo]);
        f[2].write("\n");
        
for f1 in f: f1.close();

for graph in graphs:
    g = open("graphs/" + graph + ".gnuplot", "w");
    g.write(
"""set xlabel 'n'
set ylabel 'Nombre de cycles'
plot '{}.dat' title '{}' with linespoints
""".format(graph, algos[0]));

    for (i, algo) in enumerate(algos[1:]):
        g.write("replot '{}.dat' using 1:{} title '{}' with linespoints\n".format(graph, i + 3, algo));

    g.write(
"""set term postscript color
set output '{}.eps'
set encoding utf8
replot
""".format(graph));
