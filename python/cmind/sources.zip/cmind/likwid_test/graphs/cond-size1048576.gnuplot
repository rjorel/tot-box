set xlabel 'n'
set ylabel 'Nombre de cycles'
plot 'cond-size1048576.dat' title 'AccSum' with linespoints
replot 'cond-size1048576.dat' using 1:3 title 'FastAccSum' with linespoints
replot 'cond-size1048576.dat' using 1:4 title 'HybridSum' with linespoints
replot 'cond-size1048576.dat' using 1:5 title 'iFastSum' with linespoints
replot 'cond-size1048576.dat' using 1:6 title 'OnlineExactTwoSum' with linespoints
set term postscript color
set output 'cond-size1048576.eps'
set encoding utf8
replot
