set xlabel 'n'
set ylabel 'Nombre de cycles'
set logscale x
set logscale y
plot 'size-cond8.dat' title 'AccSum' with linespoints
replot 'size-cond8.dat' using 1:3 title 'FastAccSum' with linespoints
replot 'size-cond8.dat' using 1:4 title 'HybridSum' with linespoints
replot 'size-cond8.dat' using 1:5 title 'iFastSum' with linespoints
replot 'size-cond8.dat' using 1:6 title 'OnlineExactTwoSum' with linespoints
set term postscript color
set output 'size-cond8.eps'
set encoding utf8
replot
