#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sum.h"

#define NB_IT   1


enum
{
    ACC, FAST_ACC, IFAST, HYBRID, ONLINE_EXACT_TWO, ONLINE_EXACT_FAST_TWO
};


double (*algos[])(double *, unsigned int) = { AccSum, FastAccSum, iFastSum,
                                              HybridSum, OnlineExactTwoSum, OnlineExactFastTwoSum };
                                              
void initGeneratedVector(double **vector, const char *filename, unsigned int *size, double *cond, double *sum)
{
    FILE *file;
	int r;
	
	if ((file = fopen(filename, "rb")) == NULL) {
	    printf("%s: No such file or directory\n", filename);
	    exit(0);
    }
    
	r = fread(size, sizeof(unsigned int), 1, file);
	r = fread(cond, sizeof(double), 1, file);
	
	*vector = malloc(*size * sizeof(double));
	r = fread(*vector, sizeof(double), *size, file);
	r = fread(sum, sizeof(double), 1, file);
	fclose(file);
}


double doStats(const char *data, int numAlgo)
{
    double *vector, cond, sum, res;
    unsigned int size;

	initGeneratedVector(&vector, data, &size, &cond, &sum);
  likwid_markerStartRegion("1");
/* CM_TEMPLATE_KERNEL_START */
	res = algos[numAlgo](vector, size);
  likwid_markerStopRegion("1");
/* CM_TEMPLATE_KERNEL_END */
    free(vector);
    
    return res;
}


int main(int argc, char** argv)
{
	double s = 0;
	long ct_repeat = 0;
    long ct_repeat_max = 1;
    int ct_return = 0;

  likwid_markerInit();
/* CM_TEMPLATE_PROGRAM_START */

	if (argc != 3) exit(0);
//    if (getenv("CT_REPEAT_MAIN") != NULL) ct_repeat_max = atol(getenv("CT_REPEAT_MAIN"));

//    for (ct_repeat=0; ct_repeat<ct_repeat_max; ct_repeat++) {
	    if (!strcmp(argv[1], "AccSum")) s = doStats(argv[2], ACC);
	    else if (!strcmp(argv[1], "FastAccSum")) s = doStats(argv[2], FAST_ACC);
	    else if (!strcmp(argv[1], "iFastSum")) s = doStats(argv[2], IFAST);
	    else if (!strcmp(argv[1], "HybridSum")) s = doStats(argv[2], HYBRID);
	    else if (!strcmp(argv[1], "OnlineExactTwoSum")) s = doStats(argv[2], ONLINE_EXACT_TWO);
	    else if (!strcmp(argv[1], "OnlineExactFastTwoSum")) s = doStats(argv[2], ONLINE_EXACT_FAST_TWO);
	    
        printf("%lf\n", s);
//    }

  likwid_markerClose();
/* CM_TEMPLATE_PROGRAM_END */

    return 0;
}
