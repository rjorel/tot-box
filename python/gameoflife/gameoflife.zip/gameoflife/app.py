import os
import sys

from PyQt5.QtWidgets import QApplication

from gameoflife.core import GameWrapper, Shape
from gameoflife.widgets import Window


APP_DIR = os.path.dirname(os.path.realpath(__file__))
SHAPE_DIR = APP_DIR + '/shapes'


def get_shape_file_paths():
    file_names = sorted(os.listdir(SHAPE_DIR))

    return [
        SHAPE_DIR + '/' + file_name 
        for file_name in file_names
    ]


def build_shape_from_file(file_path):
    with open(file_path, 'r') as fd:
        values = list(map(int, fd.read().split()))

        coords = tuple([
            tuple(values[i:i + 2])
            for i in range(0, len(values), 2)
        ])

    return Shape(coords)


if __name__ == '__main__':
    app = QApplication(sys.argv)

    shapes = [None] + [
        build_shape_from_file(file_path)
        for file_path in get_shape_file_paths()
    ]

    game = GameWrapper(100, 200)
    window = Window(game, shapes, 1200, 600)

    sys.exit(app.exec_())
