from random import choice

from . import game


class Shape:

    def __init__(self, coords):
        self._coords = self._normalize(coords)

        self._width = self._compute_width()
        self._height = self._compute_height()

    def _normalize(self, coords):
        x_min = min(self._get_xs(coords))
        y_min = min(self._get_ys(coords))

        return [
            (y - y_min, x - x_min)
            for (y, x) in coords
        ]

    @staticmethod
    def _get_xs(coords):
        return list(map(lambda xy: xy[1], coords))

    @staticmethod
    def _get_ys(coords):
        return list(map(lambda xy: xy[0], coords))

    def _compute_width(self):
        xs = self._get_xs(self._coords)

        return max(xs) - min(xs)

    def _compute_height(self):
        ys = self._get_ys(self._coords)

        return max(ys) - min(ys)

    @property
    def coords(self):
        return self._coords

    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height


class ShapeSelector:

    def __init__(self, shapes):
        self._shapes = shapes
        self._current_shape_index = 0

    @property
    def current_shape(self):
        return self._shapes[self._current_shape_index]

    def select_previous_shape(self):
        self._move(-1)

    def _move(self, delta):
        self._current_shape_index += delta
        self._current_shape_index %= len(self._shapes)

    def select_next_shape(self):
        self._move(1)


class GameWrapper:

    def __init__(self, num_rows, num_columns):
        self._num_rows = num_rows
        self._num_columns = num_columns

        game.initialize(self._num_rows, self._num_columns)

    def __del__(self):
        game.release()

    @property
    def num_rows(self):
        return self._num_rows

    @property
    def num_columns(self):
        return self._num_columns

    def is_living_cell(self, row, column):
        return game.is_living_cell(row, column)

    def make_cell_alive(self, row, column):
        game.make_cell_alive(row, column)

    def reset_cells(self):
        game.reset_cells()

    def randomize_cells(self):
        game.randomize_cells()

    def evolve_cells(self):
        game.evolve_cells()
