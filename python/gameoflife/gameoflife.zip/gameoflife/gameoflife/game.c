#define PY_SSIZE_T_CLEAN
#include <Python.h>

#define DEAD_CELL   0
#define ALIVE_CELL  1

typedef uint8_t cell_t;

static unsigned int num_rows;
static unsigned int num_columns;
static unsigned int num_cells;

static cell_t *cells;
static cell_t *next_cells;

static PyObject *
game_initialize(PyObject *self, PyObject *const *args, Py_ssize_t nargs) {
    if (nargs != 2) {
        PyErr_SetString(PyExc_TypeError, "initialize() takes 2 positional arguments");
        return NULL;
    }

    num_rows = (unsigned int) PyLong_AsLong(args[0]);
    num_columns = (unsigned int) PyLong_AsLong(args[1]);
    num_cells = num_rows * num_columns;

    cells = calloc(num_cells, sizeof(cell_t));
    next_cells = calloc(num_cells, sizeof(cell_t));

    Py_RETURN_NONE;
}

static PyObject *
game_release(PyObject *module) {
    free(cells);
    free(next_cells);

    Py_RETURN_NONE;
}

static cell_t get_cell_at(int row, int column);

static PyObject *
game_is_living_cell(PyObject *self, PyObject *const *args, Py_ssize_t nargs) {
    if (nargs != 2) {
        PyErr_SetString(PyExc_TypeError, "is_living_cell() takes 2 positional arguments");
        return NULL;
    }

    unsigned int row = (unsigned int) PyLong_AsLong(args[0]);
    unsigned int column = (unsigned int) PyLong_AsLong(args[1]);

    if (get_cell_at(row, column) == ALIVE_CELL) {
        Py_RETURN_TRUE;
    }

    Py_RETURN_FALSE;
}

static int get_cell_offset(int row, int column);

cell_t get_cell_at(int row, int column) {
    return cells[get_cell_offset(row, column)];
}

int get_cell_offset(int row, int column) {
    return row * num_columns + column;
}

static PyObject *
game_make_cell_alive(PyObject *self, PyObject *const *args, Py_ssize_t nargs) {
    if (nargs != 2) {
        PyErr_SetString(PyExc_TypeError, "make_cell_alive() takes 2 positional arguments");
        return NULL;
    }

    unsigned int row = (unsigned int) PyLong_AsLong(args[0]);
    unsigned int column = (unsigned int) PyLong_AsLong(args[1]);

    cells[get_cell_offset(row, column)] = ALIVE_CELL;
    
    Py_RETURN_NONE;
}

static PyObject *
game_reset_cells(PyObject *module) {
    memset(cells, 0, num_cells * sizeof(char));

    Py_RETURN_NONE;
}

static PyObject *
game_randomize_cells(PyObject *module) {
    for (unsigned int cell_offset = 0; cell_offset < num_cells; cell_offset++) {
        cells[cell_offset] = (cell_t) rand() & 1;
    }

    Py_RETURN_NONE;
}

static int count_living_neighbors(int cell_offset);
static void swap_cell_buffers();

static PyObject *
game_evolve_cells(PyObject *module) {
    for (unsigned int offset = 0; offset < num_cells; offset++) {
        switch (count_living_neighbors(offset)) {
            case 2:
                next_cells[offset] = cells[offset];
                break;

            case 3:
                next_cells[offset] = 1;
                break;

            default:
                next_cells[offset] = 0;
                break;
        }
    }

    swap_cell_buffers();

    Py_RETURN_NONE;
}

static int get_cell_row(int cell_offset);
static int get_cell_column(int cell_offset);
static int get_cyclic_index(int index, unsigned int max_index);

int count_living_neighbors(int cell_offset) {
    int row = get_cell_row(cell_offset),
        column = get_cell_column(cell_offset);

    int left_row = get_cyclic_index(row - 1, num_rows),
        right_row = get_cyclic_index(row + 1, num_rows);

    int above_column = get_cyclic_index(column - 1, num_columns),
        below_column = get_cyclic_index(column + 1, num_columns);

    return get_cell_at(left_row, above_column)
        + get_cell_at(left_row, column)
        + get_cell_at(left_row, below_column)
        + get_cell_at(row, above_column)
        + get_cell_at(row, below_column)
        + get_cell_at(right_row, above_column)
        + get_cell_at(right_row, column)
        + get_cell_at(right_row, below_column);
}

int get_cell_row(int cell_offset) {
    return cell_offset / num_columns;
}

int get_cell_column(int cell_offset) {
    return cell_offset % num_columns;
}

int get_cyclic_index(int index, unsigned int max_index) {
    return (index + max_index) % max_index;
}

void swap_cell_buffers() {
    cell_t *tmp;
    
    tmp = cells;
    cells = next_cells;
    next_cells = tmp;
}

// Setup module.
static PyMethodDef game_methods[] = {
    { "initialize", (PyCFunction) game_initialize, METH_FASTCALL, "Initialize game" },
    { "release", (PyCFunction) game_release, METH_NOARGS, "Release game" },
    { "is_living_cell", (PyCFunction) game_is_living_cell, METH_FASTCALL, "Check if cell is alive" },
    { "make_cell_alive", (PyCFunction) game_make_cell_alive, METH_FASTCALL, "Make a cell alive" },
    { "reset_cells", (PyCFunction) game_reset_cells, METH_NOARGS, "Reset cells" },
    { "randomize_cells", (PyCFunction) game_randomize_cells, METH_NOARGS, "Randomize cells" },
    { "evolve_cells", (PyCFunction) game_evolve_cells, METH_NOARGS, "Evolve cells" },
    { NULL, NULL, 0, NULL }
};

static struct PyModuleDef game_module = {
    PyModuleDef_HEAD_INIT,
    "game",
    NULL,
    -1,
    game_methods
};

PyMODINIT_FUNC 
PyInit_game(void) {
    return PyModule_Create(&game_module);
}
