from PyQt5.QtCore import QBasicTimer, Qt
from PyQt5.QtGui import QColor, QCursor, QKeySequence, QPainter
from PyQt5.QtWidgets import QAction, QMainWindow, QVBoxLayout, QWidget

from .core import ShapeSelector


class Canvas(QWidget):

    def __init__(self, game, shape_selector):
        super().__init__()

        self._game = game
        self._shape_selector = shape_selector

        self._pressed_button = Qt.NoButton

        self.setMouseTracking(True)

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)

        self._show_cells(qp)
        self._show_current_selected_shape(qp)

        qp.end()

    def _show_cells(self, qp):
        self._fill_background(qp)
        self._fill_cell_rects(qp)

    def _fill_background(self, qp):
        qp.fillRect(
            0, 0,
            self.width(), self.height(),
            QColor(0, 0, 0)
        )

    def _fill_cell_rects(self, qp):
        (row_size, column_size) = self._get_cell_size()

        for i in range(0, self._game.num_rows):
            for j in range(0, self._game.num_columns):
                if self._game.is_living_cell(i, j):
                    qp.fillRect(
                        j * column_size, i * row_size,
                        column_size, row_size,
                        QColor(255, 255, 255)
                    )

    def _get_cell_size(self):
        return (
            self.height() // self._game.num_rows,
            self.width() // self._game.num_columns
        )

    def _show_current_selected_shape(self, qp):
        if not self._shape_selector.current_shape:
            return

        (row_size, column_size) = self._get_cell_size()
        current_shape = self._shape_selector.current_shape

        mouse_pos = self.mapFromGlobal(QCursor.pos())

        for (row, col) in current_shape.coords:
            qp.fillRect(
                # Show shape according to its center.
                mouse_pos.x() + (col - current_shape.width // 2) * column_size,
                mouse_pos.y() + (row - current_shape.height // 2) * row_size,
                column_size,
                row_size,
                QColor(255, 255, 255)
            )

    def mousePressEvent(self, event):
        self._pressed_button = event.button()

        if self._shape_selector.current_shape is None:
            return
        
        self._add_current_shape(event.x(), event.y())
        self.update()

    def _add_current_shape(self, x, y):
        current_shape = self._shape_selector.current_shape

        if current_shape is None:
            return

        (cell_row, cell_column) = self._compute_cell_position(x, y)

        for (row, column) in current_shape.coords:
            # Put shape according to its center.
            self._game.make_cell_alive(
                cell_row + row - current_shape.height // 2,
                cell_column + column - current_shape.width // 2
            )

    def _compute_cell_position(self, x, y):
        (row_size, column_size) = self._get_cell_size()

        return (
            y // row_size, 
            x // column_size
        )

    def mouseReleaseEvent(self, event):
        self._pressed_button = Qt.NoButton

    def mouseMoveEvent(self, event):
        # Avoid adding shapes more than once.
        if self._pressed_button == Qt.LeftButton \
            and self._shape_selector.current_shape is None:
            self._game.make_cell_alive(
                *self._compute_cell_position(event.x(), event.y())
            )

        self.update()

    def wheelEvent(self, event):
        if event.angleDelta().y() < 0:
            self._shape_selector.select_previous_shape()
        else:
            self._shape_selector.select_next_shape()

        self.update()


class Window(QMainWindow):
    _TIMER_DELAY_MS = 50

    def __init__(self, game, shapes, width=640, height=480):
        super().__init__()

        self._game = game
        self._shape_selector = ShapeSelector(shapes)

        self._canvas = Canvas(game, self._shape_selector)
        self._canvas.setFixedSize(width, height)

        self._init_ui()
        self._init_menu()
        self._init_bindings()

        self._timer = QBasicTimer()
        self._is_running = False

        self.show()

    def _init_ui(self):
        self._central_widget = QWidget()
        self._main_layout = QVBoxLayout()
        self._main_layout.addWidget(self._canvas)
        self._central_widget.setLayout(self._main_layout)

        self.setCentralWidget(self._central_widget)
        self.setWindowTitle('Game of life')

    def _init_menu(self):
        file_menu = self.menuBar().addMenu('File')
        game_menu = self.menuBar().addMenu('Game')

        self._new_button = QAction('New game', self)
        self._exit_button = QAction('Exit', self)
        self._play_pause_button = QAction('Play / Pause', self)
        self._random_button = QAction('Random configuration', self)

        self._new_button.setShortcut(QKeySequence.New)
        self._exit_button.setShortcut(QKeySequence.Quit)
        self._play_pause_button.setShortcut(Qt.Key_Return)
        self._random_button.setShortcut('R')

        file_menu.addAction(self._new_button)
        file_menu.addAction(self._exit_button)
        game_menu.addAction(self._play_pause_button)
        game_menu.addAction(self._random_button)

    def _init_bindings(self):
        self._exit_button.triggered.connect(self.close)

        self._new_button.triggered.connect(self.restart)
        self._play_pause_button.triggered.connect(self.play_pause)
        self._random_button.triggered.connect(self.random)

    def restart(self):
        self._stop_timer()

        self._game.reset_cells()
        self._canvas.update()

    def _stop_timer(self):
        self._timer.stop()
        self._is_running = False

    def play_pause(self):
        if self._is_running:
            self._stop_timer()
        else:
            self._start_timer()

    def _start_timer(self):
        self._timer.start(self._TIMER_DELAY_MS, self)
        self._is_running = True

    def random(self):
        self._stop_timer()

        self._game.randomize_cells()
        self._canvas.update()

    def timerEvent(self, event):
        if event.timerId() != self._timer.timerId():
            return

        self._game.evolve_cells()
        self._canvas.update()
