from distutils.core import Extension, setup


setup(
    name='Game of life',
    ext_modules=[
        Extension('gameoflife.game', sources=['gameoflife/game.c'])
    ]
)
