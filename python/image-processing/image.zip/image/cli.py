import argparse
import time

from image.core import AlgorithmExecutor


def parse_args():
    parser = argparse.ArgumentParser(description='Apply image processing')

    parser.add_argument('image', type=str, help='Image to process')
    parser.add_argument('algorithm', type=str, help='Algorithm to execute')
    parser.add_argument('-o', dest='output', type=str, help='Output file')

    return parser.parse_known_args()


if __name__ == '__main__':
    (args, remaining_args) = parse_args()

    executor = AlgorithmExecutor()
    start = time.time()

    image = executor.execute(args.image, args.algorithm, remaining_args)

    print('Elapsed time: {0}s'.format(time.time() - start))

    if args.output:
        image.save(args.output)
    else:
        image.show()
