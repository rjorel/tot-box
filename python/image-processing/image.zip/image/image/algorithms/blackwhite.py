import numpy as np

from . import mean


def process(image: np.ndarray, threshold: int = 128):
    means = mean.process(image)

    return (means >= threshold) * 255
