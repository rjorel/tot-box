import numpy as np


def process(image: np.ndarray, block_size: int = 1):
    rows, cols = image.shape[0], image.shape[1]

    output = np.zeros(image.shape, dtype=image.dtype)

    for row in range(0, rows):
        for col in range(0, cols):
            row_slice = slice(
                max(0, row - block_size),
                min(rows, row + block_size + 1)
            )

            col_slice = slice(
                max(0, col - block_size),
                min(cols, col + block_size + 1)
            )

            block = image[row_slice, col_slice]

            output[row, col] = block.sum(axis=(0, 1)) \
                               // (block.shape[0] * block.shape[1] or 1)

    return output
