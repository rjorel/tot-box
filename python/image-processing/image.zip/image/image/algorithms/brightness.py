import numpy as np


def process(image: np.ndarray, delta: int):
    return image + delta
