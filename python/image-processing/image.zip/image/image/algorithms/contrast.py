import numpy as np

from . import mean


def process(image: np.ndarray, delta: int, threshold: int = 127):
    means = mean.process(image)

    image[means < threshold] -= delta
    image[means > threshold] += delta

    return image
