import numpy as np

from . import mean


def process(image: np.ndarray):
    rows, cols = image.shape[0], image.shape[1]

    output = np.empty((rows, cols))

    mask_rows = np.array((
        1, 0, -1,
        2, 0, -2,
        1, 0, -1
    ))

    mask_cols = np.array((
        1, 2, 1,
        0, 0, 0,
        -1, -2, -1
    ))

    means = mean.process(image)

    for row in range(1, rows - 1):
        for col in range(1, cols - 1):
            block = means[row - 1:row + 2, col - 1:col + 2].flatten()

            d_row = _convolve(block, mask_rows)
            d_col = _convolve(block, mask_cols)

            output[row, col] = d_row * d_row + d_col * d_col

    return np.sqrt(output)


def _convolve(array1: np.ndarray, array2: np.ndarray):
    product = array1 * array2

    return product.sum()
