import numpy as np


def process(image: np.ndarray):
    if len(image.shape) < 3:
        return image

    # Color weights for channels are based on well-known heuristics.
    return image[:, :, 0] * 0.3 \
           + image[:, :, 1] * 0.59 \
           + image[:, :, 2] * 0.11
