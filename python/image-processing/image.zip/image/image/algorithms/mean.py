import numpy as np


def process(image: np.ndarray):
    if len(image.shape) < 3:
        return image

    return image.sum(axis=(2)) / 3
