import numpy as np

from . import blackwhite


def process(image: np.ndarray):
    return blackwhite.process(image, _compute_threshold(image))


def _compute_threshold(image: np.ndarray):
    # Compute the best possible threshold that separates black and white classes in an optimal way.
    histogram = _compute_histogram(image)

    # Pre-compute the sum of weighted frequencies, to save time consumption during loop.
    total_sum = sum([
        n * histogram[n] for n in range(0, 256)
    ])

    max_variance, threshold = 0, 0
    bg_sum, bg_weight = 0, 0

    for n in range(0, 255):
        # Weights are just number of pixels for 0 to n for background, and n + 1 to 255 for foreground.
        bg_weight += histogram[n]
        fg_weight = image.size - bg_weight

        if (bg_weight == 0 or fg_weight == 0):
            continue

        # Sums are weighted by the current index.
        bg_sum += n * histogram[n]
        fg_sum = total_sum - bg_sum

        bg_mean = bg_sum / bg_weight
        fg_mean = fg_sum / fg_weight

        # Compute variance according Otsu's method.
        variance = bg_weight * fg_weight * ((bg_mean - fg_mean) ** 2)

        if variance > max_variance:
            max_variance = variance
            threshold = n

    return threshold


def _compute_histogram(image: np.ndarray):
    return [
        image[image == i].size
        for i in range(0, 256)
    ]
