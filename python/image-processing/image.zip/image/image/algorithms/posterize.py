import numpy as np


def process(image: np.ndarray, scalar: int = 32):
    # Transform pixel values to closest multiples of given scalar.
    return image // scalar * scalar
