import numpy as np


def process(image: np.ndarray, factor: float):
    new_size = (
        np.array(image.shape[:2]) * factor
    ).astype(int)

    indices = (
        np.indices(new_size) / factor
    ).astype(int)

    return image[indices[0], indices[1]]
