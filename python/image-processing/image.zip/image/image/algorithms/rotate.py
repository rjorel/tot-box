from math import cos, sin
import numpy as np


def process(image: np.ndarray, angle: float):
    rows, cols = image.shape[0], image.shape[1]

    theta = np.radians(angle)
    sin_theta, cos_theta = sin(theta), cos(theta)

    # Image center is used as origin point.
    normalized_indices = _add_indices(
        np.indices((rows, cols)),
        _get_half(np.array((rows, cols))) * -1
    )

    normalized_rotated_indices = np.array((
        # y = -x.sin(theta) + y.cos(theta)
        normalized_indices[1] * -sin_theta + normalized_indices[0] * cos_theta,
        # x = x.cos(theta) + y.sin(theta)
        normalized_indices[1] * cos_theta + normalized_indices[0] * sin_theta
    ))

    # Compute new shape to initialize output image.
    output_shape = _round(np.array((
        _get_range(normalized_rotated_indices[0]),
        _get_range(normalized_rotated_indices[1])
    )))

    if len(image.shape) >= 3:
        output_shape = np.append(output_shape, image.shape[2])

    output = np.empty(output_shape, image.dtype)

    # Origin point is now the output image center.
    rotated_indices = _round(_add_indices(
        normalized_rotated_indices,
        _get_half(output_shape[:2])
    ))

    output[rotated_indices[0], rotated_indices[1]] = image

    return output


def _add_indices(array1: np.ndarray, array2: np.ndarray) -> np.ndarray:
    return np.array((
        array1[0] + array2[0],
        array1[1] + array2[1]
    ))


def _get_half(array: np.ndarray) -> np.ndarray:
    return array / 2.0 - 0.5


def _round(array: np.ndarray) -> np.ndarray:
    return np.round(array).astype(int)


def _get_range(array: np.ndarray) -> np.ndarray:
    return array.max() - array.min() + 1
