import importlib
import inspect

from PIL import Image
from PIL.Image import fromarray
import numpy as np


class AlgorithmExecutor:
    _MODULE_BASE_NAME = '.algorithms'
    _ENTRY_FUNCTION = 'process'

    def execute(self, file_path, algorithm, parameters):
        method = AlgorithmMethod(
            self._get_algorithm_method(algorithm)
        )

        return method.process(
            self._open_image(file_path),
            parameters
        )

    def _open_image(self, file_path) -> Image:
        return Image.open(file_path)

    def _get_algorithm_method(self, algorithm):
        try:
            module = importlib.import_module(
                self._get_algorithm_module_name(algorithm),
                __package__
            )

            return getattr(module, self._ENTRY_FUNCTION)

        except (ModuleNotFoundError, ImportError, AttributeError):
            raise AttributeError(f'Algorithm "{algorithm}" is not defined')

    def _get_algorithm_module_name(self, algorithm):
        return self._MODULE_BASE_NAME + '.' + algorithm


class AlgorithmMethod:

    def __init__(self, method: callable):
        self._method = method

    def process(self, image: Image, parameters: list) -> Image:
        result = self._method(
            self._convert_to_array(image),
            *self._prepare_parameters(parameters)
        )

        return self._convert_to_image(result)

    def _get_method_parameter_classes(self):
        parameters = inspect.signature(self._method).parameters.values()

        return [
            parameter.annotation
            for parameter in list(parameters)
        ]

    @staticmethod
    def _convert_to_array(image: Image):
        return np.array(image, dtype=int)

    def _prepare_parameters(self, parameters: list) -> list:
        expected_parameter_classes = self._get_method_parameter_classes()[1:]

        return [
            cls(param_value)
            for (cls, param_value) in zip(expected_parameter_classes, parameters)
        ]

    @staticmethod
    def _convert_to_image(buffer) -> Image:
        return fromarray(buffer.clip(0, 255).astype(np.ubyte))
