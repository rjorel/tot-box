#!/usr/bin/env python3

# Jeu Donkey Kong Labyrinthe
# Fichiers : dklabyrinthe.py, constantes.py

from constantes import *
from pygame.locals import *

import pygame

pygame.init()

fenetre = pygame.display.set_mode((450, 450))
fond = pygame.image.load("Ressources/accueil.png")

pygame.display.set_icon(icone)
pygame.display.set_caption(titre_fenetre)

continuer = 1
while continuer == 1:
    fenetre.blit(fond, (0, 0))
    pygame.display.flip()
    while continuer == 1:
        for event in pygame.event.get():
            if event.type == QUIT:
                continuer = 0
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    continuer = 0
                if event.key == K_F1:
                    niveau = niveau1
                    continuer = 2
                elif event.key == K_F2:
                    niveau = niveau2
                    continuer = 2

    fond = pygame.image.load("Ressources/fond.jpg")
    perso = droite
    position_perso = perso.get_rect()
    fenetre.blit(perso, position_perso)
    pygame.key.set_repeat(1, 100)
    a = 0;
    b = 0

    while continuer == 2:
        pygame.time.Clock().tick(30)
        for event in pygame.event.get():
            if event.type == QUIT:
                continuer = 0
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    continuer = 1
                    fond = pygame.image.load("Ressources/accueil.png")
                if event.key == K_w:
                    perso = haut
                    if niveau[a - 1][b] > 0:
                        position_perso = position_perso.move(0, -30)
                        a -= 1
                if event.key == K_s:
                    perso = bas
                    if niveau[a + 1][b] > 0:
                        position_perso = position_perso.move(0, 30)
                        a += 1
                if event.key == K_a:
                    perso = gauche
                    if niveau[a][b - 1] > 0:
                        position_perso = position_perso.move(-30, 0)
                        b -= 1
                if event.key == K_d:
                    perso = droite
                    if niveau[a][b + 1] > 0:
                        position_perso = position_perso.move(30, 0)
                        b += 1

        fenetre.blit(fond, (0, 0))
        fenetre.blit(depart, (0, 0))
        fenetre.blit(arrivee, (420, 420))
        for i in range(0, 15):
            for j in range(0, 15):
                if niveau[i][j] == 0:
                    fenetre.blit(mur, (j * sprite, i * sprite))
        fenetre.blit(perso, position_perso)
        pygame.display.flip()

        if niveau[a][b] == 3:
            continuer = 1
            victoire.play()
            fond = pygame.image.load("Ressources/accueil.png")
