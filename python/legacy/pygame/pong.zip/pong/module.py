"""Classes du personnage, de l'adversaire et de la balle"""

from random import choice, randint

from pygame.locals import *

import pygame

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()

# Chargement des sons

rebond = pygame.mixer.Sound('sons/rebound.ogg')
applaudissement = pygame.mixer.Sound('sons/applause.ogg')
huee = pygame.mixer.Sound('sons/hoot.ogg')
rire = pygame.mixer.Sound('sons/laugh.ogg')


# Classes perso, adversaire, balle

class Perso:
    """Définition du personnage"""

    def __init__(self):  # Placement du personnage au départ
        self.pos_x = 10
        self.pos_y = 260

        self.pos_by = 0
        self.pos_ay = 260


class Ennemi:
    """Définition de l'adversaire"""

    def __init__(self):  # Placement de l'adversaire au départ
        self.pos_x = 620
        self.pos_y = 260

        self.pos_by = 0
        self.pos_ay = 260

        self.move = 0

    def action(self, balle):
        if self.pos_y != 430 and self.move == 0 and self.pos_y + 50 < balle.pos_y:
            self.pos_by = self.pos_y
            self.pos_ay = self.pos_y + 50

            self.pos_y += 10
            self.move = 1

        elif self.pos_y != 80 and self.move == 0 and self.pos_y > balle.pos_y:
            self.pos_by = self.pos_y + 40
            self.pos_ay = self.pos_y - 10

            self.pos_y -= 10
            self.move = 1

        if self.move != 0:
            self.move = (self.move + 1) % 20


class Balle:
    """Définition de la balle"""

    def __init__(self):  # Positionnement de la balle initial, définition de sa trajectoire
        self.pos_x = 500
        self.pos_y = 280

        self.pos_bx = 0
        self.pos_by = 0

        self.dx = -2
        self.dy = 0

        self.move = 0

    def action(self, raquette, raquette_face, raquette_cote1, raquette_cote2, direction):
        if self.pos_y > 470 or self.pos_y < 80:  # Collision de la balle sur les bords
            self.dy = -self.dy
            rebond.play()

        # Collision de la balle sur la face principale de la raquette du joueur

        if self.pos_x == raquette_face:

            if raquette.pos_y - 10 <= self.pos_y <= raquette.pos_y + 50:
                self.dx = direction
                rebond.play()

                if self.dy != 0:
                    if raquette.pos_y - 10 <= self.pos_y <= raquette.pos_y + 15:  # Deviation differente en fonction de l'endroit touche
                        self.dy += int(self.dy / abs(self.dy)) * ((randint(-15, 5) * self.dy) / 100)

                    elif raquette.pos_y + 15 < self.pos_y < raquette.pos_y + 25:
                        self.dy += int(self.dy / abs(self.dy)) * (
                            (randint(-10, 10) * self.dy) / 100)

                    elif raquette.pos_y + 25 <= self.pos_y <= raquette.pos_y + 50:
                        self.dy += int(self.dy / abs(self.dy)) * ((randint(-5, 15) * self.dy) / 100)


                else:
                    if raquette.pos_y - 10 <= self.pos_y <= raquette.pos_y + 15:
                        self.dy = choice([-1, -0.5])

                    elif raquette.pos_y + 15 < self.pos_y < raquette.pos_y + 25:
                        self.dy = choice([-0.5, 0.5])

                    elif raquette.pos_y + 25 <= self.pos_y <= raquette.pos_y + 50:
                        self.dy = choice([0.5, 1])


        elif raquette_cote1 < self.pos_x < raquette_cote2:  # Collision de la balle sur les cotés de la raquette du joueur
            if (raquette.pos_y - 10 < self.pos_y < raquette.pos_y - 5) and self.dy >= 0:
                self.dx = direction
                rebond.play()

                if self.dy >= 2:  # Petite agitation de foule quand la balle est rattrapée, alors qu'elle était compliquée a renvoyer
                    interjection.play()

                if self.dy != 0:
                    self.dy = -1.5 * self.dy
                else:
                    self.dy = -0.75

            elif (raquette.pos_y + 45 < self.pos_y < raquette.pos_y + 50) and self.dy <= 0:
                self.dx = direction
                rebond.play()

                if self.dy <= -2:  # Petite agitation de foule quand la balle est rattrapée, alors qu'elle était compliquée a renvoyer
                    interjection.play()

                if self.dy != 0:
                    self.dy = -1.5 * self.dy
                else:
                    self.dy = 0.75

        if self.move == 0:  # Blocage de la balle, pour ralentir la vitesse de la balle
            self.pos_bx = self.pos_x
            self.pos_by = self.pos_y

            self.pos_x += self.dx
            self.pos_y += self.dy

        self.move = (self.move + 1) % 3
