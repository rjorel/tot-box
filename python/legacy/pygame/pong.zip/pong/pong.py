#!/usr/bin/env python3

#################################################################
#                  PROGRAMMEUR : Raphael Jorel                  #
#                                                               #
# FICHIERS :                                                    #
#   - pong.py, module.py                                       #
#   - applause.ogg, eeeh.ogg, hoot.ogg, laught.ogg,             #
#       rebound.ogg -> dossier 'sons'                           #
#                                                               #
# DESCRIPTION :                                                 #
#   Le jeu pong classique, on doit déplacer sa raquette pour    #
#   renvoyer la balle.                                          #
#                                                               #
#################################################################


from module import *

# Environnement du jeu

fenetre = pygame.display.set_mode((640, 480))

pygame.display.set_caption('Pong')

police = pygame.font.match_font('Comic Sans MS')
texte = pygame.font.Font(police, 50)

pygame.key.set_repeat(20, 20)

# Création des surfaces utilisées

carre = pygame.Surface((10, 10))
carre_noir = pygame.Surface((10, 10))
ligne = pygame.Surface((640, 5))

carre.fill((255, 255, 255))
carre_noir.fill((0, 0, 0))
ligne.fill((255, 255, 255))


# Fonctions

def affichage_raquettes():
    for i in range(0, 50, 10):
        fenetre.blit(carre, (perso.pos_x, perso.pos_y + i))
        fenetre.blit(carre, (ennemi.pos_x, ennemi.pos_y + i))


def affichage_scores():
    fenetre.blit(ligne, (0, 72))
    fenetre.blit(texte.render('{}'.format(score), True, (255, 255, 255)), (230, 0))
    fenetre.blit(texte.render('{}'.format(score_ennemi), True, (255, 255, 255)), (370, 0))


# Début

perso = Perso()
ennemi = Ennemi()
balle = Balle()

score = 0
score_ennemi = 0

fenetre.fill((0, 0, 0))
affichage_raquettes()
affichage_scores()

continuer = 1

while continuer:
    for event in pygame.event.get():
        if event.type == QUIT or event.type == KEYDOWN and event.key == K_ESCAPE:
            continuer = 0

        elif event.type == KEYDOWN:
            if event.key == K_s and perso.pos_y != 430:
                perso.pos_by = perso.pos_y
                perso.pos_ay = perso.pos_y + 50

                perso.pos_y += 10

            elif event.key == K_z and perso.pos_y != 80:
                perso.pos_by = perso.pos_y + 40
                perso.pos_ay = perso.pos_y - 10

                perso.pos_y -= 10

            elif event.key == K_p:
                fenetre.blit(texte.render('Pause', True, (255, 255, 255)), (250, 180))
                pygame.display.flip()
                pygame.key.set_repeat(100, 20)
                continuer = 2
                while continuer == 2:
                    event = pygame.event.wait()
                    if event.type == QUIT:
                        continuer = 0
                    elif event.type == KEYDOWN and event.key == K_p:
                        fenetre.fill((0, 0, 0))
                        affichage_raquettes()
                        affichage_scores()

                        continuer = 1
                        pygame.key.set_repeat(20, 20)

    ennemi.action(balle)
    balle.action(perso, 20, 0, 20, 2)
    balle.action(ennemi, 610, 610, 630, -2)

    fenetre.blit(carre_noir, (perso.pos_x, perso.pos_by))  # Affichage du joueur
    fenetre.blit(carre, (perso.pos_x, perso.pos_ay))

    fenetre.blit(carre_noir, (ennemi.pos_x, ennemi.pos_by))  # Affichage de l'adversaire
    fenetre.blit(carre, (ennemi.pos_x, ennemi.pos_ay))

    fenetre.blit(carre_noir, (balle.pos_bx, balle.pos_by))  # Affichage de la balle
    fenetre.blit(carre, (balle.pos_x, balle.pos_y))

    pygame.display.flip()

    if balle.pos_x == 0 or balle.pos_x == 630:
        if balle.pos_x == 0:
            if -1 <= balle.dy <= 1:  # Si la balle était trop facile a rattraper, la foule rigole
                rire.play()
            else:
                huee.play()
            score_ennemi += 1

        else:
            applaudissement.play()
            score += 1

        affichage_raquettes()
        pygame.time.delay(2000)
        perso = Perso()
        ennemi = Ennemi()
        balle = Balle()

        fenetre.fill((0, 0, 0))
        affichage_raquettes()
        affichage_scores()

    pygame.time.delay(2)
