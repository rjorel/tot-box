from random import randint

from pygame.locals import *

import pygame

pygame.init()

# Environnement du jeu

fenetre = pygame.display.set_mode((640, 480))

texte = pygame.font.Font(None, 36)
texte_1 = pygame.font.Font(None, 30)

decor = str(randint(0, 6))
fond = pygame.image.load("ressources/" + decor + ".jpg").convert()
if decor == "1" or decor == "2" or decor == "6":  # Couleur d'écriture en fonction du fond d'écran
    c = 0;
    e = 255
if decor == "0" or decor == "3" or decor == "4" or decor == "5":
    c = 255;
    e = 0

"""Classes du personnage, de l'ennemi, fonction d'affichage"""


def affichage(perso, ennemi):
    fenetre.blit(fond, (0, 0))
    fenetre.blit(texte.render("Vie : %d HP" % perso.vie, 1, (c, c, c)), (20, 20))
    fenetre.blit(texte.render("Vie ennemi : %d HP" % ennemi.vie, 1, (c, c, c)), (350, 20))
    fenetre.blit(texte.render("Rett : %d RP" % perso.rett, 1, (c, c, c)), (20, 70))
    fenetre.blit(texte.render("Rett ennemi : %d RP" % ennemi.rett, 1, (c, c, c)), (350, 70))


def affichage_boost(perso, ennemi):
    if perso.poison > 2:
        fenetre.blit(texte.render("Empoisonné", 1, (200, 0, 0)), (350, 280))
    if perso.vigueur > 2:
        fenetre.blit(texte.render("Vigueur", 1, (0, 0, 200)), (20, 150))
    if perso.paralysie > 4:
        fenetre.blit(texte.render("Paralysie", 1, (0, 0, 200)), (20, 170))
    if perso.paralyse > 0:
        fenetre.blit(texte.render("Paralyse", 1, (200, 0, 0)), (350, 300))
    if perso.reduction > 3:
        fenetre.blit(texte.render("Réduction", 1, (0, 0, 200)), (20, 190))
    if ennemi.sommeil > 3:
        fenetre.blit(texte.render("Endormi", 1, (200, 0, 0)), (20, 300))
    if ennemi.infection > 3:
        fenetre.blit(texte.render("Infecté", 1, (200, 0, 0)), (20, 280))


def menu_general():
    fenetre.blit(texte.render("Attaque", 1, (c, c, c)), (20, 430))
    fenetre.blit(texte.render("Magie", 1, (c, c, c)), (280, 430))
    fenetre.blit(texte.render("Boost", 1, (c, c, c)), (550, 430))


def menu_attaque():
    fenetre.blit(texte.render("Coup", 1, (c, c, c)), (20, 430))
    fenetre.blit(texte.render("Punition", 1, (c, c, c)), (260, 430))
    fenetre.blit(texte.render("Combo", 1, (c, c, c)), (540, 430))


def menu_magie():
    fenetre.blit(texte.render("Soins", 1, (c, c, c)), (20, 430))
    fenetre.blit(texte.render("Vol de vie", 1, (c, c, c)), (250, 430))
    fenetre.blit(texte.render("Poison", 1, (c, c, c)), (540, 430))


def menu_boost():
    fenetre.blit(texte.render("Vigueur", 1, (c, c, c)), (20, 430))
    fenetre.blit(texte.render("Paralysie", 1, (c, c, c)), (260, 430))
    fenetre.blit(texte.render("Réduction", 1, (c, c, c)), (500, 430))


class Perso:
    """Définition du personnage"""

    def __init__(self):
        self.vie = 10000
        self.rett = 0
        self.vigueur = 0
        self.paralysie = 0
        self.paralyse = 0
        self.reduction = 0
        self.punition = 0
        self.soins = 0
        self.vol_de_vie = 0
        self.poison = 0

    def _coup(self, ennemi):
        a = 100
        b = 200
        cc = randint(0, 3)
        if self.paralysie > 4:
            y = randint(0, 1)
            if ennemi.type == 2:
                y = randint(0, 4)
            if y == 0:
                self.paralyse = 2
            if self.vigueur > 2:
                a = 500
                b = 700
        if cc == 0:
            if self.paralysie > 4:
                self.paralyse = 2
                a = 300
                b = 500
            if self.vigueur > 2:
                a = 700
                b = 900
            fenetre.blit(texte.render("Coup critique", 1, (0, 200, 0)), (230, 100))
        y = randint(a, b)
        if ennemi.renvoi > 4:
            pourcentage = randint(60, 80)
            z = y - int(((100 - pourcentage) * y) / 100)
            y = y - int((pourcentage * y) / 100)
            self.vie -= z
            fenetre.blit(texte_1.render("-%d (renvoi)" % z, 1, (200, 0, 0)), (83, 40))
        ennemi.vie -= y
        w = randint(5, 10)
        self.rett += w
        fenetre.blit(texte_1.render("-%d" % y, 1, (200, 0, 0)), (507, 40))
        fenetre.blit(texte_1.render("+%d" % w, 1, (0, 200, 0)), (93, 90))

    def _punition(self, ennemi):
        blocage = 0
        if self.punition > 0:
            blocage = 1
        else:
            a = randint(10, 30)
            b = randint(10, 30)
            y = int(a * ennemi.vie / 100)
            z = int(b * self.vie / 100)
            ennemi.vie -= y
            self.vie -= z
            self.punition = 4
            fenetre.blit(texte_1.render("-{}".format(y), 1, (200, 0, 0)), (507, 40))
            fenetre.blit(texte_1.render("-{}".format(z), 1, (200, 0, 0)), (83, 40))
        return blocage, self.punition

    def _combo(self, ennemi):
        i = 1
        self.rett -= 20
        fenetre.blit(texte_1.render("-20", 1, (200, 0, 0)), (93, 90))
        pygame.display.flip()
        pygame.time.delay(500)
        while i != 0:
            y = randint(75, 100)
            if ennemi.renvoi > 4:
                pourcentage = randint(60, 80)
                z = y - int(((100 - pourcentage) * y) / 100)
                y = y - int((pourcentage * y) / 100)
                self.vie -= z
                fenetre.blit(texte_1.render("-{} (renvoi)".format(z), 1, (200, 0, 0)), (83, 40))
            ennemi.vie -= y
            fenetre.blit(texte_1.render("-{}".format(y), 1, (200, 0, 0)), (507, 40))
            pygame.display.flip()
            pygame.time.delay(50)
            if self.vie < 0 or ennemi.vie < 0:
                break
            affichage(self, ennemi)
            affichage_boost(self, ennemi)
            pygame.display.flip()
            pygame.time.delay(50)
            i = randint(0, 50)
            if ennemi.type == 2:
                i = randint(0, 20)

    def _soins(self):
        blocage = 0
        if self.soins > 0:
            blocage = 1
            temps = self.soins
        else:
            a = 900
            b = 1100
            cc = randint(0, 3)
            if cc == 0:
                a = 1400
                b = 1600
                fenetre.blit(texte.render("Coup critique", 1, (0, 200, 0)), (230, 100))
            y = randint(a, b)
            self.vie += y
            self.soins = 3
            fenetre.blit(texte_1.render("+{}".format(y), 1, (0, 200, 0)), (81, 40))
        return blocage, self.soins

    def _vol_de_vie(self, ennemi):
        blocage = 0
        if self.vol_de_vie > 0:
            blocage = 1
        else:
            a = 500
            b = 700
            cc = randint(0, 3)
            if cc == 0:
                a = 800
                b = 1000
                cc = randint(0, 3)
                fenetre.blit(texte.render("Coup critique", 1, (0, 200, 0)), (230, 100))
            y = randint(a, b)
            self.vie += y
            ennemi.vie -= y
            self.vol_de_vie = 5
            fenetre.blit(texte_1.render("+{}".format(y), 1, (0, 200, 0)), (81, 40))
            fenetre.blit(texte_1.render("-{}".format(y), 1, (200, 0, 0)), (507, 40))
        return blocage, self.vol_de_vie

    def _poison(self):
        blocage = 0
        if self.poison > 0:
            blocage = 1
        else:
            self.poison = 5
            w = randint(5, 10)
            self.rett += w
            fenetre.blit(texte_1.render("+{}".format(w), 1, (0, 200, 0)), (93, 90))
        return blocage, self.poison

    def _vigueur(self):
        blocage = 0
        if self.vigueur > 0:
            blocage = 1
        else:
            self.vigueur = 6
        return blocage, self.vigueur

    def _paralysie(self):
        blocage = 0
        if self.paralysie > 0:
            blocage = 1
        else:
            self.paralysie = 7
        return blocage, self.paralysie

    def _reduction(self):
        blocage = 0
        if self.reduction > 0:
            blocage = 1
        else:
            self.reduction = 6
        return blocage, self.reduction


class Ennemi:
    """Définition des ennemis"""

    def __init__(self, x, y, z):
        self.vie = y
        self.rett = 0
        self.sommeil = 0
        self.force = 0
        self.renvoi = 0
        self.infection = 0
        self.level = z
        self.type = x

    # Guerrier    
    def _coup(self, perso):
        a = 800
        b = 1000
        if perso.reduction > 3:
            a = 200
            b = 300
        y = randint(a * self.level, b * self.level)
        perso.vie -= y
        w = randint(1, 3);
        self.rett += w
        fenetre.blit(texte.render("Frappe", 1, (c, c, c)), (400, 200))
        fenetre.blit(texte_1.render("-%d" % y, 1, (200, 0, 0)), (83, 40))
        fenetre.blit(texte_1.render("+%d" % w, 1, (0, 200, 0)), (519, 90))

    def _enchainement(self, perso):
        a = 100;
        b = 200;
        self.rett -= 20
        fenetre.blit(texte.render("Enchaînement", 1, (c, c, c)), (400, 200))
        fenetre.blit(texte_1.render("-20", 1, (200, 0, 0)), (519, 90))
        pygame.display.flip()
        pygame.time.delay(500)
        for i in range(0, 5):
            y = randint(a * self.level, b * self.level);
            perso.vie -= y
            fenetre.blit(texte_1.render("-%d" % y, 1, (200, 0, 0)), (83, 40))
            pygame.display.flip()
            pygame.time.delay(500)
            if perso.vie < 0:
                break
            affichage(perso, self)
            affichage_boost(perso, self)
            fenetre.blit(texte.render("Enchaînement", 1, (c, c, c)), (400, 200))
            pygame.display.flip()
            pygame.time.delay(500)
            a += 100;
            b += 200

    # Mage
    def _coup_1(self, perso):
        a = 30;
        b = 60
        if self.force > 3:
            a = 800;
            b = 1000
        if perso.reduction > 3:
            a = 10;
            b = 20
        if self.force > 3 and perso.reduction > 3:
            a = 300;
            b = 500
        y = randint(a * self.level, b * self.level);
        perso.vie -= y
        w = randint(5, 10);
        self.rett += w
        fenetre.blit(texte.render("Frappe", 1, (c, c, c)), (400, 200))
        fenetre.blit(texte_1.render("-%d" % y, 1, (200, 0, 0)), (83, 40))
        fenetre.blit(texte_1.render("+%d" % w, 1, (0, 200, 0)), (519, 90))

    def _sommeil(self):
        fenetre.blit(texte.render("Sommeil", 1, (c, c, c)), (400, 200))
        self.sommeil = 5

    def _force(self):
        fenetre.blit(texte.render("Force", 1, (c, c, c)), (400, 200))
        self.force = 7

    def _renvoi(self):
        fenetre.blit(texte.render("Renvoi", 1, (c, c, c)), (400, 200))
        self.renvoi = 7

    def _infection(self):
        w = randint(5, 10);
        self.rett += w
        fenetre.blit(texte.render("Infection", 1, (c, c, c)), (400, 200))
        fenetre.blit(texte_1.render("+%d" % w, 1, (0, 200, 0)), (519, 90))
        self.infection = 5

    def _eclair(self, perso):
        z = 0;
        self.rett -= 20
        fenetre.blit(texte.render("Eclair", 1, (c, c, c)), (400, 200))
        fenetre.blit(texte_1.render("-20", 1, (200, 0, 0)), (519, 90))
        pygame.display.flip()
        pygame.time.delay(500)
        for i in range(0, 3):
            y = randint(800 * self.level, 1000 * self.level);
            perso.vie -= y
            fenetre.blit(texte_1.render("-%d" % y, 1, (200, 0, 0)), (83, 40))
            pygame.display.flip()
            pygame.time.delay(500)
            if perso.vie < 0:
                break
            affichage(perso, self)
            affichage_boost(perso, self)
            fenetre.blit(texte.render("Eclair", 1, (c, c, c)), (400, 200))
            pygame.display.flip()
            pygame.time.delay(500)
