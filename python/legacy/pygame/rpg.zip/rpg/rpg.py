#!/usr/bin/env python3

#################################################################
#                  PROGRAMMEUR : Raphael Jorel                  #
#                                                               #
# DESCRIPTION :                                                 #
#   Un Role Playing Game qui se joue par manche, deux           #
#   adversaires et quatre difficultés, neufs techniques         #
#   différentes.                                                #
#                                                               #
#################################################################


from module import *

pygame.display.set_caption("RPG")

musique = pygame.mixer.Sound('ressources/musique.ogg')
musique.play(loops=-1)

blocage = 0;
temps = 0

# Début

fenetre.blit(fond, (0, 0))  # Choix de l'adversaire
fenetre.blit(texte.render("Choix de l'adversaire :", 1, (c, c, c)), (180, 50))
fenetre.blit(texte.render("Guerrier", 1, (c, c, c)), (250, 100))
fenetre.blit(texte.render("Mage", 1, (c, c, c)), (270, 150))
pygame.display.flip()

continuer = 1
while continuer == 1:
    event = pygame.event.wait()
    if event.type == KEYDOWN and event.key == K_ESCAPE:
        continuer = vie = vie_ennemi = ennemi = 0
    if event.type == MOUSEBUTTONDOWN and event.button == 1:
        if 250 < event.pos[0] < 350 and 100 < event.pos[1] < 120:
            ennemi = 'guerrier'
            vie_ennemi = 25000
            continuer = 2
        if 270 < event.pos[0] < 335 and 150 < event.pos[1] < 170:
            ennemi = 'mage'
            vie_ennemi = 8000
            continuer = 2

if continuer == 2:
    fenetre.blit(fond, (0, 0))  # Choix de la difficulté
    fenetre.blit(texte.render("Choix de la difficulte:", 1, (c, c, c)), (180, 50))
    fenetre.blit(texte.render("Facile", 1, (c, c, c)), (260, 100))
    fenetre.blit(texte.render("Normal", 1, (c, c, c)), (255, 150))
    fenetre.blit(texte.render("Difficile", 1, (c, c, c)), (250, 200))
    fenetre.blit(texte.render("Hardcore", 1, (c, c, c)), (240, 250))
    pygame.display.flip()

while continuer == 2:
    event = pygame.event.wait()
    if event.type == KEYDOWN and event.key == K_ESCAPE:
        continuer = vie = vie_ennemi = ennemi = 0
    if event.type == MOUSEBUTTONDOWN and event.button == 1:
        if 260 < event.pos[0] < 335 and 100 < event.pos[1] < 120:
            level = 0.5
            continuer = 0
        if 255 < event.pos[0] < 340 and 150 < event.pos[1] < 170:
            level = 1
            continuer = 0
        if 250 < event.pos[0] < 350 and 200 < event.pos[1] < 220:
            level = 1.2
            continuer = 0
        if 240 < event.pos[0] < 355 and 250 < event.pos[1] < 270:
            level = 1.4
            continuer = 0

perso = Perso()
ennemi = Ennemi(ennemi, vie_ennemi, level)

while perso.vie > 0 and ennemi.vie > 0:  # Début du jeu
    perso.vigueur -= 1;
    perso.paralysie -= 1;
    perso.paralyse -= 1;
    perso.reduction -= 1
    perso.punition -= 1;
    perso.soins -= 1;
    perso.vol_de_vie -= 1;
    perso.poison -= 1

    continuer = 1
    affichage(perso, ennemi)
    affichage_boost(perso, ennemi)
    if ennemi.sommeil > 3:
        continuer = 0
        pass
    else:
        menu_general()

    if ennemi.infection > 3 and blocage == 0:
        y = randint(500 * ennemi.level, 1000 * ennemi.level);
        perso.vie -= y
        fenetre.blit(texte_1.render("-{} (infection)".format(y), 1, (200, 0, 0)), (83, 40))
        pygame.display.flip()
        pygame.time.delay(1000)
        affichage(perso, ennemi)
        affichage_boost(perso, ennemi)
        if ennemi.sommeil <= 3:
            menu_general()
    if blocage == 1:
        blocage = 0

    while continuer > 0:
        event = pygame.event.wait()
        if event.type == KEYDOWN and event.key == K_ESCAPE:
            continuer = ennemi = 0
        if event.type == MOUSEBUTTONDOWN and event.button == 1:
            if 430 < event.pos[1] < 450:
                if 20 < event.pos[0] < 115:
                    continuer = 2
                if 280 < event.pos[0] < 355:
                    continuer = 3
                if 550 < event.pos[0] < 620:
                    continuer = 4
        pygame.display.flip()

        if continuer > 1:
            affichage(perso, ennemi)
            affichage_boost(perso, ennemi)
            if continuer == 2:
                menu_attaque()
            elif continuer == 3:
                menu_magie()
            else:
                menu_boost()

        while continuer == 2:
            event = pygame.event.wait()
            if event.type == KEYDOWN and event.key == K_ESCAPE:
                continuer = ennemi = 0
            if event.type == MOUSEBUTTONDOWN and event.button == 3:
                affichage(perso, ennemi)
                affichage_boost(perso, ennemi)
                menu_general()
                continuer = 1
            if event.type == MOUSEBUTTONDOWN and event.button == 1:
                if 430 < event.pos[1] < 450:
                    if 20 < event.pos[0] < 80:
                        fenetre.blit(texte.render("Coup", 1, (e, e, e)), (20, 430))
                        perso._coup(ennemi)
                        continuer = 0
                    if 260 < event.pos[0] < 360:
                        fenetre.blit(texte.render("Punition", 1, (e, e, e)), (260, 430))
                        blocage, temps = perso._punition(ennemi)
                        continuer = 0
                    if 540 < event.pos[0] < 620:
                        fenetre.blit(texte.render("Combo", 1, (e, e, e)), (540, 430))
                        if perso.rett < 20:
                            fenetre.blit(texte.render("Requiert 20 RP", 1, (200, 0, 0)), (230, 100))
                            pygame.display.flip()
                            pygame.time.delay(1000)
                            affichage(perso, ennemi)
                            affichage_boost(perso, ennemi)
                            menu_general()
                            continuer = 1
                        else:
                            perso._combo(ennemi)
                            continuer = 0
            pygame.display.flip()

        while continuer == 3:
            event = pygame.event.wait()
            if event.type == KEYDOWN and event.key == K_ESCAPE:
                continuer = ennemi = 0
            if event.type == MOUSEBUTTONDOWN and event.button == 3:
                affichage(perso, ennemi)
                affichage_boost(perso, ennemi)
                menu_general()
                continuer = 1
            if event.type == MOUSEBUTTONDOWN and event.button == 1:
                if 430 < event.pos[1] < 450:
                    if 20 < event.pos[0] < 80:
                        fenetre.blit(texte.render("Soins", 1, (e, e, e)), (20, 430))
                        blocage, temps = perso._soins()
                        continuer = 0
                    if 250 < event.pos[0] < 370:
                        fenetre.blit(texte.render("Vol de vie", 1, (e, e, e)), (250, 430))
                        blocage, temps = perso._vol_de_vie(ennemi)
                        continuer = 0
                    if 540 < event.pos[0] < 620:
                        fenetre.blit(texte.render("Poison", 1, (e, e, e)), (540, 430))
                        blocage, temps = perso._poison()
                        continuer = 0
            pygame.display.flip()

        while continuer == 4:
            event = pygame.event.wait()
            if event.type == KEYDOWN and event.key == K_ESCAPE:
                continuer = ennemi = 0
            if event.type == MOUSEBUTTONDOWN and event.button == 3:
                affichage(perso, ennemi)
                affichage_boost(perso, ennemi)
                menu_general()
                continuer = 1
            if event.type == MOUSEBUTTONDOWN and event.button == 1:
                if 430 < event.pos[1] < 450:
                    if 20 < event.pos[0] < 110:
                        fenetre.blit(texte.render("Vigueur", 1, (e, e, e)), (20, 430))
                        blocage, temps = perso._vigueur()
                        continuer = 0
                    if 260 < event.pos[0] < 370:
                        fenetre.blit(texte.render("Paralysie", 1, (e, e, e)), (260, 430))
                        blocage, temps = perso._paralysie()
                        continuer = 0
                    if 500 < event.pos[0] < 620:
                        fenetre.blit(texte.render("Réduction", 1, (e, e, e)), (500, 430))
                        blocage, temps = perso._reduction()
                        continuer = 0
            pygame.display.flip()

    if perso.vie > 10000:
        perso.vie = 10000
    if perso.vie <= 0 or ennemi.vie <= 0:
        pygame.time.delay(1000)
        break

    if blocage:
        perso.vigueur += 1;
        perso.paralysie += 1;
        perso.paralyse += 1;
        perso.reduction += 1
        perso.punition += 1;
        perso.soins += 1;
        perso.vol_de_vie += 1;
        perso.poison += 1
        fenetre.blit(texte.render("{} tours de relance".format(temps), 1, (200, 0, 0)), (200, 100))
        pygame.display.flip()
        pygame.time.delay(1000)
        continue

    affichage_boost(perso, ennemi)
    pygame.display.flip()
    pygame.time.delay(1000)
    affichage(perso, ennemi)
    affichage_boost(perso, ennemi)

    if perso.poison > 2:
        a = 600;
        b = 800
        y = randint(a, b)
        if ennemi.renvoi > 4:
            pourcentage = randint(60, 80)
            z = y - int(((100 - pourcentage) * y) / 100)
            y = y - int((pourcentage * y) / 100)
            perso.vie -= z
            fenetre.blit(texte_1.render("-{} (renvoi)".format(z), 1, (200, 0, 0)), (83, 40))
        ennemi.vie -= y
        fenetre.blit(texte_1.render("-{} (poison)".format(y), 1, (200, 0, 0)), (507, 40))
        pygame.display.flip()
        pygame.time.delay(1000)
        affichage(perso, ennemi)
        affichage_boost(perso, ennemi)
        if perso.vie <= 0 or ennemi.vie <= 0:
            break
    if perso.paralyse > 0:
        continue

    if ennemi.type == 'guerrier':
        if ennemi.rett >= 20:
            ennemi._enchainement(perso)
        else:
            ennemi._coup(perso)

    elif ennemi.type == 'mage':
        ennemi.sommeil -= 1;
        ennemi.force -= 1;
        ennemi.renvoi -= 1;
        ennemi.infection -= 1
        continuer = 1
        debug = 0
        while continuer == 1:
            if ennemi.rett >= 20:
                ennemi._eclair(perso)
                continuer = 0
                continue
            if ennemi.vie < 800 and perso.sommeil < 0:
                ennemi._sommeil()
                continuer = 0
                continue
            if ennemi.renvoi < 0 and (perso.rett >= 20 or perso.poison > 3 or perso.vigueur > 3):
                ennemi._renvoi()
                continuer = 0
                continue
            if ennemi.rett < 20 and ennemi.rett >= 15 or debug == 1000 or ennemi.force > 3:
                ennemi._coup_1(perso)
                continuer = 0
                continue

            y = randint(0, 3)
            if y == 0 and ennemi._sommeil <= 0:
                ennemi._sommeil()
                continuer = 0
            elif y == 1 and ennemi.force <= 0:
                force = ennemi._force()
                continuer = 0
            elif y == 2 and ennemi.infection <= 0:
                ennemi._infection()
                continuer = 0
            else:
                debug += 1

    affichage_boost(perso, ennemi)
    pygame.display.flip()
    pygame.time.delay(1000)

if ennemi.type == 'guerrier':
    y = 25000
else:
    y = 8000

if perso.vie < 0:
    if ennemi.vie > 0.8 * y:
        x = "Il vous a mis votre raclée"
    elif ennemi.vie > 0.6 * y:
        x = "Il a carrément fait le café"
    elif ennemi.vie > 0.4 * y:
        x = "Il vous a bien géré sur ce coup-la"
    elif ennemi.vie > 0.2 * y:
        x = "Il n'a pas eu trop peur"
    elif ennemi.vie > 0:
        x = "Il a eu chaud tout de même"

if ennemi.vie < 0:
    if perso.vie > 8000:
        x = "Vous avez été phénoménal"
    elif perso.vie > 6000:
        x = "Vous avez bien géré"
    elif perso.vie > 4000:
        x = "Mouais, pas mauvais"
    elif perso.vie > 2000:
        x = "Ça a été chaud tout de même"
    elif perso.vie > 0:
        x = "Vous êtes passé pas loin de la mort"

if ennemi > 0:
    fenetre.blit(fond, (0, 0))
    fenetre.blit(texte.render(x, 1, (0, 0, 0)), (150, 240))
    pygame.display.flip()
    pygame.time.delay(3000)
