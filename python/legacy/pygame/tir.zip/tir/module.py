"""Images, classes du personnage, des ennemis, des balles"""

from random import randint

from pygame.locals import *

import pygame

pygame.init()
fenetre = pygame.display.set_mode((640, 480))

# Création des balles

img_balle = pygame.Surface((4, 4))
img_balle_ennemi = pygame.Surface((4, 4))

img_balle.fill((255, 255, 255))
img_balle_ennemi.fill((0, 0, 0))

# Chargement des images du jeu

mur = pygame.image.load('ressources/mur.png')

perso_droite = pygame.image.load('ressources/perso_droite.png').convert_alpha()
perso_gauche = pygame.image.load('ressources/perso_gauche.png').convert_alpha()
perso_haut = pygame.image.load('ressources/perso_haut.png').convert_alpha()
perso_bas = pygame.image.load('ressources/perso_bas.png').convert_alpha()

ennemi_droite = pygame.image.load('ressources/ennemi_droite.png').convert_alpha()
ennemi_gauche = pygame.image.load('ressources/ennemi_gauche.png').convert_alpha()
ennemi_haut = pygame.image.load('ressources/ennemi_haut.png').convert_alpha()
ennemi_bas = pygame.image.load('ressources/ennemi_bas.png').convert_alpha()

# Création de la map

niv = []
for i in range(0, 24):
    niv.append([])
    for j in range(0, 32):
        niv[i].append(randint(0, 9))
    niv[i].append(0)

niv.append([])
for i in range(0, 32):
    niv[24].append(0)

niv[10][14] = niv[11][14] = 1


# Classes du personnages, des ennemis, et des balles

class Perso:
    """Définition du personnage :
        - sa position de départ
        - ses actions (déplacements, tirs)

    """

    def __init__(self):
        self.direction = perso_droite  # Position de départ
        self.j = 14
        self.i = 10
        self.tir = 0  # Délai d'attente pour tirer

    def action(self, fenetre, balle):
        continuer = 2

        for event in pygame.event.get():
            if event.type == QUIT or event.type == KEYDOWN and event.key == K_ESCAPE:
                continuer = 0

            elif event.type == KEYDOWN:
                if event.key == K_d:  # Déplacement du personnage
                    self.direction = perso_droite
                    if niv[self.i][self.j + 1] != 0 and niv[self.i + 1][self.j + 1] != 0:
                        self.j += 1

                elif event.key == K_q:
                    self.direction = perso_gauche
                    if niv[self.i][self.j - 1] != 0 and niv[self.i + 1][self.j - 1] != 0:
                        self.j -= 1

                elif event.key == K_s:
                    self.direction = perso_bas
                    if niv[self.i + 2][self.j] != 0:
                        self.i += 1

                elif event.key == K_z:
                    self.direction = perso_haut
                    if niv[self.i - 1][self.j] != 0:
                        self.i -= 1

                elif event.key == K_SPACE and self.tir == 0:  # Action de tir, création d'un objet balle
                    balle.append(Balle(self.j * 20, self.i * 20, self.direction))
                    self.tir = 1

        if self.tir != 0:  # Definition du temps d'attente pour tirer à nouveau
            self.tir = (self.tir + 1) % 100

        return continuer


class Ennemi:
    """Définition des ennemis :
        - leur position
        - leurs actions (déplacements, tirs)

    """

    def __init__(self):
        self.tir = 0  # Délai d'attente pour tirer
        self.move = 0  # Délai d'attente pour le déplacement
        y = randint(0, 3)  # Placement aléatoire des ennemis sur les bords

        if y == 0:
            self.direction = ennemi_droite
            self.j = 0
            self.i = randint(0, 22)

        elif y == 1:
            self.direction = ennemi_gauche
            self.j = 31
            self.i = randint(0, 22)

        elif y == 2:
            self.direction = ennemi_bas
            self.j = randint(0, 31)
            self.i = 22

        else:
            self.direction = ennemi_haut
            self.j = randint(0, 31)
            self.i = 0

    def action(self, balle):
        y = randint(0, 9)
        if y == 0 and self.tir == 0:
            balle.append(Balle(self.j * 20, self.i * 20, self.direction))
            self.tir = 1

        elif y == 1 and self.move == 0:
            self.direction = ennemi_droite
            self.move = 1
            if niv[self.i][self.j + 1] != 0 and niv[self.i + 1][self.j + 1] != 0:
                self.j += 1

        elif y == 2 and self.move == 0:
            self.direction = ennemi_gauche
            self.move = 1
            if niv[self.i][self.j - 1] != 0 and niv[self.i + 1][self.j - 1] != 0:
                self.j -= 1

        elif y == 3 and self.move == 0:
            self.direction = ennemi_bas
            self.move = 1
            if niv[self.i + 2][self.j] != 0:
                self.i += 1

        elif y == 4 and self.move == 0:
            self.direction = ennemi_haut
            self.move = 1
            if niv[self.i - 1][self.j] != 0:
                self.i -= 1

        if self.tir != 0:  # Définition du temps d'attente pour tirer à nouveau
            self.tir = (self.tir + 1) % 100

        if self.move != 0:  # Temps d'attente pour se déplacer
            self.move = (self.move + 1) % 200


class Balle:
    """Trajectoire de la balle"""

    def __init__(self, x, y,
                 pos):  # Paramètres de positionnement de la balle, par rapport au personnage qui tire
        if pos == perso_droite or pos == ennemi_droite:
            self.i = y + 13
            self.j = x + 20
            self.direction = 1

        elif pos == perso_gauche or pos == ennemi_gauche:
            self.i = y + 13
            self.j = x
            self.direction = 2

        elif pos == perso_bas or pos == ennemi_bas:
            self.i = y + 20
            self.j = x
            self.direction = 3

        elif pos == perso_haut or pos == ennemi_haut:
            self.i = y + 10
            self.j = x + 15
            self.direction = 4

    def trajectoire(self):
        if self.direction == 1:
            self.j += 5
        elif self.direction == 2:
            self.j -= 5
        elif self.direction == 3:
            self.i += 5
        elif self.direction == 4:
            self.i -= 5
