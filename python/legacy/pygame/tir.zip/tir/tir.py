#!/usr/bin/env python3

#################################################################
#                  PROGRAMMEUR : Raphael Jorel                  #
#                                                               #
# FICHIERS :                                                    #
#   - tir.py, module.py                                        #
#   - ennemi_bas.png, ennemi_droite.png, ennemi_gauche.png,     #
#       ennemi_haut.png, mur.png, perso_bas.png,                #
#       perso_droite.png, perso_gauche.png, perso_haut.png      #
#           -> dossier 'ressources'                             #
#                                                               #
# DESCRIPTION :                                                 #
#   Un jeu de tir très classique, le joueur dispose de trois    #
#   vies pour tuer le plus d'ennemis possible.                  #
#                                                               #
#################################################################


from module import *

# Environnement du jeu

pygame.display.set_caption('Tir')

police = pygame.font.match_font('Segoe Script')
texte = pygame.font.Font(police, 30)

pygame.key.set_repeat(10, 100)

# Début

vie = 3
continuer = 1
score = 0

while vie > 0 and continuer:
    perso = Perso()
    ennemi = []
    balle = []
    balle_ennemi = []
    continuer = 2
    compteur = 0

    while continuer > 1:
        fenetre.fill((100, 150, 255))
        continuer = perso.action(fenetre, balle)

        if compteur < 5:
            ennemi.append(Ennemi())
            compteur += 1

        # Affichage

        for i in range(0, 24):  # Mur
            for j in range(0, 32):
                if niv[i][j] == 0:
                    fenetre.blit(mur, (j * 20, i * 20))

        i = 0
        while i < len(ennemi):  # Ennemis
            ennemi[i].action(balle_ennemi)
            fenetre.blit(ennemi[i].direction, (ennemi[i].j * 20, ennemi[i].i * 20))
            i += 1

        fenetre.blit(perso.direction, (perso.j * 20, perso.i * 20))  # Joueur

        i = 0
        while i < len(balle):  # Balles
            balle[i].trajectoire()
            fenetre.blit(img_balle, (balle[i].j, balle[i].i))
            if niv[balle[i].i // 20][balle[i].j // 20] == 0:
                del (balle[i])
                i -= 1
            i += 1

        i = 0
        while i < len(balle_ennemi):
            balle_ennemi[i].trajectoire()
            fenetre.blit(img_balle_ennemi, (balle_ennemi[i].j, balle_ennemi[i].i))
            if niv[balle_ennemi[i].i // 20][balle_ennemi[i].j // 20] == 0:
                del (balle_ennemi[i])
                i -= 1
            i += 1

        fenetre.blit(texte.render('{}'.format(score), True, (0, 0, 0)), (10, 440))
        pygame.display.flip()

        # Définition du toucher des balles

        i = 0
        while i < len(balle):  # Balles joueur
            j = 0
            while j < len(ennemi):
                if balle[i].j // 20 == ennemi[j].j and (
                    balle[i].i // 20 == ennemi[j].i or balle[i].i // 20 == ennemi[j].i + 1):
                    pygame.time.delay(500)
                    del (balle[i])
                    del (ennemi[j])
                    i -= 1
                    j -= 1
                    compteur -= 1
                    score += 1
                    break
                j += 1
            i += 1

        i = 0
        while i < len(balle_ennemi):  # Balles ennemies
            if balle_ennemi[i].j // 20 == perso.j and (
                balle_ennemi[i].i // 20 == perso.i or balle_ennemi[i].i // 20 == perso.i + 1):
                pygame.time.delay(2000)
                continuer = 1
                vie -= 1
            i += 1

fenetre.blit(texte.render('GAME OVER', True, (0, 0, 0)), (220, 200))
pygame.display.flip()
pygame.time.delay(2000)
