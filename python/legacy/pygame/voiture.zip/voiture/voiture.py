#!/usr/bin/env python3

#################################################################
#                  PROGRAMMEUR : Raphael Jorel                  #
#                                                               #
# FICHIERS :                                                    #
#   - brique.png, civil.png, explosion.png, fissure.png,        #
#       voiture.png -> dossier 'ressources'                     #
#   - accident.ogg, musique.ogg -> dossier 'ressources'         #
#                                                               #
# DESCRIPTION :                                                 #
#   Un jeu de voiture simple, il suffit de laisser avancer la   #
#   voiture tout en évitant les obstacles.                      #
#                                                               #
#################################################################


from random import choice, randint

from pygame.locals import *

import pygame

pygame.mixer.pre_init(44100, -16, 2, 2048)
pygame.init()

# Environnement du jeu

fenetre = pygame.display.set_mode((640, 480))
fenetre.fill((0, 230, 0))

pygame.display.set_caption('Voiture')

route = fenetre.subsurface((120, 0), (400, 480))
endroit_score = fenetre.subsurface((0, 450), (120, 30))
endroit_vie = fenetre.subsurface((0, 420), (120, 50))

police = pygame.font.match_font('Comic Sans MS')
texte = pygame.font.Font(police, 40)
texte_2 = pygame.font.Font(police, 20)

pygame.key.set_repeat(20, 20)

# Création des surfaces de couleurs

trait_blanc = pygame.Surface((10, 480))
bande_blanche = pygame.Surface((10, 10))

trait_blanc.fill((255, 255, 255))
bande_blanche.fill((255, 255, 255))

# Chargement des images de la voiture, des obstables, et du son d'accident, ainsi que de la musique de fond

joueur = pygame.image.load('ressources/voiture.png').convert_alpha()
civil = pygame.image.load('ressources/civil.png').convert_alpha()
explosion = pygame.image.load('ressources/explosion.png').convert_alpha()
brique = pygame.image.load('ressources/brique.png').convert_alpha()
fissure = pygame.image.load('ressources/fissure.png').convert_alpha()
vie = pygame.image.load('ressources/vie.png').convert_alpha()

accident = pygame.mixer.Sound('ressources/accident.ogg')
musique = pygame.mixer.Sound('ressources/musique.ogg')


# Classes des ennemis et du joueur

class Perso:

    def __init__(self):
        self.pos_x = 200
        self.pos_y = 400


class Voiture:
    """Définition de la position des voitures, et de leur hitbox"""

    def __init__(self):
        self.pos_x = choice([50, 120, 178, 245, 315])
        self.pos_y = -75
        self.accident = False

    def toucher(self):
        global continuer
        global vies

        if perso.pos_y - 70 < self.pos_y < perso.pos_y + 75:
            if perso.pos_x - 35 < self.pos_x < perso.pos_x + 35:
                route.blit(explosion, (self.pos_x - 40, self.pos_y - 20))
                route.blit(explosion, (perso.pos_x - 40, perso.pos_y - 20))
                pygame.display.flip()
                accident.play()
                pygame.time.delay(2000)
                continuer = 1
                vies -= 1


class Mur:
    """Définition de la positions des murs, et de leur hitbox"""

    def __init__(self):
        self.pos_x = choice([50, 140, 240])
        self.pos_y = -58

    def toucher(self, auto):
        global continuer
        global vies

        if auto.pos_y - 35 < self.pos_y < auto.pos_y + 75:
            if auto.pos_x - 100 < self.pos_x < auto.pos_x + 35:
                route.blit(explosion, (auto.pos_x - 40, auto.pos_y - 20))
                pygame.display.flip()
                accident.play()
                if auto is perso:
                    pygame.time.delay(2000)
                    continuer = 1
                    vies -= 1
                else:
                    auto.accident = True


class Fissure:
    """Définition de la positions des fissures, et de leur hitbox"""

    def __init__(self):
        self.pos_x = choice([0, 325])
        self.pos_y = -20

    def toucher(self, auto):
        global continuer
        global vies

        if auto.pos_y - 20 < self.pos_y < auto.pos_y + 75:
            if auto.pos_x - 75 < self.pos_x < auto.pos_x + 35:
                route.blit(explosion, (auto.pos_x - 40, auto.pos_y - 20))
                pygame.display.flip()
                accident.play()
                if auto is perso:
                    pygame.time.delay(2000)
                    continuer = 1
                    vies -= 1
                else:
                    auto.accident = True


# Fonctions

def affichage_vie():
    endroit_vie.fill((0, 230, 0))
    for i in range(0, vies - 1):
        endroit_vie.blit(vie, (i * 40, 0))

# Début

vitesse = 200
bandes = [0, 10, 20, 30, 40, 50, 120, 130, 140, 150, 160, 170, 240, 250, 260, 270, 280, 290, 360,
          370, 380, 390, 400, 410]  # Emplacements des bandes initialement
vies = 4
continuer = 1
score = 0

musique.play(loops=-1)

while vies > 0 and continuer:
    voitures = []
    murs = []
    crevasses = []
    perso = Perso()
    continuer = 2
    affichage_vie()

    while continuer == 2:
        pygame.time.Clock().tick(500)

        for event in pygame.event.get():
            if event.type == QUIT:
                continuer = 0

            elif event.type == KEYDOWN:
                if event.key == K_q:
                    perso.pos_x -= 10

                elif event.key == K_d:
                    perso.pos_x += 10

                elif event.key == K_p:
                    route.blit(texte.render('Pause', True, (0, 0, 0)), (150, 200))
                    pygame.display.flip()
                    pygame.key.set_repeat(100, 20)
                    continuer = 3
                    while continuer == 3:
                        event = pygame.event.wait()
                        if event.type == QUIT:
                            continuer = 0
                        elif event.type == KEYDOWN and event.key == K_p:
                            continuer = 2
                            pygame.key.set_repeat(20, 20)

        if perso.pos_x < 10:  # Limite de la route
            perso.pos_x = 10
        elif perso.pos_x > 354:
            perso.pos_x = 354

        y = randint(0, 200)
        if y == 0:
            voitures.append(Voiture())
        elif y == 1:
            murs.append(Mur())
        elif y == 2:
            crevasses.append(Fissure())

        # Dessin de la route

        endroit_score.fill((0, 230, 0))
        route.fill((150, 150, 150))

        route.blit(trait_blanc, (20, 0))
        route.blit(trait_blanc, (370, 0))

        score += 1  # Incrémentation du score

        for i, bande in enumerate(bandes):  # Affichage, déplacement des bandes
            route.blit(bande_blanche, (190, bande))
            bandes[i] = (bande + 2) % 480

        for i, mur in enumerate(murs):  # Affichage, déplacement des murs
            route.blit(brique, (mur.pos_x, mur.pos_y))

            mur.pos_y += 2
            if mur.pos_y > 480:
                del (murs[i])

        for i, crevasse in enumerate(crevasses):  # Affichage, déplacement des fissures
            route.blit(fissure, (crevasse.pos_x, crevasse.pos_y))

            crevasse.pos_y += 2
            if crevasse.pos_y > 480:
                del (crevasses[i])

        for i, voiture in enumerate(voitures):  # Affichage, déplacement des voitures

            if voiture.accident == False:
                voiture.pos_y += 1
                route.blit(civil, (voiture.pos_x, voiture.pos_y))
            else:
                voiture.pos_y += 2
                route.blit(explosion, (voiture.pos_x - 40, voiture.pos_y - 20))

            if voiture.pos_y > 480:
                del (voitures[i])

        i = len(str(score))  # Affichage du score
        endroit_score.blit(texte_2.render('{}'.format(score), True, (0, 0, 0)), (100 - (i * 10), 0))

        route.blit(joueur, (perso.pos_x, perso.pos_y))  # Affichage du personnage

        pygame.display.flip()

        # Collisions

        for voiture in voitures:
            voiture.toucher()

        for mur in murs:
            mur.toucher(perso)

            for voiture in voitures:
                if voiture.accident == False:
                    mur.toucher(voiture)

        for crevasse in crevasses:
            crevasse.toucher(perso)

            for voiture in voitures:
                if voiture.accident == False:
                    crevasse.toucher(voiture)

fenetre.blit(texte.render('GAME OVER', True, (0, 0, 0)), (200, 200))
pygame.display.flip()
pygame.time.delay(2000)
