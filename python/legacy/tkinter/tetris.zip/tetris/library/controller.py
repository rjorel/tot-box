from random import choice

from library import model, view


class Player:
    """ The player view and action. """

    __colors = ["grey", "black", "purple", "brown", "orange", "blue", "red", "green", "yellow"];

    def __init__(self, root, canvas, rows, columns, size):
        self.__root = root;
        self.__canvas = canvas;
        self.__rows = rows;
        self.__columns = columns;
        self.__size = size;

        self.__shape = None;  # Model.
        self.__shapeView = None;  # View.
        self.newShape();

        self.__grid = [];  # Game grid, to store the placed shapes.
        for i in range(0, rows):  # Void at beginning, of course.
            self.__grid.append([None] * columns);

        self.__root.bind("<KeyPress-q>", lambda event: self.left());  # Key bindings.
        self.__root.bind("<KeyPress-d>", lambda event: self.right());
        self.__root.bind("<KeyPress-s>", lambda event: self.down());
        self.__root.bind("<KeyPress-z>", lambda event: self.rotate());

    def next(self):
        self.check();
        self.__shapeView.draw();
        self.move(0, 1);

        self.__root.after(500, self.next);

    def newShape(self):
        x = int(self.__columns / 2 - 1);  # New shape at the middle.
        self.__shape = choice([model.Bar(x), model.Square(x), model.Podium(x),
                               model.LeftStairCase(x), model.RightStairCase(x),
                               model.RightAngle(x), model.LeftAngle(x)]);

        self.__shapeView = view.Shape(self.__shape, choice(Player.__colors),
                                      # Create a view for the
                                      self.__size, self.__canvas);  # new model.

    # Check if the shape can be at the coords given in arguments.
    def checkPosition(self, x, y):
        width, height = self.__shape.getSize();

        if (x < 0 or (x + width) > self.__columns): return False;
        if ((y + height) > self.__rows): return False;
        if ([True for (lx, ly) in self.__shape.getCoordsList()
             if (self.__grid[y + ly][x + lx] != None)] != []):
            return False;

        return True;

    # Check if a shape is placed. Create a new shape if it's the case.    
    def check(self):
        y = self.__shape.gety();

        if (
        not self.checkPosition(self.__shape.getx(), y + 1)):  # If True, the shape can't go further.
            self.retrieveIds();  # At first, get the shape ids.

            for i in range(0, self.__shape.getHeight()):  # Check if a line is completed.
                if (not (None in self.__grid[y + i])):
                    for id in self.__grid[y + i]:  # Remove all the squares of the line.
                        self.__canvas.delete(id);

                    del (self.__grid[y + i]);  # Remove the line, and put an empty line.
                    self.__grid.insert(0, [None] * self.__columns);

                    for row in range(y + i, -1, -1):  # Now, down all the squares above.
                        for id in self.__grid[row]:
                            if (id != None):
                                self.__canvas.move(id, 0, self.__size);

            self.newShape();

    def move(self, dx, dy):
        if (self.checkPosition(self.__shape.getx() + dx, self.__shape.gety() + dy)):
            self.__shape.move(dx, dy);
            self.__shapeView.draw();

    def retrieveIds(self):
        ids = self.__shapeView.getIds();
        for (i, (x, y)) in enumerate(self.__shape.getCoords()):
            self.__grid[y][x] = ids[i];

    def down(self):
        self.move(0, 1);

    def left(self):
        self.move(-1, 0);

    def right(self):
        self.move(1, 0);

    # Rotate the shape, and go back if it's not possible.
    def rotate(self):
        self.__shape.rotate();

        if (not self.checkPosition(self.__shape.getx(), self.__shape.gety())):
            self.__shape.rotate(False);

        self.__shapeView.draw();
