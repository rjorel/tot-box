""" Util class for configuration representation. """


class Configuration:
    """ Shape configuration. """

    def __init__(self, width=0, height=0, coords=[]):
        self.__width = width;
        self.__height = height;
        self.__coords = coords;

    def getCoords(self): return list(self.__coords);

    def getWidth(self): return self.__width;

    def getHeight(self): return self.__height;


class Shape:
    """ Basis class for shape. """

    def __init__(self, x=0, y=0, config=Configuration(), pos=0):
        self._x = x;
        self._y = y;
        self._pos = pos;

        self._config = config;

    def getCoordsList(self): return self._config.getCoords();

    def getCoords(self):
        return [(self._x + x, self._y + y) for (x, y) in self._config.getCoords()];

    def getSize(self): return (self._config.getWidth(), self._config.getHeight());

    def getWidth(self): return self._config.getWidth();

    def getHeight(self): return self._config.getHeight();

    def getx(self): return self._x;

    def gety(self): return self._y;

    def setx(self, x): self._x = x;

    def sety(self, y): self._y = y;

    def rotate(self, clockwise=True): return;  # Kind of virtual function.

    def move(self, dx, dy):
        self._x += dx;
        self._y += dy;


class Square(Shape):
    """ The square, it doesn't rotate. """

    def __init__(self, x=0, y=0):
        Shape.__init__(self, x, y, Configuration(2, 2, [(0, 0), (0, 1), (1, 0), (1, 1)]));


class Bar(Shape):
    """ The bar, just two possible positions. """

    __configs = [Configuration(1, 4, [(0, 0), (0, 1), (0, 2), (0, 3)]),
                 Configuration(4, 1, [(0, 0), (1, 0), (2, 0), (3, 0)])];

    def __init__(self, x=0, y=0):
        Shape.__init__(self, x, y, Bar.__configs[0]);

    def rotate(self, clockwise=True):
        self._pos = 1 - self._pos;
        self._config = Bar.__configs[self._pos];

        if (self._pos == 0):  # Some coords changes, to respect the original shape moves.
            self._x += 1;
            self._y -= 1;
        else:
            self._x -= 1;
            self._y += 1;


class LeftStairCase(Shape):
    """ Staircase shape, two positions. """

    __configs = [Configuration(2, 3, [(0, 0), (0, 1), (1, 1), (1, 2)]),
                 Configuration(3, 2, [(0, 1), (1, 1), (1, 0), (2, 0)])];

    def __init__(self, x=0, y=0):
        Shape.__init__(self, x, y, LeftStairCase.__configs[0]);

    def rotate(self, clockwise=True):
        self._pos = 1 - self._pos;
        self._config = LeftStairCase.__configs[self._pos];


class RightStairCase(Shape):
    """ Staircase shape, two positions. """

    __configs = [Configuration(2, 3, [(1, 0), (1, 1), (0, 1), (0, 2)]),
                 Configuration(3, 2, [(0, 0), (1, 0), (1, 1), (2, 1)])];

    def __init__(self, x=0, y=0):
        Shape.__init__(self, x, y, RightStairCase.__configs[0]);

    def rotate(self, clockwise=True):
        self._pos = 1 - self._pos;
        self._config = RightStairCase.__configs[self._pos];


class Podium(Shape):
    """ The T shape. """

    __configs = [Configuration(3, 2, [(1, 0), (0, 1), (1, 1), (2, 1)]),
                 Configuration(2, 3, [(0, 0), (0, 1), (1, 1), (0, 2)]),
                 Configuration(3, 2, [(0, 0), (1, 0), (2, 0), (1, 1)]),
                 Configuration(2, 3, [(1, 0), (0, 1), (1, 1), (1, 2)])];

    def __init__(self, x=0, y=0):
        Shape.__init__(self, x, y, Podium.__configs[0]);

    def rotate(self, clockwise=True):
        if (clockwise):
            self._pos = (self._pos + 1) % 4;
        else:
            self._pos = (self._pos + 3) % 4;

        if (self._pos == 1):  # Some coords changes, to respect the original shape moves.
            self._x += 1;

        elif (self._pos == 2):
            self._x -= 1;

        self._config = Podium.__configs[self._pos];


class RightAngle(Shape):
    """ Right L shape. """

    __configs = [Configuration(2, 3, [(1, 0), (1, 1), (1, 2), (0, 2)]),
                 Configuration(3, 2, [(0, 0), (0, 1), (1, 1), (2, 1)]),
                 Configuration(2, 3, [(0, 0), (1, 0), (0, 1), (0, 2)]),
                 Configuration(3, 2, [(0, 0), (1, 0), (2, 0), (2, 1)])];

    def __init__(self, x=0, y=0):
        Shape.__init__(self, x, y, RightAngle.__configs[0]);

    def rotate(self, clockwise=True):
        if (clockwise):
            self._pos = (self._pos + 1) % 4;
        else:
            self._pos = (self._pos + 3) % 4;

        if (self._pos == 2):  # Some coords changes, to respect the original shape moves.
            self._x += 1;

        elif (self._pos == 3):
            self._x -= 1;

        self._config = RightAngle.__configs[self._pos];


class LeftAngle(Shape):
    """ Left L shape. """

    __configs = [Configuration(2, 3, [(0, 0), (0, 1), (0, 2), (1, 2)]),
                 Configuration(3, 2, [(0, 0), (1, 0), (2, 0), (0, 1)]),
                 Configuration(2, 3, [(0, 0), (1, 0), (1, 1), (1, 2)]),
                 Configuration(3, 2, [(0, 1), (1, 1), (2, 1), (2, 0)])];

    def __init__(self, x=0, y=0):
        Shape.__init__(self, x, y, LeftAngle.__configs[0]);

    def rotate(self, clockwise=True):
        if (clockwise):
            self._pos = (self._pos + 1) % 4;
        else:
            self._pos = (self._pos + 3) % 4;

        if (self._pos == 0):  # Some coords changes, to respect the original shape moves.
            self._x += 1;

        elif (self._pos == 1):
            self._x -= 1;

        self._config = LeftAngle.__configs[self._pos];
