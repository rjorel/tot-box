class Shape:
    """ General view for shapes. """

    def __init__(self, shape, color, size, canvas):
        self.__shape = shape;
        self.__color = color;
        self.__size = size;
        self.__canvas = canvas;

        self.__ids = [];
        for (x, y) in self.__shape.getCoords():  # Create the canvas ids.
            self.__ids.append(self.__canvas.create_rectangle(-1, -1, -1, -1, fill=color));

    def getIds(self):
        return list(self.__ids);

    def draw(self):
        for (i, (x, y)) in enumerate(self.__shape.getCoords()):
            self.__canvas.coords(self.__ids[i], x * self.__size, y * self.__size,
                                 (x + 1) * self.__size, (y + 1) * self.__size);
