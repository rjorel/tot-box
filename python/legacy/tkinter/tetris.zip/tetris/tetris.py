#!/usr/bin/env python3

from tkinter import *

from library import controller


class Window:
    """ Window display. """

    def __init__(self, rows=25, columns=15, size=20):
        self.__root = Tk();

        self.__rows = rows;
        self.__columns = columns;
        self.__size = size;

        self.__canvas = Canvas(self.__root, width=columns * size, height=rows * size,
                               background="white");
        self.__canvas.pack();

        self.__player = controller.Player(self.__root, self.__canvas, rows, columns, size);

        self.__root.title("Tetris");
        self.__root.resizable(False, False);

        self.__player.next();
        self.__root.mainloop();


if (__name__ == "__main__"):
    Window();
