import sys

from PyQt5.QtWidgets import QApplication
import matplotlib.pyplot as plt
import serial
from serial.tools import list_ports

from monitor.connectors import FakeConnector, SerialPortConnector
from monitor.core import Application, Graph, Line, Measure, Transformation
from monitor.widgets import Window


def pu_function(data):
    tension = data.get('tension')
    intensity = data.get('intensity')

    return [
        tension / intensity
        for (tension, intensity) in zip(tension.get_values(), intensity.get_values())
    ]


def p100_function(data):
    water = data.get('water')

    return [
        0.5 * 0.008 * 0.064 * (x ** 3)
        for x in water.get_values()
    ]


def tsr_function(data):
    rotor_measures = data.get('rotor')
    water = data.get('water')

    return [
        rotor / water
        for (rotor, water) in zip(rotor_measures.get_values(), water.get_values())
    ]


def performance_function(data):
    pu_data = data.get('pu')
    p100_data = data.get('p100')

    return [
        pu / p100
        for (pu, p100) in zip(pu_data.get_values(), p100_data.get_values())
    ]


def get_connector():
    available_ports = list_ports.comports()

    for port in available_ports:
        try:
            return SerialPortConnector(port.device)

        except serial.serialutil.SerialException:
            pass

    return FakeConnector()


def make_application():
    water = Measure()
    rotor = Measure()
    tension = Measure()
    intensity = Measure()

    pu = Transformation(pu_function, tension=tension, intensity=intensity)
    p100 = Transformation(p100_function, water=water)
    tsr = Transformation(tsr_function, rotor=rotor, water=water)
    performance = Transformation(performance_function, pu=pu, p100=p100)

    measures = [
        water, rotor, tension, intensity
    ]

    lines = [
        Line(water, name='Vitesse eau', unit='Noeuds', color='blue'),
        Line(rotor, name='Vitesse pale', unit='RPM', color='red'),
        Line(tension, name='Tension', unit='Volts', color='blue'),
        Line(intensity, name='Intensité', unit='Ampères', color='red'),
        Line(pu, name='Pu', unit='', color='blue'),
        Line(p100, name='P100', unit='', color='red'),
        Line(tsr, name='TSR', unit='', color='blue'),
        Line(performance, name='Rendement', unit='%age', color='red'),
    ]

    graphs = [
        Graph(lines[0:2], x_label='Temps (s)', multi_scales=True),
        Graph(lines[2:4], x_label='Temps (s)', multi_scales=True),
        Graph(lines[4:6], x_label='Temps (s)'),
        Graph(lines[6:8], x_label='Temps (s)', multi_scales=True),
    ]

    return Application(
        get_connector(), measures, lines, graphs
    )


if __name__ == '__main__':
    plt.style.use('bmh')

    app = QApplication(sys.argv)

    window = Window(
        make_application()
    )

    sys.exit(app.exec())
