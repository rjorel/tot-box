import abc
from random import random
from time import sleep

import serial


class Connector(abc.ABC):
    @abc.abstractmethod
    def next_line(self):
        return NotImplemented


class FakeConnector(Connector):
    _MIN = -10
    _MAX = 10

    _LATENCY_COEFF = 0.01

    def next_line(self):
        self._fake_latency()

        return str(self._random_float())

    def _fake_latency(self):
        sleep(random() * self._LATENCY_COEFF)

    def _random_float(self):
        return random() * (self._MAX - self._MIN) + self._MIN


class SerialPortConnector(Connector):

    def __init__(self, port, baud_rate=9600):
        self._serial = serial.Serial(port, baudrate=baud_rate)

    def next_line(self):
        return self._serial.readline()
