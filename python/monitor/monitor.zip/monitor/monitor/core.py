from typing import List

from .connectors import Connector


class Measure:

    def __init__(self):
        self._values = []

    def get_values(self):
        return self._values

    def add_value(self, value):
        self._values.append(value)


class Transformation:

    def __init__(self, func: callable, **kwargs):
        self._func = func
        self._args = kwargs

    def get_values(self):
        return self._func(self._args)


class Line:

    def __init__(self, measure: Measure or Transformation, name, unit, color):
        self._measure = measure
        self._name = name
        self._unit = unit
        self._color = color

    @property
    def measure(self):
        return self._measure

    @property
    def name(self):
        return self._name

    @property
    def unit(self):
        return self._unit

    @property
    def color(self):
        return self._color


class Graph:

    def __init__(self, lines, x_label='X', multi_scales=False):
        self._lines = lines
        self._x_label = x_label

        self._multi_scales = multi_scales

    @property
    def x_label(self):
        return self._x_label

    @property
    def lines(self):
        return self._lines

    @property
    def num_lines(self):
        return len(self._lines)

    @property
    def multi_scales(self):
        return bool(self._multi_scales)


class Application:

    def __init__(self, connector: Connector, measures: List[Measure], lines, graphs):
        self._connector = connector
        self._measures = measures
        self._lines = lines
        self._graphs = graphs

        self._times = []

    @property
    def connector(self):
        return self._connector

    @property
    def measures(self):
        return self._measures

    @property
    def lines(self):
        return self._lines

    @property
    def graphs(self):
        return self._graphs

    @property
    def times(self):
        return self._times
