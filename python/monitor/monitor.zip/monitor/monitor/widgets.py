import csv
from math import sqrt
import time

from PyQt5.QtCore import QBasicTimer, Qt
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QAction, QFileDialog, QGridLayout, QHBoxLayout, QLabel, QMainWindow, QPushButton, \
    QSizePolicy, QVBoxLayout, QWidget
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure

from .core import Application, Graph


class GraphWidget(QWidget):
    _GRAPH_WIDTH = 5
    _GRAPH_HEIGHT = 4
    _GRAPH_DPI = 80

    _LINE_SIZE = 10

    def __init__(self, app: Application, graph: Graph, parent=None):
        super().__init__(parent)

        self._app = app
        self._graph = graph

        self._value_labels = []

        self._init_ui()

    def _init_ui(self):
        label_layout = QGridLayout()

        for (i, line) in enumerate(self._graph.lines):
            label_layout.addWidget(QLabel(line.name, self), i, 0)

            label = QLabel(self)
            label_layout.addWidget(label, i, 1)

            self._value_labels.append(label)

        self._init_canvas()

        main_layout = QVBoxLayout(self)

        main_layout.addWidget(self._canvas)
        main_layout.addLayout(label_layout)

    def _init_canvas(self):
        self._canvas = FigureCanvasQTAgg(
            Figure(figsize=(self._GRAPH_WIDTH, self._GRAPH_HEIGHT), dpi=self._GRAPH_DPI)
        )

        self._canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self._original_axes = self._canvas.figure.add_subplot(111)
        self._original_axes.set_xlabel(self._graph.x_label)

        self._axes = [self._original_axes]

        # If the graph use different scales for lines, y-axis has to be twined.
        if self._graph.multi_scales:
            for _ in range(0, len(self._graph.lines[1:])):
                self._axes.append(self._original_axes.twinx())

        # If not, the y-axis is shared by all lines.
        else:
            self._axes += [self._original_axes] * len(self._graph.lines[1:])

        for (axes, line) in zip(self._axes, self._graph.lines):
            axes.set_ylabel(line.unit)

        plots = [
            axes.plot([], [], marker='o', color=line.color, label=line.name)
            for (axes, line) in zip(self._axes, self._graph.lines)
        ]

        # Get first object of plots, corresponding to Matplotlib's Line2D.
        self._lines = [plot[0] for plot in plots]

        labels = [line.get_label() for line in self._lines]

        self._original_axes.legend(self._lines, labels, loc=0)

    def update(self):
        super().update()

        # Display last values for each line in labels provided for this purpose.
        for (label, line) in zip(self._value_labels, self._graph.lines):
            data = line.measure.get_values()

            try:
                label.setText(str(data[-1]))
            except IndexError:
                pass

        self._update_canvas()

    def _update_canvas(self):
        x_values = self._get_displayed_values(self._app.times)
        ys_values = []

        for (line, graph_line) in zip(self._lines, self._graph.lines):
            y_values = self._get_displayed_values(graph_line.measure.get_values())

            line.set_data(x_values, y_values)
            ys_values.append(y_values)

        self._update_limits(x_values, ys_values)

        self._canvas.draw()

    def _get_displayed_values(self, values):
        return values[-self._LINE_SIZE:]

    def _update_limits(self, x_values, ys_values):
        self._original_axes.set_xlim([
            min(x_values), max(x_values)
        ])

        for (axes, y_values) in zip(self._axes, ys_values):
            current_y_limits = axes.get_ylim()

            axes.set_ylim([
                float(min(current_y_limits[0], *y_values)),
                float(max(current_y_limits[1], *y_values))
            ])


class Window(QMainWindow):
    _TIMER_DELAY_MS = 1000

    def __init__(self, app: Application, parent=None):
        super().__init__(parent)

        self._app = app

        self._init_ui()
        self._init_menu()
        self._init_buttons()
        self._init_bindings()

        self._timer = QBasicTimer()
        self._timer.start(self._TIMER_DELAY_MS, self)
        self._is_running = False

        self._start_time = time.time()

        self.setWindowTitle('Monitor')
        self.show()

    def _init_ui(self):
        self._central_widget = QWidget(self)
        self._main_layout = QVBoxLayout(self._central_widget)

        graph_layout = QGridLayout()

        # Use square root value of number of graphs to optimize graph placement in grid.
        sqrt_num_lines = int(
            sqrt(len(self._app.graphs))
        )

        self._graph_widgets = []

        for (i, graph) in enumerate(self._app.graphs):
            widget = GraphWidget(self._app, graph)

            row = i % sqrt_num_lines
            col = i // sqrt_num_lines

            graph_layout.addWidget(widget, row, col)

            self._graph_widgets.append(widget)

        self._main_layout.addLayout(graph_layout)
        
        self.setCentralWidget(self._central_widget)

    def _init_menu(self):
        file_menu = self.menuBar().addMenu('File')

        self._exit_action = QAction('Exit', self)
        self._exit_action.setShortcut(QKeySequence.Quit)

        file_menu.addAction(self._exit_action)

    def _init_buttons(self):
        self._start_button = QPushButton('Start / Resume', self)
        self._pause_button = QPushButton('Pause', self)
        self._stop_and_save_button = QPushButton('Stop \'n Save', self)

        button_layout = QHBoxLayout()

        button_layout.setAlignment(Qt.AlignRight)
        button_layout.addWidget(self._start_button)
        button_layout.addWidget(self._pause_button)
        button_layout.addWidget(self._stop_and_save_button)

        self._main_layout.addLayout(button_layout)

    def _init_bindings(self):
        self._exit_action.triggered.connect(self.close)
        self._start_button.clicked.connect(self.start)
        self._pause_button.clicked.connect(self.pause)
        self._stop_and_save_button.clicked.connect(self.stop_and_save)

    def start(self):
        self._is_running = True

    def pause(self):
        self._is_running = False

    def stop_and_save(self):
        self.pause()

        try:
            self._save_lines()
        except IOError:
            pass

    def _save_lines(self):
        self._save_as_file(
            self._get_file_name()
        )

    def _get_file_name(self):
        (file, _) = QFileDialog.getSaveFileName(
            self, 'Save file', '.', 'CSV files (*.csv)'
        )

        if not file:
            raise IOError

        if not file.endswith('.csv'):
            file += '.csv'

        return file

    def _save_as_file(self, filename):
        headers = self._get_headers()

        with open(filename, 'w') as fd:
            writer = csv.DictWriter(fd, headers)

            writer.writeheader()
            writer.writerows(self._get_rows())

    def _get_headers(self):
        line_names = [
            line.name for line in self._app.lines
        ]

        return ['Time'] + list(line_names)

    def _get_rows(self):
        headers = self._get_headers()
        data = self._get_graph_data()

        return [
            {
                headers[i]: value
                for (i, value) in enumerate(values)
            }
            for values in zip(*data)
        ]

    def _get_graph_data(self):
        data = [self._app.times]

        for line in self._app.lines:
            data.append(line.measure.get_values())

        return data

    def timerEvent(self, event):
        if event.timerId() != self._timer.timerId():
            return

        # Get values event if we do not use them.
        # Data are produced in real-time, we can not stop to get them.
        values = self._get_connector_values()

        if not self._is_running:
            return

        self._app.times.append(
            self._get_elapsed_time()
        )

        for (measure, value) in zip(self._app.measures, values):
            measure.add_value(value)

        for widget in self._graph_widgets:
            widget.update()

    def _get_connector_values(self):
        return [
            float(
                self._app.connector.next_line()
            )
            for _ in range(0, len(self._app.measures))
        ]

    def _get_elapsed_time(self):
        return time.time() - self._start_time
