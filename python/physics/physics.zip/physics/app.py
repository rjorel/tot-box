import sys

from PyQt5.QtWidgets import QApplication

from physics.colliders import PlaneCollider
from physics.core import Point, System
from physics.forces import DragForce, GravityForce
from physics.ode import ParticleODE
from physics.solvers import MidPointSolver
from physics.widgets import Window


if __name__ == '__main__':
    app = QApplication(sys.argv)

    particles = []

    forces = [
        GravityForce(particles),  # Earth gravity.
        DragForce(particles),  # Just to decrease global system energy.
    ]

    colliders = [
        PlaneCollider(Point(0, 0), Point(1, 0)),
        PlaneCollider(Point(0, 480), Point(0, -1)),
        PlaneCollider(Point(640, 0), Point(-1, 0)),
    ]

    ode = ParticleODE(particles, forces)
    solver = MidPointSolver(ode)
    system = System(solver, particles, colliders, forces)

    win = Window(system, 640, 480)

    sys.exit(app.exec_())

