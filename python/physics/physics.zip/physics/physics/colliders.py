import abc

from .core import Particle, Point


class Collider(abc.ABC):
    @abc.abstractmethod
    def hit(self, particle: Particle):
        return NotImplemented


class PlaneCollider(Collider):
    _EPSILON = 10e-5

    def __init__(self, origin: Point, direction: Point, restitution_coefficient=0.8):
        self._origin = origin
        self._normal = direction.normalized()
        self._restitution_coefficient = restitution_coefficient

    def hit(self, particle: Particle):
        if not self._is_colliding_particle(particle):
            return

        # Reverse the particle speed.
        normal_speed = self._normal * self._normal.dot(particle.speed)
        tangent_speed = particle.speed - normal_speed

        # Place the particle at plane boundary.
        self._fix_overshooting(particle)

        # Change speed and apply a coefficient that symbolizes the energy loss.
        particle.speed = tangent_speed - normal_speed * self._restitution_coefficient

    def _is_colliding_particle(self, particle: Particle):
        distance = self._get_distance_to_particle(particle)

        # Not a vector direction but a value to know if the particle is currently going against the plane.
        direction = self._normal.dot(particle.speed)

        return distance < PlaneCollider._EPSILON and direction < 0

    def _get_distance_to_particle(self, particle: Particle):
        return (particle.position - self._origin).dot(self._normal) - particle.radius

    def _fix_overshooting(self, particle: Particle):
        """
        Simple fixing method. Point projection on plane.
        """

        # We want to place the point at a distance equal to radius from the plane.
        # So the plane origin is shifted from a radius value in the normal plane direction.
        # I don't understand why I'm obliged to subtract 1 to avoid that particles bounce on surface.
        plane_origin = self._origin + self._normal * (particle.radius - 1)
        diff_vector = particle.position - plane_origin

        # Classical way to compute projection on plane.
        particle.position = particle.position - self._normal * diff_vector.dot(self._normal)
