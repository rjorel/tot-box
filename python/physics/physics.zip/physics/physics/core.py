from math import acos, atan2, sqrt


class Point:
    def __init__(self, x, y):
        self._x = x
        self._y = y

    @property
    def x(self):
        return self._x

    @property
    def y(self):
        return self._y

    def __add__(self, other: 'Point'):
        return Point(self._x + other.x, self._y + other.y)

    def __sub__(self, other: 'Point'):
        return Point(self._x - other.x, self._y - other.y)

    def __neg__(self):
        return Point(-self._x, -self._y)

    def __mul__(self, scalar):
        return Point(self._x * scalar, self._y * scalar)

    def __floordiv__(self, scalar):
        try:
            return Point(self._x // scalar, self._y // scalar)
        except ZeroDivisionError:
            return Point(0, 0)

    def __truediv__(self, scalar):
        try:
            return Point(self._x / scalar, self._y / scalar)
        except ZeroDivisionError:
            return Point(0, 0)

    def __str__(self):
        return "(x: {}, y: {})".format(self._x, self._y)

    def norm(self):
        return sqrt(self._x ** 2 + self._y ** 2)

    def normalize(self):
        self /= self.norm()

    def normalized(self):
        return self / self.norm()

    def truncated(self):
        return Point(round(self._x), round(self._y))

    def polar(self):
        return self.norm(), atan2(self._y, self._x)

    def angle(self, vector: 'Point'):
        try:
            return acos((self._x * vector.x + self._y * vector.y) / (self.norm() * vector.norm()))
        except ArithmeticError:
            return 0

    def distance(self, point: 'Point'):
        return (point - self).norm()

    def scale(self, length):
        return self * (length / self.norm())

    def dot(self, point: 'Point'):
        return self._x * point.x + self._y * point.y


class Vector(Point):
    pass


class Particle:

    def __init__(self, position: Point, speed: Vector = Vector(0, 0), radius=10, mass=10, color=(0, 0, 0)):
        self._position = position
        self._speed = speed
        self._force = Vector(0, 0)

        self._radius = radius
        self._mass = mass
        self._color = color

    @property
    def position(self):
        return self._position

    @position.setter
    def position(self, position):
        self._position = position

    @property
    def speed(self):
        return self._speed

    @speed.setter
    def speed(self, speed):
        self._speed = speed

    @property
    def force(self):
        return self._force

    @property
    def radius(self):
        return self._radius

    @property
    def mass(self):
        return self._mass

    @property
    def color(self):
        return self._color

    def reset_force(self):
        self._force = Point(0, 0)

    def add_force(self, force):
        self._force += force

    def is_colliding(self, other: 'Particle'):
        return self._position.distance(other.position) <= other.radius + self._radius


class System:

    def __init__(self, solver, particles, colliders, forces):
        self._solver = solver
        self._particles = particles
        self._colliders = colliders
        self._forces = forces

    @property
    def particles(self):
        return self._particles

    @property
    def colliders(self):
        return self._colliders

    @property
    def forces(self):
        return self._forces

    def next_step(self, dt=0.4):
        self._solver.step(dt)
        self._handle_colliders()

    def _handle_colliders(self):
        for collider in self._colliders:
            for particle in self._particles:
                collider.hit(particle)
