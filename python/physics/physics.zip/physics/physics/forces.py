import abc
from typing import List

from .core import Particle, Point


class Force(abc.ABC):
    @abc.abstractmethod
    def apply(self):
        return NotImplemented


class GravityForce(Force):
    def __init__(self, particles: List[Particle], gravity_constant: Point = Point(0, 9.81)):
        self._particles = particles
        self._gravity_constant = gravity_constant

    def apply(self):
        for particle in self._particles:
            particle.add_force(self._gravity_constant * particle.mass)


class DragForce(Force):
    def __init__(self, particles: List[Particle], friction_constant=0.01):
        self._particles = particles
        self._friction_constant = friction_constant

    def apply(self):
        for particle in self._particles:
            particle.add_force(particle.speed * -self._friction_constant)
