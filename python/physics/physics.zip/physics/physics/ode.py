import abc
from itertools import chain
from typing import List

from .core import Particle, Point
from .forces import Force


class ODE(abc.ABC):
    """ Ordinary Differential Equation system. """

    @abc.abstractmethod
    def get_dim(self) -> int:
        return NotImplemented

    @abc.abstractmethod
    def get_state(self) -> tuple:
        return NotImplemented

    @abc.abstractmethod
    def set_state(self, data: tuple or list):
        return NotImplemented

    @abc.abstractmethod
    def get_derivative(self) -> tuple:
        return NotImplemented


class ParticleODE(ODE):
    def __init__(self, particles: List[Particle], forces: List[Force]):
        self._particles = particles
        self._forces = forces

    def get_dim(self) -> int:
        return 4 * len(self._particles)

    def get_state(self) -> tuple:
        return tuple(chain(*[
            (
                particle.position.x, particle.position.y,
                particle.speed.x, particle.speed.y
            ) for particle in self._particles
        ]))

    def set_state(self, data: tuple or list):
        for (index, particle) in enumerate(self._particles):
            particle.position = Point(data[4 * index + 0], data[4 * index + 1])
            particle.speed = Point(data[4 * index + 2], data[4 * index + 3])

    def get_derivative(self) -> tuple:
        self._reset_forces()
        self._apply_forces()

        # For each particle, 4 values : [speed (x, y), force (x, y) / mass].
        return tuple(chain(*[
            (
                particle.speed.x, particle.speed.y,
                particle.force.x / particle.mass,
                particle.force.y / particle.mass
            ) for particle in self._particles
        ]))

    def _reset_forces(self):
        for particle in self._particles:
            particle.reset_force()

    def _apply_forces(self):
        for force in self._forces:
            force.apply()
