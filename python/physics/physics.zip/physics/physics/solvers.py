import abc

from .ode import ODE


class Solver(abc.ABC):
    @abc.abstractmethod
    def step(self, dt):
        return NotImplemented


class EulerSolver(Solver):
    """
    Simple method to move to next step. Add each state to its derivative value from ODE system.
    """

    def __init__(self, ode: ODE):
        self._ode = ode

    def step(self, dt):
        new_state = [0] * self._ode.get_dim()

        for (index, (state, derivative)) in enumerate(zip(self._ode.get_state(), self._ode.get_derivative())):
            new_state[index] = state + derivative * dt

        self._ode.set_state(new_state)


class MidPointSolver(Solver):
    """
    More advanced method to compute next step.
    Use Euler computation but take the middle point to have a better approximation of next step.
    """

    def __init__(self, ode: ODE):
        self._ode = ode

    def step(self, dt):
        dim = self._ode.get_dim()
        current_state = self._ode.get_state()

        new_state = [0] * dim

        for (index, (state, derivative)) in enumerate(zip(current_state, self._ode.get_derivative())):
            new_state[index] = state + derivative * dt

        # Midpoint computation.
        mid = [0] * dim

        for index in range(0, dim):
            mid[index] = (current_state[index] + new_state[index]) / 2

        # New derivative computation.
        self._ode.set_state(mid)

        for (index, (state, derivative)) in enumerate(zip(current_state, self._ode.get_derivative())):
            new_state[index] = state + derivative * dt

        self._ode.set_state(new_state)
