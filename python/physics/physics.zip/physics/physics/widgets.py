from random import randint
from typing import List

from PyQt5.QtCore import QBasicTimer, Qt
from PyQt5.QtGui import QColor, QKeySequence, QPainter
from PyQt5.QtWidgets import QAction, QHBoxLayout, QMainWindow, QWidget

from .core import Particle, Point, System, Vector


class Canvas(QWidget):
    def __init__(self, particles: List[Particle]):
        super().__init__()

        self._particles = particles

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)

        self._draw_background(qp)
        self._draw_particles(qp)

        qp.end()

    def _draw_background(self, qp: QPainter):
        qp.fillRect(
            0, 0,
            self.width(), self.height(),
            QColor(255, 255, 255)
        )

    def _draw_particles(self, qp: QPainter):
        for particle in self._particles:
            pos = particle.position
            radius = particle.radius

            qp.setBrush(QColor(*particle.color))

            qp.drawEllipse(
                int(pos.x - radius),
                int(pos.y - radius),
                int(radius * 2),
                int(radius * 2)
            )

    def mousePressEvent(self, event):
        if event.button() != Qt.LeftButton:
            return

        self._particles.append(
            self._create_particle(event.x(), event.y())
        )

    @staticmethod
    def _create_particle(x, y):
        radius = randint(5, 20)
        mass = radius
        color = (
            randint(0, 255), randint(0, 255), randint(0, 255)
        )

        return Particle(
            Point(x, y), Vector(randint(-20, 20), 0), radius, mass, color
        )


class Window(QMainWindow):
    _TIMER_DELAY_MS = 30

    def __init__(self, system: System, width, height):
        super().__init__()

        self._system = system
        self._width = width
        self._height = height

        self._init_ui()
        self._init_menu()

        self._timer = QBasicTimer()
        self._timer.start(self._TIMER_DELAY_MS, self)

        self.setWindowTitle('Physics')
        self.show()

    def _init_ui(self):
        self._central_widget = QWidget(self)
        self._canvas = Canvas(self._system.particles)

        main_layout = QHBoxLayout(self._central_widget)
        main_layout.addWidget(self._canvas)

        self._canvas.setFixedSize(self._width, self._height)

        self.setCentralWidget(self._central_widget)

    def _init_menu(self):
        file_menu = self.menuBar().addMenu('File')

        action = QAction('Exit', self)
        action.triggered.connect(self.close)
        action.setShortcut(QKeySequence.Quit)

        file_menu.addAction(action)

    def timerEvent(self, event):
        if event.timerId() != self._timer.timerId():
            return

        self._system.next_step()
        self._canvas.update()
