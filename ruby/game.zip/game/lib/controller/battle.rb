
require_relative "../model/player"
require_relative "../model/enemy"
require_relative "../view/display"
require_relative "../view/interface"


module Controller
    class Battle
        def initialize(player, enemy)
            @player = player;
            @enemy = enemy;
        end

        def start()
            while (!@player.dead?() && !@enemy.dead?())
                system("clear"); 
                puts("------------------");
                View::Player.description(@player);
                puts("------------------");
                View::Interface.battleMenu();
                
                loop do
                    print("Choice : ");
                    begin
                        ret = Integer(gets().chomp());
                    rescue ArgumentError => e
                        ret = -1;
                    end
                    
                    if (ret < 0 || ret > 9) then puts("Bad argument".red());
                    else break; end
                 end

                @player.attack(@enemy, @player.strength - @enemy.defense);
                @enemy.attack(@player, @enemy.strength - @player.defense);
            end

            puts("End battle".green());
        end
    end
end
