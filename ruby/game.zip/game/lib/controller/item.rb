
require_relative "../model/utils"
require_relative "../model/rand"
require_relative "../model/item"


module Controller

    class Item
        def initialize(item)
            @item = item;
        end

        def use(player, cItem, board)
            puts("Nothing to do with a simple object".red());
        end
    end


    class Tree < Item
        def use(player, cItems, board)
            print("Hit the tree to get fruits ? (y / n) ");
            case (gets().chomp())
                when 'y', 'Y'
                    if (@item.numFruits > 0) then
                        item = Model::Fruit.new();
                        cItems[item] = Controller::Fruit.new(item);
                        player.items.push(item);
                        @item.loseFruit();
                        puts("You get a fruit".green());
                    else
                        puts("Sorry, nothing in this tree".red());
                    end
            end
        end
    end


    class Stone < Item
        def use(player, cItems, board)
            print("Throw the stone at an enemy ? (y / n) ");
            case (gets().chomp())
                when 'y', 'Y'
                    if (board.enemies.empty?()) then
                        puts("No enemy to do this action".red());
                    else
                        puts("Choose the enemy to hurt :");
                        board.enemies.each_with_index() do |enemy, index|
                            puts("\t#{index + 1}. #{enemy.name()}");
                        end

                        print("Choice : ");
                        begin
                            ret = Integer(gets().chomp());
                        rescue ArgumentError => e
                            ret = 0;
                        end

                        if (ret > 0 && ret <= board.enemies.size()) then
                            enemy = board.enemies[ret - 1];

                            damages = @item.weight + Model::Rand.get().next(-5..5);
                            enemy.damage((damages < 0) ? 0 : damages);
                            player.items.delete(@item);
                            cItems.delete(@item);
                            print("Enemy lost #{damages} HP by stone\n".green());

                            if (enemy.dead?()) then
                                board.enemies.delete(enemy);
                                puts("The enemy is dead".blue());
                            end
                        else
                            puts("Bad argument".red());
                        end
                    end
            end
        end
    end

    
    class Fruit < Item
        def use(player, cItems, board)
            print("Eat the fruit to get life ? (y / n) ");
            case (gets().chomp())
                when 'y', 'Y'
                    life = Model::Rand.get().next(0..20);
                    player.addLife(life);
                    
                    puts("You get #{life} HP".green());
                    player.items.delete(@item);
                    cItems.delete(@item);
            end
        end
    end
end
