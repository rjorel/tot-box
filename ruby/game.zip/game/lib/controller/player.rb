
require_relative "../model/utils"
require_relative "../controller/battle"


module Controller
    class Player
        def initialize(player)
            @player = player;
        end

        def move(dir, x = Bound.new(0, 2), y = Bound.new(0, 2))
            case dir
                when :left
                    if (@player.coords.x > x.min) then @player.move(-1, 0); end

                when :right
                    if (@player.coords.x < x.max) then @player.move(1, 0); end

                when :up
                    if (@player.coords.y > y.min) then @player.move(0, -1); end

                when :down
                    if (@player.coords.y < y.max) then @player.move(0, 1); end
            end
        end
    
        def attack(board)
            enemies = board.enemies;
            
            if (enemies.empty?()) then
                puts("No enemy to attack".red());
                return;
            end
                
            puts("Enemy(ies) to attack :\n")
            
            enemies.each_with_index() do |enemy, index|
                printf(
                    "%d. %s (life: %d, strength: %d, defense: %d)\n",
                    index + 1, enemy.name(), enemy.life, enemy.strength, enemy.defense
                );
            end

            print("Choice : ");
            begin 
                ret = Integer(gets().chomp());
            rescue ArgumentError => e
                ret = 0;
            end

            if (ret > 0 && ret <= enemies.size()) then
                Controller::Battle.new(@player, enemies[ret - 1]).start();
                
                if (enemies[ret - 1].dead?()) then
                    enemies.delete(enemies[ret - 1]);
                    puts("The enemy is dead".blue());
                end
            else
                puts("Bad argument".red());
            end
        end

        def pickup(board)
            items = board.items;
            
            if (items.empty?()) then
                puts("No item to pick up".red());
                return;
            end
               
            puts("Item(s) to pick up :\n")
            items.each_with_index() do |item, index|
                printf("%d. %s (%s)\n", index + 1, item.name(), item.movable?() ? "movable" : "no movable");
            end
            
            print("Choice : ");
            begin
                ret = Integer(gets().chomp());
            rescue ArgumentError => e
                ret = 0;
            end

            if (ret > 0 && ret <= items.size()) then
                item = items[ret - 1];
                
                if (item.movable?()) then
                    @player.addItem(item);
                    items.delete(item);
                else
                    puts("This item is not movable".red());
                end
            else
                puts("Bad argument".red());
            end
        end
        
        def use(cItems, board)
            if (@player.items.empty?() && board.items.empty?()) then
                puts("No item to use".red());
                return;
            end
          
            offset = 0;
            puts("Item(s) to use :\n");
            if (!@player.items.empty?()) then
                puts("Yours :");
                @player.items.each_with_index() do |item, index|
                    puts("\t#{index + 1}. #{item.name()}");
                end

                offset = @player.items.size();
            end

            if (!board.items.empty?()) then
                puts("Here :");
                board.items.each_with_index() do |item, index|
                    puts("\t#{offset + index + 1}. #{item.name()}");
                end
            end

            print("Choice : ");
            begin
                ret = Integer(gets().chomp());
            rescue ArgumentError => e
                ret = 0;
            end
            
            objects = @player.items + board.items;
            if (ret > 0 && ret <= objects.size()) then
                item = objects[ret - 1];
                cItems[item].use(@player, cItems, board);
            else
                puts("Bad argument".red());
            end
        end
    end
end
