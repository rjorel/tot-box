
require_relative "model/item"
require_relative "model/rand"
require_relative "model/player"
require_relative "model/enemy"
require_relative "model/board"
require_relative "model/utils"
require_relative "view/display"
require_relative "view/interface"
require_relative "controller/player"
require_relative "controller/item"


class Game
    @@size_x = 3;
    @@size_y = 3;

    def initialize(numItem = 0, numEnemy = 0)
        @player = Model::Player.new(100, 50, 20, 50, [0, 0]);
        @cPlayer = Controller::Player.new(@player);
        @cItems = {};
        @boards = [];

        0.upto(@@size_y).each do |i|
            @boards.push([]);
            
            0.upto(@@size_x).each do |j|
                @boards[i].push(Model::Board.new());
            end
        end
      
        1.upto(numItem).each do |i|
            case Model::Rand.get().next(0..1)
                when 0
                    object = Model::Tree.new(Model::Rand.get().next(0..3));
                    @cItems[object] = Controller::Tree.new(object);
                when 1
                    object = Model::Stone.new();
                    @cItems[object] = Controller::Stone.new(object);
                else
                    object = Model::Item.new();
                    @cItems[object] = Controller::Item.new(object);
            end

            @boards[Model::Rand.get().next(0..@@size_y)][Model::Rand.get().next(0..@@size_x)].addItem(object);
        end
        
        1.upto(numEnemy).each do |i|
            @boards[Model::Rand.get().next(0..@@size_y)][Model::Rand.get().next(0..@@size_x)].addEnemy(
                Model::Enemy.new(Model::Rand.get().next(20..100),
                                 Model::Rand.get().next(10..50),
                                 Model::Rand.get().next(10..50))
            );
        end
    end

    def play()
        loop do
            system("clear");
            if (@player.dead?()) then
                puts("You are dead".red());
                gets();
                break;
            end
       
            View::Interface.hud(@player, @boards[@player.coords.y][@player.coords.x]); 
            View::Interface.position(@player, [0, @@size_x], [0, @@size_y]); 
            View::Interface.menu();
            print("Choice : ");
           
            case gets().chomp()
                when 'a', 'A'; @cPlayer.attack(@boards[@player.coords.y][@player.coords.x]); gets();
                when 'p', 'P'; @cPlayer.pickup(@boards[@player.coords.y][@player.coords.x]); gets();
                when 'u', 'U'; @cPlayer.use(@cItems, @boards[@player.coords.y][@player.coords.x]); gets();
                when 'q', 'Q'; break;

                when 'ml'; @cPlayer.move(:left, Bound.new(0, @@size_x), Bound.new(0, @@size_y));
                when 'mr'; @cPlayer.move(:right, Bound.new(0, @@size_x), Bound.new(0, @@size_y));
                when 'mu'; @cPlayer.move(:up, Bound.new(0, @@size_x), Bound.new(0, @@size_y));
                when 'md'; @cPlayer.move(:down, Bound.new(0, @@size_x), Bound.new(0, @@size_y));
                else 
                    puts("Wrong action".red());
                    gets();
            end
        end
    end
end
