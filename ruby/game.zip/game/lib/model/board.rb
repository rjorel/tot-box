
require_relative "item"
require_relative "enemy"


module Model
    class Board
        attr_reader :items, :enemies
    
        def initialize()
            @items = [];
            @enemies = [];
        end
    
        def addItem(item)
            @items.push(item);
        end
    
        def addEnemy(enemy)
            @enemies.push(enemy);
        end
        
        def delItem(item)
            @items.delete(item);
        end
    
        def delEnemy(enemy)
            @enemies.delete(enemy);
        end
    
    end
end
