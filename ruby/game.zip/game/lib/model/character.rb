
module Model
    class Character
        attr_reader :life, :strength, :defense
    
        def initialize(life, strength, defense)
            @life = life;
            @strength = strength;
            @defense = defense;
        end
    
        def name()
            return "Character";
        end
        
        def damage(value)
            @life -= value;
        end
    
        def attack(other, value)
            other.damage(value);
        end

        def addLife(value)
            @life += value;
        end
    
        def dead?()
            return (life <= 0);
        end
    end
end
