
require_relative "utils"
require_relative "character"


module Model
    class Enemy < Character
    
        def initialize(life = 100, strength = 50, defense = 20)
            super(life, strength, defense);
        end
    
    
        def name()
            return "Enemy";
        end
    end
end
