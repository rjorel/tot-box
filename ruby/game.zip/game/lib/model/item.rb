
module Model
    class Item
        attr_reader :weight
    
        def initialize(weight = 0)
            @weight = weight;
        end
    
        def movable?()
            return false;
        end
    
        def name()
            return "Item";
        end

        def to_s()
            return "";
        end
    end
    
    
    class Tree < Item
        attr_reader :numFruits

        def initialize(numFruits)
            super(100);
            @numFruits = numFruits;
        end
    
        def movable?()
            return false;
        end
    
        def name()
            return "Tree";
        end

        def loseFruit()
            @numFruits -= 1;
        end
    end
    
    
    class Stone < Item
        def initialize()
            super(5);
        end
    
        def movable?()
            return true;
        end
    
        def name()
            return "Stone";
        end
    end


    class Fruit < Item
        def initialize()
            super(2);
        end

        def movable?()
            return true;
        end

        def name()
            return "Fruit";
        end
    end
end
