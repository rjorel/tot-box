
require_relative "utils"
require_relative "character"
require_relative "item"


module Model
    class Player < Character
        attr_reader :weightMax, :coords, :items
    
        def initialize(life = 100, strength = 50, defense = 20, weight = 0, coords = [0, 0])
            super(life, strength, defense);
            @weightMax = weight;
            @coords = Coords.new(coords[0], coords[1]);
            @items = [];
        end
    
        def name()
            return "Player";
        end
    
        def move(dx, dy)
            @coords.x += dx;
            @coords.y += dy;
        end
    
        def addItem(item)
            @items.push(item);
        end
    end
end
