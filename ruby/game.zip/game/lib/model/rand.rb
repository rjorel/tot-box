
module Model
    class Rand
        @@rand = nil;

        def initialize()
            @generator = Random.new();
        end

        def Rand.get()
            if (@@rand == nil) then @@rand = Rand.new(); end
            return @@rand;
        end

        def next(object)
            return @generator.rand(object);
        end
        
        private :initialize
    end
end
