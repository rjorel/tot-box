
class Coords
    attr_accessor :x, :y

    def initialize(x = 0, y = 0)
        @x = x;
        @y = y;
    end
end


class Bound
    attr_accessor :min, :max

    def initialize(min = 0, max = 0)
        @min = min;
        @max = max;
    end
end


class String
    def black()     "\033[30m#{self}\033[0m"; end
    def red()       "\033[31m#{self}\033[0m"; end
    def green()     "\033[32m#{self}\033[0m"; end
    def yellow()    "\033[33m#{self}\033[0m"; end
    def blue()      "\033[34m#{self}\033[0m"; end
    def magenta()   "\033[35m#{self}\033[0m"; end
    def cyan()      "\033[36m#{self}\033[0m"; end
    def gray()      "\033[37m#{self}\033[0m"; end
end
