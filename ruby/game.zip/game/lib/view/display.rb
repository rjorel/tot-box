
require_relative "../model/utils"
require_relative "../model/player"
require_relative "../model/enemy"
require_relative "../model/item"
require_relative "../model/board"


module View
    class Player
        def Player.description(player)
            w = 0;
            player.items.each() do |item| 
                w += item.weight;
            end
            
            print("Player :\n".green() +
                  "\tLife : #{player.life.to_s()}\n" +
                  "\tStrength : #{player.strength.to_s()}\n" + 
                  "\tDefense : #{player.defense.to_s()}\n" +
                  "\tWeight : #{w.to_s()} / #{player.weightMax.to_s()}\n");

            if (player.items.empty?())
                puts("No item.");
            else
                print("Item(s) : ");
                player.items.each() do |item|
                    print(item.name() + " ");
                end
                puts("");
            end
        end
    end


    class Enemy
        def Enemy.description(enemy)
            puts("Enemy :\n".red() +
                 "\tLife : #{enemy.life.to_s()}\n" +
                 "\tStrength : #{enemy.strength.to_s()}\n" +
                 "\tDefense : #{enemy.defense.to_s()}");
        end
    end


    class Item 
        def Item.description(item)
            puts("A simple item.".blue());
        end
    end
    
    
    class Tree
        def Tree.description(tree)
            puts("A tree. No movable. Weight : #{tree.weight.to_s()}".blue());
        end
    end


    class Stone 
        def Stone.description(stone)
            puts("A stone. Movable. Weight : #{stone.weight.to_s()}".blue());
        end
    end


    class Fruit
        def Fruit.description(fruit)
            puts("A fruit. Movable. Weight : #{fruit.weight.to_s()}".blue());
        end
    end


    class Board
        def Board.description(board)
            if (board.items.empty?()) then
                puts("No item.");
            else
                board.items.each do |item|
                    case item
                        when Model::Tree
                            View::Tree.description(item);
                        when Model::Stone
                            View::Stone.description(item);
                        when Model::Fruit
                            View::Fruit.description(item);
                        else
                            View::Item.description(item);
                    end
                end
            end

            if (board.enemies.empty?()) then
                puts("No enemy.");
            else
                board.enemies.each do |enemy|
                    Enemy.description(enemy);
                end
            end
        end
    end
end
