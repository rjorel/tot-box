
require_relative "../model/utils"
require_relative "display"

module View
    class Interface
        def Interface.hud(player, board)
            puts("------------------");
            View::Player.description(player);
            puts("------------------");
            View::Board.description(board);
            puts("------------------");
        end


        def Interface.menu()
            puts("Actions :");
            puts("\ta.  attack");
            puts("\tp.  pick up an object");
            puts("\tu.  use an object");
            puts("\tml. move left");
            puts("\tmr. move down");
            puts("\tmu. move up");
            puts("\tmd. move down");
            puts("\tq.  Quit");
        end
   

        def Interface.position(player, x = Bound.new(0, 2), y = Bound.new(0, 2))
            y.min.upto(y.max).each do |i|
                x.min.upto(x.max).each do |j|
                    printf("%s ", (i == player.coords.y && j == player.coords.x) ? "x" : "o");
                end
                puts("");
            end
        end


        def Interface.battleMenu()
            puts("Actions :")
            puts("\t1. Simple shot");
            puts("\t2. Punishment");
            puts("\t3. Multiple shot");
            puts("\t4. Healing");
            puts("\t5. Flight life");
            puts("\t6. Poisoning");
            puts("\t7. Strength");
            puts("\t8. Paralysis");
            puts("\t9. Reduction");
            puts("\t0. Escape");
        end
    end
end
