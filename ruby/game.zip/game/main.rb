#!/usr/bin/env ruby

require_relative "lib/game"

g = Game.new(10, 2);
g.play();
