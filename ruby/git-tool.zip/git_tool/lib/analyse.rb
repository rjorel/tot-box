
require "rugged"
require "mongo"

require_relative "database"


class Analyse
    def initialize(name, repo)
        @mongo = Database.new();
        @name = name;
        @repo = repo;
    end

    def run()
        col = @mongo.db['angular'];
        walker = Rugged::Walker.new(@repo)
        walker.sorting(Rugged::SORT_TOPO | Rugged::SORT_REVERSE)
        walker.push(@repo.head.target)
        
        old_tree = nil;
        angular = false;
        numCommitAngular = -1;
        totCommit = 0;

        walker.each_with_index() do |commit, index|
            tree = commit.tree();

            if (numCommitAngular == -1)
                tree.diff(old_tree, {:reverse => true}).each_line() do |line|
                    if (line.addition?() && line.content =~ /angular/) then
                        numCommitAngular = index;
                        break;
                    end 
                end
            end

            old_tree = tree;
            totCommit += 1;
        end
        
        puts("#{@name['url']} -> #{numCommitAngular} / #{totCommit}");
        col.insert_one({
            'repo' => @name['folder'],
            'angular' => (numCommitAngular >= 0 && numCommitAngular <= 50) ? true : false,
            'commit' => numCommitAngular
        });
    end
end
