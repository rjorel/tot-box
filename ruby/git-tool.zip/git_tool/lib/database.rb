
require "mongo"
require_relative "utils"


class Database
    attr_reader :db

    def initialize()
        Mongo::Logger.logger.level = ::Logger::FATAL
		@db = Mongo::Client.new(['127.0.0.1:27017'], :database => "internship");
    end

    def view()
        @db['angular'].find().each() do |entry| 
            puts entry.inspect();
        end
    end

    def stat()
        total = 0;
        numTrue = 0;
        @db['angular'].find.each() do |entry|
            if (entry['angular']) then
                numTrue += 1;
            end
            
            total += 1;
        end

        puts("Angular is present from the beginning in #{numTrue} / #{total} projects (#{numTrue / Float(total) * 100} %)"); 
    end

    def clean()
        @db['angular'].find().delete_many();
    end

    def export(args)
        return if (Utils.argsEmpty?(args));
        
        file = File.open(args[0], "w");
        @db['angular'].find().each() do |entry| 
            file.write(entry['repo'] + "," + entry['angular'].to_s() + "," + entry['commit'].to_s() + "\n");
        end
        
        file.close();
    end
end
