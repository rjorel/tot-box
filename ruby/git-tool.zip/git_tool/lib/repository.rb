
require "rugged"
require "mongo"

require_relative "utils"
require_relative "analyse"


class Repository
    def Repository.clone()
        return if (!Utils.confExists?());
        json = Utils.parseConf();

        json['repo'].each() do |repo|
            begin
                Rugged::Repository::clone_at(repo['url'], json['dir'] + "/" + repo['folder'], {
                    transfer_progress: lambda { |total_objects, indexed_objects, received_objects, local_objects, total_deltas, indexed_deltas, received_bytes|
                        msg = "Clone of #{repo['url']} in progress : #{received_objects}/#{total_objects} objects received.\r";
                        $stderr.print(msg);
    	            }
                });
                
                puts("");
            rescue => e
                puts(e);
            end
        end
        
    end

    
    def Repository.analyse()
        return if (!Utils.confExists?());
        json = Utils.parseConf();

        json['repo'].each() do |repo|
            begin
                a = Analyse.new(repo, Rugged::Repository.new(json['dir'] + "/" + repo['folder']));
                a.run();
            rescue => e
                puts(e);
            end
        end
    end
end
