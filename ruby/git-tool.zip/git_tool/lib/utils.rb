
require "json" 


class Utils
    @@conf = ".conf.json"


    # Basics function to read the configuration file, and parse JSON file.

    def Utils.confExists?()
        if (!File.exists?(@@conf)) then
            puts("No configuration file");
            return false;
        end

        return true;
    end

    def Utils.argsEmpty?(args)
        if (args.empty?()) then
            puts("Empty argument");
            return true;
        end

        return false;
    end

    def Utils.parseConf()
        content = File.read(@@conf);
        return JSON.parse(content);
    end

    def Utils.writeConf(json)
        conf = File.open(@@conf, "w");
        conf.write(JSON.pretty_generate(json));
        conf.close();
    end

    def Utils.readFile(filename)
        if (!File.exists?(filename)) then
            puts("'#{filename}' doesn't exist");
            return [];
        end
        
        if (File.directory?(filename)) then
            puts("'#{filename}' is a directory");
            return [];
        end

        return File.readlines(filename);
    end


    # Function for the actions of the user.

    def Utils.init(args)
        if (!File.exists?(@@conf)) then
            Utils.writeConf({"dir" => "", "repo" => []});
        end
    end

    def Utils.destroy(args)
        File.unlink(@@conf);
    end

    def Utils.dir(args)
        return if (!Utils.confExists?() || Utils.argsEmpty?(args));
        json = Utils.parseConf();
        
        json['dir'] = args[0];
        Utils.writeConf(json);
    end

    def Utils.add(args)
        return if (!Utils.confExists?() || Utils.argsEmpty?(args));
        
        if (args[0] == "--file") then
            args.shift();
            Utils.add(Utils.readFile(args[0]));
        else
            json = Utils.parseConf();
            args.each() do |url|
                url = url.chomp();
                json['repo'].delete("url" => url, "folder" => url.gsub(/[:.\/]/, "_"));
                json['repo'].push({"url" => url, "folder" => url.gsub(/[:.\/]/, "_")});
            end
            
            Utils.writeConf(json);
        end
    end

    def Utils.remove(args)
        return if (!Utils.confExists?() || Utils.argsEmpty?(args));
        json = Utils.parseConf();
        
        if (args[0] == "--file") then
            args.shift();
            Utils.remove(Utils.readFile(args[0]));
        else
            json = Utils.parseConf();
            args.each() do |url|
                url = url.chomp();
                json['repo'].delete("url" => url, "folder" => url.gsub(/[:.\/]/, "_"));
            end
            
            Utils.writeConf(json);
        end
    end
end
