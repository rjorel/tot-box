use std::collections::HashMap;
use std::fs::File;
use std::io::{self, ErrorKind, Read};

use example::build_user;
use example::IpAddr;
use example::Point;
use example::Rectangle;
use example::Shape;
use example::User;

extern "C" {
    fn abs(value: i32) -> u32;
}

fn main() {
    // Loop.
    for i in 1..3 {
        println!("{}", i);
    }

    // Basic function call.
    println!("{}", five());

    // Ownership principle.
    let s1 = String::from("hello");
    let s2 = s1; // Take ownership.
    println!("{}, world!", s2); // Can not use `s1` here, because value has been moved to `s2`.

    // References.
    let s = String::from("Hello world!");

    println!("First word: {}", first_word(&s));
    println!("Length: {}", calculate_length(&s));

    // Simple struct.
    let user1 = build_user(
        "John Doe".to_string(),
        "john.doe@example.com".to_string(),
    );

    let user2 = User {
        username: "Foo Bar".to_string(),
        email: "foo.bar@example.com".to_string(),
        ..user1 // Copy other values that are not references.
    };

    println!("Users: {:?}, {:?}", user1, user2);

    /* Tuple struct. */
    let p = Point(0, 2, 1);
    println!("{} {} {}", p.0, p.1, p.2);

    /* Struct with methods. */
    let rect1 = Rectangle {
        width: 30,
        height: 50,
    };

    let rect2 = Rectangle::square(20);

    println!("rect1 is {:?}", rect1);
    println!("rect1 is {:#?}", rect2);  // Pretty print debug.
    println!("rect1 area is {} - {}", rect1.area(), rect1.can_hold(&rect2));

    /* Enums. */
    let home = IpAddr::V4(String::from("127.0.0.1"));
    let loopback = IpAddr::V6(String::from("::1"));

    println!("{:?}, {:?}", home, loopback);

    match loopback {
        IpAddr::V6(address) => println!("Address: {}", address),
        _ => println!("No address"),
    }

    /* Options and pattern matching. */
    let x = 5;
    let y: Option<i8> = Some(5);

    let sum = x + match y {
        None => 0,
        Some(value) => value,
    };

    println!("Sum: {}", sum);

    let three = Some(3);

    if let Some(value) = three {
        println!("Value: {}", value);
    }

    if Some(3) == three {
        println!("three");
    }

    /* Vectors. */
    let v1 = vec![1, 3, 2];
    println!("Third value: {}", v1[2]);

    match v1.get(2) {
        Some(value) => println!("Element is {}", value),
        None => println!("There is no element."),
    }

    match v1.get(20) {
        Some(value) => println!("Element is {}", value),
        None => println!("There is no element."),
    }

    let mut v2 = vec![15, 12, 42];
    for i in &mut v2 {
        *i += 10;
    }

    println!("Vector: {:?}", v2);

    /* UTF-8 strings. */
    let hello = "Здравствуйте";

    println!("String length: {}", hello.len());
    println!("String bytes: {:?}", hello.as_bytes());

    for (i, c) in hello.chars().enumerate() {
        println!("hello[{}]: {}", i, c);
    }

    /* Hashmaps. */
    let mut scores = HashMap::new();
    let first_key = "blue".to_string();
    let second_key = "yellow".to_string();

    scores.insert(&first_key, 10);
    scores.insert(&second_key, 50);  // `first_key` and `second_key` are invalid after that.

    println!("Scores: {:?}", scores);
    println!("Blue: {:?}", scores.get(&"blue".to_string()));
    println!("Yellow: {:?}", scores.get(&"yellow".to_string()));

    for (key, value) in &scores {
        println!("{}: {}", key, value);
    }

    /* Error handling. */
    File::open("hello.txt").unwrap_or_else(|error| {
        if error.kind() == ErrorKind::NotFound {
            File::create("hello.txt").unwrap_or_else(|error| {
                panic!("Problem creating the file: {:?}", error);
            })
        } else {
            panic!("Problem opening the file: {:?}", error);
        }
    });

    let content = read_file("Cargo.lock").expect("Panic!");
    println!("Content file: {}", content);

    /* Generic. */
    println!("Largest int: {}", largest(&vec![1, 2, 3]));
    println!("Largest float: {}", largest(&vec![1.2, 1.1, 1.0]));

    /* Lifetimes. */
    println!("Longest: {}", longest("abc", "test"));
    
    /* Extern functions (ABI). */
    unsafe {
        println!("Abs: {}", abs(-3));
    }
}

fn five() -> i32 {
    5 // Last expression without ';' means "returns this value";
}

fn first_word(s: &str) -> &str {
    let bytes = s.as_bytes();

    for (i, &item) in bytes.iter().enumerate() {
        if item == b' ' {
            return &s[..i];
        }
    }

    return &s[..];
}

fn calculate_length(s: &str) -> usize {
    return s.len();
}

fn read_file(filepath: &str) -> Result<String, io::Error> {
    let mut s = String::new();

    File::open(filepath)?.read_to_string(&mut s)?; // `?` propagates result error if happens.

    return Ok(s);
}

fn largest<T>(list: &[T]) -> T where T: PartialOrd + Copy {
    let mut largest = list[0];

    for &item in list {
        if item > largest {
            largest = item;
        }
    }

    return largest;
}

fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() > y.len() {
        x
    } else {
        y
    }
}
