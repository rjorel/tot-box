use std::env::{self, Args};
use std::fs;
use std::io::Error as IoError;

pub struct Config {
    pub query: String,
    pub filename: String,
    pub case_sensitive: bool,
}

impl Config {
    pub fn new(mut args: Args) -> Result<Config, &'static str> {
        args.next(); // Skip executable name.

        let query = match args.next() {
            Some(arg) => arg,
            None => return Err("Didn't get a query string"),
        };

        let filename = match args.next() {
            Some(arg) => arg,
            None => return Err("Didn't get a file name"),
        };

        let case_sensitive = env::var("CASE_INSENSITIVE").is_err();

        return Ok(Config { query, filename, case_sensitive });
    }
}

pub fn run(config: &Config) -> Result<(), IoError> {
    let content = fs::read_to_string(&config.filename)?;

    let results = if config.case_sensitive {
        search(&config.query, &content)
    } else {
        search_case_insensitive(&config.query, &content)
    };

    for line in results {
        println!("{}", line);
    }

    return Ok(());
}

fn search<'a>(query: &'a str, content: &'a str) -> std::vec::Vec<&'a str> {
    return content
        .lines()
        .filter(|line| {
            return line.contains(query);
        })
        .collect();
}

pub fn search_case_insensitive<'a>(query: &str, content: &'a str) -> Vec<&'a str> {
    let query = query.to_lowercase();

    return content
        .lines()
        .filter(|line| {
            return line.to_lowercase().contains(&query);
        })
        .collect();
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn get_one_result() {
        let query = "duct";
        let content = "\
Rust:
safe, fast, productive.
Pick three.";

        assert_eq!(vec!["safe, fast, productive."], search(query, content));
    }

    #[test]
    fn check_case_insensitive() {
        let query = "rUsT";
        let content = "\
Rust:
safe, fast, productive.
Pick three.
Trust me.";

        assert_eq!(vec!["Rust:", "Trust me."], search_case_insensitive(query, content));
    }
}